# xhs-mcp（Netlify 版）—— 让 ai-virtual-phone 的 AI 真实刷小红书

**新手上手请看：`小红书接入教程.html`（用浏览器打开，一步一步带截图式说明）。**
本文件是给之后维护用的技术说明。

---

## 这是什么

一个跑在你**已有的 Netlify 站点**上的 MCP 服务器，暴露 10 个小红书工具给
ai-virtual-phone 的 AI 角色调用。不需要 Cloudflare、不需要新账号、不需要命令行。

```
AI 角色 → ai-virtual-phone(浏览器) → 你站点/.netlify/functions/xhs-mcp
                                        → 内置签名 → 真实小红书 API
```

## 文件

| 文件 | 作用 |
|---|---|
| `netlify/functions/xhs-mcp.mjs` | **唯一需要部署的文件**。约 2400 行，约 100 KB |
| `小红书接入教程.html` | 零基础图文教程 |
| `来源与许可.md` | **转发给别人时必须一并附上**。第三方代码的来源、许可证、署名要求 |
| `selftest.mjs` | 本地自测（67 项断言，会拦截网络，不会真的打小红书） |
| `preview-diagnostics.mjs` | 离线生成两份体检页预览，用来对照实际输出 |
| `体检页预览-*.html` | 体检页长什么样的示例（可直接用浏览器打开） |

`xhs-mcp.mjs` 分两部分：

1. **第 1 部分（约 1500 行）**：从 SullyOS `worker/index.js` 的 `XHSLite` 模块
   原样取出的纯 JS 签名实现（`x-s` / `x-s-common` / `x-t` / `XYS_` 等），
   算法源自 Cloxl/xhshow（MIT）。只依赖 `fetch` / `crypto.subtle` / `TextEncoder`，
   Node 18+ 直接可跑，所以能塞进 Netlify Function。**未做任何修改。**
2. **第 2 部分**：MCP 协议层（JSON-RPC 手写实现，含握手 / tools-list / tools-call /
   结果压缩 / CORS / Bearer 鉴权）。这一层是自主实现。

## 许可（分发前必读）

| 层 | 项目 | 许可证 | 对再分发的要求 |
|---|---|---|---|
| 算法源头 | [Cloxl/xhshow](https://github.com/Cloxl/xhshow)（Python） | **MIT** | 保留版权与许可声明（`Copyright (c) 2024 Cloxl`） |
| JS 实现 | [qegj567-cloud/SullyOS](https://github.com/qegj567-cloud/SullyOS) | **PolyForm Noncommercial 1.0.0** | 附许可证链接 + `Required Notice` 那行；**禁商用** |
| 本文件 | xhs-mcp.mjs 第 2 部分 | 原创 | 可随本文件一起分发 |

**必须原样附带的署名：**

```
Required Notice: Copyright (c) 2024-2026 NMJ (SullyOS / 手抓糯米机)
```

**许可证全文：** <https://polyformproject.org/licenses/noncommercial/1.0.0>

PolyForm Noncommercial 明确授予了分发权（Distribution License）和修改权
（Changes and New Works License），**前提是非商业用途**——所以个人之间的非商业分享
**无需事先取得作者授权**，但必须把许可证和上面那行署名带上。想商用则必须单独联系作者。

> 上游注释自称「已与 Python 原版逐字节比对验证（见 `worker/xhs-lite/test/`）」，
> 这是上游作者的陈述，本项目**未独立复验**，仅作来源转述。

详见 `来源与许可.md`。

## 部署

1. 在仓库里新建 `netlify/functions/xhs-mcp.mjs`，粘贴文件内容
2. Netlify → Site configuration → Environment variables：
   - `XHS_COOKIE` = 小红书完整 cookie（必须含 `a1=` 和 `web_session=`）
   - `MCP_KEY`（可选）= 任意密码，设了就要求 `Authorization: Bearer <密码>`
3. 触发部署
4. 浏览器打开 `https://<站点>/.netlify/functions/xhs-mcp`，应看到
   `{"status":"ok","tools":10,"cookie_configured":true,...}`
5. ai-virtual-phone → 设置 → 工具箱 → MCP Servers → 添加新MCP工具
   - 服务器 URL：上面的地址
   - **直连模式：保持打开**（见下方「站点门禁」）
   - 访问 Token：填 `MCP_KEY`（如果设了）
   - 点「发现工具」→ 创建 → **记得打开列表里的开关**

## 体检页（`?check=1`）

出问题时**先来这里**，不用 F12、不用控制台、手机也能看：

```
https://<站点>/.netlify/functions/xhs-mcp?check=1
```

它会真的去问一次小红书「我是谁」，然后用大白话给出结论 + 下一步。页面会报告：

- cookie 配没配、多少字符、有几个字段
- 有没有 `a1=` / `web_session=`，缺哪些关键字段
- 是否疑似被截断、是否误带了 `Cookie: ` 前缀、是否被引号包住、是否含换行
- 小红书的原始回包（`code` / `success` / `msg`）
- 登录态结论与修改建议

设了 `MCP_KEY` 时，网址末尾要追加 `&key=<MCP_KEY>`。
要机读格式（给脚本用）就加 `&format=json`。

**安全**：体检页只报告 cookie 的**长度与字段名**，永不回显 cookie 的值——
`selftest.mjs` 第 9 组里有专门的断言守着这一点。

## 站点门禁：为什么必须开「直连模式」

如果 Netlify 站点可见性不是 Public（Project configuration → General →
Visitor access → Project visibility，或在 Access & security → Password Protection），
那么**整站**（首页、favicon、静态 json、以及这个函数）都会对没有登录凭证的请求
返回 `401 Login Redirect`。实测过：`/favicon.ico`、`/countries.geo.json` 这种纯静态文件
一样被拦，说明拦截发生在边沿层，与应用自身的 `middleware.ts` 无关
（后者在 matcher 里排除了 `.ico` / `.json` 等扩展名）。

后果：

| 用法 | 结果 |
|---|---|
| ai-virtual-phone **直连模式打开** | 请求由**你的浏览器**发出，带着登录凭证 → 放行 → 正常 |
| ai-virtual-phone 直连模式**关闭** | 改由 `/api/tool-proxy` 服务端转发，没有凭证 → 401 |
| reqbin / curl 等外部工具 | 同样 401，永远进不来 |

所以：**站点是私有的话，直连模式必须保持打开。**
若想用服务端转发或外部工具调试，只能把站点改成 Public——但**先设 `MCP_KEY`**，
否则函数等于裸奔（10 个工具里有发帖和评论）。

## 环境变量改了要重新部署

Netlify 的环境变量不会自动生效。每次改 `XHS_COOKIE` 或 `MCP_KEY` 后，
都要 Deploys → Trigger deploy → Deploy site。

## 工具清单

| 工具 | 说明 |
|---|---|
| `xhs_check_login` | 检查登录态，返回账号昵称 |
| `xhs_search` | 关键词搜索笔记 |
| `xhs_list_feeds` | 首页推荐流 |
| `xhs_get_feed_detail` | 笔记正文 + 评论 |
| `xhs_post_comment` | 发表评论 |
| `xhs_reply_comment` | 回复评论 |
| `xhs_like_feed` | 点赞 / 取消点赞 |
| `xhs_favorite_feed` | 收藏 / 取消收藏 |
| `xhs_user_profile` | 用户主页与 TA 的笔记 |
| `xhs_publish` | 发布图文笔记 |

## 几个容易踩的坑

- **URL 不能以 `/sse` 结尾**。客户端靠后缀判断传输方式，`/sse` 会被当成旧版
  双端点协议，那套流程本实现没有。
- **单次工具结果被客户端截到 2000 字符**（`lib/tool-executor.ts` 里的
  `MAX_RESULT_LENGTH`）。所以服务端主动把搜索压到 6~8 条、正文压到 700 字。
- **`xsec_token` 是关键**。每条笔记一个、会过期，没有它取不到评论也发不了评论。
  所以它被直接塞进了搜索 / 首页 / 主页的返回里，方便模型传给下一步。
- **新建的 MCP 服务器默认 `enabled: false`**，必须在列表里手动打开开关。
- **MCP 工具只在前台聊天可用**。离线回复 / 定时消息跑在 Supabase Edge Functions
  (`supabase/functions/push-generate`)，那条链路没有工具执行器。
- **项目自带的 `lib/xiaohongshu-engine.ts` 是模拟小红书**（角色扮演用），
  与真实小红书无关，两套互不相通。

## 常见的「小红书不认 cookie」长什么样

```
{"code":-101,"success":false,"msg":"无登录信息，或登录信息为空"}
```

这是小红书 `/api/sns/web/v2/user/me` 的标准未登录回包。看到它说明请求**已经打到了小红书**
（即网络、签名、域名都通），只是这串 cookie 没有被认可。按可能性排序：

| 可能 | 怎么看出来 |
|---|---|
| cookie 里没有 `web_session=` | 体检页「含 web_session=」为「否」 |
| 复制到了登录之前的旧请求 | 同上（登录前的请求只有 `a1`/`gid` 这类设备字段） |
| cookie 已过期 | 体检页关键字段齐全但登录态仍无效 |
| 粘贴被截断 | 体检页「疑似被截断」为「是」（正常一千多字符） |
| 误带了 `Cookie: ` 前缀 / 首尾引号 / 折行 | 体检页对应行会点名 |

注意：`resolveCookie()` 会先检查有没有 `a1=`，没有就直接抛出配置提示。
所以**能看到 `-101` 这条回包，说明 `a1=` 是存在的**——问题出在会话字段，不是复制长度为零。

### 真机实测记录（2026-09-12，实际部署站点）

体检页 v1.2.0 在真机跑通，输出的结论就是上面第一行，且**精确定位到了字段**：

```
XHS_COOKIE          已配置，741 字符
cookie 字段数        15
含 a1=              是
含 web_session=      否        ← 病根
缺失的关键字段        web_session
疑似被截断           否
开头带 Cookie: 前缀   否
被引号包住           否
值含换行             否
最后试过的接口        webapi.rednote.com
小红书返回的原始内容   {"code":-101,"success":false,"msg":"无登录信息，或登录信息为空","data":{}}
```

**741 字符 / 15 个字段 / 有 `a1=` / 无 `web_session=`** = 教科书式的「未登录访客 cookie」。
即：用户复制的是一份**登录之前**的请求头（或在网页版其实没登录成功）。
这也反证了体检页的字段检测是有效的——它把「长度看着挺正常」和「字段不对」区分开了。

**据此确定的取 cookie 正确姿势**（已写进教程第 2 步）：

1. 网页版右上角必须是**头像**，不是「登录」按钮。手机 App 登录 ≠ 网页版登录，必须单独登一次。
2. 扫码后**必须在手机上点「确认登录」**，否则二维码不变绿，cookie 里不会有 `web_session`。
3. 筛选框搜 **`user/me`**（专门查「我是谁」的接口，比 `homefeed` 更能保证是登录后请求）。
4. 有几条时点**最上面（最新）**那条，别点到刷新前的旧记录。
5. 复制后先在记事本里 `Ctrl+F` 搜到 `web_session=` 再往下走；正常长度一千多字符。

## 本地自测

```
node selftest.mjs
```

会把 `globalThis.fetch` 换掉，所以**不会**真的请求小红书。
覆盖（67 项断言）：探活 / CORS / 握手 / 工具清单 / 无 cookie 报错 / 未知工具 /
非法 JSON / 通知 / MCP_KEY 鉴权 / 批量请求 / 签名头是否真的生成
（`x-s`、`x-t`、`x-s-common`）/ **体检页的四种结论与「不回显 cookie 值」**。

体检页的视觉预览可以离线生成：

```
node preview-diagnostics.mjs
```

## 已知未验证

- 只做过拦截网络的本地自测，**没有在真实 Netlify + 真实 cookie 上端到端跑过**。
- 上游响应结构（`{feeds:[]}`、`{data:{note,comments}}`）来自对 SullyOS 源码的推断，
  渲染层做了多形状兜底（`pickNotes` 等），但真机跑通后建议核对一遍。
- 体检页里的「下一步建议」文案是按小红书常见的几种失败形态写的，真机上遇到
  没预料到的回包时，`&format=json` 里的 `raw` 字段会保留原始响应，便于补文案。

/* Apply before first paint; no dependency on the host bridge. */
(() => {
  "use strict";
  const key = "fis.collect.appearance";
  const modes = ["auto", "dark", "light"];
  const media = window.matchMedia ? window.matchMedia("(prefers-color-scheme: dark)") : null;
  let mode = "auto";
  try { const saved = localStorage.getItem(key); if (modes.includes(saved)) mode = saved; } catch {}
  function apply() {
    const dark = mode === "dark" || (mode === "auto" && media?.matches);
    document.documentElement.dataset.theme = dark ? "dark" : "light";
    document.documentElement.style.colorScheme = dark ? "dark" : "light";
    document.querySelector('meta[name="theme-color"]')?.setAttribute("content", dark ? "#141416" : "#ffffff");
  }
  window.CollectTheme = {
    get mode() { return mode; },
    set(value) {
      if (!modes.includes(value)) return;
      mode = value;
      try { localStorage.setItem(key,mode); } catch {}
      apply();
    },
    cycle() { this.set(modes[(modes.indexOf(mode) + 1) % modes.length]); }
  };
  if (media?.addEventListener) media.addEventListener("change",apply);
  else if (media?.addListener) media.addListener(apply);
  apply();
})();

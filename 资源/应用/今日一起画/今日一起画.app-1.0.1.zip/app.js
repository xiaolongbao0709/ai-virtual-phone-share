(()=>{
  'use strict';
  const sdk=()=>window.AiPhone||window.AiPhoneApp;
  const $=id=>document.getElementById(id);
  const COLORS=['#25323e','#df524b','#ef9f39','#f0ca45','#55a36a','#4c7fc4','#7866aa','#e984a3'];
  const PROMPTS=[
    '画你今天吃过、或最想吃的一样东西','画一种只有我们知道的天气','画对方此刻可能正在做的事','画一间想和对方住一晚的小屋','画今天最像你的一个物件','画一只代表今天心情的小动物','画我们下一次见面时的第一幕','画一份只给对方看的秘密地图','画你想递给对方的一束奇怪的花','画窗外没有发生、但你希望发生的事','画一艘会把我们带去某处的船','画你想和对方分享的一杯饮料','画一个属于我们的路标','画对方如果变成天气会是什么样','画你今天差点忘记的小瞬间','画一颗不按照常理生长的树','画旅行途中最想寄出的明信片','画一个可以装下坏心情的容器','画醒来后最想看到的风景','画一盏只在等人时亮起的灯','画我们在陌生城市会一起寻找的东西','画今天的声音长什么样','画一扇推开后会抵达好地方的门','画你认为幸福最小的形状','画一份没有文字的晚安','画对方会喜欢的一件小礼物','画一个绝不会迷路的星座','画我们共同养的一只幻想生物','画你今天想藏起来的一种颜色','画一顿发生在世界尽头的早餐','画一把只为对方撑开的伞','画我们在月球上的临时住处','画一种能够被收藏的风','画一个没有时间的车站','画今天让你嘴角动了一下的东西','画你想带对方走过的一段路','画一座由零食组成的城市','画一件看起来没用但很温柔的发明','画对方睡着以后做的梦','画一张通往明天的车票'
  ];
  const views=['homeView','drawView','waitingView','revealView','galleryView'];
  const canvas=$('userCanvas'),ctx=canvas.getContext('2d',{willReadFrequently:true});
  const roleCanvas=$('roleCanvas'),roleCtx=roleCanvas.getContext('2d');
  const state={characters:[],rounds:[],launch:null,selected:null,current:null,retry:null,color:COLORS[0],width:11,eraser:false,drawing:false,history:[],busy:false};

  function toast(text){try{sdk().ui.toast(text)}catch(_){}}
  function showView(id){views.forEach(v=>$(v).classList.toggle('active',v===id));window.scrollTo(0,0)}
  function localDateKey(date=new Date()){const y=date.getFullYear(),m=String(date.getMonth()+1).padStart(2,'0'),d=String(date.getDate()).padStart(2,'0');return `${y}-${m}-${d}`}
  function hash(text){let h=2166136261;for(let i=0;i<text.length;i++){h^=text.charCodeAt(i);h=Math.imul(h,16777619)}return h>>>0}
  function promptFor(dateKey){return PROMPTS[hash('today-draw:'+dateKey)%PROMPTS.length]}
  function promptNumber(dateKey){const origin=new Date('2026-01-01T00:00:00'),now=new Date(dateKey+'T00:00:00');return Math.max(1,Math.floor((now-origin)/86400000)+1)}
  function prettyDate(dateKey=localDateKey()){const d=new Date(dateKey+'T00:00:00');return `${d.getMonth()+1}月${d.getDate()}日 · ${['星期日','星期一','星期二','星期三','星期四','星期五','星期六'][d.getDay()]}`}
  function escapeHtml(s){return String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]))}
  function selectedCharacter(){return state.characters.find(c=>String(c.id)===String($('characterSelect').value))||state.characters[0]||null}
  function normalizeList(v){return Array.isArray(v)?v:Array.isArray(v?.items)?v.items:[]}

  function whiteCanvas(){ctx.save();ctx.fillStyle='#fff';ctx.fillRect(0,0,canvas.width,canvas.height);ctx.restore()}
  function point(ev){const r=canvas.getBoundingClientRect();return{x:(ev.clientX-r.left)*canvas.width/r.width,y:(ev.clientY-r.top)*canvas.height/r.height}}
  function snapshot(){if(state.history.length>=16)state.history.shift();state.history.push(ctx.getImageData(0,0,canvas.width,canvas.height))}
  function startStroke(ev){ev.preventDefault();snapshot();state.drawing=true;const p=point(ev);ctx.beginPath();ctx.moveTo(p.x,p.y);canvas.setPointerCapture?.(ev.pointerId)}
  function moveStroke(ev){if(!state.drawing)return;ev.preventDefault();const p=point(ev);ctx.lineWidth=state.width;ctx.lineCap='round';ctx.lineJoin='round';ctx.strokeStyle=state.eraser?'#fff':state.color;ctx.lineTo(p.x,p.y);ctx.stroke()}
  function endStroke(){state.drawing=false;ctx.closePath()}
  function renderPalette(){$('palette').innerHTML=COLORS.map(c=>`<button class="color${c===state.color&&!state.eraser?' active':''}" data-color="${c}" style="background:${c}"></button>`).join('');[...$('palette').children].forEach(b=>b.onclick=()=>{state.color=b.dataset.color;state.eraser=false;$('eraserBtn').classList.remove('active');renderPalette()})}
  function userImage(){return canvas.toDataURL('image/jpeg',.86)}
  function hasDrawing(){const data=ctx.getImageData(0,0,canvas.width,canvas.height).data;let colored=0;for(let i=0;i<data.length;i+=32){if(data[i]<245||data[i+1]<245||data[i+2]<245){colored++;if(colored>80)return true}}return false}

  function cleanColor(v,fallback='#40505a'){const s=String(v||'');return /^#[0-9a-f]{3,8}$/i.test(s)?s:fallback}
  function num(v,min,max,f=0){const n=Number(v);return Number.isFinite(n)?Math.max(min,Math.min(max,n)):f}
  function normalizeDrawing(raw){
    const d=raw&&typeof raw==='object'?raw:{};const elements=Array.isArray(d.elements)?d.elements:[];
    return{background:cleanColor(d.background,'#fffdf8'),elements:elements.slice(0,120).map(e=>{
      const type=['path','line','circle','rect','ellipse'].includes(e?.type)?e.type:'path';
      const base={type,color:cleanColor(e.color),fill:e.fill&&e.fill!=='none'?cleanColor(e.fill,'#ffffff'):null,width:num(e.width,1,10,2.4)};
      if(type==='path')base.points=(Array.isArray(e.points)?e.points:[]).slice(0,160).map(p=>[num(p?.[0],0,100),num(p?.[1],0,100)]);
      if(type==='line'){base.x1=num(e.x1,0,100);base.y1=num(e.y1,0,100);base.x2=num(e.x2,0,100);base.y2=num(e.y2,0,100)}
      if(type==='circle'){base.x=num(e.x,0,100);base.y=num(e.y,0,100);base.r=num(e.r,1,50,10)}
      if(type==='rect'){base.x=num(e.x,0,100);base.y=num(e.y,0,100);base.w=num(e.w,1,100,20);base.h=num(e.h,1,100,20);base.radius=num(e.radius,0,20,0)}
      if(type==='ellipse'){base.x=num(e.x,0,100);base.y=num(e.y,0,100);base.rx=num(e.rx,1,50,10);base.ry=num(e.ry,1,50,8)}
      return base
    }).filter(e=>e.type!=='path'||e.points.length>1)}
  }
  function drawVector(target,drawing){
    const c=target.getContext('2d'),s=target.width/100;c.save();c.fillStyle=drawing.background||'#fffdf8';c.fillRect(0,0,target.width,target.height);c.lineCap='round';c.lineJoin='round';
    drawing.elements.forEach(e=>{c.beginPath();c.strokeStyle=e.color;c.lineWidth=e.width*s;c.fillStyle=e.fill||'transparent';
      if(e.type==='path'){c.moveTo(e.points[0][0]*s,e.points[0][1]*s);e.points.slice(1).forEach(p=>c.lineTo(p[0]*s,p[1]*s))}
      if(e.type==='line'){c.moveTo(e.x1*s,e.y1*s);c.lineTo(e.x2*s,e.y2*s)}
      if(e.type==='circle')c.arc(e.x*s,e.y*s,e.r*s,0,Math.PI*2);
      if(e.type==='ellipse')c.ellipse(e.x*s,e.y*s,e.rx*s,e.ry*s,0,0,Math.PI*2);
      if(e.type==='rect'){const x=e.x*s,y=e.y*s,w=e.w*s,h=e.h*s,r=Math.min(e.radius*s,w/2,h/2);c.moveTo(x+r,y);c.arcTo(x+w,y,x+w,y+h,r);c.arcTo(x+w,y+h,x,y+h,r);c.arcTo(x,y+h,x,y,r);c.arcTo(x,y,x+w,y,r);c.closePath()}
      if(e.fill)c.fill();c.stroke()
    });c.restore()
  }
  function parseJson(text){let s=String(text||'').trim().replace(/^```(?:json)?\s*/i,'').replace(/\s*```$/,'');const a=s.indexOf('{'),b=s.lastIndexOf('}');if(a<0||b<a)throw new Error('角色没有返回可读取的画稿 JSON。');s=s.slice(a,b+1);return JSON.parse(s)}
  function priorDrawingMemories(characterId){const old=state.rounds.filter(r=>String(r.characterId)===String(characterId)).slice(0,8);return old.length?`\n\n你们以前在这个应用里完成过这些画（只用于保持共同经历，不要复刻旧画）：\n${old.map(r=>`- ${r.dateKey}，题目“${r.prompt}”：用户画了${r.guess||'一幅画'}；你画了${r.roleAnswer||r.roleCaption}`).join('\n')}`:''}
  async function callDrawModel(character,prompt){
    const instruction=`今天的双人绘画题目是：“${prompt}”。你和用户必须独立作画；此刻你还没有看到用户的画。请以当前角色的性格和经历决定自己会画什么，并把画转换为下面的 JSON 协议。只输出 JSON，不要 Markdown，不要解释。\n\n坐标范围均为 0 到 100。elements 可用：\n- path: {"type":"path","color":"#十六进制","width":1-10,"points":[[x,y],...]}\n- line: {"type":"line","color":"#...","width":数字,"x1":0,"y1":0,"x2":0,"y2":0}\n- circle: {"type":"circle","color":"#...","fill":"#...或none","width":数字,"x":0,"y":0,"r":0}\n- ellipse: 同 circle，但使用 rx、ry\n- rect: 使用 x、y、w、h、radius。\n\n请画成有辨识度但保留随手涂鸦感的作品，使用 12-40 个元素，每条 path 最多 12 个点，整个 JSON 尽量控制在 9000 字符内，不允许文字。最终结构必须为：{"caption":"你给自己这幅画的一句题注","answer":"你画的具体内容","drawing":{"background":"#fffdf8","elements":[]}}${priorDrawingMemories(character.id)}`;
    const result=await sdk().ai.generate({characterId:character.id,appTags:['daily-drawing','partner-draw'],instruction});
    const raw=result?.text||result?.content||String(result||'');
    try{return{data:parseJson(raw),raw}}
    catch(firstError){
      const fix=await sdk().ai.generate({characterId:character.id,appTags:['daily-drawing','json-repair'],messages:[{role:'assistant',content:raw,createdAt:new Date().toISOString()}],instruction:'上一次画稿没有成为合法 JSON。保留原意，严格按原题要求修复；只输出一个合法 JSON 对象，不要代码围栏和解释。'});
      const fixed=fix?.text||fix?.content||String(fix||'');return{data:parseJson(fixed),raw:fixed}
    }
  }
  async function callReactionModel(character,prompt,userDataUrl,roleAnswer,roleCaption){
    const messages=[
      {role:'assistant',content:`这是我刚刚独立完成、尚未看用户作品时提交的答案。我的画是：${roleAnswer}。我给它的题注是：${roleCaption}`,createdAt:new Date(Date.now()-1000).toISOString()},
      {role:'user',content:`现在同时揭晓。题目是：“${prompt}”。这是用户刚才独立画出的作品。请真正观察图片再回应；不要依据题目猜图。`,image:userDataUrl,createdAt:new Date().toISOString()}
    ];
    const instruction='你正在和用户玩每日双人绘画。请保持当前角色真实、自然的口吻：先猜用户具体画了什么，再说出对这幅画的个性化反应，最后比较两个人的画有哪些有趣差异或默契。必须只输出合法 JSON：{"guess":"我看见/猜到的具体内容","reaction":"自然回应，1-3句","comparison":"对两幅画的比较，1-2句"}。若确实看不见图片，要坦白，禁止假装。';
    const result=await sdk().ai.generate({characterId:character.id,appTags:['daily-drawing','reveal','vision'],messages,instruction});
    const raw=result?.text||result?.content||String(result||'');
    try{return parseJson(raw)}catch(_){return{guess:'我已经看到你的画了。',reaction:raw,comparison:''}}
  }

  async function createRound(){
    if(state.busy)return;if(!hasDrawing()){toast('画纸还是空的，先画几笔吧');return}const character=selectedCharacter();if(!character){toast('还没有选择角色');return}
    state.busy=true;state.retry=createRound;showView('waitingView');$('waitingStep').textContent='第一步 · TA 正在独立作画';$('waitingTitle').textContent=`${character.name||'TA'} 正在画自己的答案`;$('waitingHint').textContent='这时 TA 还没有看见你的画。';
    const dateKey=localDateKey(),prompt=promptFor(dateKey),dataUrl=userImage();
    try{
      const partner=await callDrawModel(character,prompt);const roleData=partner.data||{};const drawing=normalizeDrawing(roleData.drawing);
      if(!drawing.elements.length)throw new Error('角色返回的画稿里没有有效线条。');
      $('waitingStep').textContent='第二步 · 同时揭晓';$('waitingTitle').textContent='TA 正在认真看你的画';$('waitingHint').textContent='视觉通道已打开，正在交换彼此的答案。';
      const reaction=await callReactionModel(character,prompt,dataUrl,String(roleData.answer||roleData.caption||''),String(roleData.caption||''));
      $('waitingStep').textContent='第三步 · 装订画册';$('waitingTitle').textContent='正在保存今天的两张画';
      const media=await sdk().media.put({dataUrl});
      const payload={dateKey,prompt,characterId:String(character.id),characterName:character.name||'对方',userImageRef:media.ref,roleDrawing:drawing,roleCaption:String(roleData.caption||roleData.answer||'今天的这一张。').slice(0,300),roleAnswer:String(roleData.answer||'').slice(0,300),guess:String(reaction.guess||'').slice(0,500),reaction:String(reaction.reaction||'').slice(0,1200),comparison:String(reaction.comparison||'').slice(0,800),memorySaved:false,shared:false,createdAt:new Date().toISOString()};
      const saved=await sdk().db.create('rounds',payload);state.current={...payload,id:saved?.id||saved?.data?.id};state.rounds.unshift(state.current);await showReveal(state.current,dataUrl);state.retry=null
    }catch(e){showError(e?.message||String(e))}finally{state.busy=false}
  }
  async function mediaData(ref){if(!ref)return'';const res=await sdk().media.get({ref});return res?.dataUrl||''}
  async function showReveal(round,knownDataUrl){
    state.current=round;showView('revealView');$('revealPrompt').textContent=round.prompt;$('revealDate').textContent=prettyDate(round.dateKey);$('roleArtLabel').textContent=`${round.characterName}的画`;$('roleCaption').textContent=round.roleCaption||'';$('letterFrom').textContent=`FROM · ${String(round.characterName||'TA').toUpperCase()}`;$('roleGuess').textContent=round.guess||'';$('roleReaction').textContent=round.reaction||'';$('roleComparison').textContent=round.comparison||'';$('rememberToggle').checked=!round.memorySaved&&!round.shared;$('shareBtn').textContent=round.shared?'已投递到聊天':'投递到聊天';$('shareBtn').disabled=!!round.shared;
    $('userArt').src=knownDataUrl||await mediaData(round.userImageRef);drawVector(roleCanvas,normalizeDrawing(round.roleDrawing));
  }
  function memorySummary(round){return `在“今日一起画”中，${round.characterName}和用户完成了题目“${round.prompt}”。用户画的是：${round.guess||'一幅画'}；${round.characterName}画的是：${round.roleAnswer||round.roleCaption}。${round.characterName}当时的感想：${round.reaction}`.slice(0,1800)}
  async function rememberCurrent(){const r=state.current;if(!r||r.memorySaved||r.shared||!$('rememberToggle').checked)return;await sdk().memory.addTimeline({characterId:r.characterId,appLabel:'今日一起画',detail:'daily_drawing_completed',summary:memorySummary(r),appEventId:`today-draw-${r.id||r.characterId+'-'+r.dateKey}`,data:{roundId:r.id||'',dateKey:r.dateKey,prompt:r.prompt}});r.memorySaved=true;if(r.id)await sdk().db.update('rounds',r.id,{memorySaved:true})}
  async function shareCurrent(){const r=state.current;if(!r||r.shared)return;try{await sdk().chat.sendCard({characterId:r.characterId,role:'user',summary:`完成了今日双人画：${r.prompt}`,historyText:`[今日一起画完成：题目“${r.prompt}”。用户画的是：${r.guess||'一幅画'}；${r.characterName}画的是：${r.roleAnswer||r.roleCaption}。${r.characterName}的感想：${r.reaction}]`,card:{title:'今日一起画',subtitle:`与 ${r.characterName} 的双人画`,body:r.prompt,accentColor:'#709a8e',sections:[{title:'TA 的一句话',body:r.reaction||r.roleCaption}]}});r.shared=true;if(r.id)await sdk().db.update('rounds',r.id,{shared:true});$('shareBtn').textContent='已投递到聊天';$('shareBtn').disabled=true;toast('已经投递到聊天') }catch(e){showError(e?.message||String(e))}}

  function currentForSelection(){const c=selectedCharacter();return c&&state.rounds.find(r=>r.dateKey===localDateKey()&&String(r.characterId)===String(c.id))}
  function computeStreak(){const days=new Set(state.rounds.map(r=>r.dateKey));let count=0,d=new Date();while(days.has(localDateKey(d))){count++;d=new Date(d.getFullYear(),d.getMonth(),d.getDate()-1)}return count}
  function refreshHome(){const key=localDateKey(),p=promptFor(key),n=promptNumber(key);$('prettyDate').textContent=prettyDate(key);$('streak').textContent=`连续 ${computeStreak()} 天`;$('promptNo').textContent=`TODAY · ${String(n).padStart(3,'0')}`;$('todayPrompt').textContent=p;$('drawPrompt').textContent=p;$('totalCount').textContent=state.rounds.length;$('partnerCount').textContent=new Set(state.rounds.map(r=>r.characterId)).size;$('monthCount').textContent=state.rounds.filter(r=>r.dateKey.slice(0,7)===key.slice(0,7)).length;const done=currentForSelection();$('todayDone').classList.toggle('hidden',!done);$('startBtn').classList.toggle('hidden',!!done);if(done)$('donePartner').textContent=`与 ${done.characterName} · ${done.prompt}`}
  async function loadRounds(){try{state.rounds=normalizeList(await sdk().db.list('rounds',{limit:300})).sort((a,b)=>String(b.createdAt||'').localeCompare(String(a.createdAt||'')))}catch(_){state.rounds=[]}}
  async function renderGallery(){showView('galleryView');const list=$('galleryList');list.innerHTML='';$('emptyGallery').classList.toggle('hidden',state.rounds.length>0);for(const r of state.rounds){const item=document.createElement('article');item.className='gallery-item';item.innerHTML=`<div class="gallery-meta"><b>${escapeHtml(r.prompt)}</b><small>${escapeHtml(r.dateKey)} · ${escapeHtml(r.characterName)}</small></div><div class="gallery-thumbs"><img alt="你的画"><canvas width="320" height="320"></canvas></div><div class="gallery-quote">${escapeHtml(r.reaction||r.roleCaption||'')}</div>`;list.appendChild(item);item.querySelector('img').src=await mediaData(r.userImageRef);drawVector(item.querySelector('canvas'),normalizeDrawing(r.roleDrawing));item.onclick=()=>showReveal(r)}}
  function showError(message){$('errorText').textContent=message;$('errorBox').classList.remove('hidden')}
  function hideError(){$('errorBox').classList.add('hidden')}

  function bind(){
    canvas.addEventListener('pointerdown',startStroke);canvas.addEventListener('pointermove',moveStroke);canvas.addEventListener('pointerup',endStroke);canvas.addEventListener('pointercancel',endStroke);
    $('undoBtn').onclick=()=>{const p=state.history.pop();if(p)ctx.putImageData(p,0,0)};$('clearBtn').onclick=()=>{snapshot();whiteCanvas()};
    [...document.querySelectorAll('[data-width]')].forEach(b=>b.onclick=()=>{state.width=Number(b.dataset.width);state.eraser=false;document.querySelectorAll('[data-width]').forEach(x=>x.classList.remove('active'));b.classList.add('active');$('eraserBtn').classList.remove('active');renderPalette()});$('eraserBtn').onclick=()=>{state.eraser=true;$('eraserBtn').classList.add('active');renderPalette()};
    $('characterSelect').onchange=refreshHome;$('startBtn').onclick=()=>{state.selected=selectedCharacter();state.history=[];whiteCanvas();showView('drawView')};$('submitBtn').onclick=createRound;$('openTodayBtn').onclick=()=>{const r=currentForSelection();if(r)showReveal(r)};
    $('homeBtn').onclick=()=>{refreshHome();showView('homeView')};$('galleryBtn').onclick=renderGallery;$('historyBtn').onclick=renderGallery;$('backHomeBtn').onclick=async()=>{try{await rememberCurrent();await loadRounds();refreshHome();showView('homeView');toast('今天的画已经收好')}catch(e){showError(e?.message||String(e))}};$('shareBtn').onclick=shareCurrent;$('retryBtn').onclick=()=>{hideError();const fn=state.retry;if(fn)fn()};$('backHomeBtn').disabled=false;
  }
  async function init(){
    whiteCanvas();renderPalette();bind();$('todayPrompt').textContent='正在翻开今天的画纸……';
    try{state.launch=await sdk().app.getLaunchContext()}catch(_){state.launch={}}
    try{state.characters=normalizeList(await sdk().characters.list())}catch(_){state.characters=[]}
    const sel=$('characterSelect');sel.innerHTML=state.characters.length?state.characters.map(c=>`<option value="${escapeHtml(c.id)}">${escapeHtml(c.name||c.id)}</option>`).join(''):'<option value="">未读取到角色</option>';if(state.launch?.characterId&&state.characters.some(c=>String(c.id)===String(state.launch.characterId)))sel.value=String(state.launch.characterId);
    await loadRounds();refreshHome()
  }
  if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',init);else init();
})();

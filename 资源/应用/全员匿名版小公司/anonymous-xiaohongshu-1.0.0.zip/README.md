# 匿名小红书（Float 可导入 App）

这是一个独立于 Float 内置小红书的导入应用。它不会读取或修改内置小红书的 profile、帖子、评论、`kk` 数据或账号映射。

## 安装

在 Float 的应用市场/本地导入中选择：

```text
anonymous-xiaohongshu-1.0.0.zip
```

首次打开后进入“账号”页：

1. 手动设置当前用户的匿名昵称、简介和默认头像。
2. 为需要参加匿名小红书的每个角色手动设置匿名昵称和默认头像，并启用该账号。
3. 如需平台 NPC，可手动新增固定 NPC 账号。

## 身份模型

- 所有公开作者统一为 `social_account`。
- 帖子、评论、点赞和关系只引用稳定 `accountId`。
- 昵称修改不会修改 `accountId`，历史内容不会丢失。
- 真实 owner 绑定保存在本 App 私有集合 `actor_bindings_private` 中。
- 模型上下文通过白名单重新构造，不会序列化 owner 绑定集合。
- 每次角色生成只调用一个 `characterId`，不使用多角色生成。
- 当前角色只获得自己的 self 映射；其他账号默认是 `unknown`。
- `memory.search` 只搜索当前 viewer 的记忆，且必须命中明确身份陈述；相似线索不会建立揭露关系。
- 管理页可按 `viewerCharacterId + accountId` 人工确认或撤销明确揭露。

## Prompt 隔离

角色生成不使用会自动装配宿主全局记忆的 `ai.generate`。应用通过 `ai.chat` 只传当前角色自身经过过滤的人设、当前角色自己的匿名账号、按 viewer/account 隔离的 App 私有历史和公开 feed。

这样，普通小红书中已有的 `kk = Chloe` 不会被带入匿名版生成请求。匿名版帖子仍会通过按角色 timeline 写入后续普通聊天，但主体始终是具体 `accountId / displayName`。

安装包还注册一条全局身份保护规则。该规则没有任何真实 owner 映射，并且只对带有 `[匿名小红书]` 或本 App `social_account/accountId` 标记的内容生效。

## 权限

- `app.data.read/write`：本 App 私有账号、帖子与关系数据。
- `app.assets.read`：六个默认匿名头像。
- `characters.read`：读取角色 id/name 供管理页使用；生成时只保留当前角色经过敏感来源过滤的 persona/personality，真实头像永不使用。
- `ai.chat`：逐个调用指定角色或固定平台 NPC，并通过单个 `characterId` 选择对应 API 配置。
- `memory.search`：仅当前 viewer 的明确身份揭露检查。
- `memory.write`：按角色写入匿名账号 timeline。
- `ui.toast`：保存/发布提示。

应用不申请 `user.profile.read`、`user.persona.read`、`user.preferences.read`、`chat.read` 或 `chat.write`。

## 已知宿主边界

- Float 当前会把 Custom App timeline 的内部 `authorType` 归类为 `user`，但该字段不会渲染给模型；模型看到的是本 App 提供的 `social_account/accountId` 摘要。
- Custom App 不能主动触发内置应用使用的原生长期记忆总结计数器。为保持连续性，本 App 同时保存按 `viewerCharacterId + accountId` 隔离的网络印象，并维护可更新的 timeline 实体锚点。

## 开发与验证

```powershell
node scripts/build-anonymous-xiaohongshu.mjs
node scripts/test-anonymous-xiaohongshu.mjs
```

测试覆盖需求 Case 1–14、prompt 作用域、私有字段裁剪、单角色生成、稳定 accountId、改名、默认头像和 ZIP 文件结构。

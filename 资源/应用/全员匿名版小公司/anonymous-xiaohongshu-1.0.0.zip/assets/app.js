(function () {
  "use strict";

  var SOURCE_LABEL = "[匿名小红书]";
  var APP_TAG = "anonymous_xiaohongshu";
  var COLLECTIONS = {
    accounts: "social_accounts",
    bindings: "actor_bindings_private",
    posts: "posts",
    viewerStates: "viewer_account_states",
    disclosures: "viewer_identity_disclosures"
  };
  var DEFAULT_AVATARS = ["default-01", "default-02", "default-03", "default-04", "default-05", "default-06"];
  var RESERVED_ACCOUNT_NAMES = ["kk", "chloe", "{{user}}"];
  var MAX_FEED_FOR_MODEL = 24;
  var api = window.AiPhone || window.AiPhoneApp;
  var state = {
    accounts: [],
    bindings: [],
    posts: [],
    viewerStates: [],
    disclosures: [],
    characters: [],
    characterRuntime: {},
    avatarUrls: {},
    mediaUrls: {},
    npcDrafts: [],
    activePage: "feedPage",
    feedMode: "discover",
    selectedPostId: "",
    pendingImageFile: null,
    busy: false
  };

  function text(value) {
    return String(value == null ? "" : value).replace(/\u0000/g, "").trim();
  }

  function compact(value, maxLength) {
    var result = text(value).replace(/\s+/g, " ");
    return result.length > maxLength ? result.slice(0, maxLength) + "…" : result;
  }

  function escapeHtml(value) {
    return String(value == null ? "" : value)
      .replace(/&/g, "&amp;")
      .replace(/</g, "&lt;")
      .replace(/>/g, "&gt;")
      .replace(/"/g, "&quot;")
      .replace(/'/g, "&#39;");
  }

  function escapeRegExp(value) {
    return String(value).replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
  }

  function opaqueId(prefix) {
    var random = "";
    if (window.crypto && typeof window.crypto.randomUUID === "function") {
      random = window.crypto.randomUUID().replace(/-/g, "").slice(0, 14);
    } else {
      random = Date.now().toString(36) + Math.random().toString(36).slice(2, 10);
    }
    return prefix + "_" + random;
  }

  function uniqueStrings(values) {
    var seen = Object.create(null);
    return (values || []).map(text).filter(function (item) {
      var key = item.toLowerCase();
      if (!item || seen[key]) return false;
      seen[key] = true;
      return true;
    });
  }

  function sanitizeCharacterSelfContext(value, extraForbiddenNames) {
    var forbiddenNames = uniqueStrings(extraForbiddenNames || []);
    return String(value == null ? "" : value)
      .split(/\r?\n/)
      .map(function (line) { return line.trim(); })
      .filter(function (line) {
        return line
          && !/(?:\bkk\b|chloe|\{\{user\}\}|普通小红书|用户的小红书账号|小红书马甲|xiaohongshu)/i.test(line)
          && !forbiddenNames.some(function (name) {
            return new RegExp("(^|[^\\p{L}\\p{N}_])" + escapeRegExp(name) + "([^\\p{L}\\p{N}_]|$)", "iu").test(line);
          });
      })
      .join("\n")
      .slice(0, 8000);
  }

  function publicAccount(account) {
    if (!account) return null;
    return {
      kind: "social_account",
      accountId: text(account.id || account.accountId),
      displayName: text(account.displayName),
      avatarRef: DEFAULT_AVATARS.indexOf(account.avatarRef) >= 0 ? account.avatarRef : DEFAULT_AVATARS[0],
      bio: compact(account.bio, 240),
      aliases: uniqueStrings((account.aliasHistory || []).map(function (entry) {
        return typeof entry === "string" ? entry : entry && entry.displayName;
      }))
    };
  }

  function publicPost(post, accounts) {
    var account = accounts.find(function (item) { return item.id === post.authorAccountId; });
    return {
      postId: post.id,
      author: publicAccount(account),
      title: compact(post.title, 100),
      body: compact(post.body, 1800),
      hasImage: Boolean(post.imageRef),
      tags: (post.tags || []).map(function (tag) { return compact(tag, 40); }).filter(Boolean).slice(0, 12),
      createdAt: post.createdAt,
      comments: (post.comments || []).slice(-20).map(function (comment) {
        var commentAccount = accounts.find(function (item) { return item.id === comment.authorAccountId; });
        return {
          commentId: comment.id,
          author: publicAccount(commentAccount),
          text: compact(comment.text, 500),
          createdAt: comment.createdAt,
          replyToCommentId: text(comment.replyToCommentId) || undefined
        };
      })
    };
  }

  function viewerAccountKey(viewerCharacterId, accountId) {
    return text(viewerCharacterId) + "::" + text(accountId);
  }

  function findBinding(bindings, kind, ownerId) {
    return bindings.find(function (binding) {
      return binding.ownerKind === kind && binding.ownerId === ownerId;
    }) || null;
  }

  function findBindingForAccount(bindings, accountId) {
    return bindings.find(function (binding) { return binding.accountId === accountId; }) || null;
  }

  function disclosureStatus(disclosures, bindings, viewerCharacterId, accountId) {
    var selfBinding = findBinding(bindings, "character", viewerCharacterId);
    if (selfBinding && selfBinding.accountId === accountId) return "self";
    var record = disclosures.find(function (item) {
      return item.viewerCharacterId === viewerCharacterId
        && item.accountId === accountId
        && item.status === "explicitly_disclosed";
    });
    return record ? "explicitly_disclosed" : "unknown";
  }

  function safePerspective(input) {
    var viewerId = text(input.viewerCharacterId);
    var accounts = (input.accounts || []).map(publicAccount).filter(Boolean);
    var bindings = input.bindings || [];
    var disclosures = input.disclosures || [];
    var selfBinding = findBinding(bindings, "character", viewerId);
    return {
      source: SOURCE_LABEL,
      viewerCharacterId: viewerId,
      selfAccount: selfBinding ? accounts.find(function (account) { return account.accountId === selfBinding.accountId; }) || null : null,
      accounts: accounts.map(function (account) {
        return {
          kind: "social_account",
          accountId: account.accountId,
          displayName: account.displayName,
          avatarRef: account.avatarRef,
          bio: account.bio,
          identityState: disclosureStatus(disclosures, bindings, viewerId, account.accountId)
        };
      })
    };
  }

  function containsPrivateFields(value) {
    var json = JSON.stringify(value || {});
    return /"(?:ownerKind|ownerId|bindingId|persona|personality|avatar)"\s*:/.test(json);
  }

  function strictDisclosureMatch(memoryTexts, account, binding, ownerDisplayName) {
    var projection = publicAccount(account);
    if (!projection || !binding) return false;
    var aliases = uniqueStrings([projection.displayName].concat(projection.aliases || []));
    var ownerName = text(ownerDisplayName);
    var speculative = /(?:[?？]|可能|也许|大概|猜|怀疑|像是|听起来像|似乎|是不是|难道|询问|问是否|否认|不是|并非|maybe|perhaps|guess|suspect|sounds? like|might be|could be|is this|asked|whether|denied|\bnot\b)/i;
    return (memoryTexts || []).some(function (raw) {
      var content = text(raw);
      if (!content || speculative.test(content)) return false;
      if (/\[小红书[^\]]*\]/.test(content) && content.indexOf(SOURCE_LABEL) < 0) return false;
      return aliases.some(function (alias) {
        var a = escapeRegExp(alias);
        if (binding.ownerKind === "human_controller") {
          return new RegExp("(?:" + a + ")(?:\\s|[，,。:：-]){0,5}(?:is me|是我|就是我|是我的账号|是我的匿名账号|belongs to me)", "i").test(content)
            || new RegExp("(?:I am|I'm|我是|我就是|我的账号是|我的匿名账号是)(?:\\s|[，,。:：-]){0,5}(?:" + a + ")", "i").test(content);
        }
        if (binding.ownerKind !== "character" || !ownerName) return false;
        var o = escapeRegExp(ownerName);
        return new RegExp("(?:" + a + ").{0,12}(?:is|就是|属于|belongs to).{0,12}(?:" + o + ")", "i").test(content)
          || new RegExp("(?:" + a + ").{0,12}是.{0,6}(?:" + o + ").{0,6}的(?:匿名)?账号", "i").test(content)
          || new RegExp("(?:" + o + ").{0,12}(?:owns|使用|账号是|匿名账号是).{0,12}(?:" + a + ")", "i").test(content)
          || new RegExp("(?:" + o + ").{0,30}(?:明确|承认|告诉|said|told).{0,30}(?:" + a + ").{0,15}(?:是自己的(?:匿名)?账号|is (?:his|her|their) account|is me)", "i").test(content);
      });
    });
  }

  function identityLeakReason(value, realNames) {
    var output = text(value);
    if (!output) return "empty";
    if (/(?:ownerKind|ownerId|ActorBinding|characterId|human_controller)/i.test(output)) return "private-field";
    if (/(?:是不是你|是你吗|你的小号|你的马甲|另一个账号|听起来像|这很像|我怀疑|我猜这|现实中是谁|现实身份|真实身份|背后的人|背后是谁|has to be|must be|is this you|your alt|alt account|sounds? like|real[- ]life identity|who you are|I suspect|I think I know who)/i.test(output)) return "identity-speculation";
    if (/(?:某匿名用户|一个匿名用户|an anonymous user|some anonymous account)/i.test(output)) return "account-collapse";
    var names = uniqueStrings(realNames || []);
    for (var index = 0; index < names.length; index += 1) {
      if (new RegExp("(^|[^\\p{L}\\p{N}_])" + escapeRegExp(names[index]) + "([^\\p{L}\\p{N}_]|$)", "iu").test(output)) {
        return "real-name";
      }
    }
    return "";
  }

  function parseAction(raw) {
    var source = text(raw).replace(/^```(?:json)?\s*/i, "").replace(/\s*```$/, "");
    var start = source.indexOf("{");
    var end = source.lastIndexOf("}");
    if (start < 0 || end <= start) return null;
    try {
      var parsed = JSON.parse(source.slice(start, end + 1));
      if (!parsed || typeof parsed !== "object" || Array.isArray(parsed)) return null;
      return parsed;
    } catch (_error) {
      return null;
    }
  }

  function validateAction(action, availablePostIds, realNames, reactionPostId) {
    if (!action || ["post", "comment", "none"].indexOf(action.action) < 0) return "invalid-action";
    if (reactionPostId && action.action === "post") return "reaction-cannot-post";
    if (action.action === "none") return "";
    var visibleText = action.action === "post"
      ? [action.title, action.body, (action.tags || []).join(" ")].join(" ")
      : action.text;
    var leak = identityLeakReason(visibleText, realNames);
    if (leak) return leak;
    if (action.action === "post") {
      if (!text(action.title) || !text(action.body)) return "empty-post";
      return "";
    }
    var target = text(action.targetPostId);
    if (!target || availablePostIds.indexOf(target) < 0) return "invalid-target";
    if (reactionPostId && target !== reactionPostId) return "wrong-reaction-target";
    if (!text(action.text)) return "empty-comment";
    return "";
  }

  function memorySummary(input) {
    var account = publicAccount(input.account);
    var subject = input.isSelf ? "你的账号“" + account.displayName + "”" : "账号“" + account.displayName + "”";
    return SOURCE_LABEL + "[social_account:" + account.accountId + "][显示名:" + account.displayName + "] " + subject + compact(input.actionText, 1200);
  }

  function renameAccount(account, nextDisplayName, changedAt) {
    var nextName = text(nextDisplayName);
    if (!account || !nextName || nextName === account.displayName) return account;
    var history = Array.isArray(account.aliasHistory) ? account.aliasHistory.slice() : [];
    history.push({ displayName: account.displayName, changedAt: changedAt || new Date().toISOString() });
    return Object.assign({}, account, { displayName: nextName, aliasHistory: history });
  }

  var Core = {
    SOURCE_LABEL: SOURCE_LABEL,
    APP_TAG: APP_TAG,
    DEFAULT_AVATARS: DEFAULT_AVATARS.slice(),
    publicAccount: publicAccount,
    publicPost: publicPost,
    viewerAccountKey: viewerAccountKey,
    safePerspective: safePerspective,
    containsPrivateFields: containsPrivateFields,
    strictDisclosureMatch: strictDisclosureMatch,
    identityLeakReason: identityLeakReason,
    parseAction: parseAction,
    validateAction: validateAction,
    memorySummary: memorySummary,
    renameAccount: renameAccount,
    sanitizeCharacterSelfContext: sanitizeCharacterSelfContext,
    disclosureStatus: disclosureStatus
  };
  window.AnonymousXhsCore = Core;

  if (window.__ANON_XHS_DISABLE_BOOT__) return;

  function $(selector) { return document.querySelector(selector); }
  function $all(selector) { return Array.prototype.slice.call(document.querySelectorAll(selector)); }

  function setBusy(active, label) {
    state.busy = active;
    $("#busyOverlay").classList.toggle("hidden", !active);
    $("#busyText").textContent = label || "正在处理…";
    $("#refreshActorsButton").disabled = active;
    $("#publishButton").disabled = active;
  }

  function showBanner(message, timeoutMs) {
    var node = $("#statusBanner");
    node.textContent = message;
    node.classList.remove("hidden");
    if (timeoutMs) window.setTimeout(function () { node.classList.add("hidden"); }, timeoutMs);
  }

  function toast(message) {
    if (api && api.ui && typeof api.ui.toast === "function") {
      api.ui.toast(message).catch(function () { showBanner(message, 3000); });
    } else {
      showBanner(message, 3000);
    }
  }

  async function upsert(collection, row) {
    var current = await api.db.get(collection, row.id);
    if (current) return api.db.update(collection, row.id, row);
    return api.db.create(collection, row);
  }

  async function reloadState() {
    var results = await Promise.all([
      api.db.list(COLLECTIONS.accounts, { limit: 500 }),
      api.db.list(COLLECTIONS.bindings, { limit: 500 }),
      api.db.list(COLLECTIONS.posts, { limit: 500 }),
      api.db.list(COLLECTIONS.viewerStates, { limit: 500 }),
      api.db.list(COLLECTIONS.disclosures, { limit: 500 }),
      api.characters.list()
    ]);
    state.accounts = results[0] || [];
    state.bindings = results[1] || [];
    state.posts = (results[2] || []).sort(function (a, b) { return String(b.createdAt).localeCompare(String(a.createdAt)); });
    state.viewerStates = results[3] || [];
    state.disclosures = results[4] || [];
    state.characterRuntime = {};
    var rawCharacters = results[5] || [];
    state.characters = rawCharacters.map(function (character) {
      var id = text(character.id);
      return { id: id, name: text(character.name) || "未命名角色" };
    });
    rawCharacters.forEach(function (character) {
      var id = text(character.id);
      var otherNames = state.characters.filter(function (item) { return item.id !== id; }).map(function (item) { return item.name; });
      state.characterRuntime[id] = {
        persona: sanitizeCharacterSelfContext(character.persona, otherNames),
        personality: sanitizeCharacterSelfContext(character.personality, otherNames)
      };
    });
  }

  async function loadAvatarAssets() {
    await Promise.all(DEFAULT_AVATARS.map(async function (avatarRef) {
      var path = "assets/avatars/" + avatarRef + ".png";
      state.avatarUrls[avatarRef] = await api.app.getAssetUrl(path);
    }));
  }

  function accountById(accountId) {
    return state.accounts.find(function (account) { return account.id === accountId; }) || null;
  }

  function bindingForAccount(accountId) {
    return findBindingForAccount(state.bindings, accountId);
  }

  function humanBinding() {
    return findBinding(state.bindings, "human_controller", "current_human");
  }

  function humanAccount() {
    var binding = humanBinding();
    return binding ? accountById(binding.accountId) : null;
  }

  function enabledCharacterBindings() {
    return state.bindings.filter(function (binding) {
      return binding.ownerKind === "character"
        && binding.enabled !== false
        && accountById(binding.accountId)
        && state.characters.some(function (character) { return character.id === binding.ownerId; });
    });
  }

  function enabledNpcBindings() {
    return state.bindings.filter(function (binding) {
      return binding.ownerKind === "npc" && binding.enabled !== false && accountById(binding.accountId);
    });
  }

  function ownerLabel(binding) {
    if (!binding) return "未知现实身份";
    if (binding.ownerKind === "human_controller") return "当前对话者";
    if (binding.ownerKind === "character") {
      var character = state.characters.find(function (item) { return item.id === binding.ownerId; });
      return character ? character.name : "已移除角色";
    }
    return "平台 NPC";
  }

  function avatarUrl(account) {
    return state.avatarUrls[(account && account.avatarRef) || DEFAULT_AVATARS[0]] || "";
  }

  function timeLabel(iso) {
    var date = new Date(iso || Date.now());
    if (Number.isNaN(date.getTime())) return "刚刚";
    var diff = Date.now() - date.getTime();
    if (diff < 60000) return "刚刚";
    if (diff < 3600000) return Math.floor(diff / 60000) + "分钟前";
    if (diff < 86400000) return Math.floor(diff / 3600000) + "小时前";
    return (date.getMonth() + 1) + "-" + date.getDate();
  }

  function setPage(pageId) {
    state.activePage = pageId;
    $all(".page").forEach(function (page) { page.classList.toggle("active", page.id === pageId); });
    $all(".nav-item").forEach(function (button) { button.classList.toggle("active", button.dataset.page === pageId); });
    if (pageId === "managePage") renderManagement();
    if (pageId === "composePage") renderComposeAccount();
  }

  function renderComposeAccount() {
    var account = humanAccount();
    var node = $("#composeAccount");
    if (!account) {
      node.innerHTML = "<span>尚未配置匿名账号</span>";
      return;
    }
    node.innerHTML = '<img class="avatar" src="' + escapeHtml(avatarUrl(account)) + '" alt="" />'
      + '<span><strong>' + escapeHtml(account.displayName) + '</strong><span class="account-id">' + escapeHtml(account.id) + "</span></span>";
  }

  function renderFeed() {
    var human = humanAccount();
    var posts = state.posts.filter(function (post) {
      return state.feedMode !== "mine" || (human && post.authorAccountId === human.id);
    });
    $("#feedEmpty").classList.toggle("hidden", posts.length > 0);
    $("#feedGrid").innerHTML = posts.map(function (post) {
      var author = accountById(post.authorAccountId) || { displayName: "已停用账号", avatarRef: DEFAULT_AVATARS[0], id: post.authorAccountId };
      var likes = (post.likedByAccountIds || []).length;
      var cover = post.imageRef
        ? '<div class="note-cover has-image"><img data-media-ref="' + escapeHtml(post.imageRef) + '" alt="" /><span class="account-chip">' + escapeHtml(author.displayName) + " · " + escapeHtml(author.id) + "</span></div>"
        : '<div class="note-cover"><div class="text-cover">' + escapeHtml(post.title || post.body) + '</div><span class="account-chip">' + escapeHtml(author.displayName) + " · " + escapeHtml(author.id) + "</span></div>";
      return '<article class="note-card" data-post-id="' + escapeHtml(post.id) + '">'
        + cover
        + '<div class="note-body"><div class="note-title">' + escapeHtml(post.title || "无标题") + "</div>"
        + '<div class="note-meta"><img class="avatar" src="' + escapeHtml(avatarUrl(author)) + '" alt="" />'
        + '<span class="note-author">' + escapeHtml(author.displayName) + '</span><span class="note-likes">♡ ' + likes + "</span></div></div></article>";
    }).join("");
    resolveVisibleMedia();
  }

  async function resolveVisibleMedia() {
    var images = $all("img[data-media-ref]");
    await Promise.all(images.map(async function (image) {
      var ref = image.dataset.mediaRef;
      if (!ref) return;
      if (!state.mediaUrls[ref]) {
        try {
          var media = await api.media.get({ ref: ref });
          state.mediaUrls[ref] = media && media.dataUrl ? media.dataUrl : "";
        } catch (_error) {
          state.mediaUrls[ref] = "";
        }
      }
      if (state.mediaUrls[ref]) image.src = state.mediaUrls[ref];
    }));
  }

  function editorHtml(input) {
    var account = input.account;
    var binding = input.binding;
    var enabled = input.kind === "human_controller" ? true : !binding || binding.enabled !== false;
    var avatarRef = account && DEFAULT_AVATARS.indexOf(account.avatarRef) >= 0 ? account.avatarRef : DEFAULT_AVATARS[0];
    var accountId = account ? account.id : text(input.draftAccountId);
    var ownerId = binding ? binding.ownerId : input.ownerId;
    var bindingId = binding ? binding.id : text(input.draftBindingId);
    var avatars = DEFAULT_AVATARS.map(function (ref) {
      return '<button type="button" class="avatar-option ' + (ref === avatarRef ? "selected" : "") + '" data-avatar-choice="' + ref + '"><img src="' + escapeHtml(state.avatarUrls[ref]) + '" alt="' + ref + '" /></button>';
    }).join("");
    return '<div class="account-editor" data-owner-kind="' + escapeHtml(input.kind) + '" data-owner-id="' + escapeHtml(ownerId) + '" data-binding-id="' + escapeHtml(bindingId) + '" data-account-id="' + escapeHtml(accountId) + '">'
      + '<div class="owner-row"><div class="owner-label"><strong>' + escapeHtml(input.label) + '</strong><span>真实身份仅在管理页可见</span></div>'
      + (input.kind === "human_controller" ? '<span class="private-badge">APP 私有账号</span>' : '<label class="switch"><input class="account-enabled" type="checkbox" ' + (enabled ? "checked" : "") + ' />参与</label>') + "</div>"
      + '<div class="editor-grid"><input class="text-field account-display-name" maxlength="40" placeholder="手动填写匿名昵称" value="' + escapeHtml(account ? account.displayName : input.displayName || "") + '" />'
      + '<input class="text-field account-bio" maxlength="160" placeholder="简介（可选）" value="' + escapeHtml(account ? account.bio || "" : input.bio || "") + '" /></div>'
      + '<input class="avatar-value" type="hidden" value="' + avatarRef + '" /><div class="avatar-select">' + avatars + "</div>"
      + (accountId ? '<span class="private-badge">稳定 accountId：' + escapeHtml(accountId) + "</span>" : '<span class="private-badge">保存后生成稳定 accountId</span>')
      + (input.kind === "npc" && binding ? '<button class="delete-npc" type="button" data-disable-npc="' + escapeHtml(binding.id) + '">停用此 NPC</button>' : "")
      + "</div>";
  }

  function renderManagement() {
    var hb = humanBinding();
    var ha = hb ? accountById(hb.accountId) : null;
    $("#humanAccountCard").innerHTML = editorHtml({
      label: "当前用户控制的匿名账号",
      kind: "human_controller",
      ownerId: "current_human",
      binding: hb,
      account: ha
    });

    $("#characterAccountList").innerHTML = state.characters.map(function (character) {
      var binding = findBinding(state.bindings, "character", character.id);
      return editorHtml({
        label: character.name,
        kind: "character",
        ownerId: character.id,
        binding: binding,
        account: binding ? accountById(binding.accountId) : null
      });
    }).join("") || '<div class="sheet">Float 中还没有可配置的角色。</div>';

    var npcRows = enabledNpcBindings().map(function (binding) {
      return editorHtml({ label: "平台 NPC", kind: "npc", ownerId: binding.ownerId, binding: binding, account: accountById(binding.accountId) });
    });
    state.npcDrafts.forEach(function (draft) {
      npcRows.push(editorHtml({
        label: "新平台 NPC",
        kind: "npc",
        ownerId: draft.ownerId,
        draftBindingId: draft.bindingId,
        draftAccountId: draft.accountId,
        displayName: draft.displayName,
        bio: draft.bio
      }));
    });
    $("#npcAccountList").innerHTML = npcRows.join("") || '<div class="sheet">暂无平台 NPC。点击“新增”后手动设置网名。</div>';
    renderDisclosurePanel();
  }

  function renderDisclosurePanel() {
    var viewers = enabledCharacterBindings();
    var accounts = state.accounts.filter(function (account) {
      var binding = bindingForAccount(account.id);
      return binding && binding.enabled !== false && binding.ownerKind !== "npc";
    });
    var current = state.disclosures.filter(function (item) { return item.status === "explicitly_disclosed"; });
    var list = current.map(function (item) {
      var viewer = state.characters.find(function (character) { return character.id === item.viewerCharacterId; });
      var account = accountById(item.accountId);
      return viewer && account
        ? '<div class="disclosure-item">' + escapeHtml(viewer.name) + ' 已明确得知：' + escapeHtml(account.displayName) + " 的现实身份（仅此 viewer）</div>"
        : "";
    }).join("");
    $("#disclosurePanel").innerHTML = '<label for="disclosureViewer">当前 viewer character</label><select id="disclosureViewer">'
      + viewers.map(function (binding) {
        var character = state.characters.find(function (item) { return item.id === binding.ownerId; });
        return '<option value="' + escapeHtml(binding.ownerId) + '">' + escapeHtml(character ? character.name : binding.ownerId) + "</option>";
      }).join("") + '</select><label for="disclosureAccount">已经明确揭露的账号</label><select id="disclosureAccount">'
      + accounts.map(function (account) {
        var binding = bindingForAccount(account.id);
        return '<option value="' + escapeHtml(account.id) + '">' + escapeHtml(account.displayName) + " ← " + escapeHtml(ownerLabel(binding)) + "</option>";
      }).join("") + '</select><div class="disclosure-actions"><button class="confirm-disclosure" id="confirmDisclosure" type="button">确认明确揭露</button><button class="clear-disclosure" id="clearDisclosure" type="button">恢复 unknown</button></div>'
      + '<div class="disclosure-list">' + (list || '<div class="disclosure-item">当前没有人工确认的身份揭露。</div>') + "</div>";
  }

  function collectEditorSpecs() {
    return $all(".account-editor").map(function (row) {
      var enabledInput = row.querySelector(".account-enabled");
      return {
        ownerKind: row.dataset.ownerKind,
        ownerId: row.dataset.ownerId,
        bindingId: row.dataset.bindingId,
        accountId: row.dataset.accountId,
        displayName: text(row.querySelector(".account-display-name").value),
        bio: text(row.querySelector(".account-bio").value),
        avatarRef: row.querySelector(".avatar-value").value,
        enabled: row.dataset.ownerKind === "human_controller" || !enabledInput || enabledInput.checked
      };
    });
  }

  async function saveAccounts() {
    var specs = collectEditorSpecs();
    var active = specs.filter(function (spec) { return spec.enabled; });
    var names = Object.create(null);
    for (var index = 0; index < active.length; index += 1) {
      var spec = active[index];
      if (!spec.displayName) throw new Error("所有启用账号都必须手动填写匿名昵称。");
      var key = spec.displayName.toLowerCase();
      var forbidden = RESERVED_ACCOUNT_NAMES.concat(state.characters.map(function (character) { return character.name.toLowerCase(); }));
      if (forbidden.indexOf(key) >= 0) throw new Error("匿名昵称不能直接使用已知现实身份或普通小红书账号名：“" + spec.displayName + "”。");
      if (names[key]) throw new Error("匿名昵称必须唯一：“" + spec.displayName + "”重复了。");
      names[key] = true;
      if (DEFAULT_AVATARS.indexOf(spec.avatarRef) < 0) throw new Error("头像只能使用匿名版内置默认头像。");
    }

    var renames = [];
    for (var specIndex = 0; specIndex < specs.length; specIndex += 1) {
      var item = specs[specIndex];
      var existingBinding = item.bindingId ? state.bindings.find(function (binding) { return binding.id === item.bindingId; }) : null;
      if (!item.enabled && !existingBinding) continue;
      var accountId = item.accountId || (existingBinding && existingBinding.accountId) || opaqueId("acct");
      var bindingId = item.bindingId || (existingBinding && existingBinding.id) || opaqueId("bind");
      var existingAccount = accountById(accountId);
      if (item.displayName) {
        var nextAccount = existingAccount ? renameAccount(existingAccount, item.displayName) : {
          id: accountId,
          kind: "social_account",
          displayName: item.displayName,
          avatarRef: item.avatarRef,
          bio: item.bio,
          aliasHistory: []
        };
        nextAccount.avatarRef = item.avatarRef;
        nextAccount.bio = item.bio;
        nextAccount.kind = "social_account";
        await upsert(COLLECTIONS.accounts, nextAccount);
        if (existingAccount && existingAccount.displayName !== nextAccount.displayName) {
          renames.push({ before: existingAccount.displayName, account: nextAccount });
        }
      }
      await upsert(COLLECTIONS.bindings, {
        id: bindingId,
        accountId: accountId,
        ownerKind: item.ownerKind,
        ownerId: item.ownerId,
        enabled: item.enabled
      });
    }
    state.npcDrafts = [];
    await reloadState();
    for (var renameIndex = 0; renameIndex < renames.length; renameIndex += 1) {
      await propagateRename(renames[renameIndex].account, renames[renameIndex].before);
    }
    renderAll();
    toast("匿名账号配置已保存");
  }

  async function setManualDisclosure(status) {
    var viewer = text($("#disclosureViewer") && $("#disclosureViewer").value);
    var accountId = text($("#disclosureAccount") && $("#disclosureAccount").value);
    if (!viewer || !accountId) throw new Error("请选择 viewer 和账号。");
    var id = viewerAccountKey(viewer, accountId);
    var existing = state.disclosures.find(function (item) { return item.id === id; });
    if (status === "unknown") {
      if (existing) await api.db.delete(COLLECTIONS.disclosures, id);
    } else {
      await upsert(COLLECTIONS.disclosures, {
        id: id,
        viewerCharacterId: viewer,
        accountId: accountId,
        status: "explicitly_disclosed",
        evidenceSource: "manual_confirmation"
      });
    }
    await reloadState();
    renderDisclosurePanel();
    await refreshEntityAnchor(viewer, accountId);
    toast(status === "unknown" ? "已恢复为 unknown" : "已按当前角色确认身份揭露");
  }

  function disclosureFor(viewerCharacterId, accountId) {
    return disclosureStatus(state.disclosures, state.bindings, viewerCharacterId, accountId);
  }

  async function refreshDisclosureFromMemory(viewerCharacterId, accountId) {
    if (disclosureFor(viewerCharacterId, accountId) !== "unknown") return;
    var account = accountById(accountId);
    var binding = bindingForAccount(accountId);
    if (!account || !binding || binding.ownerKind === "npc") return;
    var aliases = uniqueStrings([account.displayName].concat((account.aliasHistory || []).map(function (entry) { return entry.displayName; })));
    var foundTexts = [];
    for (var index = 0; index < aliases.length; index += 1) {
      try {
        var result = await api.memory.search({ characterId: viewerCharacterId, query: aliases[index], limit: 30 });
        (result.entries || []).forEach(function (entry) {
          if (entry && entry.content) foundTexts.push(entry.content);
        });
      } catch (_error) {
        return;
      }
    }
    var ownerName = binding.ownerKind === "character" ? ownerLabel(binding) : "";
    if (!strictDisclosureMatch(foundTexts, account, binding, ownerName)) return;
    await upsert(COLLECTIONS.disclosures, {
      id: viewerAccountKey(viewerCharacterId, accountId),
      viewerCharacterId: viewerCharacterId,
      accountId: accountId,
      status: "explicitly_disclosed",
      evidenceSource: "explicit_memory_statement"
    });
    state.disclosures = await api.db.list(COLLECTIONS.disclosures, { limit: 500 });
  }

  async function refreshDisclosuresForViewer(viewerCharacterId) {
    var relevant = uniqueStrings(state.posts.slice(0, MAX_FEED_FOR_MODEL).map(function (post) { return post.authorAccountId; }));
    var selfBinding = findBinding(state.bindings, "character", viewerCharacterId);
    if (selfBinding) relevant.push(selfBinding.accountId);
    for (var index = 0; index < relevant.length; index += 1) {
      await refreshDisclosureFromMemory(viewerCharacterId, relevant[index]);
    }
  }

  function identityLine(viewerCharacterId, account) {
    var status = disclosureFor(viewerCharacterId, account.id);
    if (status === "self") {
      return '<social_account accountId="' + account.id + '" displayName="' + account.displayName + '" identityState="self">这是你自己的平台账号。</social_account>';
    }
    if (status === "explicitly_disclosed") {
      return '<social_account accountId="' + account.id + '" displayName="' + account.displayName + '" identityState="explicitly_disclosed">该账号已向当前角色明确揭露为' + ownerLabel(bindingForAccount(account.id)) + '；只允许当前角色使用这项知识。</social_account>';
    }
    return '<social_account accountId="' + account.id + '" displayName="' + account.displayName + '" identityState="unknown">这是稳定网络人格；现实身份未知，禁止推断或试探。</social_account>';
  }

  function buildViewerInstruction(viewerCharacterId, selfAccount, focusPostId) {
    var perspective = safePerspective({
      viewerCharacterId: viewerCharacterId,
      accounts: state.accounts,
      bindings: state.bindings,
      disclosures: state.disclosures
    });
    if (containsPrivateFields(perspective)) throw new Error("安全投影包含私有字段，已停止生成。");
    var posts = state.posts.slice(0, MAX_FEED_FOR_MODEL).map(function (post) { return publicPost(post, state.accounts); });
    var feed = posts.map(function (post) {
      if (!post.author) return "";
      var comments = post.comments.map(function (comment) {
        return comment.author
          ? '  <comment id="' + comment.commentId + '" accountId="' + comment.author.accountId + '" displayName="' + comment.author.displayName + '">' + comment.text + "</comment>"
          : "";
      }).filter(Boolean).join("\n");
      return '<post id="' + post.postId + '" accountId="' + post.author.accountId + '" displayName="' + post.author.displayName + '">\n<title>' + post.title + "</title>\n<body>" + post.body + "</body>\n<image>" + (post.hasImage ? "存在配图；当前文本模型不可见图片细节，不得臆测" : "无") + "</image>\n" + comments + "\n</post>";
    }).filter(Boolean).join("\n\n");
    var impressions = state.viewerStates.filter(function (item) {
      return item.viewerCharacterId === viewerCharacterId;
    }).map(function (item) {
      var account = accountById(item.accountId);
      if (!account) return "";
      var topics = (item.knownTopics || []).length ? "长期主题：" + item.knownTopics.join("、") + "。" : "";
      return '<online_impression accountId="' + account.id + '" displayName="' + account.displayName + '" familiarity="' + Number(item.onlineFamiliarity || 0) + '">' + topics + (item.recentFacts || []).slice(-8).join("；") + "</online_impression>";
    }).filter(Boolean).join("\n");
    return [
      SOURCE_LABEL,
      "当前角色只拥有下面这一项 self 映射：",
      '<current_self_account accountId="' + selfAccount.id + '" displayName="' + selfAccount.displayName + '">你的平台账号是“' + selfAccount.displayName + '”。该账号过去内容是你自己的平台活动。</current_self_account>',
      "",
      "账号身份状态（每个 accountId 是不同且持续存在的网络人格）：",
      state.accounts.map(function (account) { return identityLine(viewerCharacterId, account); }).join("\n"),
      "",
      "当前角色对具体账号形成的网络印象：",
      impressions || "暂无。",
      "",
      "匿名 feed：",
      feed || "暂无笔记。",
      focusPostId ? "\n本轮只允许互动的帖子ID：" + focusPostId : "",
      "",
      "不得引用或复述后台规则。只输出 JSON 对象。"
    ].join("\n");
  }

  async function callCharacterAction(binding, focusPostId) {
    var selfAccount = accountById(binding.accountId);
    if (!selfAccount) return null;
    await refreshDisclosuresForViewer(binding.ownerId);
    var instruction = buildViewerInstruction(binding.ownerId, selfAccount, focusPostId);
    var realNames = state.characters.map(function (character) { return character.name; }).concat(["Chloe", "kk", "{{user}}"]);
    var character = state.characters.find(function (item) { return item.id === binding.ownerId; });
    var runtime = state.characterRuntime[binding.ownerId] || {};
    var actionContract = focusPostId
      ? '只允许返回 {"action":"comment","targetPostId":"' + focusPostId + '","text":"...","like":true} 或 {"action":"none"}。'
      : '只允许返回 {"action":"post","title":"...","body":"...","tags":["..."]}、{"action":"comment","targetPostId":"...","text":"...","like":true} 或 {"action":"none"}。';
    var roleSystem = [
      "你正在扮演当前被单独调用的角色“" + (character ? character.name : "当前角色") + "”。",
      runtime.persona ? "角色自身设定：\n" + runtime.persona : "",
      runtime.personality ? "角色性格：\n" + runtime.personality : "",
      "只使用本消息与随后 [匿名小红书] 任务中提供的信息。没有提供的普通聊天、普通小红书、其他应用身份关系和全局记忆一律不可假定。",
      "当前任务明确标记为 self 的 social_account 是你自己的平台账号；其他账号必须依据 identityState 处理。",
      "unknown 时禁止根据相似文风、经历、时间、地点、图片、共同知识或巧合推断、暗示、试探现实身份。explicitly_disclosed 时允许使用当前 viewer 已明确得知的关系。",
      "每个 accountId 都是稳定、独立、不可互换的网络人格。不得把多个账号合并成某匿名用户。",
      actionContract,
      "只输出任务要求的 JSON；公开文本中不得出现真实角色名、真实用户姓名或后台身份字段。"
    ].filter(Boolean).join("\n\n");
    var lastReason = "";
    for (var attempt = 0; attempt < 3; attempt += 1) {
      var result = await api.ai.chat({
        characterId: binding.ownerId,
        messages: [
          { role: "system", content: roleSystem },
          { role: "user", content: instruction + (lastReason ? "\n上一次输出因安全检查失败（" + lastReason + "）。重新输出，不能包含真实姓名、身份推断或泛化匿名账号。" : "") }
        ],
        temperature: 0.82,
        maxTokens: 850,
        timeoutMs: 120000
      });
      var action = parseAction(result && result.text);
      var reason = validateAction(action, state.posts.map(function (post) { return post.id; }), realNames, focusPostId);
      if (!reason) return action;
      lastReason = reason;
    }
    return null;
  }

  async function callNpcAction(binding, focusPostId) {
    var account = accountById(binding.accountId);
    if (!account) return null;
    var feed = state.posts.slice(0, MAX_FEED_FOR_MODEL).map(function (post) { return publicPost(post, state.accounts); });
    var prompt = [
      SOURCE_LABEL,
      "你只负责一个固定的 pseudonymous social_account。",
      "你的账号是 " + account.displayName + "（accountId=" + account.id + "）。",
      "所有其他 accountId 都是不同、稳定的网络人格；不要猜测任何现实身份，也不要使用真实角色名。",
      "根据 feed 返回 JSON 动作。post: {\"action\":\"post\",\"title\":\"...\",\"body\":\"...\",\"tags\":[\"...\"]}；comment: {\"action\":\"comment\",\"targetPostId\":\"...\",\"text\":\"...\",\"like\":true}；none: {\"action\":\"none\"}。",
      JSON.stringify(feed),
      focusPostId ? "只允许评论帖子：" + focusPostId : "允许 post、comment 或 none。"
    ].join("\n");
    var result = await api.ai.chat({
      messages: [
        { role: "system", content: "只输出 JSON。不得输出身份推断、真实姓名、后台身份字段或‘某匿名用户’式合并描述。" },
        { role: "user", content: prompt }
      ],
      temperature: 0.85,
      maxTokens: 700,
      timeoutMs: 90000
    });
    var action = parseAction(result && result.text);
    var reason = validateAction(action, state.posts.map(function (post) { return post.id; }), state.characters.map(function (character) { return character.name; }).concat(["Chloe", "kk", "{{user}}"]), focusPostId);
    return reason ? null : action;
  }

  async function persistPost(post) {
    await upsert(COLLECTIONS.posts, post);
    var index = state.posts.findIndex(function (item) { return item.id === post.id; });
    if (index >= 0) state.posts.splice(index, 1, post);
    else state.posts.unshift(post);
    state.posts.sort(function (a, b) { return String(b.createdAt).localeCompare(String(a.createdAt)); });
  }

  async function applyActorAction(binding, action) {
    if (!action || action.action === "none") return;
    var account = accountById(binding.accountId);
    if (!account) return;
    if (action.action === "post") {
      var post = {
        id: opaqueId("post"),
        authorAccountId: account.id,
        title: compact(action.title, 80),
        body: compact(action.body, 1800),
        tags: uniqueStrings(action.tags || []).slice(0, 10),
        comments: [],
        likedByAccountIds: [],
        savedByAccountIds: [],
        createdAt: new Date().toISOString()
      };
      await persistPost(post);
      await recordSocialEvent("post", account.id, post, null);
      return;
    }
    var target = state.posts.find(function (post) { return post.id === action.targetPostId; });
    if (!target) return;
    var comment = {
      id: opaqueId("comment"),
      authorAccountId: account.id,
      text: compact(action.text, 500),
      createdAt: new Date().toISOString()
    };
    var updated = Object.assign({}, target, {
      comments: (target.comments || []).concat(comment),
      likedByAccountIds: action.like === true
        ? uniqueStrings((target.likedByAccountIds || []).concat(account.id))
        : (target.likedByAccountIds || []).slice()
    });
    await persistPost(updated);
    await recordSocialEvent("comment", account.id, updated, comment);
  }

  async function runActorRound(focusPostId) {
    var bindings = enabledCharacterBindings();
    for (var index = 0; index < bindings.length; index += 1) {
      setBusy(true, "正在让第 " + (index + 1) + " / " + bindings.length + " 个匿名角色账号查看 feed…");
      try {
        var action = await callCharacterAction(bindings[index], focusPostId);
        await applyActorAction(bindings[index], action);
      } catch (error) {
        console.warn("[AnonymousXHS] character action skipped", error);
      }
    }
    var npcs = enabledNpcBindings();
    if (npcs.length > 0) {
      var npcBinding = npcs[Math.floor(Math.random() * npcs.length)];
      try {
        setBusy(true, "正在刷新平台匿名账号…");
        var npcAction = await callNpcAction(npcBinding, focusPostId);
        await applyActorAction(npcBinding, npcAction);
      } catch (error) {
        console.warn("[AnonymousXHS] npc action skipped", error);
      }
    }
    setBusy(false);
    renderAll();
  }

  async function updateViewerState(viewerCharacterId, account, fact, topics) {
    var id = viewerAccountKey(viewerCharacterId, account.id);
    var current = state.viewerStates.find(function (item) { return item.id === id; });
    var next = {
      id: id,
      viewerCharacterId: viewerCharacterId,
      accountId: account.id,
      onlineFamiliarity: Math.min(100, Number(current && current.onlineFamiliarity || 0) + 1),
      interactionCount: Number(current && current.interactionCount || 0) + 1,
      knownTopics: uniqueStrings((current && current.knownTopics || []).concat(topics || [])).slice(-30),
      recentFacts: uniqueStrings((current && current.recentFacts || []).concat(compact(fact, 220))).slice(-12),
      lastSeenAt: new Date().toISOString()
    };
    await upsert(COLLECTIONS.viewerStates, next);
    var index = state.viewerStates.findIndex(function (item) { return item.id === id; });
    if (index >= 0) state.viewerStates.splice(index, 1, next); else state.viewerStates.push(next);
    return next;
  }

  async function writeTimeline(viewerCharacterId, summary, detail, appEventId, data) {
    var safeData = {
      source: data.source,
      accountId: data.accountId,
      displayName: data.displayName,
      postId: data.postId || undefined,
      commentId: data.commentId || undefined
    };
    await api.memory.addTimeline({
      characterId: viewerCharacterId,
      appLabel: "匿名小红书",
      detail: detail,
      summary: summary,
      appEventId: appEventId,
      data: safeData,
      createdAt: data.createdAt || new Date().toISOString()
    });
  }

  async function refreshEntityAnchor(viewerCharacterId, accountId) {
    var account = accountById(accountId);
    if (!account) return;
    var viewerState = state.viewerStates.find(function (item) {
      return item.viewerCharacterId === viewerCharacterId && item.accountId === accountId;
    });
    var status = disclosureFor(viewerCharacterId, accountId);
    var relationship = status === "self"
      ? "这是你自己的平台账号。"
      : status === "explicitly_disclosed"
        ? "当前角色已明确得知该账号的现实身份为“" + ownerLabel(bindingForAccount(accountId)) + "”；这项知识只属于当前角色。"
        : "该账号的现实身份状态为 unknown；你可以熟悉其网络人格，但不得推断、暗示或试探现实身份。";
    var facts = viewerState && viewerState.recentFacts && viewerState.recentFacts.length
      ? "近期印象：" + viewerState.recentFacts.slice(-8).join("；") + "。"
      : "暂时没有更多网络印象。";
    var topics = viewerState && viewerState.knownTopics && viewerState.knownTopics.length
      ? "长期主题：" + viewerState.knownTopics.join("、") + "。"
      : "";
    var eventId = "anonymous_xhs_entity:" + accountId;
    try {
      await api.memory.deleteTimeline({ characterId: viewerCharacterId, appEventId: eventId });
    } catch (_error) {}
    await writeTimeline(
      viewerCharacterId,
      SOURCE_LABEL + "[social_account:" + account.id + "][当前显示名:" + account.displayName + "] 这是一个稳定、独立、持续存在的网络账号。" + relationship + topics + facts,
      "anonymous_social_account_anchor",
      eventId,
      { source: "anonymous_social_account", accountId: account.id, displayName: account.displayName }
    );
  }

  async function recordSocialEvent(kind, accountId, post, comment) {
    var account = accountById(accountId);
    if (!account) return;
    var viewers = enabledCharacterBindings();
    var actionText = kind === "post"
      ? "发布了笔记《" + compact(post.title, 90) + "》：" + compact(post.body, 420) + "。"
      : "在笔记《" + compact(post.title, 90) + "》下评论：“" + compact(comment && comment.text, 360) + "”。";
    for (var index = 0; index < viewers.length; index += 1) {
      var viewer = viewers[index];
      var isSelf = viewer.accountId === account.id;
      await updateViewerState(
        viewer.ownerId,
        account,
        actionText,
        kind === "post" ? uniqueStrings((post.tags || []).concat(post.title || "")) : []
      );
      await writeTimeline(
        viewer.ownerId,
        memorySummary({ account: account, isSelf: isSelf, actionText: actionText }),
        kind === "post" ? "anonymous_social_post" : "anonymous_social_comment",
        "anonymous_xhs_" + kind + ":" + (comment ? comment.id : post.id),
        {
          source: kind === "post" ? "anonymous_social_post" : "anonymous_social_comment",
          accountId: account.id,
          displayName: account.displayName,
          postId: post.id,
          commentId: comment && comment.id,
          createdAt: comment && comment.createdAt || post.createdAt
        }
      );
      await refreshEntityAnchor(viewer.ownerId, account.id);
    }
  }

  async function propagateRename(account, previousName) {
    var viewers = enabledCharacterBindings();
    for (var index = 0; index < viewers.length; index += 1) {
      var viewer = viewers[index];
      var known = viewer.accountId === account.id || state.viewerStates.some(function (item) {
        return item.viewerCharacterId === viewer.ownerId && item.accountId === account.id;
      });
      if (!known) continue;
      await updateViewerState(
        viewer.ownerId,
        account,
        "账号显示名由“" + previousName + "”改为“" + account.displayName + "”，accountId 未改变。"
      );
      await writeTimeline(
        viewer.ownerId,
        SOURCE_LABEL + "[social_account:" + account.id + "] 账号“" + previousName + "”已将显示名改为“" + account.displayName + "”；accountId 未改变，这是同一个持续存在的网络账号。",
        "anonymous_social_account_renamed",
        "anonymous_xhs_rename:" + account.id + ":" + Date.now(),
        { source: "anonymous_social_account_renamed", accountId: account.id, displayName: account.displayName }
      );
      await refreshEntityAnchor(viewer.ownerId, account.id);
    }
  }

  async function fileToDataUrl(file) {
    return new Promise(function (resolve, reject) {
      var reader = new FileReader();
      reader.onload = function () { resolve(String(reader.result || "")); };
      reader.onerror = function () { reject(new Error("图片读取失败")); };
      reader.readAsDataURL(file);
    });
  }

  async function publishHumanPost() {
    var account = humanAccount();
    if (!account) {
      setPage("managePage");
      throw new Error("请先设置当前用户的匿名账号。");
    }
    var title = text($("#postTitle").value);
    var body = text($("#postBody").value);
    if (!title || !body) throw new Error("标题和正文不能为空。");
    setBusy(true, "正在发布匿名笔记…");
    var imageRef = "";
    if (state.pendingImageFile) {
      var dataUrl = await fileToDataUrl(state.pendingImageFile);
      var stored = await api.media.put({ dataUrl: dataUrl, mime: state.pendingImageFile.type });
      imageRef = stored && stored.ref || "";
    }
    var post = {
      id: opaqueId("post"),
      authorAccountId: account.id,
      title: compact(title, 80),
      body: compact(body, 1800),
      tags: uniqueStrings($("#postTags").value.split(/[,，#]+/)).slice(0, 10),
      imageRef: imageRef,
      comments: [],
      likedByAccountIds: [],
      savedByAccountIds: [],
      createdAt: new Date().toISOString()
    };
    await persistPost(post);
    await recordSocialEvent("post", account.id, post, null);
    $("#postTitle").value = "";
    $("#postBody").value = "";
    $("#postTags").value = "";
    $("#postImage").value = "";
    $("#imagePickerText").textContent = "添加图片";
    state.pendingImageFile = null;
    setPage("feedPage");
    renderAll();
    await runActorRound(post.id);
  }

  function renderDetail(postId) {
    var post = state.posts.find(function (item) { return item.id === postId; });
    if (!post) return;
    state.selectedPostId = postId;
    var author = accountById(post.authorAccountId) || { id: post.authorAccountId, displayName: "已停用账号", avatarRef: DEFAULT_AVATARS[0] };
    var human = humanAccount();
    var liked = Boolean(human && (post.likedByAccountIds || []).indexOf(human.id) >= 0);
    var image = post.imageRef ? '<img class="detail-image" data-media-ref="' + escapeHtml(post.imageRef) + '" alt="" />' : "";
    var comments = (post.comments || []).map(function (comment) {
      var account = accountById(comment.authorAccountId) || { id: comment.authorAccountId, displayName: "已停用账号", avatarRef: DEFAULT_AVATARS[0] };
      return '<div class="comment"><img class="avatar" src="' + escapeHtml(avatarUrl(account)) + '" alt="" /><div class="comment-content"><strong>' + escapeHtml(account.displayName) + '</strong><small>' + escapeHtml(account.id) + " · " + timeLabel(comment.createdAt) + '</small><p>' + escapeHtml(comment.text) + "</p></div></div>";
    }).join("");
    $("#detailContent").innerHTML = image
      + '<div class="detail-copy"><div class="detail-author"><img class="avatar" src="' + escapeHtml(avatarUrl(author)) + '" alt="" /><div><strong>' + escapeHtml(author.displayName) + '</strong><small>social_account · ' + escapeHtml(author.id) + "</small></div></div>"
      + "<h1>" + escapeHtml(post.title) + "</h1><p>" + escapeHtml(post.body) + '</p><div class="tag-list">' + (post.tags || []).map(function (tag) { return '<span class="tag">#' + escapeHtml(tag) + "</span>"; }).join("") + "</div>"
      + '<div class="detail-toolbar"><button id="detailLike" class="' + (liked ? "active" : "") + '" type="button">' + (liked ? "♥" : "♡") + " " + (post.likedByAccountIds || []).length + '</button><button id="detailReact" type="button">让角色查看</button></div></div>'
      + '<section class="comments"><h2>评论 · ' + (post.comments || []).length + "</h2>" + (comments || '<div class="empty-state" style="padding:20px">还没有评论</div>') + '</section><div class="comment-box"><input id="humanCommentText" maxlength="500" placeholder="以你的匿名账号评论" /><button id="sendHumanComment" type="button">发送</button></div>';
    $("#detailModal").classList.remove("hidden");
    resolveVisibleMedia();
  }

  async function toggleHumanLike() {
    var post = state.posts.find(function (item) { return item.id === state.selectedPostId; });
    var account = humanAccount();
    if (!post || !account) throw new Error("请先配置匿名账号。");
    var likes = (post.likedByAccountIds || []).slice();
    var index = likes.indexOf(account.id);
    if (index >= 0) likes.splice(index, 1); else likes.push(account.id);
    await persistPost(Object.assign({}, post, { likedByAccountIds: likes }));
    renderFeed();
    renderDetail(post.id);
  }

  async function sendHumanComment() {
    var post = state.posts.find(function (item) { return item.id === state.selectedPostId; });
    var account = humanAccount();
    var value = text($("#humanCommentText") && $("#humanCommentText").value);
    if (!post || !account) throw new Error("请先配置匿名账号。");
    if (!value) return;
    var comment = { id: opaqueId("comment"), authorAccountId: account.id, text: compact(value, 500), createdAt: new Date().toISOString() };
    var updated = Object.assign({}, post, { comments: (post.comments || []).concat(comment) });
    await persistPost(updated);
    await recordSocialEvent("comment", account.id, updated, comment);
    renderFeed();
    renderDetail(post.id);
  }

  function renderAll() {
    renderFeed();
    renderComposeAccount();
    if (state.activePage === "managePage") renderManagement();
  }

  function bindEvents() {
    $all("[data-page]").forEach(function (button) {
      button.addEventListener("click", function () { setPage(button.dataset.page); });
    });
    $("#brandButton").addEventListener("click", function () { setPage("feedPage"); });
    $("#manageButton").addEventListener("click", function () { setPage("managePage"); });
    $("#refreshActorsButton").addEventListener("click", function () {
      runActorRound("").catch(function (error) { setBusy(false); showBanner(error.message, 5000); });
    });
    $("#publishButton").addEventListener("click", function () {
      publishHumanPost().catch(function (error) { setBusy(false); showBanner(error.message, 5000); });
    });
    $("#postImage").addEventListener("change", function (event) {
      state.pendingImageFile = event.target.files && event.target.files[0] || null;
      $("#imagePickerText").textContent = state.pendingImageFile ? state.pendingImageFile.name : "添加图片";
    });
    $("#feedGrid").addEventListener("click", function (event) {
      var card = event.target.closest("[data-post-id]");
      if (card) renderDetail(card.dataset.postId);
    });
    $all(".feed-tab").forEach(function (button) {
      button.addEventListener("click", function () {
        state.feedMode = button.dataset.feed;
        $all(".feed-tab").forEach(function (item) { item.classList.toggle("active", item === button); });
        renderFeed();
      });
    });
    $("#managePage").addEventListener("click", function (event) {
      var avatarButton = event.target.closest("[data-avatar-choice]");
      if (avatarButton) {
        var editor = avatarButton.closest(".account-editor");
        editor.querySelectorAll(".avatar-option").forEach(function (item) { item.classList.remove("selected"); });
        avatarButton.classList.add("selected");
        editor.querySelector(".avatar-value").value = avatarButton.dataset.avatarChoice;
        return;
      }
      var disableButton = event.target.closest("[data-disable-npc]");
      if (disableButton) {
        var binding = state.bindings.find(function (item) { return item.id === disableButton.dataset.disableNpc; });
        if (binding) {
          upsert(COLLECTIONS.bindings, Object.assign({}, binding, { enabled: false })).then(async function () {
            await reloadState();
            renderManagement();
          });
        }
      }
    });
    $("#addNpcButton").addEventListener("click", function () {
      state.npcDrafts.push({ ownerId: opaqueId("npc"), bindingId: opaqueId("bind"), accountId: opaqueId("acct") });
      renderManagement();
    });
    $("#saveAccountsButton").addEventListener("click", function () {
      setBusy(true, "正在保存匿名账号配置…");
      saveAccounts().catch(function (error) { showBanner(error.message, 5000); }).finally(function () { setBusy(false); });
    });
    $("#disclosurePanel").addEventListener("click", function (event) {
      if (event.target.id === "confirmDisclosure") {
        setManualDisclosure("explicitly_disclosed").catch(function (error) { showBanner(error.message, 5000); });
      }
      if (event.target.id === "clearDisclosure") {
        setManualDisclosure("unknown").catch(function (error) { showBanner(error.message, 5000); });
      }
    });
    $("#detailModal").addEventListener("click", function (event) {
      if (event.target.closest("[data-close-modal]")) {
        $("#detailModal").classList.add("hidden");
        return;
      }
      if (event.target.id === "detailLike") toggleHumanLike().catch(function (error) { showBanner(error.message, 5000); });
      if (event.target.id === "sendHumanComment") sendHumanComment().catch(function (error) { showBanner(error.message, 5000); });
      if (event.target.id === "detailReact") {
        var targetPost = state.selectedPostId;
        $("#detailModal").classList.add("hidden");
        runActorRound(targetPost).catch(function (error) { setBusy(false); showBanner(error.message, 5000); });
      }
    });
  }

  async function boot() {
    if (!api) {
      document.body.innerHTML = '<div style="padding:24px;font:14px sans-serif">此应用必须在 Float 中导入运行。</div>';
      return;
    }
    try {
      setBusy(true, "正在载入匿名账号…");
      await Promise.all([reloadState(), loadAvatarAssets()]);
      bindEvents();
      renderAll();
      if (!humanAccount()) {
        setPage("managePage");
        showBanner("首次使用：请先手动设置当前用户的匿名昵称、头像和简介。", 8000);
      }
    } catch (error) {
      console.error("[AnonymousXHS] boot failed", error);
      showBanner(error instanceof Error ? error.message : String(error));
    } finally {
      setBusy(false);
    }
  }

  if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", boot);
  else boot();
})();

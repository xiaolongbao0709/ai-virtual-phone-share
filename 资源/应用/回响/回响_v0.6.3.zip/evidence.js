(function(root,factory){
  const api=factory();
  if(typeof module!=='undefined'&&module.exports)module.exports=api;
  else root.ResonanceEvidence=api;
})(typeof globalThis!=='undefined'?globalThis:this,function(){
  const esc=value=>String(value??'').replace(/[&<>"']/g,char=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[char]));
  const svgUnits=value=>[...String(value??'')].reduce((sum,char)=>sum+(/[\u2E80-\u9FFF\uF900-\uFAFF]/.test(char)?2:1),0);
  function svgFit(value,maxUnits){
    let output='',used=0;
    for(const char of String(value??'')){
      const size=/[\u2E80-\u9FFF\uF900-\uFAFF]/.test(char)?2:1;
      if(used+size>maxUnits)return output+'…';
      output+=char;used+=size;
    }
    return output;
  }
  function svgLines(value,maxUnits,maxLines=3){
    const lines=[];let line='',used=0;
    for(const char of String(value??'')){
      const size=/[\u2E80-\u9FFF\uF900-\uFAFF]/.test(char)?2:1;
      if(used+size>maxUnits){
        lines.push(line);line=char;used=size;
        if(lines.length===maxLines){lines[maxLines-1]=svgFit(lines[maxLines-1],Math.max(1,maxUnits-1))+'…';return lines}
      }else{line+=char;used+=size}
    }
    if(line&&lines.length<maxLines)lines.push(line);
    return lines;
  }
  function barcodeSvg(x,y,width,height,seed=''){
    const source=String(seed||'0'),count=32,unit=width/count;
    return Array.from({length:count},(_,index)=>{
      const code=source.charCodeAt(index%source.length)||index,scale=(code+index)%4===0?2.2:(code+index)%3===0?1.45:.72;
      return `<rect x="${(x+index*unit).toFixed(2)}" y="${y}" width="${Math.min(unit*scale,unit*2.3).toFixed(2)}" height="${height}"/>`;
    }).join('');
  }
  function qrSvg(x,y,size,seed=''){
    const source=String(seed||'0'),cells=9,unit=size/cells;let output='';
    for(let row=0;row<cells;row++)for(let col=0;col<cells;col++){
      const finder=(row<3&&col<3)||(row<3&&col>5)||(row>5&&col<3),code=source.charCodeAt((row*cells+col)%source.length)||0;
      if(finder||((code+row*7+col*11)%3===0))output+=`<rect x="${(x+col*unit).toFixed(2)}" y="${(y+row*unit).toFixed(2)}" width="${(unit+.15).toFixed(2)}" height="${(unit+.15).toFixed(2)}"/>`;
    }
    return output;
  }
  function canonicalEvidenceType(value){
    const type=String(value||'DOCUMENT').trim().toUpperCase();
    if(/BOARDING|FLIGHT PASS/.test(type))return'boarding-pass';
    if(/TRAIN|RAIL/.test(type))return'train-ticket';
    if(/SUPERMARKET|GROCERY/.test(type))return'supermarket-receipt';
    if(/COFFEE|CAFE|CAFÉ/.test(type))return'coffee-receipt';
    if(/GAS|FUEL|PETROL/.test(type))return'gas-receipt';
    if(/REPAIR|MAINTENANCE/.test(type))return'repair-invoice';
    if(/EXPRESS|DELIVERY|COURIER|PARCEL/.test(type))return'delivery-order';
    if(/HOTEL|LODGING/.test(type))return'hotel-order';
    if(/PARKING/.test(type))return'parking-ticket';
    if(/MUSEUM|GALLERY/.test(type))return'museum-ticket';
    if(/CONCERT|PERFORMANCE|SHOW TICKET/.test(type))return'concert-ticket';
    if(/POLAROID|PHOTO|IMAGE/.test(type))return'polaroid-photo';
    if(/EMAIL|E-MAIL/.test(type))return'email';
    if(/SMS|TEXT MESSAGE/.test(type))return'sms';
    if(/OLD CHAT|CHAT RECORD|CHAT LOG/.test(type))return'old-chat';
    if(/VOICE|AUDIO TRANSCRIPT/.test(type))return'voice-transcript';
    if(/CALENDAR/.test(type))return'calendar';
    if(/COURSE|CLASS SCHEDULE|TIMETABLE/.test(type))return'course-schedule';
    if(/MEETING|MINUTES/.test(type))return'meeting-minutes';
    if(/HANDWRITTEN|HANDWRITING/.test(type))return'handwritten-note';
    if(/SHOPPING LIST|GROCERY LIST/.test(type))return'shopping-list';
    if(/APPOINTMENT|RESERVATION RECORD/.test(type))return'appointment';
    if(/MEDICAL|REGISTRATION FORM|HOSPITAL/.test(type))return'medical-form';
    if(/FORUM/.test(type))return'forum-post';
    if(/SOCIAL|STATUS POST|MOMENT/.test(type))return'social-post';
    if(/RECEIPT|BILL/.test(type))return'supermarket-receipt';
    if(/INVOICE/.test(type))return'repair-invoice';
    if(/ORDER/.test(type))return'delivery-order';
    if(/TICKET|PASS/.test(type))return'train-ticket';
    if(/NOTE/.test(type))return'handwritten-note';
    if(/LIST/.test(type))return'shopping-list';
    if(/MESSAGE/.test(type))return'sms';
    if(/POST/.test(type))return'social-post';
    return'document';
  }

  const style='<style>.tiny{font:7px ui-monospace,monospace;letter-spacing:.7px;fill:#777}.label{font:7.5px ui-monospace,monospace;letter-spacing:.5px;fill:#777}.value{font:9.5px ui-monospace,monospace;fill:#111}.medium{font:700 13px ui-monospace,monospace;fill:#111}.big{font:700 17px ui-monospace,monospace;fill:#111}.tinyInverse{font:7px ui-monospace,monospace;letter-spacing:.7px;fill:#fff}.valueInverse{font:9.5px ui-monospace,monospace;fill:#fff}.mediumInverse{font:700 13px ui-monospace,monospace;fill:#fff}.bigInverse{font:700 17px ui-monospace,monospace;fill:#fff}.line{stroke:#aaa;stroke-width:1;fill:none}.dark{fill:#111}.soft{fill:#ececec}.paper{fill:#fff}</style>';
  const t=(x,y,value,cls='value',anchor='start')=>`<text x="${x}" y="${y}" class="${cls}" text-anchor="${anchor}">${esc(value)}</text>`;
  const path=d=>`<path d="${d}" class="line"/>`;
  const fieldList=node=>(Array.isArray(node.fields)?node.fields:[]).map(field=>({label:String(field.label||''),value:String(field.value??'')})).filter(field=>field.value);
  function field(node,pattern,fallback='—'){
    const hit=fieldList(node).find(item=>pattern.test(item.label.toUpperCase()));
    return hit?.value||fallback;
  }
  const allValues=node=>fieldList(node).map(item=>item.value);
  const raw=node=>String(node.rawText||node.excerpt||node.summary||'');
  const dateTime=node=>`${svgFit(node.date||'DATE UNKNOWN',14)} · ${svgFit(node.time||'—',8)}`;

  function trainTicket(node,type){
    const route=field(node,/ROUTE|STRECKE|路线/,node.location),train=field(node,/TRAIN|车次/,'—'),seat=field(node,/SEAT|PLATZ|座位/,'—');
    const routeParts=String(route).split(/→|—>|-|–/).map(x=>x.trim()).filter(Boolean);
    return `${t(18,66,'RAIL / FAHRKARTE','medium')}${t(18,91,svgFit(routeParts[0]||route,12),'medium')}${t(229,91,svgFit(routeParts[1]||'DESTINATION',12),'medium','end')}${path('M25 110H229M25 110l8-5v10M221 105l8 5-8 5')}<circle cx="25" cy="110" r="4" fill="#111"/><circle cx="229" cy="110" r="4" fill="#fff" stroke="#111"/><path d="M244 48v248" class="line" stroke-dasharray="3 5"/>${t(18,142,'TRAIN','label')}${t(90,142,svgFit(train,18),'value')}${t(18,168,'SEAT','label')}${t(90,168,svgFit(seat,22),'value')}${t(18,194,'DEPART','label')}${t(90,194,dateTime(node),'value')}${t(18,220,'CLASS','label')}${t(90,220,'2 / STANDARD','value')}${t(278,72,'VALID','label','middle')}${t(278,102,svgFit(node.time||'—',8),'big','middle')}<g fill="#111">${qrSvg(257,128,43,node.id)}</g>${t(278,183,svgFit(train,8),'tiny','middle')}${t(278,276,'DB / ARCHIVE','tiny','middle')}<g fill="#111">${barcodeSvg(23,258,202,20,node.id)}</g>`;
  }
  function boardingPass(node,type){
    const route=field(node,/ROUTE|FROM|DESTINATION/,node.location),flight=field(node,/FLIGHT|航班/,'—'),gateRaw=field(node,/GATE|登机口/,'—');
    const gate=(gateRaw.match(/(?:GATE|登机口)\s*([A-Z0-9-]+)/i)||[])[1]||gateRaw;
    return `${t(18,65,'BOARDING PASS','medium')}${t(18,86,svgFit(route,33),'value')}${path('M18 98h294M235 48v248')}<path d="M235 48v248" class="line" stroke-dasharray="2 5"/>${t(18,123,'FLIGHT','label')}${t(82,123,svgFit(flight,16),'medium')}${t(18,151,'DATE','label')}${t(82,151,svgFit(node.date,15),'value')}${t(18,179,'BOARDING','label')}${t(82,179,svgFit(node.time||'—',9),'big')}${t(18,211,'ZONE','label')}${t(82,211,'GROUP 03','value')}${t(18,239,'SEAT','label')}${t(82,239,svgFit(field(node,/SEAT/,'—'),18),'value')}${t(274,72,'GATE','label','middle')}${t(274,111,svgFit(gate,8),'big','middle')}<g fill="#111">${qrSvg(252,139,45,node.id)}</g>${t(274,204,svgFit(flight,9),'value','middle')}${t(274,225,svgFit(node.date,10),'tiny','middle')}<g fill="#111">${barcodeSvg(249,251,50,30,node.id)}</g>`;
  }
  function supermarketReceipt(node,type){
    const values=allValues(node).slice(0,5),store=values[0]||node.location;
    return `<path d="M43 55l8-6 8 6 8-6 8 6 8-6 8 6 8-6 8 6 8-6 8 6 8-6 8 6 8-6 8 6 8-6 8 6 8-6 8 6 8-6 8 6 8-6 8 6 8-6 8 6 8-6 8 6 8-6 8 6 8-6 8 6 8-6 8 6V306H43Z" fill="#fff" stroke="#999"/>${t(165,76,svgFit(store,30),'medium','middle')}${t(165,94,'KASSENBON / RECEIPT','tiny','middle')}${t(165,112,dateTime(node),'label','middle')}${path('M58 124h214')}${values.slice(1,5).map((value,index)=>`${t(58,146+index*28,svgFit(value,31),'value')}${t(272,146+index*28,String(index+1).padStart(2,'0'),'tiny','end')}`).join('')}${path('M58 254h214')}${t(58,274,'SUMME','medium')}${t(272,274,svgFit(field(node,/TOTAL|AMOUNT|SUM|合计/,'—'),15),'medium','end')}<g fill="#111">${barcodeSvg(77,287,176,13,node.id)}</g>`;
  }
  function coffeeReceipt(node,type){
    const values=allValues(node),shop=values[0]||node.location,items=values.slice(1,4),tableRaw=field(node,/TABLE|TISCH/,'07');
    const table=(String(tableRaw).match(/([A-Z]?\d{1,3})\s*$/i)||[])[1]||svgFit(tableRaw,5);
    return `<rect x="28" y="56" width="274" height="238" rx="2" fill="#fff" stroke="#888"/>${t(44,78,'CAFÉ ORDER','medium')}${t(286,78,'PAID','label','end')}<circle cx="263" cy="111" r="27" fill="none" stroke="#111"/>${t(263,107,'TABLE','tiny','middle')}${t(263,124,table,'medium','middle')}${t(44,101,svgFit(shop,27),'value')}${t(44,120,dateTime(node),'tiny')}${path('M44 134h242')}${items.map((value,index)=>`${t(48,158+index*31,`0${index+1}`,'tiny')}${t(75,158+index*31,svgFit(value,29),'value')}`).join('')}${path('M44 249h242')}${t(44,270,'THANK YOU / DANKE','label')}${t(286,270,svgFit(node.time||'—',8),'value','end')}<circle cx="278" cy="62" r="3" fill="#111"/>`;
  }
  function gasReceipt(node,type){
    const pump=field(node,/ZAPF|PUMP|泵/,'—'),fuel=field(node,/KRAFT|FUEL|燃油/,'—'),amount=field(node,/AMOUNT|TOTAL|金额/,'—'),station=field(node,/STATION|站点/,node.location);
    return `${t(18,66,'FUEL STATION','medium')}${t(18,86,svgFit(station,35),'value')}<rect x="18" y="103" width="106" height="114" fill="#ececec" stroke="#888"/><rect x="35" y="120" width="72" height="42" fill="#fff" stroke="#888"/>${t(71,136,'PUMP','tiny','middle')}${t(71,157,svgFit(pump,7),'big','middle')}<path d="M124 124h18v66h-18M142 137c22 0 21 22 21 35v30" class="line"/>${t(190,116,'FUEL','label')}${t(190,135,svgFit(fuel,19),'medium')}${t(190,164,'TOTAL','label')}${t(190,190,svgFit(amount,14),'big')}${t(190,215,'TIME','label')}${t(190,233,dateTime(node),'value')}${path('M18 247h294')}${t(18,268,'LITRES','label')}${t(82,268,svgFit(field(node,/LITRE|LITER|升/,'—'),12),'value')}${t(190,268,'UNIT PRICE','label')}${t(312,268,svgFit(field(node,/PRICE|单价/,'—'),12),'value','end')}<g fill="#111">${barcodeSvg(171,287,141,16,node.id)}</g>`;
  }
  function repairInvoice(node,type){
    const workshop=field(node,/WORKSHOP|GARAGE|维修/,node.location),repair=field(node,/^REPAIR|^WORK(?:\s|$)|项目/,'—'),serial=field(node,/SERIAL|编号/,'—'),total=field(node,/TOTAL|AMOUNT|合计/,'—');
    const repairLines=svgLines(repair,23,2);
    return `${t(18,65,'REPAIR INVOICE','medium')}${t(312,65,'SERVICE COPY','tiny','end')}${t(18,85,svgFit(workshop,38),'value')}${path('M18 99h294M18 126h294M18 190h294M18 226h294M18 265h294M101 99v166M247 99v166')}${t(24,117,'ITEM','label')}${t(108,117,'DESCRIPTION','label')}${t(254,117,'STATUS','label')}${t(24,148,'01','tiny')}${repairLines.map((line,index)=>t(108,146+index*18,line,'value')).join('')}${t(254,148,'DONE','value')}${t(24,181,'02','tiny')}${t(108,181,'INSPECTION / TEST','value')}${t(254,181,'OK','value')}${t(24,214,'SERIAL','label')}${t(108,214,svgFit(serial,23),'value')}${t(24,250,'TOTAL','medium')}${t(312,250,svgFit(total,15),'medium','end')}<rect x="18" y="277" width="112" height="23" fill="none" stroke="#999"/>${t(74,292,'TECHNICIAN','tiny','middle')}<g fill="#111">${barcodeSvg(172,279,140,18,node.id)}</g>`;
  }
  function deliveryOrder(node,type){
    const sender=field(node,/SENDER|FROM|寄件/,'—'),recipient=field(node,/RECIPIENT|TO|收件/,'—'),tracking=field(node,/TRACK|运单/,'—'),status=field(node,/STATUS|状态/,'—');
    return `${t(18,65,'EXPRESS / DELIVERY','medium')}${t(312,65,'PRIORITY','tiny','end')}<rect x="18" y="78" width="294" height="65" fill="#fff" stroke="#999"/>${t(28,96,'FROM','label')}${t(28,116,svgFit(sender,39),'value')}${t(28,135,svgFit(node.location,39),'tiny')}<rect x="18" y="152" width="294" height="67" fill="#ececec" stroke="#999"/>${t(28,171,'DELIVER TO','label')}${t(28,193,svgFit(recipient,39),'medium')}${t(28,210,svgFit(status,39),'tiny')}<g fill="#111">${barcodeSvg(28,234,274,31,tracking+node.id)}</g>${t(165,278,svgFit(tracking,35),'medium','middle')}<rect x="247" y="84" width="52" height="47" fill="#111"/>${t(273,103,'48H','mediumInverse','middle')}${t(273,121,'TRACKED','tinyInverse','middle')}`;
  }
  function hotelOrder(node,type){
    const hotel=field(node,/HOTEL|PROPERTY|酒店/,node.location),room=field(node,/ROOM|房型/,'—'),booking=field(node,/BOOK|REFERENCE|预订/,'—'),nights=field(node,/NIGHT|入住/,'—');
    return `${t(18,65,'STAY CONFIRMATION','medium')}${t(18,87,svgFit(hotel,38),'value')}${path('M18 101h294')}<rect x="18" y="116" width="82" height="79" fill="#111"/>${t(59,141,'CHECK IN','tinyInverse','middle')}${t(59,166,svgFit(node.date,9),'mediumInverse','middle')}${t(59,183,svgFit(node.time||'—',8),'tinyInverse','middle')}<rect x="109" y="116" width="203" height="79" fill="#fff" stroke="#999"/>${t(124,136,'ROOM','label')}${t(124,157,svgFit(room,22),'medium')}${t(124,181,svgFit(nights,27),'value')}${t(18,219,'BOOKING REFERENCE','label')}${t(18,244,svgFit(booking,17),'big')}${path('M18 258h294')}${t(18,281,'GUEST','label')}${t(78,281,svgFit(field(node,/GUEST|NAME|姓名/,'L. J. Z.'),19),'value')}<path d="M273 266v31h25v-31M279 266v-8h13v8" class="line"/>`;
  }
  function parkingTicket(node,type){
    const zone=field(node,/ZONE|区域/,'—'),plate=field(node,/PLATE|车牌/,'—'),valid=field(node,/VALID|有效/,'—');
    return `<rect x="18" y="55" width="294" height="241" fill="#fff" stroke="#777"/>${t(60,118,'P','big','middle')}<rect x="29" y="69" width="62" height="62" fill="none" stroke="#111" stroke-width="3"/>${t(116,74,'PARKSCHEIN','medium')}${t(116,95,svgFit(node.location,25),'tiny')}${path('M108 108h190')}${t(116,129,'ZONE','label')}${t(188,129,svgFit(zone,16),'value')}${t(116,154,'PLATE','label')}${t(188,154,svgFit(plate,16),'medium')}${t(116,179,'VALID','label')}${t(188,179,svgFit(valid,16),'value')}${path('M29 206h269')}${t(29,228,'ISSUED','label')}${t(94,228,dateTime(node),'value')}<rect x="29" y="243" width="269" height="32" fill="#ececec"/>${t(43,264,'DISPLAY BEHIND WINDSCREEN','medium')}<g fill="#111">${barcodeSvg(222,282,76,8,node.id)}</g>`;
  }
  function museumTicket(node,type){
    const venue=field(node,/VENUE|MUSEUM|场馆/,node.location),exhibition=field(node,/EXHIBITION|展览/,'GENERAL COLLECTION'),admission=field(node,/ADMISSION|TYPE|票种/,'ADULT');
    return `<rect x="18" y="58" width="294" height="228" fill="#fff" stroke="#888"/>${t(31,80,'MUSEUM ADMISSION','medium')}${t(31,102,svgFit(venue,34),'value')}<rect x="31" y="119" width="199" height="77" fill="#ececec"/>${t(43,140,'CURRENT EXHIBITION','label')}${svgLines(exhibition,27,2).map((line,index)=>t(43,163+index*18,line,'medium')).join('')}<path d="M246 58v228" class="line" stroke-dasharray="3 5"/>${t(279,83,'ENTRY','label','middle')}${t(279,111,svgFit(node.time||'OPEN',8),'big','middle')}${t(279,134,svgFit(node.date,10),'tiny','middle')}<g fill="#111">${qrSvg(260,153,38,node.id)}</g>${t(31,221,'ADMISSION','label')}${t(31,243,svgFit(admission,25),'medium')}${path('M31 257h199')}<path d="M180 268h50M190 258v20M203 250v28M216 260v18" class="line"/>`;
  }
  function concertTicket(node,type){
    const venue=field(node,/VENUE|HALL|场馆/,node.location),program=field(node,/PROGRAM|EVENT|演出/,'—'),seat=field(node,/SEAT|座位/,'—');
    return `${t(18,65,'LIVE / CONCERT','medium')}${t(312,65,svgFit(node.date,12),'tiny','end')}${t(18,88,svgFit(venue,39),'value')}${t(18,116,svgFit(program,31),'big')}<path d="M18 132h294" class="line"/><path d="M55 246a110 90 0 0 1 220 0" fill="none" stroke="#aaa"/><path d="M77 246a88 68 0 0 1 176 0M101 246a64 45 0 0 1 128 0" class="line"/><rect x="121" y="250" width="88" height="19" fill="#111"/>${t(165,264,'STAGE','tinyInverse','middle')}${t(18,157,'DOORS','label')}${t(18,179,svgFit(node.time||'—',9),'medium')}${t(238,157,'SEAT','label')}${t(312,179,svgFit(seat,18),'medium','end')}<circle cx="165" cy="207" r="5" fill="#111"/>${t(165,199,'YOU','tiny','middle')}<g fill="#111">${barcodeSvg(18,284,294,13,node.id)}</g>`;
  }
  function polaroidPhoto(node,type){
    const caption=field(node,/CAPTION|说明/,node.excerpt||node.title),camera=field(node,/CAMERA|相机/,'CAMERA UNKNOWN');
    return `<rect x="42" y="56" width="246" height="247" fill="#fff" stroke="#888"/><rect x="56" y="71" width="218" height="170" fill="#e6e6e6" stroke="#aaa"/><path d="M56 218l57-48 36 27 43-62 82 83" class="line"/><circle cx="226" cy="111" r="19" fill="#ccc"/><path d="M68 86h31M68 86v31M262 86h-31M262 86v31" class="line"/>${t(61,263,svgFit(caption,34),'value')}${t(61,282,svgFit(node.date+' · '+node.location,37),'tiny')}${t(276,282,svgFit(camera,16),'tiny','end')}<path d="M28 68l35-18M267 310l35-18" stroke="#aaa" stroke-width="7" opacity=".45"/>`;
  }
  function email(node,type){
    const sender=field(node,/FROM|SENDER|发件/,'UNKNOWN SENDER'),subject=field(node,/SUBJECT|主题/,'(NO SUBJECT)'),lines=svgLines(raw(node),40,4);
    return `<rect x="18" y="56" width="294" height="239" rx="5" fill="#fff" stroke="#888"/><rect x="18" y="56" width="294" height="28" fill="#ececec"/>${t(31,75,'×   —   □','value')}${t(299,75,'MAIL ARCHIVE','tiny','end')}<circle cx="43" cy="111" r="14" fill="#111"/>${t(65,106,svgFit(sender,27),'value')}${t(298,106,svgFit(dateTime(node),15),'tiny','end')}${t(65,124,'TO: ARCHIVED RECIPIENT','tiny')}${path('M31 139h268')}${t(31,160,svgFit(subject,32),'medium')}${lines.map((line,index)=>t(31,190+index*20,line,'value')).join('')}${path('M31 274h268')}${t(31,289,'REPLY','tiny')}${t(92,289,'FORWARD','tiny')}${t(299,289,'•••','value','end')}`;
  }
  function sms(node,type){
    const sender=field(node,/SENDER|FROM|发送/,'UNKNOWN'),lines=svgLines(raw(node),27,4);
    return `<rect x="63" y="52" width="204" height="252" rx="24" fill="#fff" stroke="#888"/><rect x="135" y="61" width="60" height="7" rx="3" fill="#111"/>${t(165,89,svgFit(sender,22),'medium','middle')}${t(165,104,dateTime(node),'tiny','middle')}<path d="M76 114h178" class="line"/><rect x="95" y="130" width="151" height="82" rx="16" fill="#ececec"/>${lines.map((line,index)=>t(109,153+index*17,line,'value')).join('')}<path d="M102 208l-13 9 6-20" fill="#ececec"/>${t(234,228,'DELIVERED','tiny','end')}<rect x="78" y="255" width="174" height="29" rx="14" fill="none" stroke="#aaa"/>${t(92,274,'MESSAGE','tiny')}${t(236,275,'↑','medium','middle')}`;
  }
  function oldChat(node,type){
    const sender=field(node,/SENDER|ACCOUNT|用户/,'ARCHIVED USER'),lines=svgLines(raw(node),31,4);
    return `<rect x="18" y="55" width="294" height="241" fill="#f3f3f3" stroke="#888"/>${t(31,76,'CHAT LOG / READ ONLY','medium')}${t(299,76,'ARCHIVED','tiny','end')}${path('M18 88h294')}<rect x="31" y="103" width="73" height="45" fill="#dddddd"/>${t(67,122,'USER','tiny','middle')}${t(67,140,svgFit(sender,11),'value','middle')}<rect x="116" y="103" width="181" height="79" fill="#fff" stroke="#bbb"/>${lines.slice(0,3).map((line,index)=>t(128,126+index*18,line,'value')).join('')}<rect x="51" y="198" width="204" height="38" fill="#d9d9d9"/>${t(63,220,svgFit(lines[3]||'NO FURTHER MESSAGES',30),'value')}<path d="M58 236l-11 8 5-17" fill="#d9d9d9"/>${t(165,264,'— '+dateTime(node)+' —','tiny','middle')}<path d="M31 279h266" class="line" stroke-dasharray="2 4"/>${t(165,291,'END OF EXPORTED HISTORY','tiny','middle')}`;
  }
  function voiceTranscript(node,type){
    const values=allValues(node).slice(0,4),fallback=svgLines(raw(node),35,4),lines=values.length?values:fallback;
    const bars=Array.from({length:46},(_,index)=>{const h=5+((node.id.charCodeAt(index%node.id.length)+index*9)%28);return`<rect x="${52+index*5.2}" y="${102-h/2}" width="2" height="${h}" fill="#111"/>`}).join('');
    return `${t(18,65,'VOICE TRANSCRIPT','medium')}${t(312,65,'AUTO / RAW','tiny','end')}<circle cx="31" cy="102" r="17" fill="#111"/><path d="M26 94l13 8-13 8z" fill="#fff"/>${bars}${t(18,137,'00:00','tiny')}${t(312,137,'00:37','tiny','end')}${path('M18 149h294')}${lines.slice(0,4).map((line,index)=>`${t(24,174+index*29,String(index+1).padStart(2,'0'),'label')}${t(62,174+index*29,svgFit(line,38),'value')}`).join('')}${t(18,293,'LOW CONFIDENCE SEGMENTS MARKED / ARCHIVE COPY','tiny')}`;
  }
  function calendarRecord(node,type){
    const title=field(node,/TITLE|EVENT|标题/,node.title),calendar=field(node,/CALENDAR|日历/,'PRIVATE'),reminder=field(node,/REMINDER|提醒/,'NONE'),status=field(node,/STATUS|状态/,'—');
    const day=(String(node.date).match(/\d{1,2}(?!.*\d)/)||['—'])[0];
    return `<rect x="18" y="58" width="294" height="226" fill="#fff" stroke="#888"/><rect x="18" y="58" width="86" height="226" fill="#111"/>${t(61,82,'CAL','tinyInverse','middle')}${t(61,128,day,'bigInverse','middle')}${t(61,151,svgFit(node.date,11),'tinyInverse','middle')}${t(61,263,svgFit(node.time||'ALL DAY',9),'mediumInverse','middle')}${t(122,82,svgFit(calendar,24),'label')}${t(122,113,svgFit(title,17),'big')}${path('M121 129h171')}${t(122,154,'LOCATION','label')}${t(122,173,svgFit(node.location,27),'value')}${t(122,201,'REMINDER','label')}${t(207,201,svgFit(reminder,15),'value')}${t(122,229,'STATUS','label')}${t(207,229,svgFit(status,15),'medium')}${rectCheck(122,251,true)}${t(142,259,'SYNCED','tiny')}`;
  }
  function rectCheck(x,y,checked=false){return `<rect x="${x}" y="${y-9}" width="11" height="11" fill="none" stroke="#888"/>${checked?`<path d="M${x+2} ${y-4}l3 3 6-8" stroke="#111" fill="none"/>`:''}`}
  function courseSchedule(node,type){
    const course=field(node,/COURSE|CLASS|课程/,node.title),lecturer=field(node,/LECTURER|TEACHER|教师/,'—'),room=field(node,/ROOM|教室/,'—'),week=field(node,/WEEK|DAY|星期/,'—');
    const cols=[47,100,153,206,259],days=['MON','TUE','WED','THU','FRI'];
    return `${t(18,65,'COURSE SCHEDULE','medium')}${t(312,65,svgFit(week,18),'tiny','end')}<rect x="18" y="82" width="294" height="179" fill="#fff" stroke="#888"/>${days.map((day,index)=>t(cols[index]+1,99,day,'tiny','middle')).join('')}${[108,139,170,201,232].map(y=>path(`M18 ${y}h294`)).join('')}${[73,126,179,232,285].map(x=>path(`M${x} 82v179`)).join('')}<rect x="76" y="112" width="101" height="55" fill="#111"/>${svgLines(course,13,2).map((line,index)=>t(126,132+index*16,line,'valueInverse','middle')).join('')}${t(126,159,svgFit(room,13),'tinyInverse','middle')}${t(22,129,'08:00','tiny')}${t(22,160,'09:00','tiny')}${t(22,191,'10:00','tiny')}${t(22,222,'11:00','tiny')}${t(18,282,'LECTURER','label')}${t(82,282,svgFit(lecturer,15),'value')}${t(312,282,svgFit(room,11),'medium','end')}`;
  }
  function meetingMinutes(node,type){
    const topic=field(node,/TOPIC|SUBJECT|议题/,node.title),attendees=field(node,/ATTENDEE|参与/,'—'),decision=field(node,/DECISION|决定/,'—'),next=field(node,/NEXT|ACTION|下一步/,'—');
    return `${t(18,65,'MEETING MINUTES','medium')}${t(312,65,dateTime(node),'tiny','end')}${path('M18 78h294')}${t(18,98,'01 / TOPIC','label')}${t(18,119,svgFit(topic,35),'medium')}${path('M18 132h294')}${t(18,152,'02 / ATTENDEES','label')}${t(18,173,svgFit(attendees,42),'value')}${path('M18 186h294')}${t(18,206,'03 / DECISION','label')}${t(18,227,svgFit(decision,42),'value')}${path('M18 240h294')}${rectCheck(18,270,false)}${t(40,270,'NEXT ACTION','label')}${t(125,270,svgFit(next,27),'value')}${t(18,298,'RECORDER','label')}${t(85,298,'UNCONFIRMED','tiny')}${path('M202 294h110')}`;
  }
  function handwrittenNote(node,type){
    const lines=(allValues(node).length?allValues(node):svgLines(raw(node),35,5)).slice(0,5);
    return `<rect x="29" y="57" width="272" height="239" fill="#fff" stroke="#999"/><path d="M29 57h272v21H29z" fill="#e4e4e4"/><path d="M70 78v218" stroke="#bbb"/><path d="M29 111h272M29 145h272M29 179h272M29 213h272M29 247h272M29 281h272" class="line"/>${t(44,72,'HAND NOTE','tiny')}<g transform="rotate(-1 165 180)">${lines.map((line,index)=>`${t(82,105+index*34,svgFit(line,34),'value')}${index===1?'<path d="M80 110l190-4" stroke="#555"/>':''}`).join('')}</g><path d="M137 49h57v17h-57z" fill="#ccc" opacity=".55"/>${t(290,289,svgFit(node.date,12),'tiny','end')}`;
  }
  function shoppingList(node,type){
    const items=(allValues(node).length?allValues(node):svgLines(raw(node),34,6)).slice(0,6);
    return `${t(18,65,'SHOPPING LIST','medium')}${t(312,65,svgFit(node.date,13),'tiny','end')}<rect x="18" y="80" width="294" height="207" fill="#fff" stroke="#888"/>${items.map((item,index)=>`${rectCheck(32,108+index*29,index===0)}${t(55,108+index*29,svgFit(item,34),'value')}${t(296,108+index*29,String(index+1).padStart(2,'0'),'tiny','end')}${index<items.length-1?path(`M31 ${117+index*29}h267`):''}`).join('')}<rect x="18" y="80" width="7" height="207" fill="#111"/>${t(18,304,'FOUND FOLDED / LOCATION UNKNOWN','tiny')}`;
  }
  function appointmentRecord(node,type){
    const service=field(node,/SERVICE|OFFICE|服务/,node.title),reference=field(node,/REFERENCE|BOOK|编号/,'—'),counterRaw=field(node,/COUNTER|SCHALTER|柜台/,'—'),status=field(node,/STATUS|状态/,'CONFIRMED');
    const counter=(counterRaw.match(/(?:SCHALTER|COUNTER|柜台)\s*([A-Z0-9-]+)/i)||[])[1]||counterRaw;
    return `${t(18,65,'APPOINTMENT','medium')}${t(312,65,svgFit(status,15),'tiny','end')}<rect x="18" y="81" width="294" height="91" fill="#111"/>${t(33,105,'SERVICE','tinyInverse')}${t(33,132,svgFit(service,22),'bigInverse')}${t(33,154,svgFit(node.location,39),'tinyInverse')}<rect x="18" y="184" width="184" height="98" fill="#fff" stroke="#888"/>${t(31,207,'REFERENCE','label')}${t(31,236,svgFit(reference,20),'medium')}${t(31,263,dateTime(node),'value')}<rect x="214" y="184" width="98" height="98" fill="#ececec" stroke="#888"/>${t(263,207,'COUNTER','label','middle')}${t(263,242,svgFit(counter,8),'big','middle')}${t(263,266,'WAIT HERE','tiny','middle')}<g fill="#fff">${qrSvg(275,87,29,node.id)}</g>`;
  }
  function medicalForm(node,type){
    const department=field(node,/DEPARTMENT|CLINIC|科室/,node.location),patient=field(node,/PATIENT|NAME|患者/,'—'),caseValue=field(node,/CASE|TYPE|就诊/,'—'),note=field(node,/NOTE|备注/,'—');
    return `${t(18,65,'MEDICAL REGISTRATION','medium')}<rect x="274" y="52" width="38" height="38" fill="#111"/><path d="M293 59v24M281 71h24" stroke="#fff" stroke-width="4"/>${t(18,88,svgFit(department,36),'value')}${path('M18 101h294')}${t(18,124,'PATIENT','label')}${t(96,124,svgFit(patient,25),'medium')}${t(18,151,'DATE / TIME','label')}${t(96,151,dateTime(node),'value')}${t(18,178,'CASE','label')}${t(96,178,svgFit(caseValue,27),'value')}${path('M18 193h294')}${rectCheck(19,219,true)}${t(40,219,'OUTPATIENT','label')}${rectCheck(125,219,false)}${t(146,219,'INPATIENT','label')}${rectCheck(226,219,false)}${t(247,219,'URGENT','label')}${t(18,247,'NOTE','label')}${t(18,267,svgFit(note,43),'value')}${path('M18 282h192')}${t(218,289,'SIGN','tiny')}${path('M245 286h67')}`;
  }
  function forumPost(node,type){
    const sender=field(node,/SENDER|USER|AUTHOR|用户/,'ARCHIVED USER'),lines=svgLines(raw(node),29,5);
    return `<rect x="18" y="55" width="294" height="241" fill="#fff" stroke="#888"/><rect x="18" y="55" width="294" height="30" fill="#111"/>${t(30,75,'FORUM / THREAD VIEW','mediumInverse')}${t(299,75,'2009 MODE','tinyInverse','end')}<rect x="18" y="85" width="78" height="181" fill="#ececec"/>${t(57,108,'USER','tiny','middle')}${t(57,130,svgFit(sender,11),'value','middle')}<circle cx="57" cy="158" r="17" fill="#bbb"/>${t(57,188,'POSTS 047','tiny','middle')}${t(57,204,'OFFLINE','tiny','middle')}${t(108,105,'# 00421','tiny')}${t(299,105,dateTime(node),'tiny','end')}${lines.map((line,index)=>t(108,132+index*20,line,'value')).join('')}${path('M108 242h188')}${t(108,260,'SIGNATURE: ROTOR / MACHINING','tiny')}${rectCheck(108,283,false)}${t(130,283,'QUOTE','tiny')}${t(299,283,'REPLY 0','tiny','end')}`;
  }
  function socialPost(node,type){
    const sender=field(node,/SENDER|USER|AUTHOR|用户/,'UNKNOWN'),lines=svgLines(raw(node),36,3);
    return `<rect x="35" y="55" width="260" height="242" fill="#fff" stroke="#888"/><circle cx="57" cy="82" r="13" fill="#111"/>${t(78,79,svgFit(sender,20),'medium')}${t(78,94,svgFit(dateTime(node),20),'tiny')}${t(280,83,'•••','value','end')}${lines.map((line,index)=>t(48,122+index*18,line,'value')).join('')}<rect x="48" y="169" width="234" height="77" fill="#e4e4e4"/><path d="M48 238l55-42 31 23 41-37 55 56" class="line"/><circle cx="243" cy="190" r="13" fill="#c7c7c7"/>${path('M48 259h234')}${t(53,279,'♡  0','value')}${t(121,279,'□  0','value')}${t(191,279,'↗','value')}${t(280,279,'⌑','value','end')}`;
  }
  function documentLayout(node,type){
    const fields=fieldList(node).slice(0,6);
    return `${t(18,65,svgFit(type,32),'medium')}${t(312,65,svgFit(node.date,15),'tiny','end')}${path('M18 80h294')}${fields.map((item,index)=>`${t(20,107+index*31,svgFit(item.label,12).toUpperCase(),'label')}${t(112,107+index*31,svgFit(item.value,30),'value')}`).join('')}<g fill="#111">${barcodeSvg(184,278,128,20,node.id)}</g>`;
  }

  const renderers={
    'train-ticket':trainTicket,'boarding-pass':boardingPass,'supermarket-receipt':supermarketReceipt,'coffee-receipt':coffeeReceipt,'gas-receipt':gasReceipt,'repair-invoice':repairInvoice,'delivery-order':deliveryOrder,'hotel-order':hotelOrder,'parking-ticket':parkingTicket,'museum-ticket':museumTicket,'concert-ticket':concertTicket,'polaroid-photo':polaroidPhoto,email,sms,'old-chat':oldChat,'voice-transcript':voiceTranscript,calendar:calendarRecord,'course-schedule':courseSchedule,'meeting-minutes':meetingMinutes,'handwritten-note':handwrittenNote,'shopping-list':shoppingList,appointment:appointmentRecord,'medical-form':medicalForm,'forum-post':forumPost,'social-post':socialPost,document:documentLayout
  };
  function evidenceSvg(node){
    const type=String(node.evidenceType||'DOCUMENT').toUpperCase(),layout=canonicalEvidenceType(type),renderer=renderers[layout]||documentLayout;
    const header=`${style}${t(18,27,'EVIDENCE '+svgFit(String(node.id||'').slice(-5).toUpperCase(),8),'medium')}${t(312,27,svgFit(node.sourceStatus||'来源不明',14),'tiny','end')}${path('M16 42h298')}`;
    return `<svg viewBox="0 0 330 330" role="img" aria-label="${esc(svgFit(type,30))}" data-layout="${layout}"><rect x="1" y="1" width="328" height="328" fill="#fff" stroke="#777"/>${header}${renderer(node,type)}${t(312,321,'RESONANCE ARCHIVE','tiny','end')}</svg>`;
  }
  return{svgUnits,svgFit,svgLines,barcodeSvg,canonicalEvidenceType,evidenceSvg};
});

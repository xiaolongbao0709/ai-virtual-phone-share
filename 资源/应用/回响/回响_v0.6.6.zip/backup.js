(function(root,factory){
  const api=factory();
  if(typeof module==='object'&&module.exports)module.exports=api;
  root.ResonanceBackup=api;
})(typeof globalThis!=='undefined'?globalThis:this,function(){
  'use strict';
  const FORMAT='resonance.archive.backup';
  const VERSION=1;
  const LIMIT=500; // The host silently caps db.list at 500, without pagination.
  const COLLECTIONS=Object.freeze([
    'resonance_nodes','resonance_memories','resonance_triggers',
    'resonance_blindspots','resonance_conflicts','resonance_revisits',
    'resonance_profiles','resonance_testimonies','resonance_versions',
    'resonance_traces','settings'
  ]);
  const isObject=x=>x!==null&&typeof x==='object'&&!Array.isArray(x);
  function rowsFrom(value){
    if(Array.isArray(value))return value;
    if(Array.isArray(value?.items))return value.items;
    if(Array.isArray(value?.data))return value.data;
    throw Error('数据库返回的记录格式无法识别，已中止备份');
  }
  function validateRows(name,rows){
    if(!Array.isArray(rows))throw Error(`${name} 缺少记录数组`);
    if(rows.length>=LIMIT)throw Error(`${name} 达到小手机每次最多读取 ${LIMIT} 条的上限，无法保证完整备份；未执行操作`);
    const keys=new Set();
    for(const row of rows){
      if(!isObject(row)||typeof row.id!=='string'||!row.id.trim())throw Error(`${name} 存在没有有效 id 的记录`);
      if(keys.has(row.id))throw Error(`${name} 存在重复 id：${row.id}`);
      keys.add(row.id);
    }
    return rows;
  }
  function checksum(value){let hash=0x811c9dc5;for(let i=0;i<value.length;i++){hash^=value.charCodeAt(i);hash=Math.imul(hash,0x01000193)}return`fnv1a32-${(hash>>>0).toString(16).padStart(8,'0')}-${value.length}`}
  async function readAll(db){
    if(!db?.list)throw Error('小手机未提供数据库读取能力');
    const data={};
    for(const name of COLLECTIONS){
      const result=await db.list(name,{limit:LIMIT});
      data[name]=validateRows(name,rowsFrom(result));
    }
    return data;
  }
  function makeBackup(data){
    const snapshot={};
    for(const name of COLLECTIONS)snapshot[name]=validateRows(name,data[name]);
    const counts=Object.fromEntries(COLLECTIONS.map(name=>[name,snapshot[name].length]));
    return{format:FORMAT,version:VERSION,appId:'resonance.archive',createdAt:new Date().toISOString(),counts,checksum:checksum(JSON.stringify(snapshot)),collections:snapshot};
  }
  function parseBackup(raw){
    let file;
    try{file=typeof raw==='string'?JSON.parse(raw):raw}catch{throw Error('文件不是有效的 JSON 备份')}
    if(!isObject(file)||file.format!==FORMAT||file.appId!=='resonance.archive')throw Error('这不是《回响》的备份文件');
    if(file.version!==VERSION)throw Error(`不支持此备份版本：${String(file.version)}`);
    if(!isObject(file.collections))throw Error('备份文件缺少档案数据');
    const actual=Object.keys(file.collections);
    if(actual.length!==COLLECTIONS.length||actual.some(name=>!COLLECTIONS.includes(name)))throw Error('备份的档案类型不完整，已中止恢复');
    for(const name of COLLECTIONS){validateRows(name,file.collections[name]);if(file.counts?.[name]!==file.collections[name].length)throw Error(`${name} 的记录数量校验失败，已中止恢复`)}
    if(file.checksum!==checksum(JSON.stringify(file.collections)))throw Error('备份完整性校验失败，文件可能不完整或已被修改');
    return file;
  }
  function count(data){return COLLECTIONS.reduce((sum,name)=>sum+data[name].length,0)}
  function planRestore(current,incoming,mode){
    if(!['merge','replace'].includes(mode))throw Error('未知恢复方式');
    const result={};
    for(const name of COLLECTIONS){
      const old=validateRows(name,current[name]),fresh=validateRows(name,incoming[name]);
      if(mode==='replace'){result[name]=fresh;continue}
      const seen=new Set(old.map(row=>row.id));
      const missing=fresh.filter(row=>!seen.has(row.id));
      result[name]=old.concat(missing);
      if(result[name].length>=LIMIT)throw Error(`${name} 合并后会达到读取上限，已中止恢复；请另选方式`);
    }
    return result;
  }
  async function applySnapshot(db,current,target){
    if(!db?.create||!db?.delete)throw Error('小手机未提供完整数据库写入能力');
    for(const name of COLLECTIONS){
      if(JSON.stringify(current[name])===JSON.stringify(target[name]))continue;
      // db.create prepends. Rebuild in reverse so record order is restored too.
      for(const row of current[name])await db.delete(name,row.id);
      for(const row of [...target[name]].reverse())await db.create(name,row);
    }
  }
  async function restore(db,file,mode){
    const parsed=parseBackup(file);
    const current=await readAll(db);
    const target=planRestore(current,parsed.collections,mode);
    try{await applySnapshot(db,current,target)}catch(error){
      // The SDK has no transactions. Attempt to reconstruct the pre-import snapshot.
      try{const after=await readAll(db);await applySnapshot(db,after,current)}
      catch(rollback){throw Error(`恢复中断，自动回滚也失败：${error.message}；${rollback.message}。请保留原备份文件`)}
      throw Error(`恢复中断，已尝试还原操作前状态：${error.message}`);
    }
    return{before:count(current),after:count(target),imported:count(parsed.collections)};
  }
  return{FORMAT,VERSION,LIMIT,COLLECTIONS,readAll,makeBackup,parseBackup,planRestore,restore,count};
});

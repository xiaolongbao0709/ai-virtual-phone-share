(() => {
  "use strict";
  const A = window.AiPhone || window.AiPhoneApp;
  const $ = s => document.querySelector(s);
  const $$ = s => [...document.querySelectorAll(s)];

  const state = {
    chars: [],
    characterId: "",
    purpose: "return",
    mode: "auto",
    messages: [],
    events: [],
    routes: [],
    selectedEventKey: "",
    selectedRouteId: "",
    selectedMessageIds: new Set(),
    timingMessageId: "",
    timingManual: false,
    anchorTime: null,
    autoTiming: null,
    autoBasis: null,
    lastPreview: null,
    triggerDirty: false,
    editingRouteId: ""
  };

  const pad = n => String(n).padStart(2, "0");
  const localDateKey = d => `${d.getFullYear()}-${pad(d.getMonth()+1)}-${pad(d.getDate())}`;
  const hm = d => `${pad(d.getHours())}:${pad(d.getMinutes())}`;
  const fmt = d => `${localDateKey(d)} ${hm(d)}`;
  const addMin = (d,n) => new Date(d.getTime()+n*60000);
  const safeText = v => String(v ?? "").trim();
  const norm = s => safeText(s).replace(/\s+/g, "");
  const clamp = (v,a,b) => Math.max(a, Math.min(b, v));
  const randInt = (a,b) => {
    const lo = Math.ceil(Math.min(a,b));
    const hi = Math.floor(Math.max(a,b));
    return lo + Math.floor(Math.random() * (hi-lo+1));
  };
  const asDate = (dateKey,time) => {
    const m = String(dateKey||"").match(/^(\d{4})-(\d{2})-(\d{2})$/);
    const t = String(time||"").match(/^(\d{1,2}):(\d{2})$/);
    return (!m||!t) ? null : new Date(+m[1], +m[2]-1, +m[3], +t[1], +t[2], 0, 0);
  };
  const parseLocalInput = v => v ? new Date(v) : null;
  const dateTimeLocalValue = d => `${localDateKey(d)}T${pad(d.getHours())}:${pad(d.getMinutes())}`;
  const randomDate = (start,end) => new Date(randInt(start.getTime(), end.getTime()));
  const charName = id => state.chars.find(c=>c.id===id)?.name || id || "未命名角色";
  async function toast(message){ try{ await A.ui.toast(message); }catch{} }
  async function dbList(collection,limit=300){ try{return await A.db.list(collection,{limit});}catch{return [];} }

  function roleLabel(m){ return m?.role === "assistant" ? charName(state.characterId) : "你"; }
  function messageById(id){ return state.messages.find(m=>String(m.id)===String(id)); }
  function selectedMessages(){
    return state.messages
      .filter(m => state.selectedMessageIds.has(String(m.id)))
      .sort((a,b) => Date.parse(a.createdAt||0)-Date.parse(b.createdAt||0));
  }
  function displayMessageLine(m){ return `${roleLabel(m)}：${safeText(m.content)}`; }
  function looksLikeTimingClue(text){
    const s=norm(text);
    return /(洗澡|冲澡|换衣|吃饭|做饭|收拾|整理|休息|睡觉|午睡|打球|篮球|足球|羽毛球|网球|健身|运动|训练|跑步|游泳|瑜伽|开会|会议|上课|下课|电影|演出|工作|加班|下班|回家|到家|通勤|路上|开车|出发|到公司|回公司|回宿舍|到宿舍|忙完|结束后|完了找|完再|出来找|出来再|待会|等会|晚点|之后|以后|再聊|找你|联系你|分钟后|小时后|明天|今晚|晚上|下午|上午|早上)/.test(s);
  }
  function suggestTimingMessage(){
    const picked=selectedMessages();
    if(!picked.length) return null;
    if(state.purpose==="return"){
      return picked[picked.length-1];
    }
    const firstPickedAt=Date.parse(picked[0].createdAt||0);
    const priorAssistants=state.messages
      .filter(m=>m.role==="assistant" && Date.parse(m.createdAt||0)<=firstPickedAt)
      .sort((a,b)=>Date.parse(b.createdAt||0)-Date.parse(a.createdAt||0));
    return priorAssistants.find(m=>looksLikeTimingClue(m.content)) || priorAssistants[0] || picked[0];
  }
  function renderTimingMessageSelect(){
    const sel=$("#timingMessage"); if(!sel)return;
    const current=state.timingMessageId; sel.innerHTML="";
    for(const m of [...state.messages].sort((a,b)=>Date.parse(b.createdAt||0)-Date.parse(a.createdAt||0))){
      const o=document.createElement("option"); o.value=String(m.id);
      const t=m.createdAt?new Date(m.createdAt).toLocaleTimeString([], {hour:"2-digit",minute:"2-digit"}):"";
      const text=safeText(m.content).replace(/\s+/g," ").slice(0,58);
      o.textContent=`${roleLabel(m)} · ${t} · ${text}`; sel.appendChild(o);
    }
    if(current && state.messages.some(m=>String(m.id)===String(current))) sel.value=String(current);
    else if(sel.options.length) state.timingMessageId=sel.value;
  }
  function applyTimingMessage(m){
    state.timingMessageId=m?String(m.id):"";
    const sel=$("#timingMessage"); if(sel && state.timingMessageId) sel.value=state.timingMessageId;
    const d=m?.createdAt?new Date(m.createdAt):null;
    state.anchorTime=d&&!Number.isNaN(d.getTime())?d:null;
    const info=$("#anchorInfo");
    if(state.anchorTime && m){
      const pickedIds=new Set([...state.selectedMessageIds].map(String));
      const split=!pickedIds.has(String(m.id));
      const purposeText=state.purpose==="reply"?"待补回复":"约定相关消息";
      info.innerHTML=`<strong>计时起点：</strong>${fmt(state.anchorTime)} · ${roleLabel(m)}<br>${split?`${purposeText}与时间依据已分开。`:"当前时间依据来自已选消息。"} 相对“10分钟后 / 练完 / 洗完”等表达都从这条消息的真实时间起算。`;
    }else info.textContent="还没有可用的时间依据。";
  }
  function autoChooseTimingMessage(){
    state.timingManual=false;
    const m=suggestTimingMessage(); applyTimingMessage(m);
    estimateAuto(); refreshDefaultTriggerReason(true);
  }

  function syncCalendarSelectionToAnchor(){
    if(!state.anchorTime)return;
    const x=calendarAt(state.anchorTime);
    if(!x)return;
    state.selectedEventKey=x.key;
    $$("input[name='event']").forEach(r=>r.checked=r.value===x.key);
  }

  function updateSourceFromSelection(){
    const picked = selectedMessages();
    $("#sourceText").value = picked.map(displayMessageLine).filter(Boolean).join("\n");
    if(!picked.length){
      state.anchorTime=null;
      state.autoBasis=null;
    }else{
      const last=picked[picked.length-1];
      const d=last?.createdAt?new Date(last.createdAt):null;
      state.anchorTime=d&&!Number.isNaN(d.getTime())?d:null;
      const info=$("#anchorInfo");
      if(info && state.anchorTime){
        info.innerHTML=state.purpose==="reply"
          ?`<strong>消息时间：</strong>${fmt(state.anchorTime)}<br>应用会优先检查这个时间点角色是否正在日程中；找不到明确依据时不会硬猜。`
          :`<strong>参考时间：</strong>${fmt(state.anchorTime)}<br>自动估时会结合你选中的聊天内容、日程、路线或生活事件来判断。`;
      }
      syncCalendarSelectionToAnchor();
    }
    state.triggerDirty = false;
    estimateAuto();
    refreshDefaultTriggerReason(true);
  }

  function updatePurposeCopy(){
    const isReply=state.purpose==="reply";
    const listLabel=$("#messageListLabel");
    const sourceLabel=$("#sourceLabel");
    const hint=$("#purposeHint");
    if(listLabel) listLabel.textContent=isReply?"选想让他稍后接回的 USER 消息（可多选）":"选与‘稍后回来’有关的聊天（可多选）";
    if(sourceLabel) sourceLabel.textContent=isReply?"待补回复":"本次回来依据";
    const source=$("#sourceText");
    if(source) source.placeholder=isReply?"例如：我吃饭了 / 我到家了。":"例如：我先去洗澡，出来找你 / 九点再聊。";
    if(hint) hint.textContent=isReply
      ?"补上回复：你只负责选想让角色之后自然接回的消息。什么时候适合回来，应用再根据日程或已有状态判断。"
      :"如约回来：适合洗澡后、打球后、到家后、开完会、约定时间到了等本来就会再次联系的情况。";
    const autoTitle=$("#autoTitle");
    if(autoTitle) autoTitle.textContent=isReply?"自动判断":"自动估时";
    const autoSub=$("#autoSub");
    if(autoSub) autoSub.textContent=isReply
      ?"优先看你所选 USER 消息发送时角色是否正在日程中；如果聊天里有明确的忙碌/离开状态，也会作为参考。找不到可靠依据时不会硬猜。"
      :"根据所选聊天里的明确时间、日程、常用路线和生活事件估算合适的回来时间。";
  }

  function renderMessageList(){
    const host=$("#messages"); if(!host)return;
    host.innerHTML="";
    const rows=state.purpose==="reply"?state.messages.filter(m=>m.role==="user"):state.messages;
    if(!rows.length){ host.innerHTML=`<div class="empty">${state.purpose==="reply"?"最近没有可选的 USER 消息。":"还没有可选的聊天消息。"}</div>`; return; }
    for(const m of rows){
      const label=document.createElement("label"); label.className="msg";
      const cb=document.createElement("input"); cb.type="checkbox"; cb.dataset.mid=String(m.id); cb.checked=state.selectedMessageIds.has(String(m.id));
      const box=document.createElement("div"), head=document.createElement("div"), text=document.createElement("div"), time=document.createElement("div");
      head.className="msgHead"; head.textContent=roleLabel(m);
      text.className="msgText"; text.textContent=safeText(m.content);
      time.className="msgTime"; time.textContent=m.createdAt?new Date(m.createdAt).toLocaleString():"";
      box.append(head,text,time); label.append(cb,box); host.appendChild(label);
      cb.onchange=()=>{
        if(cb.checked) state.selectedMessageIds.add(String(m.id)); else state.selectedMessageIds.delete(String(m.id));
        updateSourceFromSelection();
      };
    }
  }

  function setPurpose(value){
    state.purpose=value==="reply"?"reply":"return";
    if($("#purpose")) $("#purpose").value=state.purpose;
    $$("input[name='purposeChoice']").forEach(r=>r.checked=r.value===state.purpose);
    state.selectedMessageIds.clear();
    state.timingMessageId=""; state.timingManual=false; state.anchorTime=null; state.autoTiming=null; state.autoBasis=null; state.lastPreview=null; state.triggerDirty=false;
    if($("#sourceText")) $("#sourceText").value="";
    if($("#anchorInfo")) $("#anchorInfo").textContent="先选择聊天内容。";
    updatePurposeCopy();
    renderMessageList();
    estimateAuto();
    refreshDefaultTriggerReason(true);
  }

  async function loadCharacters(){
    try{ state.chars = await A.characters.list(); }catch{ state.chars=[]; }
    const sel=$("#character"); sel.innerHTML="";
    for(const c of state.chars){
      const o=document.createElement("option"); o.value=c.id; o.textContent=c.name||c.id; sel.appendChild(o);
    }
    state.characterId = sel.value || state.chars[0]?.id || "";
  }

  async function loadMessages(){
    const host=$("#messages"); host.innerHTML='<div class="empty">读取中……</div>';
    state.selectedMessageIds.clear(); state.timingMessageId=""; state.timingManual=false; state.anchorTime=null; $("#sourceText").value="";
    if(!state.characterId){ host.innerHTML='<div class="empty">没有角色。</div>'; return; }
    try{
      const result=await A.chat.readHistory({characterId:state.characterId,limit:80});
      state.messages=(result?.messages||[])
        .filter(m=>(m.role==="assistant"||m.role==="user") && safeText(m.content) && !m.isRetracted)
        .slice(-50).reverse();
      updatePurposeCopy();
      renderMessageList();
    }catch(e){ host.innerHTML=`<div class="empty">聊天历史读取失败：${e.message||e}</div>`; }
  }

  function eventKey(item,idx){return `${item.date||""}|${item.startTime||""}|${item.endTime||""}|${item.title||""}|${idx}`;}
  async function loadEvents(){
    const host=$("#events"); host.innerHTML='<div class="empty">读取中……</div>';
    if(!state.characterId){ host.innerHTML='<div class="empty">没有角色。</div>'; return; }
    try{
      const week=await A.calendar.read({ownerType:"character",ownerId:state.characterId,date:localDateKey(new Date())});
      const items=Array.isArray(week?.plan?.items)?week.plan.items:[];
      const now=new Date();
      state.events=items.map((item,idx)=>({item,key:eventKey(item,idx)}))
        .filter(x=>{
          const s=asDate(x.item.date,x.item.startTime),e=asDate(x.item.date,x.item.endTime);
          return (e&&e>=addMin(now,-720)) || (s&&s>=now);
        })
        .sort((a,b)=>(asDate(a.item.date,a.item.startTime)?.getTime()||0)-(asDate(b.item.date,b.item.startTime)?.getTime()||0))
        .slice(0,30);
      const ref=state.anchorTime||now;
      const current=state.events.find(x=>{const s=asDate(x.item.date,x.item.startTime),e=asDate(x.item.date,x.item.endTime);return s&&e&&s<=ref&&e>=ref;});
      state.selectedEventKey=(current||state.events[0])?.key||"";
      host.innerHTML="";
      if(!state.events.length){ host.innerHTML='<div class="empty">近期没有可用日程。</div>'; return; }
      for(const x of state.events){
        const row=document.createElement("label"); row.className="event";
        const radio=document.createElement("input"); radio.type="radio"; radio.name="event"; radio.value=x.key; radio.checked=x.key===state.selectedEventKey;
        const box=document.createElement("div"),title=document.createElement("div"),meta=document.createElement("div");
        title.className="eventTitle"; title.textContent=x.item.title||"未命名日程";
        meta.className="eventMeta"; meta.textContent=`${x.item.date||""} ${x.item.startTime||"??"}-${x.item.endTime||"??"}${x.item.location?` · ${x.item.location}`:""}`;
        box.append(title,meta); row.append(radio,box); host.appendChild(row);
        radio.onchange=()=>{ state.selectedEventKey=x.key; refreshDefaultTriggerReason(); };
      }
    }catch(e){ host.innerHTML=`<div class="empty">日历读取失败：${e.message||e}</div>`; }
  }

  async function loadRoutes(){
    state.routes=(await dbList("routes",300))
      .filter(r=>["0.5","0.6"].includes(String(r.version)) && r.characterId===state.characterId)
      .sort((a,b)=>String(a.from).localeCompare(String(b.from),"zh-CN")||String(a.to).localeCompare(String(b.to),"zh-CN"));
    renderRoutes(); renderRouteSelect();
  }

  function renderRouteSelect(){
    const sel=$("#routeSelect"); sel.innerHTML="";
    if(!state.routes.length){ const o=document.createElement("option");o.value="";o.textContent="暂无常用路线";sel.appendChild(o);state.selectedRouteId="";return; }
    for(const r of state.routes){
      const o=document.createElement("option");o.value=r.id;o.textContent=`${r.from} → ${r.to} · ${r.min}-${r.max} 分钟`;sel.appendChild(o);
    }
    if(state.selectedRouteId && state.routes.some(r=>r.id===state.selectedRouteId)) sel.value=state.selectedRouteId;
    state.selectedRouteId=sel.value;
  }

  function renderRoutes(){
    const host=$("#routeList"); host.innerHTML="";
    if(!state.routes.length){ host.innerHTML='<div class="empty">这个角色还没有常用路线。先只存真正高频的几条就够了。</div>'; return; }
    for(const r of state.routes){
      const box=document.createElement("div");box.className="routeBox";
      const top=document.createElement("div");top.className="routeTop";
      const name=document.createElement("div");name.className="routeName";name.textContent=`${r.from} → ${r.to}`;
      const info=document.createElement("div");info.className="routeInfo";info.textContent=`通常 ${r.min}～${r.max} 分钟`;
      top.append(name);box.append(top,info);
      const acts=document.createElement("div");acts.className="routeActions";
      const edit=document.createElement("button");edit.className="tiny";edit.textContent="编辑";edit.onclick=()=>startEditRoute(r);
      const del=document.createElement("button");del.className="tiny danger";del.textContent="删除";del.onclick=()=>deleteRoute(r);
      acts.append(edit,del);box.append(acts);host.appendChild(box);
    }
  }

  function startEditRoute(r){
    state.editingRouteId=r.id; $("#routeFrom").value=r.from; $("#routeTo").value=r.to; $("#routeMin").value=r.min; $("#routeMax").value=r.max;
    $("#saveRoute").textContent="保存修改"; $("#cancelRouteEdit").hidden=false;
  }
  function cancelEditRoute(){
    state.editingRouteId=""; $("#routeFrom").value=""; $("#routeTo").value=""; $("#routeMin").value=25; $("#routeMax").value=40;
    $("#saveRoute").textContent="添加常用路线"; $("#cancelRouteEdit").hidden=true;
  }
  async function saveRoute(){
    try{
      const from=safeText($("#routeFrom").value),to=safeText($("#routeTo").value),min=+$("#routeMin").value,max=+$("#routeMax").value;
      if(!from||!to) throw new Error("起点和终点都要填。");
      if(!Number.isFinite(min)||!Number.isFinite(max)||min<1||max<min) throw new Error("路线时间范围不对。");
      if(state.editingRouteId){
        await A.db.update("routes",state.editingRouteId,{from,to,min,max,characterId:state.characterId,version:"0.6"}); await toast("路线已更新");
      }else{
        await A.db.create("routes",{characterId:state.characterId,from,to,min,max,version:"0.6"}); await toast("常用路线已添加");
      }
      cancelEditRoute(); await loadRoutes(); estimateAuto(); refreshDefaultTriggerReason();
    }catch(e){ await toast(`保存失败：${e.message||e}`); }
  }
  async function deleteRoute(r){
    try{ await A.db.delete("routes",r.id); if(state.selectedRouteId===r.id)state.selectedRouteId=""; await loadRoutes(); await toast("路线已删除"); estimateAuto(); }
    catch(e){ await toast(`删除失败：${e.message||e}`); }
  }

  const eventSemantic=[
    {name:"健身",event:/(健身|运动|训练|跑步|游泳|瑜伽|篮球|足球|羽毛球|网球|球赛|打球)/,text:/(练完|健身完|运动完|训练完|跑完|游完|瑜伽完|结束训练|练完找|打球|篮球|足球|羽毛球|网球|球赛)/},
    {name:"会议",event:/(会议|开会|例会|产品会|客户会)/,text:/(开完会|散会|会议结束|会结束|会后|开完再)/},
    {name:"上课",event:/(上课|课程|课堂|讲课)/,text:/(下课|上完课|课结束|讲完课)/},
    {name:"电影/演出",event:/(电影|演出|音乐会|话剧|展映)/,text:/(散场|看完电影|电影结束|演出结束|看完演出)/},
    {name:"工作",event:/(工作|公司|办公|加班)/,text:/(下班|收工|工作结束|忙完工作|忙完)/}
  ];

  const lifestyleRules=[
    {name:"换衣服",re:/(换衣|换完衣服|换好衣服|更衣)/,buckets:[{w:18,min:4,max:7},{w:62,min:7,max:12},{w:20,min:12,max:18}]},
    {name:"洗澡",re:/(洗澡|冲澡|淋浴|洗完澡|冲完澡)/,buckets:[{w:15,min:14,max:22},{w:65,min:22,max:35},{w:20,min:35,max:50}]},
    {name:"吃饭",re:/(吃饭|吃完饭|午饭|晚饭|早餐|用餐)/,buckets:[{w:15,min:20,max:30},{w:65,min:30,max:45},{w:20,min:45,max:65}]},
    {name:"做饭再吃",re:/(做饭|做菜|下厨)/,buckets:[{w:12,min:35,max:50},{w:62,min:50,max:75},{w:26,min:75,max:105}]},
    {name:"收拾整理",re:/(收拾|整理|弄完东西|打扫)/,buckets:[{w:20,min:8,max:15},{w:65,min:15,max:30},{w:15,min:30,max:45}]},
    {name:"买东西/短暂外出",re:/(买东西|便利店|超市|取快递|拿快递)/,buckets:[{w:18,min:15,max:25},{w:62,min:25,max:45},{w:20,min:45,max:70}]},
    {name:"短暂休息",re:/(休息一下|歇会|眯一会|小睡|午睡)/,buckets:[{w:25,min:20,max:35},{w:55,min:35,max:60},{w:20,min:60,max:95}]}
  ];

  function timeTendency(text){
    const s=norm(text);
    if(/(冲一下|简单洗|很快|快点|抓紧|赶时间|马上回来|一会儿就好|随便冲冲)/.test(s)) return "fast";
    if(/(多洗会|多洗一会|泡一会|泡会儿|慢慢来|不着急|久一点|多待会|多待一会)/.test(s)) return "slow";
    return "normal";
  }

  function weightedBucket(buckets,tendency="normal"){
    let arr=buckets.map(x=>({...x}));
    if(tendency==="fast") arr=arr.map((x,i)=>({...x,w:x.w*(i===0?3:i===1?0.85:0.25)}));
    if(tendency==="slow") arr=arr.map((x,i)=>({...x,w:x.w*(i===2?3:i===1?0.85:0.25)}));
    const total=arr.reduce((s,x)=>s+x.w,0); let r=Math.random()*total;
    for(const x of arr){ r-=x.w; if(r<=0)return x; }
    return arr[arr.length-1];
  }

  function makeRelativeWindow(anchor,min,max,label,why,meta={}){
    const now=new Date(), start=addMin(anchor,min), end=addMin(anchor,max);
    if(end<=now) throw new Error("按原消息时间计算，这个预计联系窗口已经过去了。请改用“我来改”。");
    const usableStart=start<addMin(now,1)?addMin(now,1):start;
    return {source:"relative",sourceLabel:label,windowStart:usableStart,windowEnd:end,runAt:randomDate(usableStart,end),why,...meta};
  }

  function explicitDuration(text,anchor){
    const s=norm(text); let m=s.match(/(\d{1,3})分钟(?:后|以后|之后|再)?/);
    if(m){ const n=+m[1]; if(n>0&&n<=720)return makeRelativeWindow(anchor,Math.max(1,n-2),n+6,`原话里的 ${n} 分钟`,`从时间依据消息的真实时间 ${hm(anchor)} 开始计算，再做很小的自然浮动。`,{kind:"explicit"}); }
    if(/半个?小时/.test(s)) return makeRelativeWindow(anchor,25,40,"原话里的半小时",`从时间依据消息的真实时间 ${hm(anchor)} 开始计算。`,{kind:"explicit"});
    m=s.match(/(\d{1,2})(?:个)?小时(?:后|以后|之后|再)?/);
    if(m){ const n=+m[1]*60; if(n>0&&n<=720)return makeRelativeWindow(anchor,Math.max(1,n-5),n+15,`原话里的 ${m[1]} 小时`,`从时间依据消息的真实时间 ${hm(anchor)} 开始计算。`,{kind:"explicit"}); }
    return null;
  }

  function explicitClock(text,anchor){
    const s=norm(text);
    const m=s.match(/(明天|今晚|晚上|下午|上午|早上)?(\d{1,2})(?:[:：点时](\d{1,2})?)?(?:点半)?/);
    if(!m) return null;
    if(!/(点|[:：]|明天|今晚|晚上|下午|上午|早上)/.test(m[0])) return null;
    let h=+m[2], minute=m[3]!==undefined&&m[3]!==""?+m[3]:0;
    if(/点半/.test(m[0])) minute=30;
    const part=m[1]||"";
    if((part==="下午"||part==="晚上"||part==="今晚")&&h<12)h+=12;
    if(part==="上午"||part==="早上"){ if(h===12)h=0; }
    if(h>23||minute>59)return null;
    const target=new Date(anchor); target.setHours(h,minute,0,0);
    if(part==="明天") target.setDate(target.getDate()+1);
    else if(target<=anchor && !part) return null;
    const now=new Date();
    const start=addMin(target,-3),end=addMin(target,8);
    if(end<=now)return null;
    const usable=start<addMin(now,1)?addMin(now,1):start;
    return {source:"clock",sourceLabel:`原话里的明确时间 ${hm(target)}`,windowStart:usable,windowEnd:end,runAt:randomDate(usable,end),why:"原话给出了明确钟点，只做很小的自然浮动。",kind:"explicit_clock"};
  }

  function naturalCalendarWindow(item,anchor="end",preset="natural"){
    const now=new Date(),base=asDate(item.date,anchor==="start"?item.startTime:item.endTime); if(!base)throw new Error("日程缺少可用时间。");
    let early,late; const title=norm(item.title);
    if(anchor==="start"){ const map={tight:[-8,-2],natural:[-15,-3],loose:[-25,-2]}; [early,late]=map[preset]||map.natural; }
    else if(/会议|开会|例会|客户/.test(title)){ const map={tight:[0,12],natural:[-3,30],loose:[-5,50]}; [early,late]=map[preset]||map.natural; }
    else if(/健身|运动|训练|跑步|游泳|瑜伽|篮球|足球|羽毛球|网球|球赛|打球/.test(title)){ const map={tight:[-5,15],natural:[-10,30],loose:[-15,50]}; [early,late]=map[preset]||map.natural; }
    else if(/课程|上课|课堂|电影|演出|音乐会/.test(title)){ const map={tight:[-2,10],natural:[-5,18],loose:[-10,30]}; [early,late]=map[preset]||map.natural; }
    else { const map={tight:[-3,12],natural:[-7,25],loose:[-15,45]}; [early,late]=map[preset]||map.natural; }
    let start=addMin(base,early),end=addMin(base,late); const minFuture=addMin(now,1);
    if(end<=now)throw new Error("这个日历联系窗口已经过去了。"); if(start<minFuture)start=minFuture;
    return {source:"calendar",sourceLabel:`日历：${item.date} ${item.startTime}-${item.endTime} ${item.title||""} · ${anchor==="start"?"开始前":"结束附近"}`,windowStart:start,windowEnd:end,runAt:randomDate(start,end),calendarItem:item,calendarAnchor:anchor,why:`使用日历事件「${item.title||"未命名"}」的${anchor==="start"?"开始时间":"结束时间"}，再加自然浮动。`,kind:"calendar"};
  }

  function calendarAt(ref){
    if(!ref)return null;
    return state.events.find(x=>{
      const a=asDate(x.item.date,x.item.startTime),b=asDate(x.item.date,x.item.endTime);
      return a&&b&&a<=ref&&b>=ref;
    })||null;
  }

  function chooseCalendarSuggestion(text,refOverride=null){
    const ref=refOverride||state.anchorTime||new Date(),s=norm(text);
    const current=calendarAt(ref);
    const next=state.events.find(x=>{const a=asDate(x.item.date,x.item.startTime);return a&&a>ref;});
    const before=/开始前|开场前|出发前|上场前|进去前/.test(s);
    if(before&&next)return {x:next,anchor:"start",reason:"聊天内容指向活动开始前，匹配最近的下一项日程。"};
    for(const x of [current,next].filter(Boolean)){
      for(const rule of eventSemantic){ if(rule.event.test(norm(x.item.title))&&rule.text.test(s))return {x,anchor:"end",reason:`聊天内容与日程「${x.item.title}」相符。`}; }
    }
    if(current&&/(结束后|结束了|结束再|忙完|完了找|完再|出来找|出来再)/.test(s))return {x:current,anchor:"end",reason:"聊天内容指向当前活动结束后的联系。"};
    return null;
  }

  function priorAssistantTimingCandidate(ref){
    if(!ref)return null;
    const cutoff=ref.getTime()-8*60*60*1000;
    return state.messages
      .filter(m=>m.role==="assistant" && Date.parse(m.createdAt||0)<=ref.getTime() && Date.parse(m.createdAt||0)>=cutoff)
      .sort((a,b)=>Date.parse(b.createdAt||0)-Date.parse(a.createdAt||0))
      .find(m=>{
        const t=norm(m.content);
        return /(洗澡|洗漱|吃饭|做饭|开会|会议|上课|课程|训练|健身|打球|篮球|足球|羽毛球|网球|跑步|游泳|电影|演出|开车|路上|通勤|回家|到家|回公司|到公司|下班|出发|忙完|结束后|等会|待会|晚点|之后|再聊|找你|分钟后|小时后|今晚|明天)/.test(t);
      })||null;
  }

  function findRouteSuggestion(text){
    const s=norm(text); if(!state.routes.length)return null;
    const scored=state.routes.map(r=>{
      const from=norm(r.from),to=norm(r.to); let score=0;
      if(from&&s.includes(from))score+=3; if(to&&s.includes(to))score+=4;
      if(from&&to&&s.includes(from)&&s.includes(to))score+=5;
      if(to==="家"&&/回家|到家/.test(s))score+=3;
      if(to==="公司"&&/回公司|到公司/.test(s))score+=3;
      if(to==="健身房"&&/去健身房|到健身房/.test(s))score+=3;
      return {r,score};
    }).filter(x=>x.score>0).sort((a,b)=>b.score-a.score);
    if(!scored.length)return null;
    if(scored[0].score>=8 || (scored.length===1 && scored[0].score>=5) || (scored[0].score>scored[1]?.score)) return scored[0].r;
    return null;
  }

  function routeTiming(route,status="normal",note=""){
    if(!state.anchorTime)throw new Error("没有时间依据消息，无法计算通勤起点。");
    let min=+route.min,max=+route.max;
    if(status==="fast"){ min=Math.max(1,Math.round(min*0.75)); max=Math.max(min,Math.round(max*0.90)); }
    if(status==="slow"){ min=Math.max(1,Math.round(min*1.15)); max=Math.max(min,Math.round(max*1.45)); }
    if(status==="custom"){ min=+$("#routeCustomMin").value; max=+$("#routeCustomMax").value; if(!Number.isFinite(min)||!Number.isFinite(max)||min<1||max<min)throw new Error("自定义通勤时间范围不对。"); }
    const label=`路线：${route.from} → ${route.to} · ${status==="normal"?"正常":status==="fast"?"偏快":status==="slow"?"偏慢":"自定义"}`;
    return makeRelativeWindow(state.anchorTime,min,max,label,`使用 ${charName(state.characterId)} 自己保存的常用路线。${note?`\n本次备注：${note}`:""}`,{source:"route",kind:"route",route,routeStatus:status,routeNote:note});
  }

  function lifestyleTiming(text,rule){
    if(!state.anchorTime)throw new Error("没有时间依据消息，无法计算生活事件起点。");
    const tendency=timeTendency(text),bucket=weightedBucket(rule.buckets,tendency);
    const tendencyLabel=tendency==="fast"?"（原话明确偏快）":tendency==="slow"?"（原话明确偏慢）":"";
    return makeRelativeWindow(state.anchorTime,bucket.min,bucket.max,`生活事件：${rule.name}${tendencyLabel}`,`采用带权重的自然耗时分布：大多数落在常见时长，偶尔更快或更久。插件不会替角色编“为什么这次花了这么久”。`,{kind:"lifestyle",activity:rule.name,tendency});
  }

  function estimateAuto(){
    state.lastPreview=null;
    state.autoBasis=null;
    const box=$("#recommend"); if(!box)return;
    const picked=selectedMessages();
    const source=safeText($("#sourceText")?.value);
    if(!picked.length || !source || !state.anchorTime){
      state.autoTiming=null;
      box.querySelector(".big").textContent=state.purpose==="reply"?"先选一条想让他之后接回的消息。":"先选与‘稍后回来’有关的聊天。";
      box.querySelector(".why").textContent="不会调用模型。";
      return;
    }
    try{
      let timing=null;
      if(state.purpose==="reply"){
        const current=calendarAt(state.anchorTime);
        if(current){
          timing=naturalCalendarWindow(current.item,"end","natural");
          timing.source="auto_calendar";
          timing.sourceLabel=`消息发送时正在进行：${current.item.title||"未命名日程"}`;
          timing.why=`你所选 USER 消息发送于 ${hm(state.anchorTime)}，当时角色正在「${current.item.title||"未命名日程"}」中，因此默认在日程结束附近恢复聊天。`;
          timing.basisType="calendar"; timing.basisText=current.item.title||"未命名日程";
          state.autoTiming=timing; state.autoBasis={type:"calendar",text:timing.basisText};
          renderRecommendation(); refreshDefaultTriggerReason(); return;
        }
        const prior=priorAssistantTimingCandidate(state.anchorTime);
        if(prior){
          const ref=new Date(prior.createdAt);
          const text=safeText(prior.content);
          timing=explicitDuration(text,ref) || explicitClock(text,ref);
          if(!timing){
            const cal=chooseCalendarSuggestion(text,ref);
            if(cal){ timing=naturalCalendarWindow(cal.x.item,cal.anchor,"natural"); timing.source="auto_calendar"; timing.sourceLabel=`聊天状态 + 日程：${cal.x.item.title||"未命名日程"}`; timing.why=`此前角色消息与日程「${cal.x.item.title||"未命名日程"}」相符。`; }
          }
          if(!timing){
            const route=findRouteSuggestion(text);
            if(route){
              const oldAnchor=state.anchorTime; state.anchorTime=ref;
              try{ timing=routeTiming(route,"normal",""); } finally{ state.anchorTime=oldAnchor; }
              if(timing){ timing.source="auto_route"; timing.sourceLabel=`此前聊天状态：${route.from} → ${route.to}`; timing.why="此前角色消息能明确匹配到已保存的常用路线。"; }
            }
          }
          if(!timing){
            const rule=lifestyleRules.find(r=>r.re.test(norm(text)));
            if(rule){
              const oldAnchor=state.anchorTime; state.anchorTime=ref;
              try{ timing=lifestyleTiming(text,rule); } finally{ state.anchorTime=oldAnchor; }
            }
          }
          if(timing){
            timing.basisType="message"; timing.basisText=text; timing.basisMessageId=String(prior.id);
            state.autoTiming=timing; state.autoBasis={type:"message",text};
            renderRecommendation(); refreshDefaultTriggerReason(); return;
          }
        }
        state.autoTiming=null;
        box.querySelector(".big").textContent="没找到可靠的自动时间依据";
        box.querySelector(".why").textContent="这不是错误。可以直接切到“按日历”或“我来改”；应用不会为了凑一个时间而硬猜。";
        refreshDefaultTriggerReason();
        return;
      }

      const text=source;
      let timing2=explicitDuration(text,state.anchorTime) || explicitClock(text,state.anchorTime);
      if(timing2){ state.autoTiming=timing2; state.autoBasis={type:"chat",text:source}; renderRecommendation(); refreshDefaultTriggerReason(); return; }
      const cal=chooseCalendarSuggestion(text,state.anchorTime);
      if(cal){ timing2=naturalCalendarWindow(cal.x.item,cal.anchor,"natural"); timing2.source="auto_calendar"; timing2.sourceLabel=`自动匹配日程：${cal.x.item.title||"未命名日程"}`; timing2.why=cal.reason; state.autoTiming=timing2; state.autoBasis={type:"calendar",text:cal.x.item.title||"未命名日程"}; renderRecommendation(); refreshDefaultTriggerReason(); return; }
      const route=findRouteSuggestion(text);
      if(route){ timing2=routeTiming(route,"normal",""); timing2.source="auto_route"; timing2.sourceLabel=`自动匹配路线：${route.from} → ${route.to}`; timing2.why="所选聊天能明确匹配到这个角色保存的常用路线。"; state.autoTiming=timing2; state.autoBasis={type:"route",text:`${route.from} → ${route.to}`}; renderRecommendation(); refreshDefaultTriggerReason(); return; }
      const rule=lifestyleRules.find(r=>r.re.test(norm(text)));
      if(rule){ timing2=lifestyleTiming(text,rule); state.autoTiming=timing2; state.autoBasis={type:"lifestyle",text:rule.name}; renderRecommendation(); refreshDefaultTriggerReason(); return; }
      timing2=makeRelativeWindow(state.anchorTime,20,50,"普通短暂离开 · 自然兜底","没有匹配到明确时间、日历、常用路线或生活事件，使用保守的本地兜底窗口。",{kind:"generic"});
      state.autoTiming=timing2; state.autoBasis={type:"generic",text:"普通短暂离开"}; renderRecommendation(); refreshDefaultTriggerReason();
    }catch(e){
      state.autoTiming=null;
      box.querySelector(".big").textContent="暂时没估出来。";
      box.querySelector(".why").textContent=String(e.message||e);
      refreshDefaultTriggerReason();
    }
  }

  function renderRecommendation(){
    const p=state.autoTiming,box=$("#recommend"); if(!p)return;
    box.querySelector(".big").textContent=`${fmt(p.windowStart)} ～ ${fmt(p.windowEnd)}`;
    box.querySelector(".why").textContent=`${p.sourceLabel}\n${p.why||""}`;
  }

  function manualCalendarTiming(){
    const x=state.events.find(e=>e.key===state.selectedEventKey); if(!x)throw new Error("先选一个日历事件。");
    return naturalCalendarWindow(x.item,$("#calendarAnchor").value,$("#calendarPreset").value);
  }
  function manualRouteTiming(){
    const route=state.routes.find(r=>r.id===$("#routeSelect").value); if(!route)throw new Error("先添加并选择一条常用路线。");
    return routeTiming(route,$("#routeStatus").value,safeText($("#routeNote").value));
  }
  function customTiming(){
    const start=parseLocalInput($("#customStart").value),end=parseLocalInput($("#customEnd").value),now=new Date();
    if(!start||!end)throw new Error("请填写完整的时间窗。"); if(end<=start)throw new Error("结束时间必须晚于开始时间。"); if(end<=now)throw new Error("这个时间窗已经过去了。");
    const usable=start<addMin(now,1)?addMin(now,1):start;
    return {source:"custom",sourceLabel:`自定义 ${fmt(usable)}～${fmt(end)}`,windowStart:usable,windowEnd:end,runAt:randomDate(usable,end),why:"你手动覆盖了插件的估时。",kind:"custom"};
  }
  function buildTiming(){
    if(state.mode==="custom")return customTiming();
    if(state.mode==="calendar")return manualCalendarTiming();
    if(state.mode==="route")return manualRouteTiming();
    if(!state.autoTiming) estimateAuto();
    if(!state.autoTiming)throw new Error("自动估时失败，请改用日历、路线或自定义。");
    return {...state.autoTiming};
  }

  function formSignature(){
    return JSON.stringify({
      characterId:state.characterId,
      purpose:state.purpose,
      messageIds:[...state.selectedMessageIds].sort(),
      sourceText:safeText($("#sourceText")?.value),
      anchorTime:state.anchorTime?.toISOString()||"",
      mode:state.mode,
      triggerReason:safeText($("#triggerReason")?.value),
      triggerNote:safeText($("#triggerNote")?.value),
      selectedEventKey:state.selectedEventKey,
      calendarAnchor:$("#calendarAnchor")?.value||"",
      calendarPreset:$("#calendarPreset")?.value||"",
      routeId:$("#routeSelect")?.value||"",
      routeStatus:$("#routeStatus")?.value||"",
      routeNote:safeText($("#routeNote")?.value),
      routeCustomMin:$("#routeCustomMin")?.value||"",
      routeCustomMax:$("#routeCustomMax")?.value||"",
      customStart:$("#customStart")?.value||"",
      customEnd:$("#customEnd")?.value||""
    });
  }

  function timingSituation(t){
    if(t?.kind==="calendar" || t?.source==="auto_calendar"){
      const title=safeText(t.calendarItem?.title)||safeText(t.basisText)||"此前的日程";
      return t.calendarAnchor==="start"
        ?`此前约定在「${title}」开始前联系，现在已经到了这个时间。`
        :`你此前在「${title}」日程中暂时不便正常聊天，现在已经可以恢复正常聊天。`;
    }
    if(t?.kind==="route" || t?.kind==="route_fallback" || t?.source==="auto_route"){
      if(t.route) return `你此前在从「${t.route.from}」到「${t.route.to}」的行程中，现在已经可以恢复正常聊天。`;
      return "你此前在通勤或移动中暂时不便正常聊天，现在已经可以恢复正常聊天。";
    }
    if(t?.kind==="lifestyle") return `你此前因为「${t.activity}」暂时离开聊天，现在已经可以恢复正常聊天。`;
    if(t?.kind==="explicit" || t?.kind==="explicit_clock") return "此前提到的联系时间现在已经到了。";
    if(t?.kind==="custom") return state.purpose==="reply"?"现在已经到了本次设定的恢复聊天时间。":"现在已经到了本次设定的联系时间。";
    return state.purpose==="reply"?"现在已经到了适合恢复这段聊天的时间。":"现在已经到了适合重新联系的时间。";
  }

  function defaultTriggerReason(timing=null){
    const picked=selectedMessages(); if(!picked.length)return "";
    const t=timing || (state.mode==="auto"?state.autoTiming:null);
    const situation=timingSituation(t);
    const note=safeText($("#triggerNote")?.value);
    const extra=note?`\n补充背景：${note}`:"";
    if(state.purpose==="reply"){
      const pickedUser=picked.filter(m=>m.role==="user");
      if(!pickedUser.length)return "";
      let quote=pickedUser.map(m=>`- ${safeText(m.content)}`).join("\n");
      if(quote.length>900) quote=quote.slice(0,900)+"…";
      return `${situation}
对方此前发过：
${quote}
请以当前真实时间和实际聊天进展为准，自然接续。${extra}`;
    }
    return `${situation}
请结合当前真实时间和实际聊天进展，自然继续。${extra}`;
  }

  function refreshDefaultTriggerReason(force=false){
    const box=$("#triggerReason"); if(!box)return;
    if(force || !state.triggerDirty) box.value=defaultTriggerReason(state.mode==="auto"?state.autoTiming:null);
  }

  function buildPreview(){
    const source=safeText($("#sourceText").value);
    if(!source)throw new Error(state.purpose==="reply"?"先选择想让角色之后接回的 USER 消息。":"先选择与‘稍后回来’有关的聊天。");
    if(!state.anchorTime)throw new Error("所选消息没有可用时间戳。");
    if(!state.characterId)throw new Error("先选择角色。");
    const timing=buildTiming();
    if(!state.triggerDirty) $("#triggerReason").value=defaultTriggerReason(timing);
    const reason=safeText($("#triggerReason").value)||defaultTriggerReason(timing);
    const result={...timing,purpose:state.purpose,sourceText:source,sourceMessageIds:[...state.selectedMessageIds],timingMessageId:timing.basisMessageId||"",timingText:timing.basisText||state.autoBasis?.text||"",timingRole:timing.basisMessageId?"assistant":"",anchorTime:new Date(state.anchorTime),triggerNote:safeText($("#triggerNote")?.value),triggerReason:reason,characterId:state.characterId,characterName:charName(state.characterId)};
    result.signature=formSignature();
    state.lastPreview=result; return result;
  }

  function previewForSchedule(){
    const sig=formSignature();
    const p=state.lastPreview;
    if(p && p.signature===sig && new Date(p.runAt).getTime()>Date.now()+1000) return p;
    return buildPreview();
  }

  function showPreview(){
    try{
      const p=buildPreview();
      const itemLabel=p.purpose==="reply"?"待补回复":"约定相关消息";
      const basis=p.sourceLabel||"";
      $("#previewBox").textContent=`角色：${p.characterName}\n用途：${p.purpose==="reply"?"补上回复":"如约回来"}\n${itemLabel}：${p.sourceText}\n参考消息时间：${fmt(p.anchorTime)}\n时间判断：${basis}\n联系窗口：${fmt(p.windowStart)} ～ ${fmt(p.windowEnd)}${$("#showExact").checked?`\n本次随机点：${fmt(p.runAt)}`:""}\n\n本次临时背景：\n${p.triggerReason}`;
    }catch(e){ $("#previewBox").textContent=`试算失败：${e.message||e}`; }
  }

  async function createPlanTask(p, extra={}){
    const taskId=`ruyue_v06_${Date.now()}_${Math.random().toString(36).slice(2,7)}`;
    const eventId=`ruyue_trigger_${taskId}`;
    const delayMs=Math.max(1000,new Date(p.runAt).getTime()-Date.now());
    const planRecord=await A.db.create("plans",{
      taskId,eventId,characterId:p.characterId,characterName:p.characterName,
      purpose:p.purpose||"return",sourceText:p.sourceText,sourceMessageIds:p.sourceMessageIds||[],timingMessageId:p.timingMessageId||"",timingText:p.timingText||"",timingRole:p.timingRole||"",anchorTime:new Date(p.anchorTime).toISOString(),triggerNote:p.triggerNote||"",triggerReason:p.triggerReason,
      source:p.source,sourceLabel:p.sourceLabel,windowStart:new Date(p.windowStart).toISOString(),windowEnd:new Date(p.windowEnd).toISOString(),runAt:new Date(p.runAt).toISOString(),
      status:"pending",version:"0.6",...extra
    });
    try{
      await A.tasks.schedule({
        id:taskId,delayMs,
        actions:[
          {type:"memory.timeline",characterId:p.characterId,summary:p.triggerReason,detail:`如约来信 · ${p.purpose==="reply"?"补上回复":"如约回来"}`,appLabel:"如约来信",appEventId:eventId,data:{kind:"ruyue_trigger",purpose:p.purpose||"return",taskId,planId:planRecord.id}},
          {type:"chat.reply",characterId:p.characterId}
        ],
        onSuccess:[
          {type:"db.update",collection:"plans",id:planRecord.id,patch:{status:"done"}}
        ],
        onFailure:[
          {type:"memory.deleteTimeline",characterId:p.characterId,appEventId:eventId},
          {type:"db.update",collection:"plans",id:planRecord.id,patch:{status:"failed"}}
        ]
      });
      return planRecord;
    }catch(e){
      try{await A.db.delete("plans",planRecord.id);}catch{}
      throw e;
    }
  }

  async function schedule(){
    try{
      const p=previewForSchedule();
      await createPlanTask(p);
      await toast("这次如约已登记");
      $("#previewBox").textContent=`已登记：${p.characterName}\n参考消息时间：${fmt(p.anchorTime)}\n联系窗口：${fmt(p.windowStart)} ～ ${fmt(p.windowEnd)}${$("#showExact").checked?`\n测试精确点：${fmt(p.runAt)}`:""}\n\n到点只触发一次普通聊天回复。`;
      state.lastPreview=null;
      await renderPlans();
    }catch(e){
      await toast(`登记失败：${e.message||e}`); $("#previewBox").textContent=`登记失败：${e.message||e}`;
    }
  }

  async function reschedulePlan(plan,startValue,endValue){
    try{
      const start=parseLocalInput(startValue),end=parseLocalInput(endValue),now=new Date();
      if(!start||!end)throw new Error("请填写完整的新时间窗。");
      if(end<=start)throw new Error("结束时间必须晚于开始时间。");
      if(end<=now)throw new Error("新的时间窗已经过去了。");
      const usable=start<addMin(now,1)?addMin(now,1):start;
      const canceled=await A.tasks.cancel(String(plan.taskId));
      if(!canceled)throw new Error("旧任务已经不在等待状态，先刷新计划列表确认一下。");
      await A.db.update("plans",plan.id,{status:"canceled",cancelReason:"已调整为新计划",canceledAt:new Date().toISOString()});
      const p={
        characterId:plan.characterId,characterName:plan.characterName||charName(plan.characterId),purpose:plan.purpose||"return",
        sourceText:plan.sourceText||"",sourceMessageIds:Array.isArray(plan.sourceMessageIds)?plan.sourceMessageIds:[],
        timingMessageId:plan.timingMessageId||"",timingText:plan.timingText||"",timingRole:plan.timingRole||"",
        anchorTime:new Date(plan.anchorTime),triggerNote:plan.triggerNote||"",triggerReason:plan.triggerReason||"",
        source:"adjusted",sourceLabel:"手动调整时间",
        windowStart:usable,windowEnd:end,runAt:randomDate(usable,end)
      };
      await createPlanTask(p,{adjustedFrom:plan.id});
      await toast("时间已调整，新计划已建立");
    }catch(e){ await toast(`调整失败：${e.message||e}`); }
    await renderPlans();
  }

  async function taskMap(){ try{const t=await A.tasks.list(); return new Map((t||[]).map(x=>[String(x.id),x]));}catch{return new Map();} }
  function statusLabel(s){return({pending:"等待中",running:"触发中",done:"已执行",failed:"失败",canceled:"已取消",cancel_failed:"取消失败"})[s]||s||"未知";}
  async function cancelPlan(plan){
    try{ const ok=await A.tasks.cancel(String(plan.taskId)); await A.db.update("plans",plan.id,{status:ok?"canceled":"cancel_failed",cancelReason:"用户手动取消"}); await toast(ok?"已取消":"没有找到等待中的任务"); }
    catch(e){ await toast(`取消失败：${e.message||e}`); }
    await renderPlans();
  }
  async function deletePlan(plan){
    try{
      if(plan.eventId && plan.characterId){ try{await A.memory.deleteTimeline({characterId:plan.characterId,appEventId:plan.eventId});}catch{} }
      await A.db.delete("plans",plan.id); await toast("记录已删除");
    }catch(e){ await toast(`删除失败：${e.message||e}`); }
    await renderPlans();
  }
  async function clearFinished(){
    try{
      const [plans,tm]=await Promise.all([dbList("plans",500),taskMap()]);
      const rows=(plans||[]).filter(p=>["0.5","0.6"].includes(String(p.version))); let n=0;
      for(const p of rows){
        const st=tm.get(String(p.taskId))?.status||p.status;
        if(["done","failed","canceled","cancel_failed"].includes(st)){
          if(p.eventId && p.characterId){ try{await A.memory.deleteTimeline({characterId:p.characterId,appEventId:p.eventId});}catch{} }
          await A.db.delete("plans",p.id); n++;
        }
      }
      await toast(n?`已清理 ${n} 条记录`:"没有可清理的记录"); await renderPlans();
    }catch(e){ await toast(`清理失败：${e.message||e}`); }
  }
  async function renderPlans(){
    const host=$("#plans"); host.innerHTML='<div class="empty">读取中……</div>';
    try{
      const [plans,tm]=await Promise.all([dbList("plans",500),taskMap()]);
      const rows=[...(plans||[])].filter(p=>["0.5","0.6"].includes(String(p.version))).sort((a,b)=>Date.parse(b.createdAt||0)-Date.parse(a.createdAt||0)).slice(0,50);
      host.innerHTML=""; if(!rows.length){ host.innerHTML='<div class="empty">还没有计划。</div>'; return; }
      for(const p of rows){
        const task=tm.get(String(p.taskId)),status=task?.status||p.status||"unknown";
        const box=document.createElement("div");box.className="plan";
        const top=document.createElement("div");top.className="planTop";
        const name=document.createElement("div");name.className="planName";name.textContent=p.characterName||p.characterId;
        const st=document.createElement("div");st.className="status";st.textContent=statusLabel(status); top.append(name,st);
        const meta=document.createElement("div");meta.className="planMeta";
        const exact=$("#showExact").checked&&p.runAt?`\n测试精确点：${new Date(p.runAt).toLocaleString()}`:"";
        const purpose=p.purpose||"return";
        const itemLabel=purpose==="reply"?"待补回复":"约定相关消息";
        meta.textContent=`用途：${purpose==="reply"?"补上回复":"如约回来"}\n${itemLabel}：${p.sourceText||""}\n参考消息时间：${p.anchorTime?new Date(p.anchorTime).toLocaleString():""}\n时间判断：${p.sourceLabel||""}\n联系窗口：${new Date(p.windowStart).toLocaleString()} ～ ${new Date(p.windowEnd).toLocaleTimeString()}${p.hiddenEventClearedAt?"\n临时背景：已在角色回复后清理":""}${exact}${task?.lastError?`\n错误：${task.lastError}`:""}`;
        box.append(top,meta);
        const acts=document.createElement("div");acts.className="routeActions";
        if(status==="pending"){
          const adjust=document.createElement("button");adjust.className="tiny";adjust.textContent="调整时间";
          const cancel=document.createElement("button");cancel.className="tiny danger";cancel.textContent="手动取消";cancel.onclick=()=>cancelPlan(p);
          acts.append(adjust,cancel);
          const panel=document.createElement("div");panel.className="adjustBox";panel.hidden=true;
          const startInput=document.createElement("input");startInput.type="datetime-local";startInput.value=dateTimeLocalValue(new Date(p.windowStart));
          const endInput=document.createElement("input");endInput.type="datetime-local";endInput.value=dateTimeLocalValue(new Date(p.windowEnd));
          const save=document.createElement("button");save.className="tiny";save.textContent="保存调整";save.onclick=()=>reschedulePlan(p,startInput.value,endInput.value);
          const close=document.createElement("button");close.className="tiny";close.textContent="收起";close.onclick=()=>panel.hidden=true;
          const inputs=document.createElement("div");inputs.className="row";inputs.append(startInput,endInput);
          const panelActs=document.createElement("div");panelActs.className="routeActions";panelActs.append(save,close);
          panel.append(inputs,panelActs);box.append(panel);
          adjust.onclick=()=>{panel.hidden=!panel.hidden;};
        }else{
          const del=document.createElement("button");del.className="tiny danger";del.textContent="删除记录";del.onclick=()=>deletePlan(p);acts.append(del);
        }
        box.append(acts);host.appendChild(box);
      }
    }catch(e){ host.innerHTML=`<div class="empty">计划读取失败：${e.message||e}</div>`; }
  }

  function switchMode(mode){
    state.mode=mode; $$('.tab').forEach(b=>b.classList.toggle('active',b.dataset.mode===mode)); $$('.modePanel').forEach(p=>p.hidden=true); $("#mode-"+mode).hidden=false;
    if(mode==="auto")estimateAuto(); refreshDefaultTriggerReason();
  }
  function setCustomDefaults(){
    const base=state.anchorTime||new Date(); const now=new Date(); const start=addMin(base,25)>now?addMin(base,25):addMin(now,5); const end=addMin(base,55)>start?addMin(base,55):addMin(start,30);
    $("#customStart").value=dateTimeLocalValue(start); $("#customEnd").value=dateTimeLocalValue(end);
  }
  async function onCharacterChange(){
    state.characterId=$("#character").value; state.selectedMessageIds.clear(); state.timingMessageId=""; state.timingManual=false; state.anchorTime=null; state.autoTiming=null; state.autoBasis=null; state.triggerDirty=false; $("#sourceText").value=""; $("#triggerReason").value=""; if($("#triggerNote")) $("#triggerNote").value="";
    await Promise.all([loadMessages(),loadEvents(),loadRoutes(),renderPlans()]); estimateAuto();
  }

  async function cleanupTimelineForPlan(plan){
    if(!plan?.eventId || !plan?.characterId || plan.hiddenEventClearedAt)return;
    try{
      await A.memory.deleteTimeline({characterId:plan.characterId,appEventId:plan.eventId});
      await A.db.update("plans",plan.id,{hiddenEventClearedAt:new Date().toISOString()});
    }catch{}
  }

  async function cleanupStaleDonePlanEvents(){
    const now=Date.now();
    const plans=await dbList("plans",500);
    for(const p of plans){
      if(!["0.5","0.6"].includes(String(p.version)) || p.status!=="done" || !p.eventId || p.hiddenEventClearedAt)continue;
      const updated=Date.parse(p.updatedAt||p.createdAt||0);
      if(Number.isFinite(updated) && now-updated>30*60*1000) await cleanupTimelineForPlan(p);
    }
  }

  function installReplyCleanupListener(){
    if(typeof A.on!=="function")return;
    A.on("chat.message.created", async payload=>{
      const message=payload?.message;
      if(message?.role!=="assistant")return;
      const characterId=payload?.characterId || payload?.contactId || "";
      if(!characterId)return;
      const msgAt=Date.parse(message.createdAt||new Date().toISOString());
      const plans=await dbList("plans",500);
      for(const p of plans){
        if(!["0.5","0.6"].includes(String(p.version)) || p.characterId!==characterId || p.status!=="done" || !p.eventId || p.hiddenEventClearedAt)continue;
        const updated=Date.parse(p.updatedAt||p.createdAt||0);
        if(!Number.isFinite(updated))continue;
        if(updated<=msgAt+30*1000) await cleanupTimelineForPlan(p);
      }
    });
  }

  async function boot(){
    if(!A){document.body.innerHTML='<pre style="padding:20px">未检测到 AiPhone SDK，请在 Float 小手机里运行。</pre>';return;}
    try{
      await loadCharacters(); setCustomDefaults();
      updatePurposeCopy(); installReplyCleanupListener();
      $("#character").onchange=onCharacterChange;
      $("#purpose").onchange=()=>setPurpose($("#purpose").value);
      $$("input[name='purposeChoice']").forEach(r=>r.onchange=()=>{ if(r.checked) setPurpose(r.value); });
      $("#refreshMessages").onclick=loadMessages;
      $("#refreshPlans").onclick=renderPlans;
      $("#preview").onclick=showPreview;
      $("#schedule").onclick=schedule;
      $("#reEstimate").onclick=()=>{state.lastPreview=null;estimateAuto();};
      $("#resetTrigger").onclick=()=>{state.triggerDirty=false;refreshDefaultTriggerReason(true);};
      $("#triggerReason").oninput=()=>{state.triggerDirty=true;};
      $("#triggerNote").oninput=()=>{ if(!state.triggerDirty) refreshDefaultTriggerReason(true); };
      $("#calendarAnchor").onchange=refreshDefaultTriggerReason;
      $("#calendarPreset").onchange=refreshDefaultTriggerReason;
      $("#routeSelect").onchange=()=>{state.selectedRouteId=$("#routeSelect").value;refreshDefaultTriggerReason();};
      $("#routeStatus").onchange=()=>{$("#routeCustomDur").hidden=$("#routeStatus").value!=="custom";refreshDefaultTriggerReason();};
      $("#routeNote").oninput=()=>refreshDefaultTriggerReason();
      $("#saveRoute").onclick=saveRoute;
      $("#cancelRouteEdit").onclick=cancelEditRoute;
      $("#clearFinished").onclick=clearFinished;
      $$('.tab').forEach(b=>b.onclick=()=>switchMode(b.dataset.mode));
      await Promise.all([loadMessages(),loadEvents(),loadRoutes(),renderPlans(),cleanupStaleDonePlanEvents()]); estimateAuto();
    }catch(e){document.body.innerHTML=`<pre style="padding:20px">启动失败：${e.message||e}</pre>`;}
  }
  boot();
})();

/* ── 动效库模块（assets/anim/animlib.js） ──
   纯数据：动效参数表（给美化助手）+ 画布 22 种动效的分组清单。
   只由 main.js 读取；失败时画布仅保留 淡入/缩放/漂浮/不动 四个基础按钮。 */
(function(){
try{
var ANIM_REF = '淡入 op0→1｜平滑 上移14px+scale.98｜推入 位移26%｜擦出 clip-path 单向展开｜切入 两帧硬切｜百叶窗 横条遮罩8px｜随机线条 竖条3px steps(10)｜飞入 位移34%+scale.92｜向内溶解 径向遮罩30%→100%｜劈裂 inset50%→0｜阶梯状 steps(4)｜展开 scaleY.08→1｜淡化 1→.72｜旋转 -7deg+10px｜中心旋转 scale.35+rotate-160｜浮入 12px 回弹｜翻转由远及近 perspective(700px) rotateY-72deg｜升起 30px｜回旋 -14deg+位移(-18px,10px)';

var CV_ANIM_GROUPS = [
{ g:'基础', list:[['fadeIn','淡入'],['smooth','平滑'],['fadeInOut','淡入淡出'],['dim','淡化'],['zoomIn','缩放'],['unfold','展开'],['cutIn','切入']] },
{ g:'推入', list:[['pushT','上'],['pushB','下'],['pushL','左'],['pushR','右']] },
{ g:'擦出', list:[['wipeT','上'],['wipeB','下'],['wipeL','左'],['wipeR','右']] },
{ g:'特殊', list:[['flyIn','飞入'],['blinds','百叶窗'],['lines','随机线条'],['dissolve','向内溶解'],['split','劈裂'],['stairs','阶梯状'],['rotateIn','旋转'],['spinCenter','中心旋转'],['floatIn','浮入'],['flipFar','翻转由远及近'],['rise','升起'],['swirl','回旋']] },
{ g:'循环', list:[['float','漂浮'],['none','不动']] }
];

window.__ANIM_LIB = {animRef: ANIM_REF, groups: CV_ANIM_GROUPS};
}catch(e){ try{ console.warn('[animlib] 加载异常，动效库降级', e); }catch(_){} }
})();

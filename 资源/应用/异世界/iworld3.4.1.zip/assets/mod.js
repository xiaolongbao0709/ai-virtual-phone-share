/* ══════════════════════════════════════════════════════════════
触感特效内核 FXEngine
—— 点触：none / star / ring / burst / 自定义
—— 拖尾：none / galaxy / silk / firefly / 自定义
自定义代码约定见 registerCustom 注释。
══════════════════════════════════════════════════════════════ */
(function(){
if(window.FXEngine) return;
var LS = { tap:'fxTapMode', trail:'fxTrailMode', custom:'fxCustomFx', del:'fxCustomFxDel' };
function lsGet(k, d){ try{ var v = localStorage.getItem(k); return v == null ? d : v; }catch(e){ return d; } }
function lsSet(k, v){ try{ localStorage.setItem(k, v); }catch(e){} }
/* App 设置里存着就优先（DB 存档比 localStorage 活得久） */
function _pref(setKey, lsKey, dv){
try{ if(window.appSettings && appSettings[setKey]) return appSettings[setKey]; }catch(e){}
return lsGet(lsKey, dv);
}
function _persist(setKey, val){
try{ if(window.appSettings){ appSettings[setKey] = val; if(window.saveSettings) saveSettings(); } }catch(e){}
}
var custom = [];                                  /* {id,name,kind,code} */
/* 存档里的 fxCustom 可能是个空数组（旧版本写过空），空数组也是“真值”，
以前会直接用它覆盖掉 localStorage 里的自定义特效，表现就是重启后全没了。
现在两边都读，按 id 合并，谁也不丢。 */
function _lsCustom(){
try{
var v = JSON.parse(lsGet(LS.custom, '[]'));
return Array.isArray(v) ? v : [];
}catch(e){ return []; }
}
/* 删除记号：DB 里的 fxCustom 会晚一步更新，只按 id 合并会把刚删的又捞回来 */
function _lsDel(){
try{ var v = JSON.parse(lsGet(LS.del, '[]')); return Array.isArray(v) ? v : []; }catch(e){ return []; }
}
function _dbDel(){
try{
if(!window.appSettings || !appSettings.fxCustomDel) return [];
var v = appSettings.fxCustomDel;
if(typeof v === 'string') v = JSON.parse(v);
return Array.isArray(v) ? v : [];
}catch(e){ return []; }
}
function _dbCustom(){
try{
if(!window.appSettings || !appSettings.fxCustom) return [];
var v = appSettings.fxCustom;
if(typeof v === 'string') v = JSON.parse(v);
return Array.isArray(v) ? v : [];
}catch(e){ return []; }
}
function _mergeCustom(){
var out = [], seen = {}, gone = {};
_dbDel().concat(_lsDel()).forEach(function(id){ gone[id] = 1; });
_dbCustom().concat(_lsCustom()).forEach(function(c){
if(!c || !c.id || seen[c.id]) return;
if(gone[c.id]) return;
if(c.kind !== 'tap' && c.kind !== 'trail') return;
if(!c.code) return;
seen[c.id] = 1; out.push({id:c.id, name:String(c.name || '未命名'), kind:c.kind, code:String(c.code)});
});
return out;
}
custom = _mergeCustom();
/* 设置从 DB 读完之后再合并一次：DB 的旧值晚到，别把内存里刚导入的顶掉 */
window.__fxSyncCustom = function(){
try{
var merged = _mergeCustom();
if(!merged.length && custom.length) merged = custom.slice();
custom = merged;
var m = mode || {};
['tap','trail'].forEach(function(k){
var v = String(m[k] || '');
if(v.indexOf('custom:') === 0 && !custom.some(function(c){ return c.id === v.slice(7); })) m[k] = 'none';
});
if(window.__fxRefresh) window.__fxRefresh();
return custom.length;
}catch(e){ return 0; }
};
function _saveDel(){
var ids = custom.map(function(c){ return c.id; });
var keep = _lsDel().filter(function(id){ return ids.indexOf(id) === -1; });
lsSet(LS.del, JSON.stringify(keep));
try{ if(window.appSettings){ appSettings.fxCustomDel = keep; } }catch(e){}
}
function saveCustom(){
lsSet(LS.custom, JSON.stringify(custom));
try{ if(window.appSettings){ appSettings.fxCustom = custom.slice(); if(window.saveSettings) saveSettings(); } }catch(e){}
_saveDel();
}
var compiled = {};                                /* id -> fn */
function compile(item){
if(compiled[item.id]) return compiled[item.id];
try{
var fn = item.kind === 'tap'
? new Function('x', 'y', item.code)
: new Function('ctx', 'pts', 'now', item.code);
compiled[item.id] = fn;
return fn;
}catch(e){ return null; }
}
/* ── 样式 ── */
var st = document.createElement('style');
st.textContent = [
'#fxTrailCanvas{position:fixed;left:0;top:0;width:100%;height:100%;z-index:900;pointer-events:none;display:none;}',
'#fxTapLayer{position:fixed;left:0;top:0;width:100%;height:100%;z-index:901;pointer-events:none;display:none;}',
'body.is-cover-view #vfPhoneFab{display:none!important;}',
'#fxTapCanvas{position:fixed;left:0;top:0;width:100%;height:100%;z-index:901;pointer-events:none;display:none;}',
'.fx-el{position:absolute;left:0;top:0;will-change:transform,opacity;pointer-events:none;}',
'@keyframes fxStarPop{0%{opacity:.95;transform:scale(.62) rotate(-14deg);}16%{opacity:1;transform:scale(1.06) rotate(-3deg);}52%{opacity:1;transform:scale(1) rotate(0);}100%{opacity:0;transform:scale(1.45) rotate(10deg);}}',
'@keyframes fxHaloOut{0%{opacity:.9;transform:translate(-50%,-50%) scale(.4);}100%{opacity:0;transform:translate(-50%,-50%) scale(1.25);}}',
'@keyframes fxRingOut{0%{opacity:.9;transform:translate(-50%,-50%) scale(.25);}70%{opacity:.35;}100%{opacity:0;transform:translate(-50%,-50%) scale(1);}}',
'@keyframes fxBurstOut{0%{opacity:1;transform:translate(-50%,-50%) translate(0,0) scale(.6);}100%{opacity:0;transform:translate(-50%,-50%) translate(var(--bx),var(--by)) scale(.25);}}',
'@keyframes fxFirefly{0%{opacity:0;transform:translate(-50%,-50%) scale(.4);}30%{opacity:.9;transform:translate(-50%,-50%) scale(1);}100%{opacity:0;transform:translate(-50%,-50%) translate(var(--fx),var(--fy)) scale(.5);}}'
].join('\n');
document.head.appendChild(st);
/* ── 点触层 ── */
var tapLayer = document.createElement('div');
tapLayer.id = 'fxTapLayer';
var trailCv = document.createElement('canvas');
trailCv.id = 'fxTrailCanvas';
var tapCv = document.createElement('canvas');
tapCv.id = 'fxTapCanvas';
function ensureDom(){
if(!tapLayer.parentNode) document.body.appendChild(tapLayer);
if(!trailCv.parentNode) document.body.appendChild(trailCv);
if(!tapCv.parentNode) document.body.appendChild(tapCv);
}
var mode = { tap:'none', trail:'none' };
var STAR_PTS = [0,-1, 0.2245,-0.309, 0.9511,-0.309, 0.3633,0.118, 0.5878,0.809,
0,0.382, -0.5878,0.809, -0.3633,0.118, -0.9511,-0.309, -0.2245,-0.309];
/* ── ① 五角星 ── */
function tapFlash(x, y){
var f = document.createElement('div');
f.className = 'fx-el';
f.style.cssText = 'transform:translate(' + x + 'px,' + y + 'px);';
var d = document.createElement('div');
d.style.cssText = 'position:absolute;left:0;top:0;width:14px;height:14px;border-radius:50%;transform:translate(-50%,-50%);' +
'background:radial-gradient(circle,rgba(255,255,255,.95) 0%,rgba(214,232,255,.35) 40%,rgba(214,232,255,0) 72%);' +
'transition:transform .16s ease-out,opacity .16s ease-out;';
f.appendChild(d);
tapLayer.appendChild(f);
requestAnimationFrame(function(){
d.style.transform = 'translate(-50%,-50%) scale(2.1)';
d.style.opacity = '0';
});
setTimeout(function(){ try{ f.remove(); }catch(e){} }, 240);
}
function tapStar(x, y){
tapFlash(x, y);
var r = 9;
var wrap = document.createElement('div');
wrap.className = 'fx-el';
wrap.style.transform = 'translate(' + x + 'px,' + y + 'px)';
wrap.style.transformOrigin = '50% 50%';
var halo = document.createElement('div');
halo.style.cssText = 'position:absolute;left:50%;top:50%;border-radius:50%;transform:translate(-50%,-50%);' +
'background:radial-gradient(circle,rgba(255,255,255,.55) 0%,rgba(214,232,255,.16) 45%,rgba(214,232,255,0) 72%);' +
'width:' + (r * 5.2) + 'px;height:' + (r * 5.2) + 'px;animation:fxHaloOut .62s ease-out forwards;';
wrap.appendChild(halo);
[ {s:r, a:1, d:0}, {s:r*0.58, a:0.55, d:45} ].forEach(function(o){
var svg = document.createElementNS('http://www.w3.org/2000/svg', 'svg');
svg.setAttribute('width', (o.s * 2.6).toFixed(1));
svg.setAttribute('height', (o.s * 2.6).toFixed(1));
svg.setAttribute('viewBox', '-1.3 -1.3 2.6 2.6');
svg.style.cssText = 'position:absolute;left:50%;top:50%;transform:translate(-50%,-50%);opacity:' + o.a + ';' +
'filter:drop-shadow(0 0 ' + (o.s * .55).toFixed(1) + 'px rgba(210,230,255,.9));';
var poly = document.createElementNS('http://www.w3.org/2000/svg', 'polygon');
var pts = [];
for(var i = 0; i < STAR_PTS.length; i += 2){
pts.push(STAR_PTS[i].toFixed(3) + ',' + STAR_PTS[i+1].toFixed(3));
}
poly.setAttribute('points', pts.join(' '));
poly.setAttribute('fill', '#fff');
poly.setAttribute('stroke', 'rgba(214,232,255,.9)');
poly.setAttribute('stroke-width', '0.05');
svg.appendChild(poly);
wrap.appendChild(svg);
setTimeout(function(){ svg.style.animation = 'fxStarPop .72s cubic-bezier(.2,.7,.3,1) forwards'; }, o.d);
});
tapLayer.appendChild(wrap);
setTimeout(function(){ try{ wrap.remove(); }catch(e){} }, 900);
}
/* ── ② 星环涟漪 ── */
function tapRing(x, y){
var wrap = document.createElement('div');
wrap.className = 'fx-el';
wrap.style.transform = 'translate(' + x + 'px,' + y + 'px)';
[0, 1].forEach(function(k){
var d = k ? 64 : 46;
var ring = document.createElement('div');
ring.style.cssText = 'position:absolute;left:50%;top:50%;width:' + d + 'px;height:' + d + 'px;border-radius:50%;' +
'border:1px solid rgba(210,232,255,' + (k ? .5 : .85) + ');' +
'box-shadow:0 0 10px rgba(180,215,255,.55),inset 0 0 10px rgba(180,215,255,.25);' +
'animation:fxRingOut ' + (k ? .72 : .58) + 's cubic-bezier(.15,.7,.25,1) forwards;' +
'animation-delay:' + (k ? 60 : 0) + 'ms;';
wrap.appendChild(ring);
});
for(var i = 0; i < 6; i++){
var ang = i / 6 * Math.PI * 2 + Math.random() * .6;
var dist = 22 + Math.random() * 8;
var dot = document.createElement('div');
dot.style.cssText = 'position:absolute;left:50%;top:50%;width:3px;height:3px;border-radius:50%;' +
'background:#fff;box-shadow:0 0 6px rgba(200,225,255,.9);' +
'transform:translate(-50%,-50%) translate(' + (Math.cos(ang)*8).toFixed(1) + 'px,' + (Math.sin(ang)*8).toFixed(1) + 'px);' +
'animation:fxBurstOut .62s ease-out forwards;animation-delay:20ms;' +
'--bx:' + (Math.cos(ang)*dist).toFixed(1) + 'px;--by:' + (Math.sin(ang)*dist).toFixed(1) + 'px;';
wrap.appendChild(dot);
}
tapLayer.appendChild(wrap);
setTimeout(function(){ try{ wrap.remove(); }catch(e){} }, 850);
}
/* ── ③ 星芒爆散 ── */
function tapBurst(x, y){
var wrap = document.createElement('div');
wrap.className = 'fx-el';
wrap.style.transform = 'translate(' + x + 'px,' + y + 'px)';
var core = document.createElement('div');
core.style.cssText = 'position:absolute;left:50%;top:50%;width:10px;height:10px;border-radius:50%;' +
'transform:translate(-50%,-50%);background:#fff;box-shadow:0 0 14px rgba(190,220,255,.95),0 0 34px rgba(140,190,255,.5);' +
'animation:fxRingOut .42s ease-out forwards;';
wrap.appendChild(core);
for(var i = 0; i < 9; i++){
var ang = Math.random() * Math.PI * 2;
var dist = 26 + Math.random() * 34;
var s = 2 + Math.random() * 2.4;
var dot = document.createElement('div');
dot.style.cssText = 'position:absolute;left:50%;top:50%;width:' + s + 'px;height:' + s + 'px;border-radius:50%;' +
'background:#fff;box-shadow:0 0 7px rgba(200,225,255,.85);' +
'animation:fxBurstOut ' + (0.5 + Math.random() * .22) + 's cubic-bezier(.15,.75,.25,1) forwards;' +
'--bx:' + (Math.cos(ang)*dist).toFixed(1) + 'px;--by:' + (Math.sin(ang)*dist).toFixed(1) + 'px;';
wrap.appendChild(dot);
}
tapLayer.appendChild(wrap);
setTimeout(function(){ try{ wrap.remove(); }catch(e){} }, 850);
}
/* ── 点触画布（流星掠 / 星芒十字） ── */
var tctx = null, tapParts = [], tapRaf = 0, tapDPR = Math.min(window.devicePixelRatio || 1, 2);
function tapResize(){
if(!tctx) return;
tapCv.width = Math.floor(window.innerWidth * tapDPR);
tapCv.height = Math.floor(window.innerHeight * tapDPR);
tapCv.style.width = window.innerWidth + 'px';
tapCv.style.height = window.innerHeight + 'px';
tctx.setTransform(tapDPR, 0, 0, tapDPR, 0, 0);
}
function glowAt(c, x, y, r, rgb, a){
var g = c.createRadialGradient(x, y, 0, x, y, r);
g.addColorStop(0, 'rgba(' + rgb + ',' + a.toFixed(3) + ')');
g.addColorStop(.4, 'rgba(' + rgb + ',' + (a * .42).toFixed(3) + ')');
g.addColorStop(1, 'rgba(' + rgb + ',0)');
c.fillStyle = g;
c.beginPath(); c.arc(x, y, r, 0, Math.PI * 2); c.fill();
}
function rayAt(c, x, y, ang, len, wid, a){
c.save(); c.translate(x, y); c.rotate(ang);
c.beginPath(); c.moveTo(0, 0); c.lineTo(-len * .07, -len);
c.lineTo(len * .07, -len); c.closePath();
c.fillStyle = 'rgba(255,255,255,' + a.toFixed(3) + ')';
c.fill(); c.restore();
}
function crossAt(c, x, y, len, a){
var g1 = c.createLinearGradient(x - len, y, x + len, y);
g1.addColorStop(0, 'rgba(255,255,255,0)');
g1.addColorStop(.5, 'rgba(255,255,255,' + a.toFixed(3) + ')');
g1.addColorStop(1, 'rgba(255,255,255,0)');
c.fillStyle = g1; c.fillRect(x - len, y - .9, len * 2, 1.8);
var g2 = c.createLinearGradient(x, y - len, x, y + len);
g2.addColorStop(0, 'rgba(214,232,255,0)');
g2.addColorStop(.5, 'rgba(255,255,255,' + a.toFixed(3) + ')');
g2.addColorStop(1, 'rgba(214,232,255,0)');
c.fillStyle = g2; c.fillRect(x - .9, y - len, 1.8, len * 2);
}
function drawTapParts(now){
if(!tctx) return;
var W2 = window.innerWidth, H2 = window.innerHeight;
tctx.clearRect(0, 0, W2, H2);
tctx.globalCompositeOperation = 'lighter';
var alive = [];
for(var i = 0; i < tapParts.length; i++){
var d = tapParts[i], p = (now - d.born) / d.dur;
if(p >= 1) continue;
if(d.kind === 'meteor'){
var L = 74, ang = d.ang, fade = Math.pow(1 - p, 1.15);
for(var k = 0; k < 22; k++){
var f = k / 21;
var px = d.x + Math.cos(ang) * L * f * (0.55 + p * .5);
var py = d.y + Math.sin(ang) * L * f * (0.55 + p * .5);
var a = Math.pow(1 - f, 2.1) * fade * .75;
var r = (1.4 + (1 - f) * 4.0) * (1 - p * .45);
glowAt(tctx, px, py, r * 2.3, '226,238,255', a);
}
var hx = d.x, hy = d.y;
glowAt(tctx, hx, hy, 13, '255,255,255', .85 * fade);
glowAt(tctx, hx + Math.cos(ang + 1.9) * 15, hy + Math.sin(ang + 1.9) * 15, 4.4, '255,255,255', .45 * fade);
glowAt(tctx, hx + Math.cos(ang - 1.6) * 11, hy + Math.sin(ang - 1.6) * 11, 3.2, '255,255,255', .35 * fade);
}else if(d.kind === 'cross'){
var grow = Math.min(1, p / .32);
var A = Math.pow(1 - p, 1.3);
var LL = 22 + 38 * grow;
crossAt(tctx, d.x, d.y, LL, .82 * A);
rayAt(tctx, d.x, d.y, Math.PI / 4, 9 * grow, 2, .45 * A);
rayAt(tctx, d.x, d.y, Math.PI / 4 + Math.PI / 2, 9 * grow, 2, .45 * A);
glowAt(tctx, d.x, d.y, 7 + 10 * grow, '255,255,255', .9 * A);
glowAt(tctx, d.x, d.y, 24, '214,232,255', .16 * A);
}else if(d.kind === 'custom'){
if(d.fn){ try{ d.fn(d.x, d.y); }catch(e){} }
}
alive.push(d);
}
tapParts = alive;
tctx.globalCompositeOperation = 'source-over';
if(tapParts.length){ tapRaf = requestAnimationFrame(function(){ drawTapParts(performance.now()); }); }
else{ tapRaf = 0; tctx.clearRect(0, 0, W2, H2); }
}
/* ── 拖尾引擎 ── */
var ctx = null, dpr = Math.min(window.devicePixelRatio || 1, 2);
var W = 0, H = 0;
function resize(){
W = window.innerWidth; H = window.innerHeight;
trailCv.width = Math.floor(W * dpr); trailCv.height = Math.floor(H * dpr);
trailCv.style.width = W + 'px'; trailCv.style.height = H + 'px';
ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
tapResize();
}
var dust = [], puffs = [], silk = [], flies = [];
var cometPts = [], mistBlobs = [];
var drawing = false, rafId = 0;
var last = {x:0, y:0, t:0};
var vNorm = 0, accDust = 0, accPuff = 0, accFly = 0, accMist = 0;
var head = {x:-999, y:-999, on:false};
var down = false, tick = 0;
function rnd(a, b){ return a + Math.random() * (b - a); }
function spawnDust(x, y, v){
var z = Math.pow(Math.random(), 3.0);
var isStar = Math.random() < 0.15;
var base = isStar ? rnd(1.5, 2.7) : rnd(0.4, 0.95);
var r = base * (0.5 + z * 2.1) * (0.85 + v * 0.25);
dust.push({
x: x + rnd(-2, 2), y: y + rnd(-2, 2), r: r, z: z, star: isStar,
rot: rnd(0, Math.PI * 2), rotV: rnd(-.8, .8) * (0.4 + z),
vx: rnd(-6, 6) * (0.25 + z), vy: rnd(-10, 3) * (0.25 + z),
born: performance.now(),
life: (isStar ? rnd(650, 1050) : rnd(420, 760)) * (0.75 + z * 0.4),
a: (isStar ? rnd(0.8, 1) : rnd(0.2, 0.46)) * (0.4 + z * 0.6),
tw: rnd(0.8, 2.2)
});
if(dust.length > 420) dust.shift();
}
function spawnPuff(x, y, v){
puffs.push({ x:x, y:y, r: rnd(14, 30) * (0.8 + v * 0.5),
born: performance.now(), life: rnd(900, 1500), a: rnd(0.03, 0.07),
vx: rnd(-4, 4), vy: rnd(-7, 2) });
if(puffs.length > 40) puffs.shift();
}
function spawnFly(x, y){
var ang = rnd(0, Math.PI * 2);
flies.push({ x:x + rnd(-6,6), y:y + rnd(-6,6),
born: performance.now(), life: rnd(1100, 1900),
r: rnd(1.4, 3.0), ph: rnd(0, 6.28),
bx: Math.cos(ang) * rnd(3, 9), by: Math.sin(ang) * rnd(3, 9) });
if(flies.length > 60) flies.shift();
}
function drawStarSpikes(p, k){
var s = p.r * (0.6 + k * 0.8);
ctx.save(); ctx.translate(p.x, p.y); ctx.rotate(p.rot);
ctx.globalAlpha = p.a * k; ctx.fillStyle = '#fff';
ctx.shadowColor = 'rgba(196,220,255,.8)'; ctx.shadowBlur = 4 * k;
ctx.beginPath(); ctx.arc(0, 0, s * .4, 0, Math.PI * 2); ctx.fill();
for(var i = 0; i < 4; i++){
ctx.save(); ctx.rotate(i * Math.PI / 2 + Math.PI / 4);
ctx.beginPath(); ctx.moveTo(0, 0); ctx.lineTo(s * .09, -s * 1.45); ctx.lineTo(0, 0);
ctx.closePath(); ctx.fill(); ctx.restore();
}
ctx.restore();
}
function drawSpeck(p, k, now){
var tw = 0.82 + 0.18 * Math.sin(now / 90 * p.tw + p.rot);
var r = p.r * (0.5 + k * 0.9);
var al = p.a * k * tw;
var g = ctx.createRadialGradient(p.x, p.y, 0, p.x, p.y, r * 2.1);
g.addColorStop(0, 'rgba(255,255,255,' + al.toFixed(3) + ')');
g.addColorStop(.45, 'rgba(214,232,255,' + (al * .35).toFixed(3) + ')');
g.addColorStop(1, 'rgba(214,232,255,0)');
ctx.fillStyle = g;
ctx.beginPath(); ctx.arc(p.x, p.y, r * 2.1, 0, Math.PI * 2); ctx.fill();
}
function push(x, y){
var now = performance.now();
var dt = Math.max(now - (last.t || now), 1);
var d = Math.hypot(x - last.x, y - last.y);
var v = Math.min(d / dt * 14, 1);
vNorm = vNorm * .68 + v * .32;
var nx = 0, ny = 0;
if(d > 0){ nx = -(y - last.y) / d; ny = (x - last.x) / d; }
if(mode.trail === 'galaxy' && d > 3){
var stepD = 2.2 + vNorm * 2.6;
var posD = stepD - accDust;
while(posD <= d){
var f = posD / d, off = rnd(-4.5, 4.5) * (0.5 + vNorm);
spawnDust(last.x + (x - last.x) * f + nx * off, last.y + (y - last.y) * f + ny * off, vNorm);
posD += stepD;
}
accDust = d - (posD - stepD); if(accDust < 0 || accDust > stepD) accDust = 0;
var stepP = 46 - vNorm * 12;
var posP = stepP - accPuff;
while(posP <= d){
var f2 = posP / d, off2 = rnd(-10, 10);
spawnPuff(last.x + (x - last.x) * f2 + nx * off2, last.y + (y - last.y) * f2 + ny * off2, vNorm);
posP += stepP;
}
accPuff = d - (posP - stepP); if(accPuff < 0 || accPuff > stepP) accPuff = 0;
}
if(mode.trail === 'silk' && d > 2){
silk.push({ x:x, y:y, w:0.5 + vNorm * 1.1, t:now });
while(silk.length > 90) silk.shift();
}
if(mode.trail === 'comet' && d > 2){
cometPts.push({x:x, y:y, t:now, w: 3.4 + vNorm * 3.6});
while(cometPts.length > 70) cometPts.shift();
if(!drawing){ drawing = true; loop(); }
}
if(mode.trail === 'mist' && d > 6){
var stepM = 30;
var posM = stepM - accMist;
while(posM <= d){
var fm = posM / d, offm = rnd(-6, 6);
mistBlobs.push({ x: last.x + (x - last.x) * fm + nx * offm,
y: last.y + (y - last.y) * fm + ny * offm,
r: rnd(24, 44) * (0.85 + vNorm * .3), born: now,
life: rnd(900, 1450), a: rnd(0.06, 0.10) });
posM += stepM;
}
accMist = d - (posM - stepM); if(accMist < 0 || accMist > stepM) accMist = 0;
while(mistBlobs.length > 60) mistBlobs.shift();
if(!drawing){ drawing = true; loop(); }
}
if(mode.trail === 'firefly' && d > 4){
var stepF = 26 - vNorm * 10;
var posF = stepF - accFly;
while(posF <= d){
var f3 = posF / d;
spawnFly(last.x + (x - last.x) * f3, last.y + (y - last.y) * f3);
posF += stepF;
}
accFly = d - (posF - stepF); if(accFly < 0 || accFly > stepF) accFly = 0;
}
last.x = x; last.y = y; last.t = now;
head.x = x; head.y = y; head.on = true;
if(!drawing){ drawing = true; loop(); }
}
function drawSilk(now){
if(silk.length < 2) return;
for(var i = 1; i < silk.length; i++){
var a = silk[i-1], b = silk[i];
var age = (now - b.t) / 620;
if(age >= 1){ continue; }
var ease = Math.pow(1 - age, 1.6);
ctx.strokeStyle = 'rgba(228,240,255,' + (0.34 * ease).toFixed(3) + ')';
ctx.lineWidth = (0.6 + b.w * 2.2) * Math.pow(ease, .6);
ctx.lineCap = 'round';
ctx.shadowColor = 'rgba(170,205,255,.7)';
ctx.shadowBlur = 8 * ease;
ctx.beginPath(); ctx.moveTo(a.x, a.y); ctx.lineTo(b.x, b.y); ctx.stroke();
}
ctx.shadowBlur = 0;
}
function loop(){
var now = performance.now();
ctx.clearRect(0, 0, W, H);
if(mode.trail === 'galaxy'){
ctx.globalCompositeOperation = 'lighter';
var aliveP = [];
for(var q = 0; q < puffs.length; q++){
var pf = puffs[q], ag = (now - pf.born) / pf.life;
if(ag >= 1) continue;
pf.x += pf.vx / 60; pf.y += pf.vy / 60;
var kk = Math.pow(1 - ag, 1.5);
var gr = ctx.createRadialGradient(pf.x, pf.y, 0, pf.x, pf.y, pf.r);
gr.addColorStop(0, 'rgba(198,220,255,' + (pf.a * kk).toFixed(3) + ')');
gr.addColorStop(.55, 'rgba(180,205,255,' + (pf.a * kk * .4).toFixed(3) + ')');
gr.addColorStop(1, 'rgba(180,205,255,0)');
ctx.fillStyle = gr;
ctx.beginPath(); ctx.arc(pf.x, pf.y, pf.r, 0, Math.PI * 2); ctx.fill();
aliveP.push(pf);
}
puffs = aliveP;
var alive = [];
for(var j = 0; j < dust.length; j++){
var p = dust[j], age2 = (now - p.born) / p.life;
if(age2 >= 1) continue;
p.x += p.vx / 60; p.y += p.vy / 60; p.rot += p.rotV / 60;
var k = 1 - age2;
if(p.star) drawStarSpikes(p, k); else drawSpeck(p, k, now);
alive.push(p);
}
dust = alive;
ctx.globalCompositeOperation = 'source-over';
}else if(mode.trail === 'silk'){
ctx.globalCompositeOperation = 'lighter';
drawSilk(now);
ctx.globalCompositeOperation = 'source-over';
while(silk.length && now - silk[0].t > 620) silk.shift();
}else if(mode.trail === 'firefly'){
ctx.globalCompositeOperation = 'lighter';
var aliveF = [];
for(var m = 0; m < flies.length; m++){
var fl = flies[m], agf = (now - fl.born) / fl.life;
if(agf >= 1) continue;
var fade = Math.sin(Math.min(agf, 1) * Math.PI);
var ox = fl.bx * (1 - agf) + Math.sin(now / 520 + fl.ph) * 4;
var oy = fl.by * (1 - agf) - agf * 18 + Math.cos(now / 640 + fl.ph) * 3;
var g2 = ctx.createRadialGradient(fl.x + ox, fl.y + oy, 0, fl.x + ox, fl.y + oy, fl.r * 3.2);
var aa = 0.75 * fade;
g2.addColorStop(0, 'rgba(255,252,232,' + aa.toFixed(3) + ')');
g2.addColorStop(.4, 'rgba(226,238,255,' + (aa * .35).toFixed(3) + ')');
g2.addColorStop(1, 'rgba(210,230,255,0)');
ctx.fillStyle = g2;
ctx.beginPath(); ctx.arc(fl.x + ox, fl.y + oy, fl.r * 3.2, 0, Math.PI * 2); ctx.fill();
aliveF.push(fl);
}
flies = aliveF;
ctx.globalCompositeOperation = 'source-over';
}
if(mode.trail === 'comet'){
ctx.globalCompositeOperation = 'lighter';
for(var ci = 1; ci < cometPts.length; ci++){
var ca = cometPts[ci-1], cb = cometPts[ci];
var cage = (now - cb.t) / 560;
if(cage >= 1) continue;
var ce = Math.pow(1 - cage, 1.7);
/* 柔光底：沿尾越旧越淡越窄 */
glowAt(ctx, cb.x, cb.y, 10 + cb.w * 2.4 * ce, '180,210,255', 0.085 * ce);
/* 外晕 */
ctx.strokeStyle = 'rgba(186,214,255,' + (0.14 * ce).toFixed(3) + ')';
ctx.lineWidth = Math.max(.5, cb.w * 2.6 * ce);
ctx.lineCap = 'round';
ctx.beginPath(); ctx.moveTo(ca.x, ca.y); ctx.lineTo(cb.x, cb.y); ctx.stroke();
/* 亮核 */
ctx.strokeStyle = 'rgba(246,250,255,' + (0.55 * Math.pow(1 - cage, 1.3)).toFixed(3) + ')';
ctx.lineWidth = Math.max(.3, cb.w * 1.05 * Math.pow(1 - cage, 1.1));
ctx.beginPath(); ctx.moveTo(ca.x, ca.y); ctx.lineTo(cb.x, cb.y); ctx.stroke();
}
ctx.globalCompositeOperation = 'source-over';
while(cometPts.length && now - cometPts[0].t > 560) cometPts.shift();
}
if(mode.trail === 'mist'){
ctx.globalCompositeOperation = 'lighter';
var aliveM = [];
for(var mi = 0; mi < mistBlobs.length; mi++){
var mb = mistBlobs[mi], mag = (now - mb.born) / mb.life;
if(mag >= 1) continue;
var mk = Math.pow(1 - mag, 1.3);
var mm = ctx.createRadialGradient(mb.x, mb.y, 0, mb.x, mb.y, mb.r * (0.7 + mag * .6));
mm.addColorStop(0, 'rgba(186,212,255,' + (mb.a * mk).toFixed(3) + ')');
mm.addColorStop(.45, 'rgba(198,222,255,' + (mb.a * mk * .55).toFixed(3) + ')');
mm.addColorStop(1, 'rgba(198,222,255,0)');
ctx.fillStyle = mm;
ctx.beginPath(); ctx.arc(mb.x, mb.y, mb.r * (0.7 + mag * .6), 0, Math.PI * 2); ctx.fill();
aliveM.push(mb);
}
mistBlobs = aliveM;
ctx.globalCompositeOperation = 'source-over';
}
/* 自定义拖尾：交给用户代码画 */
if(mode.trail === 'custom:'){
var item = findByMode('custom:');
var fn = item && compile(item);
if(fn){
ctx.globalCompositeOperation = 'lighter';
try{ fn(ctx, {x:head.x, y:head.y, down:down, v:vNorm, W:W, H:H}, now); }catch(e){ mode.trail = 'none'; }
ctx.globalCompositeOperation = 'source-over';
}else{ mode.trail = 'none'; }
}
if(head.on && mode.trail !== 'none'){
var hr = 5 + vNorm * 6;
var hg = ctx.createRadialGradient(head.x, head.y, 0, head.x, head.y, hr);
hg.addColorStop(0, 'rgba(255,255,255,.62)');
hg.addColorStop(.45, 'rgba(206,226,255,.15)');
hg.addColorStop(1, 'rgba(206,226,255,0)');
ctx.fillStyle = hg;
ctx.beginPath(); ctx.arc(head.x, head.y, hr, 0, Math.PI * 2); ctx.fill();
}
var busy = dust.length || puffs.length || silk.length || flies.length ||
cometPts.length || mistBlobs.length || down;
if(busy){ rafId = requestAnimationFrame(loop); }
else{
drawing = false; head.on = false;
ctx.clearRect(0, 0, W, H);
}
}
function findByMode(kind){
var id = mode[kind === 'tap' ? 'tap' : 'trail'].slice(7);
for(var i = 0; i < custom.length; i++) if(custom[i].id === id) return custom[i];
return null;
}
/* ── 外露 API ── */
window.FXEngine = {
init: function(defaults){
ensureDom();
ctx = trailCv.getContext('2d');
ensureDom();
tctx = tapCv.getContext('2d');
resize();
window.addEventListener('resize', resize);
var tap = _pref('fxTap', LS.tap, (defaults && defaults.tap) || 'none');
var tr = _pref('fxTrail', LS.trail, (defaults && defaults.trail) || 'none');
this.setTap(tap); this.setTrail(tr);
var selfFx = this;
setTimeout(function(){
try{
if(window.appSettings){
if(appSettings.fxTap) selfFx.setTap(appSettings.fxTap);
if(appSettings.fxTrail) selfFx.setTrail(appSettings.fxTrail);
}
}catch(e){}
}, 900);
var self = this, lastDownT = 0;
function onDown(e){
try{
var _s = document.querySelector('[data-fxsel="tap"]');
if(_s && _s.value && mode.tap !== _s.value) self.setTap(_s.value);
}catch(e0){}
var p = (e.touches && e.touches[0]) || (e.changedTouches && e.changedTouches[0]) || e;
if(!p) return;
var now = performance.now();
if(now - lastDownT < 80) return;
lastDownT = now;
self.tapAt(p.clientX, p.clientY);
}
function onMove(e){
try{
var _st = document.querySelector('[data-fxsel="trail"]');
if(_st && _st.value && mode.trail !== _st.value) self.setTrail(_st.value);
}catch(e1){}
if(mode.trail === 'none') return;
var p = (e.touches && e.touches[0]) || (e.changedTouches && e.changedTouches[0]) || e;
if(!p) return;
var now = performance.now();
if(now - tick < 8) return;
tick = now;
if(!down){ down = true; last.x = p.clientX; last.y = p.clientY; last.t = now; }
push(p.clientX, p.clientY);
}
function onUp(){ down = false; head.on = false; }
/* 捕获阶段挂，避免被正文里 stopPropagation 吃掉 */
['pointerdown', 'touchstart'].forEach(function(k){
window.addEventListener(k, onDown, {passive:true, capture:true});
document.addEventListener(k, onDown, {passive:true, capture:true});
});
['pointermove', 'touchmove'].forEach(function(k){
window.addEventListener(k, onMove, {passive:true, capture:true});
document.addEventListener(k, onMove, {passive:true, capture:true});
});
['pointerup', 'pointercancel', 'touchend', 'touchcancel'].forEach(function(k){
window.addEventListener(k, onUp, {passive:true, capture:true});
document.addEventListener(k, onUp, {passive:true, capture:true});
});
},
tapAt: function(x, y){
ensureDom();
if(mode.tap === 'star') tapLayer.style.display = 'block';
if(mode.tap === 'star') tapStar(x, y);
else if(mode.tap === 'meteor' || mode.tap === 'cross'){
tapLayer.style.display = 'block';
tapFlash(x, y);
if(!tctx){ tctx = tapCv.getContext('2d'); tapResize(); }
tapCv.style.display = 'block';
tapParts.push({ kind: mode.tap, x: x, y: y, born: performance.now(),
dur: mode.tap === 'meteor' ? 540 : 760,
ang: -0.62 + (Math.random() - .5) * .35, fn: null });
if(!tapRaf) tapRaf = requestAnimationFrame(function(){ drawTapParts(performance.now()); });
}
else if(mode.tap === 'ring') tapRing(x, y);
else if(mode.tap === 'burst') tapBurst(x, y);
else if(mode.tap.indexOf('custom:') === 0){
var item = findByMode('tap'), fn = item && compile(item);
if(fn){
if(!tctx){ tctx = tapCv.getContext('2d'); tapResize(); }
tapCv.style.display = 'block';
tapParts.push({ kind:'custom', x:x, y:y, born: performance.now(), dur: 1200, fn: fn });
if(!tapRaf) tapRaf = requestAnimationFrame(function(){ drawTapParts(performance.now()); });
}
}
},
setTap: function(name){
mode.tap = name || 'none';
lsSet(LS.tap, mode.tap);
_persist('fxTap', mode.tap);
ensureDom();
tapLayer.style.display = mode.tap === 'star' ? 'block' : 'none';
if(tapCv) tapCv.style.display = (mode.tap === 'meteor' || mode.tap === 'cross' ||
mode.tap.indexOf('custom:') === 0) ? 'block' : 'none';
if(mode.tap === 'none'){ tapParts = []; }
},
setTrail: function(name){
mode.trail = name || 'none';
lsSet(LS.trail, mode.trail);
_persist('fxTrail', mode.trail);
ensureDom();
trailCv.style.display = mode.trail === 'none' ? 'none' : 'block';
if(mode.trail !== 'none'){ resize(); }
if(mode.trail === 'none'){
dust.length = 0; puffs.length = 0; silk.length = 0; flies.length = 0;
cometPts.length = 0; mistBlobs.length = 0; down = false;
if(ctx) ctx.clearRect(0, 0, W, H);
}
},
list: function(){
return {
tap: [ {v:'none', name:'无'}, {v:'star', name:'五角星'},
{v:'meteor', name:'流星掠'}, {v:'cross', name:'星芒十字'} ]
.concat(custom.filter(function(c){ return c.kind === 'tap'; })
.map(function(c){ return {v:'custom:' + c.id, name:'自定义·' + c.name}; })),
trail: [ {v:'none', name:'无'}, {v:'galaxy', name:'银河星尘'},
{v:'comet', name:'彗尾'}, {v:'mist', name:'星雾'} ]
.concat(custom.filter(function(c){ return c.kind === 'trail'; })
.map(function(c){ return {v:'custom:' + c.id, name:'自定义·' + c.name}; }))
};
},
customList: function(kind){
return custom.filter(function(c){ return c.kind === kind; });
},
addCustom: function(kind, name, code){
var id = 'c' + Date.now().toString(36) + Math.floor(Math.random() * 99);
var item = {id:id, name:String(name || '未命名').slice(0, 16), kind:kind, code:String(code || '')};
/* 编译一次，语法错就不收 */
var test = kind === 'tap'
? new Function('x', 'y', item.code)
: new Function('ctx', 'pts', 'now', item.code);
if(!test) return null;
custom.push(item); saveCustom();
return item;
},
updateCustom: function(id, name, code){
var hit = custom.filter(function(c){ return c.id === id; })[0];
if(!hit) return null;
var item = {id:id, name:String(name || hit.name).slice(0, 16), kind:hit.kind, code:String(code == null ? hit.code : code)};
var test = item.kind === 'tap'
? new Function('x', 'y', item.code)
: new Function('ctx', 'pts', 'now', item.code);
if(!test) return null;
hit.name = item.name; hit.code = item.code;
delete compiled[id];                 /* 旧代码已编译过，必须丢掉缓存，否则改完还是跑旧的 */
saveCustom();
return hit;
},
removeCustom: function(id){
custom = custom.filter(function(c){ return c.id !== id; });
delete compiled[id];
try{ var d = _lsDel(); if(d.indexOf(id) === -1) d.push(id); lsSet(LS.del, JSON.stringify(d)); }catch(e){}
saveCustom();
if(mode.tap.indexOf(id) !== -1) this.setTap('none');
if(mode.trail.indexOf(id) !== -1) this.setTrail('none');
},
mode: function(){ return mode; }
};
/* 供设置页读取（未 init 时也能取到已选值） */
/* 开局即按上次的选择生效；默认「无」 */
window.FXEngine.init({tap:'none', trail:'none'});
/* ── 文游 JSON 容错：模型偶尔输出「带裸换行 / 中文引号 / 尾逗号」的 JSON，
直接 JSON.parse 失败后以前会把整块 JSON 当旁白显示出来。这里先修再解析。 ── */
window.__vnRepairJSON = function(txt){
try{
var t = String(txt || '');
t = t.replace(/^\uFEFF/, '').replace(/<think>[\s\S]*?<\/think>/gi, '');
var fm = t.match(/```(?:json)?\s*([\s\S]*?)```/);
if(fm) t = fm[1];
var bs = t.indexOf('{'), be = t.lastIndexOf('}');
if(bs !== -1 && be > bs) t = t.slice(bs, be + 1);
t = t.replace(/[\u201c\u201d]/g, '"').replace(/[\u2018\u2019]/g, "'");
var out = '', inStr = false, esc = false;
for(var i = 0; i < t.length; i++){
var c = t.charAt(i);
if(inStr){
if(esc){ out += c; esc = false; continue; }
if(c === '\\'){ out += c; esc = true; continue; }
if(c === '"'){ inStr = false; out += c; continue; }
if(c === '\n'){ out += '\\n'; continue; }
if(c === '\r'){ continue; }
if(c === '\t'){ out += '\\t'; continue; }
out += c; continue;
}
if(c === '"'){ inStr = true; out += c; continue; }
out += c;
}
out = out.replace(/,\s*([}\]])/g, '$1');
return out;
}catch(e){ return null; }
};
/* 判断一条 assistant 文本是否是可用的剧情节点（合法 JSON 且有 segments） */
window.__vnIsNode = function(txt){
try{
var t = String(txt || '');
if(!t) return false;
if(/^\s*(I cannot|I can't|I'm unable|I am unable|As an AI|Sorry,? I)/i.test(t)) return false;
var m = t.match(/```(?:json)?\s*([\s\S]*?)```/);
if(m) t = m[1];
var bs = t.indexOf('{'), be = t.lastIndexOf('}');
if(bs === -1 || be <= bs) return false;
var body = t.slice(bs, be + 1);
var p = null;
try{ p = JSON.parse(body); }catch(e){
if(window.__vnRepairJSON){ try{ p = JSON.parse(window.__vnRepairJSON(body)); }catch(e2){ p = null; } }
}
return !!(p && p.segments && p.segments.length);
}catch(e){ return false; }
};
window.__fxGet = function(kind){
try{ return window.FXEngine ? window.FXEngine.mode()[kind] : lsGet(kind === 'tap' ? LS.tap : LS.trail, 'none'); }catch(e){ return 'none'; }
};
/* 导入自定义特效后刷新设置页里的选项列表（以前这个钩子只被调用、从没定义，
结果新增的自定义特效存进去了，但列表里看不到） */
window.__fxRefresh = function(){
try{
['tap','trail'].forEach(function(kind){
var sel = document.querySelector('[data-fxsel="' + kind + '"]');
if(!sel || !window.FXEngine) return;
var list = window.FXEngine.list()[kind] || [];
var cur = window.__fxGet(kind);
/* 只在选项签名变化时重建：这个函数会被 500ms 轮询/存档回调反复调用，
每次重写 innerHTML 会让设置页每半秒闪一下 */
var sig = cur + '|' + list.map(function(o){ return o.v + ':' + o.name; }).join(',');
if(sel.getAttribute('data-fxsig') === sig) return;
sel.setAttribute('data-fxsig', sig);
sel.innerHTML = list.map(function(o){
return '<option value="' + o.v + '"' + (o.v === cur ? ' selected' : '') + '>' + o.name + '</option>';
}).join('');
try{ sel.value = cur; }catch(e0){}
});
}catch(e){}
};
})();
/* ── 导入自定义特效的弹窗 ── */
(function(){
var TPL = {
tap: "/* 点触自定义：拿到的 x,y 是手指坐标；\n   自己建元素挂在 body 上，记得 1 秒内清掉，否则会越积越多。\n   可用：window.FXEngine （不要在这里调 setTap/setTrail） */\nvar el = document.createElement('div');\nel.style.cssText = 'position:fixed;left:'+x+'px;top:'+y+'px;width:26px;height:26px;border-radius:50%;'+\n  'transform:translate(-50%,-50%);background:radial-gradient(circle,#fff,rgba(160,210,255,0));'+\n  'pointer-events:none;z-index:902;transition:transform .6s ease-out,opacity .6s ease-out;';\ndocument.body.appendChild(el);\nrequestAnimationFrame(function(){ el.style.transform='translate(-50%,-50%) scale(1.8)'; el.style.opacity='0'; });\nsetTimeout(function(){ el.remove(); }, 700);",
trail: "/* 拖尾自定义：每帧调用一次。\n   ctx：画布 2D 上下文（已经切到 lighter 叠加模式）\n   pts：{x,y,down,v,W,H}  —— down 表示手指还按着，v 是速度 0~1\n   now：performance.now()\n   自己维护状态请挂在 window 上 */\nvar st = window.__myTrail = window.__myTrail || {dots:[]};\nif(pts.down){\n  st.dots.push({x:pts.x,y:pts.y,r:2+Math.random()*3,life:1});\n}\nfor(var i=st.dots.length-1;i>=0;i--){\n  var d=st.dots[i]; d.life-=0.03; if(d.life<=0){ st.dots.splice(i,1); continue; }\n  ctx.fillStyle='rgba(255,255,255,'+(d.life*0.8).toFixed(2)+')';\n  ctx.beginPath(); ctx.arc(d.x,d.y,d.r*d.life,0,Math.PI*2); ctx.fill();\n}"
};
function build(){
if(document.getElementById('fxImportModal')) return;
var ov = document.createElement('div');
ov.id = 'fxImportModal';
/* 纯色不透明底：宿主 WebView 对「半透明遮罩 + 合成层」渲染不稳，
之前加了 translateZ/backface 之后整块会透出背后页面（看起来像透明底）。
现在去掉合成层属性，底色用实色。 */
ov.style.cssText = 'position:fixed;left:0;top:0;right:0;bottom:0;z-index:10000;background:#05080e;display:flex;align-items:center;justify-content:center;padding:18px;';
ov.innerHTML =
'<div style="width:100%;max-width:420px;max-height:86vh;overflow:auto;background:var(--surface,#0b1220);border:1px solid var(--border,rgba(255,255,255,.14));border-radius:16px;padding:16px;box-sizing:border-box;">'
+ '<div style="font-size:13px;letter-spacing:.16em;margin-bottom:10px;color:var(--text,#fff);" id="fxImpTitle">导入自定义特效</div>'
+ '<div style="font-size:10px;line-height:1.7;color:var(--text3,rgba(255,255,255,.45));margin-bottom:10px;" id="fxImpTip"></div>'
+ '<input id="fxImpName" placeholder="给它起个名字（≤16 字）" maxlength="16" style="width:100%;box-sizing:border-box;margin-bottom:8px;padding:9px 11px;border-radius:10px;border:1px solid var(--border,rgba(255,255,255,.14));background:rgba(255,255,255,.05);color:var(--text,#fff);font-size:12px;outline:none;">'
+ '<textarea id="fxImpCode" spellcheck="false" placeholder="在这里粘贴你的代码…（不会自动替换成模板）" style="width:100%;box-sizing:border-box;height:210px;padding:10px 11px;border-radius:10px;border:1px solid var(--border,rgba(255,255,255,.14));background:rgba(255,255,255,.04);color:var(--text,#fff);font:11.5px/1.7 ui-monospace,monospace;outline:none;resize:vertical;"></textarea>'
+ '<div style="display:flex;gap:8px;align-items:center;margin-top:8px;flex-wrap:wrap;">'
+ '<button id="fxImpTplShow" type="button" style="min-height:30px;padding:6px 10px;border-radius:9px;border:1px solid rgba(127,208,255,.34);background:rgba(127,208,255,.1);color:var(--accent,#7fd0ff);font-size:10.5px;letter-spacing:.06em;cursor:pointer;">查看模板</button>'
+ '<button id="fxImpTplFill" type="button" style="min-height:30px;padding:6px 10px;border-radius:9px;border:1px solid rgba(255,255,255,.14);background:transparent;color:var(--text3,rgba(255,255,255,.6));font-size:10.5px;letter-spacing:.06em;cursor:pointer;">填入模板</button>'
+ '<button id="fxImpTplCopy" type="button" style="min-height:30px;padding:6px 10px;border-radius:9px;border:1px solid rgba(255,255,255,.14);background:transparent;color:var(--text3,rgba(255,255,255,.6));font-size:10.5px;letter-spacing:.06em;cursor:pointer;">复制模板</button>'
+ '</div>'
+ '<div id="fxImpTplBox" style="display:none;margin-top:8px;padding:9px 10px;border-radius:10px;border:1px solid rgba(255,255,255,.1);background:rgba(255,255,255,.03);max-height:150px;overflow:auto;font:10.5px/1.65 ui-monospace,monospace;color:var(--text3,rgba(255,255,255,.55));white-space:pre-wrap;word-break:break-all;"></div>'
+ '<div id="fxImpList" style="margin:10px 0 4px;"></div>'
+ '<div style="display:flex;gap:8px;justify-content:flex-end;margin-top:10px;">'
+ '<span id="fxImpCancel" style="font-size:11px;padding:8px 14px;border-radius:10px;border:1px solid var(--border,rgba(255,255,255,.16));color:var(--text3,rgba(255,255,255,.6));cursor:pointer;">取消</span>'
+ '<span id="fxImpSave" style="font-size:11px;padding:8px 14px;border-radius:10px;border:1px solid rgba(160,230,255,.32);color:var(--accent,#7fd0ff);cursor:pointer;letter-spacing:.1em;">添加</span>'
+ '</div></div>';
document.body.appendChild(ov);
/* 按 visualViewport 固定：键盘收起、地址栏伸缩时不会再改高度，整块不会抖/闪 */
/* 打开时就把高度钉死：键盘收起/地址栏伸缩期间不再逐帧改高度，避免整块连闪。
弹窗内容自己滚动，不依赖视口变化。 */
try{
var _h0 = window.innerHeight || 800;
ov.style.top = '0'; ov.style.height = _h0 + 'px'; ov.style.bottom = 'auto';
window.addEventListener('resize', function(){
if(!ov.isConnected) return;
var h = window.innerHeight || _h0;
ov.style.height = h + 'px';
});
}catch(e){}
window.__fxModalOpen = 1;   /* 弹窗期间暂停后台轮询/存档 */
ov.addEventListener('click', function(e){ if(e.target === ov) close(); });
ov.querySelector('#fxImpTplShow').onclick = function(){
var box = ov.querySelector('#fxImpTplBox');
var shown = box.style.display !== 'none';
box.style.display = shown ? 'none' : 'block';
this.textContent = shown ? '查看模板' : '收起模板';
};
var _copyLock = 0;
function doCopy(){
var now0 = Date.now();
if(now0 - _copyLock < 600) return;   /* 一次点击可能同时触发 pointerup + click，去重 */
_copyLock = now0;
var kind0 = ov.getAttribute('data-kind') || 'tap';
var txt = TPL[kind0] || '';
var self = this;
function _fxTip(txt){
try{
var t = document.createElement('div');
t.textContent = txt;
t.style.cssText = 'position:absolute;left:50%;top:12%;transform:translateX(-50%);padding:10px 18px;border-radius:999px;'
+ 'background:rgba(10,16,26,.96);border:1px solid rgba(127,208,255,.5);color:#dff2ff;font-size:12px;letter-spacing:.06em;'
+ 'z-index:10002;pointer-events:none;box-shadow:0 8px 26px rgba(0,0,0,.5);opacity:0;transition:opacity .16s ease;';
ov.appendChild(t);
requestAnimationFrame(function(){ t.style.opacity = '1'; });
setTimeout(function(){ try{ t.style.opacity = '0'; setTimeout(function(){ t.remove(); }, 240); }catch(e){} }, 1600);
}catch(e){}
}
function done(ok){
try{ API.ui.toast(ok ? '模板已复制' : '已选中模板，长按复制'); }catch(e){}
/* 弹一个明显的气泡，避免“按了没反应” */
_fxTip(ok ? '✓ 模板已复制' : '已选中模板，长按复制');
/* toast 在部分主题/宿主里会被遮罩吃掉，按钮自己也要给反馈 */
try{
var btnEl = ov.querySelector('#fxImpTplCopy');
if(btnEl){
btnEl.textContent = ok ? '✓ 已复制' : '已选中，长按复制';
btnEl.style.borderColor = 'rgba(120,230,170,.5)';
btnEl.style.color = 'rgba(150,235,190,.95)';
setTimeout(function(){
if(!btnEl) return;
btnEl.textContent = '复制模板';
btnEl.style.borderColor = 'rgba(255,255,255,.14)';
btnEl.style.color = 'rgba(255,255,255,.6)';
}, 1400);
}
}catch(e){}
}
try{
if(navigator.clipboard && navigator.clipboard.writeText){
navigator.clipboard.writeText(txt).then(function(){ done(true); }, function(){ fallback(); });
return;
}
}catch(e){}
fallback();
function fallback(){
var ok = false;
try{
var ta = document.createElement('textarea');
ta.value = txt;
ta.setAttribute('readonly','');
ta.style.cssText = 'position:fixed;left:0;top:0;width:1px;height:1px;opacity:0;pointer-events:none;';
document.body.appendChild(ta);
ta.select(); ta.setSelectionRange(0, txt.length);
try{ ok = document.execCommand('copy'); }catch(e1){ ok = false; }
document.body.removeChild(ta);
}catch(e3){ ok = false; }
if(!ok){
var box = ov.querySelector('#fxImpTplBox');
box.style.display = 'block';
ov.querySelector('#fxImpTplShow').textContent = '收起模板';
try{
var rng = document.createRange(); rng.selectNodeContents(box);
var selr = window.getSelection(); selr.removeAllRanges(); selr.addRange(rng);
}catch(e2){}
}
done(ok);
}
}
var copyBtn = ov.querySelector('#fxImpTplCopy');
copyBtn.onclick = doCopy;
copyBtn.addEventListener('pointerup', doCopy);
ov.querySelector('#fxImpTplFill').onclick = function(){
var kind0 = ov.getAttribute('data-kind') || 'tap';
ov.querySelector('#fxImpCode').value = TPL[kind0] || '';
var box = ov.querySelector('#fxImpTplBox'); box.style.display = 'none';
ov.querySelector('#fxImpTplShow').textContent = '查看模板';
ov.querySelector('#fxImpCode').scrollTop = 0;
};
ov.querySelector('#fxImpCancel').onclick = close;
ov.querySelector('#fxImpSave').onclick = save;
function resetEdit(){
editing = null;
ov.querySelector('#fxImpName').value = '';
/* 代码框刻意不清：刚存完往往还要顺手微调，清空/换模板最烦人 */
var saveBtn = ov.querySelector('#fxImpSave'); if(saveBtn) saveBtn.textContent = '添加';
var tip = ov.querySelector('#fxImpTip');
var k0 = ov.getAttribute('data-kind') || 'tap';
if(tip) tip.textContent = k0 === 'tap'
? '代码在手指按下时执行一次，参数 x、y 是坐标。别动布局，也别在这里改开关。'
: '代码每一帧执行一次，参数 ctx、pts（{x,y,down,v,W,H}）、now。只画，不要改页面结构。';
}
function close(){ window.__fxModalOpen = 0; try{ ov.remove(); }catch(e){} }
var editing = null;                    /* 正在编辑的自定义特效 id；null = 新增 */
function renderList(kind){
var box = ov.querySelector('#fxImpList');
var arr = window.FXEngine ? window.FXEngine.customList(kind) : [];
if(!arr.length){ box.innerHTML = ''; return; }
box.innerHTML = '<div style="font-size:10px;color:var(--text3,rgba(255,255,255,.45));margin-bottom:4px;">已导入</div>'
+ arr.map(function(c){
return '<div style="display:flex;align-items:center;justify-content:space-between;gap:8px;padding:6px 0;border-bottom:1px solid rgba(255,255,255,.06);">'
+ '<span style="font-size:11px;color:var(--text,rgba(255,255,255,.8));min-width:0;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;">' + c.name + '</span>'
+ '<span style="flex:0 0 auto;display:flex;gap:10px;">'
+ '<span data-edit="' + c.id + '" style="font-size:10px;color:var(--accent,#7fd0ff);cursor:pointer;">编辑</span>'
+ '<span data-del="' + c.id + '" style="font-size:10px;color:#ff8f8f;cursor:pointer;">删除</span>'
+ '</span></div>';
}).join('');
Array.prototype.forEach.call(box.querySelectorAll('[data-del]'), function(el){
el.onclick = function(){
var id = this.getAttribute('data-del');
window.FXEngine.removeCustom(id);
if(editing === id) resetEdit();
renderList(kind);
try{ if(window.__fxRefresh) window.__fxRefresh(); }catch(e){}   /* 同步刷新设置页的点触/拖尾列表 */
try{ API.ui.toast('已删除'); }catch(e){}
};
});
Array.prototype.forEach.call(box.querySelectorAll('[data-edit]'), function(el){
el.onclick = function(){
var id = this.getAttribute('data-edit');
var arr = window.FXEngine ? window.FXEngine.customList(kind) : [];
var hit = arr.filter(function(c){ return c.id === id; })[0];
if(!hit) return;
editing = id;
ov.querySelector('#fxImpName').value = hit.name;
ov.querySelector('#fxImpCode').value = hit.code;
ov.querySelector('#fxImpSave').textContent = '保存修改';
ov.querySelector('#fxImpTip').textContent = '正在修改「' + hit.name + '」：改完点「保存修改」，不用重新导入。';
try{ ov.querySelector('#fxImpCode').scrollTop = 0; }catch(e){}
try{ ov.querySelector('#fxImpName').focus(); }catch(e){}
};
});
}
function save(){
var name = ov.querySelector('#fxImpName').value.trim();
var code = ov.querySelector('#fxImpCode').value;
if(!name){ try{API.ui.toast('先起个名字');}catch(e){} return; }
if(!code.trim()){ try{API.ui.toast('代码是空的');}catch(e){} return; }
var item = null, isEdit = !!editing, editId = editing;
try{
item = isEdit
? window.FXEngine.updateCustom(editId, name, code)
: window.FXEngine.addCustom(ov.getAttribute('data-kind'), name, code);
}
catch(err){ item = null; }
if(!item){ try{API.ui.toast('代码有语法错，先修一下');}catch(e){} return; }
try{ API.ui.toast((isEdit ? '已更新：' : '已导入：') + name); }catch(e){}
resetEdit();
renderList(ov.getAttribute('data-kind'));
/* 让设置页的选项列表刷新 */
if(window.__fxRefresh) window.__fxRefresh();
}
ov.__renderList = renderList;
ov.__resetEdit = resetEdit;
}
window.__fxImport = function(kind){
build();
var ov = document.getElementById('fxImportModal');
if(!ov) return;
window.__fxModalOpen = 1;
ov.setAttribute('data-kind', kind);
try{ ov.__resetEdit ? ov.__resetEdit() : null; }catch(e){}
ov.querySelector('#fxImpTitle').textContent = '导入自定义' + (kind === 'tap' ? '点触' : '拖尾') + '特效';
ov.querySelector('#fxImpTip').textContent = kind === 'tap'
? '代码在手指按下时执行一次，参数 x、y 是坐标。别动布局，也别在这里改开关。'
: '代码每一帧执行一次，参数 ctx、pts（{x,y,down,v,W,H}）、now。只画，不要改页面结构。';
ov.querySelector('#fxImpCode').value = '';
var tplBox = ov.querySelector('#fxImpTplBox');
if(tplBox){
tplBox.textContent = TPL[kind] || '';
tplBox.style.display = 'none';
var tplShow = ov.querySelector('#fxImpTplShow'); if(tplShow) tplShow.textContent = '查看模板';
}
ov.__renderList(kind);
};
})();
;
/* 状态栏挂件：开关 / 换图 / 大小（所有主题共用一套物理，只换贴图） */
(function(){
var cfg = window.__HangCfg = { on:true, src:'', size:1, ver:0, img:null, srcL:'', srcR:'', imgL:null, imgR:null };
function ls(k,d){ try{ var v = localStorage.getItem(k); return v == null ? d : v; }catch(e){ return d; } }
function loadImg(){
cfg.img = null;
if(!cfg.src) return;
var im = new Image();
im.onload = function(){ cfg.img = im; cfg.ver++; };
im.onerror = function(){ cfg.img = null; };
im.src = cfg.src;
}
function loadSide(which, src){
var key = which === 'l' ? 'imgL' : 'imgR';
cfg[key] = null;
if(!src) return;
var im = new Image();
im.onload = function(){ cfg[key] = im; cfg.ver++; };
im.onerror = function(){ cfg[key] = null; };
im.src = src;
}
window.__hangSync = function(){
var on = true, src = '', size = 1;
try{
if(window.appSettings){
if(typeof appSettings.hangOn === 'boolean') on = appSettings.hangOn;
if(typeof appSettings.hangImg === 'string') src = appSettings.hangImg;
if(appSettings.hangSize != null) size = Number(appSettings.hangSize) || 0;
}
}catch(e){}
if(!src) src = ls('isekai_hang_img', '');
if(size !== 0 && size !== 1 && size !== 2) size = 1;
var srcL = '', srcR = '';
try{
if(window.appSettings){
if(typeof appSettings.hangImgL === 'string') srcL = appSettings.hangImgL;
if(typeof appSettings.hangImgR === 'string') srcR = appSettings.hangImgR;
}
}catch(e){}
if(!srcL) srcL = ls('isekai_hang_l', '');
if(!srcR) srcR = ls('isekai_hang_r', '');
var lon = ls('isekai_hang_on', '');
if(lon === '0') on = false;
var lsz = ls('isekai_hang_size', '');
if(lsz !== ''){ var n = Number(lsz); if(n === 0 || n === 1 || n === 2) size = n; }
/* 用户亲手改过的值以“小键”为准：DB/镜像里的旧行经常比它晚到、或者干脆是上一次失败写入留下的旧值，
所以这里不是兜底，是让键压过其它所有来源（键只在用户改动时更新，恢复默认也会写空，不会误伤） */
try{
var _kp = null, _ki = null;
try{ _kp = JSON.parse(localStorage.getItem('isekai_hang_pick') || 'null'); }catch(e0){ _kp = null; }
try{ window.__stg && window.__stg('读配置 on=' + (on ? 1 : 0) + ' size=' + size + ' L=' + String(((window.appSettings && appSettings.hangImgL) || '').length)); }catch(e){}
try{ _ki = JSON.parse(localStorage.getItem('isekai_hang_imgs') || 'null'); }catch(e1){ _ki = null; }
var _kts = Math.max(Number(_kp && _kp.ts) || 0, Number(_ki && _ki.ts) || 0);
var _ats = (window.appSettings && Number(appSettings.hangTs)) || 0;
/* 键只有比配置行更新时才采用：否则旧键会把用户刚刚保存的新值顶回去 */
if(_kts > _ats){
if(_kp){
if(typeof _kp.on === 'boolean') on = _kp.on;
var _ks = Number(_kp.size);
if(_ks === 0 || _ks === 1 || _ks === 2) size = _ks;
}
if(_ki){
try{ window.__stg && window.__stg('图片读键 L=' + String(((_ki&&_ki.imgL)||'').length)); }catch(e){}
if(typeof _ki.imgL === 'string') srcL = _ki.imgL;
if(typeof _ki.imgR === 'string') srcR = _ki.imgR;
if(typeof _ki.img === 'string') src = _ki.img;
}
}
}catch(e2){}
// 兼容旧版单图：整串替换
if(!src && (srcL || srcR)){ src = ''; }
try{ window.__stg && window.__stg('最终 on=' + (on ? 1 : 0) + ' size=' + size + ' L=' + String((srcL || '').length)); }catch(e){}
cfg.on = on; cfg.size = size;
if(src !== cfg.src){ cfg.src = src; loadImg(); }
if(srcL !== cfg.srcL){ cfg.srcL = srcL; loadSide('l', srcL); }
if(srcR !== cfg.srcR){ cfg.srcR = srcR; loadSide('r', srcR); }
cfg.ver++;
return cfg;
};
window.__hangUpdate = function(patch){
try{
if(window.appSettings){
Object.keys(patch).forEach(function(k){ appSettings[k] = patch[k]; });
/* 记“最后一次用户改动”的时间，读档时用来判断键和配置行谁更新 */
try{
if(['hangOn','hangSize','hangImg','hangImgL','hangImgR','vfFabImg'].some(function(k){ return patch[k] !== undefined; })){
appSettings.hangTs = Date.now();
}
}catch(e){}
if(window.saveSettings) saveSettings();
}
}catch(e){}
if(patch.hangOn !== undefined){ try{ localStorage.setItem('isekai_hang_on', patch.hangOn ? '1' : '0'); }catch(e){} }
if(patch.hangSize !== undefined){ try{ localStorage.setItem('isekai_hang_size', String(patch.hangSize)); }catch(e){} }
if(patch.hangImg !== undefined){ try{ localStorage.setItem('isekai_hang_img', patch.hangImg || ''); }catch(e){} }
if(patch.hangImgL !== undefined){ try{ localStorage.setItem('isekai_hang_l', patch.hangImgL || ''); }catch(e){} }
if(patch.hangImgR !== undefined){ try{ localStorage.setItem('isekai_hang_r', patch.hangImgR || ''); }catch(e){} }
try{
var _hp = null;
try{ _hp = JSON.parse(localStorage.getItem('isekai_hang_pick') || 'null'); }catch(e4){ _hp = null; }
_hp = _hp || {};
if(patch.hangOn !== undefined) _hp.on = !!patch.hangOn;
if(patch.hangSize !== undefined) _hp.size = Number(patch.hangSize) || 0;
/* 没改大小的那次改动，不能把已存的大小抹成 undefined（否则整条键丢了 size） */
if(typeof _hp.size !== 'number') _hp.size = (typeof cfg.size === 'number' ? cfg.size : 0);
if(_hp.on === undefined) _hp.on = (cfg.on === false ? false : true);
/* 老版本把图也塞在这条键里，这里顺手清掉，别让一张大图把开关键撑爆 */
delete _hp.img; delete _hp.imgL; delete _hp.imgR;
_hp.ts = Date.now();
localStorage.setItem('isekai_hang_pick', JSON.stringify(_hp));
}catch(e5){}
try{ if(window.__stg) window.__stg('写入本地键 on=' + (_hp.on ? 1 : 0) + ' size=' + _hp.size); }catch(e){}
/* 图片单独一条键：图一大就把配额撑满，整条写失败会连大小一起丢，所以必须分开写 */
try{
var _hi = null;
try{ _hi = JSON.parse(localStorage.getItem('isekai_hang_imgs') || 'null'); }catch(e6){ _hi = null; }
_hi = _hi || {};
if(patch.hangImgL !== undefined) _hi.imgL = patch.hangImgL || '';
if(patch.hangImgR !== undefined) _hi.imgR = patch.hangImgR || '';
if(patch.hangImg !== undefined) _hi.img = patch.hangImg || '';
_hi.ts = Date.now();
var _im = { imgL: (_hi.imgL || ''), imgR: (_hi.imgR || ''), img: (_hi.img || ''), ts: Date.now() };
var _ims = JSON.stringify(_im);
var _okw = false;
try{ localStorage.setItem('isekai_hang_imgs', _ims); _okw = true; }
catch(e8){
/* 老版本可能在里面塞过几 MB 的 base64，先把这条旧键删掉再写，别让历史垃圾挡住新值 */
try{ localStorage.removeItem('isekai_hang_imgs'); localStorage.setItem('isekai_hang_imgs', _ims); _okw = true; }catch(e9){ _okw = false; }
}
try{ window.__stg && window.__stg('图片写入 ' + (_okw ? '成功' : '失败') + ' L=' + String((_im.imgL||'').length) + ' R=' + String((_im.imgR||'').length)); }catch(e){}
}catch(e7){ try{ window.__stg && window.__stg('图片写入 失败'); }catch(e){} }
window.__hangSync();
try{
if(patch.hangOn !== undefined) cfg.on = !!patch.hangOn;
if(patch.hangSize !== undefined) cfg.size = Number(patch.hangSize) || 0;
if(patch.hangImgL !== undefined){ cfg.srcL = patch.hangImgL || ''; loadSide('l', cfg.srcL); }
if(patch.hangImgR !== undefined){ cfg.srcR = patch.hangImgR || ''; loadSide('r', cfg.srcR); }
if(patch.hangImg !== undefined){ cfg.src = patch.hangImg || ''; loadImg(); }
cfg.ver++;
}catch(e){}
try{ if(window.__decoSave) window.__decoSave(); }catch(e){}
try{ if(window.__decoSave) window.__decoSave(); }catch(e){}
try{ if(window.__fxRefresh) window.__fxRefresh(); }catch(e){}
};
window.__hangPx = function(){ return [58, 76, 94][cfg.size] || 76; };
window.__askImgUrl = function(title, cb){
try{
var old = document.getElementById('__imgUrlBox'); if(old && old.parentNode) old.parentNode.removeChild(old);
var wrap = document.createElement('div');
wrap.id = '__imgUrlBox';
wrap.style.cssText = 'position:fixed;left:0;top:0;width:100%;height:100%;z-index:2400;background:rgba(6,10,16,.55);display:flex;align-items:center;justify-content:center;padding:14px;box-sizing:border-box;';
var card = document.createElement('div');
card.style.cssText = 'width:100%;max-width:340px;box-sizing:border-box;'
+ 'background:var(--surface, rgba(20,26,34,.96));'
+ 'border:1px solid var(--border, rgba(160,190,220,.22));'
+ 'border-radius:14px;padding:16px;'
+ 'box-shadow:0 18px 40px rgba(0,0,0,.28);'
+ 'font-family:inherit;color:var(--text, #dfe8f2);';
card.innerHTML = '<div style="font-size:12px;letter-spacing:.12em;color:var(--text);margin-bottom:8px;">' + title + '</div>'
+ '<div style="font-size:10px;color:var(--text3);line-height:1.6;margin-bottom:10px;">填图片直链（http/https 开头，或以 data:image 开头的图片）。留空保存＝恢复默认。</div>'
+ '<input id="__imgUrlInput" type="url" placeholder="https://… / data:image/png;base64,…" style="width:100%;box-sizing:border-box;font-size:12px;padding:9px 10px;border-radius:9px;border:1px solid var(--border);background:var(--surface2);color:var(--text);outline:none;font-family:inherit;">'
+ '<div style="display:flex;gap:8px;justify-content:flex-end;margin-top:12px;">'
+ '<span id="__imgUrlCancel" style="font-size:11px;padding:7px 14px;border-radius:9px;border:1px solid var(--border);color:var(--text2);cursor:pointer;">取消</span>'
+ '<span id="__imgUrlOk" style="font-size:11px;padding:7px 16px;border-radius:9px;border:1px solid var(--accent);color:var(--accent);background:var(--accent2);cursor:pointer;letter-spacing:.1em;">确定</span>'
+ '</div>';
wrap.appendChild(card);
document.body.appendChild(wrap);
/* 跟随可视视口：键盘弹出时整体上移到键盘之上并保持居中 */
function _fit(){
try{
var vv = window.visualViewport;
var h = vv ? vv.height : window.innerHeight;
var t = vv ? vv.offsetTop : 0;
wrap.style.height = Math.max(120, h - t) + 'px';
wrap.style.top = t + 'px';
var maxH = Math.max(140, h - 28);
card.style.maxHeight = maxH + 'px';
card.style.overflowY = 'auto';
}catch(e){}
}
_fit();
try{
if(window.visualViewport){
window.visualViewport.addEventListener('resize', _fit);
window.visualViewport.addEventListener('scroll', _fit);
}
window.addEventListener('resize', _fit);
}catch(e){}
var inp = card.querySelector('#__imgUrlInput');
setTimeout(function(){ try{ inp.focus(); }catch(e){} _fit(); }, 60);
setTimeout(_fit, 380);
function close(){ try{ if(wrap.parentNode) wrap.parentNode.removeChild(wrap); }catch(e){} }
card.querySelector('#__imgUrlCancel').onclick = close;
card.querySelector('#__imgUrlOk').onclick = function(){ var v = (inp.value || '').trim(); close(); cb(v); };
inp.onkeydown = function(e){ if(e.key === 'Enter'){ e.preventDefault(); var v = (inp.value || '').trim(); close(); cb(v); } };
}catch(e){}
};
window.addEventListener('load', function(){ setTimeout(window.__hangSync, 0); });
setTimeout(window.__hangSync, 200);
})();
;
/* 正则手机悬浮球：换一张图当球（拖动/点击逻辑不变） */
(function(){
var cfg = window.__FloatCfg = { src:'' };
window.__floatApply = function(){
var fab = document.getElementById('vfPhoneFab');
var src = cfg.src;
if(!fab) return;
if(src){
fab.textContent = '';
fab.style.backgroundImage = 'url(' + src + ')';
fab.style.backgroundSize = '100% 100%';
fab.style.backgroundPosition = 'center';
fab.style.backgroundRepeat = 'no-repeat';
fab.style.backgroundColor = 'transparent';
fab.style.border = '0';
fab.style.borderRadius = '0';
fab.style.boxShadow = 'none';
fab.style.backdropFilter = 'none';
fab.style.webkitBackdropFilter = 'none';
fab.style.fontSize = '0';
var im = new Image();
im.onload = function(){
var w = im.naturalWidth || 42, h = im.naturalHeight || 42, max = 64;
var k = Math.min(max / w, max / h, 1.6);
fab.style.width = Math.round(w * k) + 'px';
fab.style.height = Math.round(h * k) + 'px';
};
im.onerror = function(){ fab.style.width = '42px'; fab.style.height = '42px'; };
im.src = src;
} else {
fab.style.backgroundImage = '';
fab.style.backgroundColor = '';
fab.style.border = '';
fab.style.borderRadius = '';
fab.style.boxShadow = '';
fab.style.backdropFilter = '';
fab.style.webkitBackdropFilter = '';
fab.style.fontSize = '';
fab.style.width = '42px';
fab.style.height = '42px';
if(!fab.textContent) fab.textContent = '📱';
}
};
window.__floatSync = function(){
var src = '';
try{ if(window.appSettings && typeof appSettings.vfFabImg === 'string') src = appSettings.vfFabImg; }catch(e){}
if(!src){ try{ src = localStorage.getItem('isekai_vf_fab_pick') || ''; }catch(e){} }
if(!src){ try{ src = localStorage.getItem('isekai_vf_fab_img') || ''; }catch(e){} }
cfg.src = src;
window.__floatApply();
return cfg;
};
window.__floatUpdate = function(src){
try{
if(window.appSettings){ appSettings.vfFabImg = src || ''; if(window.saveSettings) saveSettings(); }
}catch(e){}
try{ localStorage.setItem('isekai_vf_fab_img', src || ''); }catch(e){}
/* 独立键：只有真换了图才写，空值不落盘（防止重载瞬间把已存的图抹掉） */
try{ if(src) localStorage.setItem('isekai_vf_fab_pick', src); }catch(e){}
window.__floatSync();
try{ if(window.__decoSave) window.__decoSave(); }catch(e){}
try{ if(window.__fxRefresh) window.__fxRefresh(); }catch(e){}
};
setTimeout(window.__floatSync, 200);
/* 悬浮球是“每个正文页新建”的元素：换图时它还不存在，元素建好后必须再刷一次，
否则设置里显示已换图、正文里还是默认手机图标 */
setInterval(function(){
try{
var fab = document.getElementById('vfPhoneFab');
if(!fab || !cfg.src) return;
var bg = fab.style.backgroundImage || '';
if(bg.indexOf(cfg.src) < 0) window.__floatApply();
}catch(e){}
}, 700);
var _t = setInterval(function(){
if(window.appSettings && appSettings.vfFabImg && !cfg.src) window.__floatSync();
}, 1500);
setTimeout(function(){ clearInterval(_t); }, 15000);
})();
;
/* 竹笺 · 悬笔挂件：玉笔架搭在版框上，两管笔随风轻晃（不拦点击） */
(function(){
if(window.__bambooBrushBoot) return; window.__bambooBrushBoot = 1;
var cv = null, ctx = null, W = 0, H = 0, DPR = 1, raf = null, running = false, last = 0;
var TAU = Math.PI * 2;
function clamp(v, a, b){ return v < a ? a : (v > b ? b : v); }
function Pend(cfg){
this.ax = 0; this.ay = 0; this.hookL = 26; this.size = 96;
this.theta = (Math.random() - .5) * .05; this.omega = 0; this.phase = Math.random() * TAU;
for(var k in cfg){ this[k] = cfg[k]; }
}
Pend.prototype.update = function(dt, wind, t){
var ambient = Math.sin(t * 1.2 + this.phase) * .02;
var g = -(12 / this.hookL) * Math.sin(this.theta);
var w = wind * .06 + ambient;
this.omega += (g + w - this.omega * .6) * dt;
this.theta += this.omega * dt;
this.theta = clamp(this.theta, -.9, .9);
};
var b1 = new Pend({type:1}), b2 = new Pend({type:2});
var wind = 0, prevX = null;
function isBamboo(){ try{ return document.body && document.body.getAttribute('data-theme') === 'bamboo'; }catch(e){ return false; } }
function barInner(){
var b = document.getElementById('dramaStatusBar');
if(!b) return null;
if(b.style.display === 'none') return null;
/* 挂到状态栏整条上（不是内层）：内层宽度会被自定义样式收窄居中，
   挂在内层就会落在文字右端而不是屏幕右边 */
return b;
}
function resize(){
if(!cv) return;
var r = cv.getBoundingClientRect();
DPR = Math.min(window.devicePixelRatio || 1, 2);
W = r.width; H = r.height;
cv.width = Math.round(W * DPR); cv.height = Math.round(H * DPR);
ctx.setTransform(DPR, 0, 0, DPR, 0, 0);
}
function layout(){
var m = Math.min(W, H);
var _bk = ((window.__hangPx && window.__hangPx()) || 76) / 76;
b1.size = clamp(m * .6, 70, 110) * _bk;
b2.size = clamp(m * .55, 62, 100) * _bk;
var right = W - 40;
b1.ax = right - 11; b1.ay = 4; b1.hookL = 27;
b2.ax = right; b2.ay = 4; b2.hookL = 27;
}
function rack(){
var x1 = b1.ax, x2 = b2.ax, y = 4;
var sx = x1 - 13, ex = x2 + 13, h = 4.2;
ctx.save();
ctx.beginPath(); ctx.moveTo(sx, y - 2); ctx.lineTo(ex, y - 2);
ctx.lineWidth = h + 1; ctx.lineCap = 'round'; ctx.strokeStyle = 'rgba(80,110,90,.15)'; ctx.stroke();
var gd = ctx.createLinearGradient(sx, y - 5, ex, y);
gd.addColorStop(0, '#d5e6dc'); gd.addColorStop(.2, '#e8f4ec'); gd.addColorStop(.5, '#c4dfd0');
gd.addColorStop(.8, '#e8f4ec'); gd.addColorStop(1, '#d5e6dc');
ctx.beginPath(); ctx.moveTo(sx, y - 2); ctx.lineTo(ex, y - 2);
ctx.lineWidth = h; ctx.strokeStyle = gd; ctx.stroke();
ctx.beginPath(); ctx.moveTo(sx, y - 3.4); ctx.lineTo(ex, y - 3.4);
ctx.lineWidth = .8; ctx.strokeStyle = 'rgba(255,255,255,.9)'; ctx.stroke();
[sx, ex].forEach(function(cx){
ctx.beginPath(); ctx.arc(cx, y - 2, h * .7, 0, TAU);
var sg = ctx.createRadialGradient(cx - 1, y - 3, 0, cx, y - 2, h * .7);
sg.addColorStop(0, '#ffffff'); sg.addColorStop(.5, '#d0d5d2'); sg.addColorStop(1, '#9ca3a0');
ctx.fillStyle = sg; ctx.fill();
ctx.strokeStyle = 'rgba(120,130,125,.5)'; ctx.lineWidth = .6; ctx.stroke();
});
ctx.restore();
}
function brush(p, type){
ctx.save(); ctx.translate(p.ax, p.ay); ctx.rotate(p.theta);
ctx.beginPath(); ctx.arc(0, 0, 1.4, 0, TAU); ctx.strokeStyle = '#b0b5b2'; ctx.lineWidth = .8; ctx.stroke();
ctx.beginPath(); ctx.moveTo(0, 1.4); ctx.lineTo(0, p.hookL - 4);
ctx.strokeStyle = '#d0d5d2'; ctx.lineWidth = 1; ctx.stroke();
ctx.beginPath(); ctx.moveTo(0, p.hookL - 4);
ctx.bezierCurveTo(0, p.hookL, 2.4, p.hookL + 1, 2.4, p.hookL - 2);
ctx.stroke();
ctx.translate(0, p.hookL);
var rodW = type === 1 ? 2.8 : 3.2, rodL = p.size * .62, bl = p.size * .34, bw = type === 1 ? 5.5 : 6.6;
ctx.beginPath(); ctx.ellipse(.7, 0, 2.8, 4.2, -.2, 0, TAU);
ctx.strokeStyle = '#d16b6b'; ctx.lineWidth = 1.1; ctx.stroke();
ctx.fillStyle = type === 1 ? '#b5d6c6' : '#e8e4db';
ctx.beginPath(); ctx.ellipse(0, 1.4, rodW * .7, 1.7, 0, 0, TAU); ctx.fill();
var rg = ctx.createLinearGradient(-rodW / 2, 0, rodW / 2, 0);
if(type === 1){ rg.addColorStop(0, '#9dbcaa'); rg.addColorStop(.3, '#cbe2d4'); rg.addColorStop(.7, '#f2faf5'); rg.addColorStop(1, '#9dbcaa'); }
else { rg.addColorStop(0, '#cfc9bc'); rg.addColorStop(.3, '#e8e4db'); rg.addColorStop(.7, '#fdfcfb'); rg.addColorStop(1, '#cfc9bc'); }
ctx.beginPath(); ctx.moveTo(-rodW / 2, 1.4); ctx.lineTo(rodW / 2, 1.4);
ctx.lineTo(rodW / 2, rodL); ctx.lineTo(-rodW / 2, rodL); ctx.closePath();
ctx.fillStyle = rg; ctx.fill();
ctx.strokeStyle = type === 1 ? 'rgba(100,150,120,.4)' : 'rgba(150,140,120,.4)';
ctx.lineWidth = .4; ctx.stroke();
if(type === 2){
ctx.fillStyle = 'rgba(130,120,100,.4)';
for(var i = 1; i <= 2; i++) ctx.fillRect(-rodW / 2, 1.4 + (rodL - 1.4) * (i / 3), rodW, .8);
}
ctx.beginPath(); ctx.moveTo(-rodW / 2, rodL); ctx.lineTo(rodW / 2, rodL);
ctx.lineTo(bw / 2 - .5, rodL + 3.6); ctx.lineTo(-bw / 2 + .5, rodL + 3.6); ctx.closePath();
ctx.fillStyle = type === 1 ? '#7b9a88' : '#b0a89b'; ctx.fill();
var bg = ctx.createLinearGradient(0, rodL + 3.6, 0, rodL + 3.6 + bl);
if(type === 1){ bg.addColorStop(0, '#8f8984'); bg.addColorStop(.6, '#696461'); bg.addColorStop(1, '#3b3836'); }
else { bg.addColorStop(0, '#f4f2ee'); bg.addColorStop(.6, '#b8aea0'); bg.addColorStop(1, '#797063'); }
ctx.beginPath();
ctx.moveTo(-bw / 2 + .5, rodL + 3.6);
ctx.bezierCurveTo(-bw * .7, rodL + 3.6 + bl * .35, -bw * .2, rodL + 3.6 + bl * .85, 0, rodL + 3.6 + bl);
ctx.bezierCurveTo(bw * .2, rodL + 3.6 + bl * .85, bw * .7, rodL + 3.6 + bl * .35, bw / 2 - .5, rodL + 3.6);
ctx.closePath(); ctx.fillStyle = bg; ctx.fill();
ctx.restore();
}
function pendant(p, img, hgt){
var L = 30, ax = p.ax + 8, ay = 5;
var ex = ax + Math.sin(p.theta) * L, ey = ay + Math.cos(p.theta) * L;
ctx.beginPath(); ctx.moveTo(ax, ay); ctx.lineTo(ex, ey);
ctx.strokeStyle = 'rgba(120,140,120,.55)'; ctx.lineWidth = 1; ctx.stroke();
var w = hgt * (img.width / (img.height || 1));
ctx.save(); ctx.translate(ex, ey); ctx.rotate(p.theta * .55);
ctx.drawImage(img, -w / 2, 0, w, hgt);
ctx.restore();
}
function frame(now){
if(!running || !ctx) return;
var dt = Math.min((now - last) / 1000, .05); last = now;
var t = now / 1000;
ctx.clearRect(0, 0, W, H);
var HC = window.__HangCfg || {on:true};
if(HC.on === false){ raf = requestAnimationFrame(frame); return; }
wind *= Math.exp(-dt * 3);
b1.update(dt, wind, t); b2.update(dt, wind, t);
var px = (window.__hangPx && window.__hangPx()) || 76;
var iL = HC.imgL || HC.img, iR = HC.imgR || HC.img;
if(iL || iR){
var items = [];
(function(){
var img1 = iL, img2 = iR;
items.push({ x: b1.ax + Math.sin(b1.theta) * 30, d: img1 ? function(){ pendant(b1, img1, px); } : function(){ brush(b1, 1); } });
items.push({ x: b2.ax + Math.sin(b2.theta) * 30, d: img2 ? function(){ pendant(b2, img2, px); } : function(){ brush(b2, 2); } });
})();
rack();
items.sort(function(u, v){ return u.x - v.x; });
for(var q = 0; q < items.length; q++) items[q].d();
} else {
if(b1.ax + Math.sin(b1.theta) * b1.hookL > b2.ax + Math.sin(b2.theta) * b2.hookL){
brush(b2, 2); brush(b1, 1);
} else { brush(b1, 1); brush(b2, 2); }
rack();
}
raf = requestAnimationFrame(frame);
}
function start(){
if(running) return;
running = true; last = performance.now();
raf = requestAnimationFrame(frame);
}
function stop(){
running = false;
if(raf){ try{ cancelAnimationFrame(raf); }catch(e){} raf = null; }
}
function ensure(){
var inner = isBamboo() ? barInner() : null;
if(!inner){
if(cv){ try{ cv.remove(); }catch(e){} cv = null; ctx = null; }
stop(); return;
}
if(cv && cv.parentNode === inner){ resize(); layout(); start(); return; }
if(cv){ try{ cv.remove(); }catch(e){} }
cv = document.createElement('canvas');
cv.id = 'bambooBrush';
inner.appendChild(cv);
ctx = cv.getContext('2d');
resize(); layout(); start();
}
window.addEventListener('pointermove', function(e){
if(!running) return;
if(prevX !== null){
var vx = e.clientX - prevX;
if(Math.abs(vx) > 1){
var im = clamp(vx * .02, -.6, .6);
b1.omega += im * 1.2; b2.omega += im * 1.2; wind = clamp(vx * .5, -15, 15);
}
}
prevX = e.clientX;
}, {passive:true});
window.addEventListener('pointerleave', function(){ prevX = null; });
window.addEventListener('resize', function(){ if(running){ resize(); layout(); } }, {passive:true});
try{
var mo = new MutationObserver(function(){ ensure(); });
mo.observe(document.body, {attributes:true, attributeFilter:['data-theme']});
var bar = document.getElementById('dramaStatusBar');
if(bar) mo.observe(bar, {attributes:true, attributeFilter:['style']});
}catch(e){}
setInterval(ensure, 1200);
setTimeout(ensure, 300);
})();
;
/* 深空 · 星月挂件：两缕星尘绳牵着星与月，随划屏的风摆动（不拦点击） */
(function(){
if(window.__starMoonBoot) return; window.__starMoonBoot = 1;
var cv = null, ctx = null, W = 0, H = 0, DPR = 1, raf = null, running = false;
var last = 0, simTime = 0, acc = 0, FIXED = 1 / 60;
var TAU = Math.PI * 2;
function clamp(v, a, b){ return v < a ? a : (v > b ? b : v); }
var dust = [];
function seedDust(){
dust.length = 0;
for(var i = 0; i < 15; i++){
dust.push({ x: Math.random() * W, y: Math.random() * H,
vx: (Math.random() - .5) * .1, vy: (Math.random() - .5) * .1,
r: Math.random() * .6 + .2, phase: Math.random() * TAU });
}
}
var windX = 0, windTX = 0, windY = 0, windTY = 0, gust = 0, gustDir = 1;
function updateWind(dt, t){
var base = Math.sin(t * .5) * .01;
if(gust > 0){
gust -= dt;
var p = 1 - gust / 3;
windTX = base + Math.sin(p * Math.PI) * gustDir * 1.5;
windTY = -Math.abs(Math.sin(p * Math.PI) * 2);
} else {
windTX = base; windTY = 0;
if(Math.random() < .001){ gust = 3; gustDir = Math.random() > .5 ? 1 : -1; }
}
windX += (windTX - windX) * 3 * dt;
windY += (windTY - windY) * 3 * dt;
}
function Rope(x, y, len, segs){
this.segs = segs; this.len = len / segs; this.pts = [];
for(var i = 0; i <= segs; i++){
this.pts.push({ x: x, y: y + i * this.len, ox: x, oy: y + i * this.len, pin: i === 0 });
}
}
Rope.prototype.update = function(wx, wy){
for(var i = 1; i < this.pts.length; i++){
var p = this.pts[i];
var vx = (p.x - p.ox) * .97, vy = (p.y - p.oy) * .97;
p.ox = p.x; p.oy = p.y;
var w = (i / this.segs) * .8;
p.x += vx + wx * w; p.y += vy + .4 + wy * w;
}
};
Rope.prototype.solve = function(){
var ay = this.pts[0].y;
for(var it = 0; it < 8; it++){
for(var i = 0; i < this.pts.length - 1; i++){
var p1 = this.pts[i], p2 = this.pts[i + 1];
var dx = p2.x - p1.x, dy = p2.y - p1.y, d = Math.sqrt(dx * dx + dy * dy);
if(!d) continue;
var diff = (this.len - d) / d;
if(p1.pin){ p2.x += dx * diff; p2.y += dy * diff; }
else if(p2.pin){ p1.x -= dx * diff; p1.y -= dy * diff; }
else { var h = diff * .5; p1.x -= dx * h; p1.y -= dy * h; p2.x += dx * h; p2.y += dy * h; }
}
for(var k = 1; k < this.pts.length; k++){ if(this.pts[k].y < ay) this.pts[k].y = ay; }
}
};
var starRope = null, moonRope = null, pendRope = null;
var star = { rot: 0, size: 16 }, moon = { rot: 0, size: 22 };
function layout(){
if(!starRope){
starRope = new Rope(0, 0, 80, 16);
moonRope = new Rope(0, 0, 80, 16);
pendRope = new Rope(0, 0, 34, 12);
}
pendRope.pts[0].x = W * .6; pendRope.pts[0].y = 3;
for(var q = 1; q < pendRope.pts.length; q++){ pendRope.pts[q].x = W * .6; pendRope.pts[q].y = 3 + q * (34 / 12); }
var m = Math.min(W, H);
star.size = clamp(m * .2, 14, 20);
moon.size = clamp(m * .26, 18, 26);
var gap = star.size * .5 + moon.size * .5 + 6;
var ropeLen = Math.min(H * .6, 74);
var ac = W * .80;
starRope.pts[0].x = ac - gap * .5; starRope.pts[0].y = 2;
moonRope.pts[0].x = ac + gap * .5; moonRope.pts[0].y = 2;
starRope.len = ropeLen / 16;
moonRope.len = (ropeLen * .95) / 16;
}
function drawRope(r){
ctx.beginPath();
var p = r.pts;
ctx.moveTo(p[0].x, p[0].y);
for(var i = 1; i < p.length; i++) ctx.lineTo(p[i].x, p[i].y);
ctx.strokeStyle = 'rgba(160,200,255,.25)'; ctx.lineWidth = .6; ctx.stroke();
}
function starPath(cx, cy, R, r){
ctx.beginPath();
for(var i = 0; i < 10; i++){
var rad = i % 2 === 0 ? R : r;
var a = i * Math.PI / 5 - Math.PI / 2;
if(i === 0) ctx.moveTo(cx + Math.cos(a) * rad, cy + Math.sin(a) * rad);
else ctx.lineTo(cx + Math.cos(a) * rad, cy + Math.sin(a) * rad);
}
ctx.closePath();
}
function drawStar(hx, hy, S, rot){
var R = S * .5, r = R * .382, cy = R;
ctx.save(); ctx.translate(hx, hy); ctx.rotate(rot);
var g1 = ctx.createRadialGradient(0, cy, 0, 0, cy, R * 1.4);
g1.addColorStop(0, 'rgba(255,240,200,.5)'); g1.addColorStop(1, 'rgba(255,200,100,0)');
ctx.save(); ctx.globalCompositeOperation = 'lighter';
ctx.fillStyle = g1; ctx.beginPath(); ctx.arc(0, cy, R * 1.4, 0, TAU); ctx.fill();
ctx.restore();
starPath(0, cy, R, r);
var g2 = ctx.createRadialGradient(-R * .2, cy - R * .2, 0, 0, cy, R * 1.1);
g2.addColorStop(0, '#ffffff'); g2.addColorStop(.4, '#ffe8a0'); g2.addColorStop(1, '#c87015');
ctx.fillStyle = g2; ctx.fill();
ctx.restore();
}
function drawMoon(hx, hy, S, rot){
var R = S * .5, d = R * .42, r = R * .8;
var x0 = (d * d + R * R - r * r) / (2 * d);
var y0 = Math.sqrt(Math.max(R * R - x0 * x0, .001));
var th = Math.atan2(y0, x0), ph = Math.atan2(y0, x0 - d);
ctx.save(); ctx.translate(hx, hy); ctx.rotate(rot - .25); ctx.translate(0, R);
ctx.beginPath();
ctx.arc(0, 0, R, -th, th, true);
ctx.arc(d, 0, r, ph, TAU - ph, false);
ctx.closePath();
var g = ctx.createLinearGradient(-R, -R * .6, R * .5, R);
g.addColorStop(0, '#FFFFFF'); g.addColorStop(.45, '#D0E0F8'); g.addColorStop(1, '#90B0E0');
ctx.fillStyle = g; ctx.fill();
ctx.restore();
}
function frame(now){
if(!running || !ctx) return;
var dt = Math.min((now - last) / 1000, .05); last = now;
var t = now / 1000;
ctx.clearRect(0, 0, W, H);
var HC = window.__HangCfg || {on:true};
if(HC.on === false){ raf = requestAnimationFrame(frame); return; }
for(var i = 0; i < dust.length; i++){
var d = dust[i];
d.x += d.vx; d.y += d.vy;
if(d.x < 0) d.x = W; if(d.x > W) d.x = 0;
if(d.y < 0) d.y = H; if(d.y > H) d.y = 0;
var al = .1 + .3 * Math.sin(t * 2 + d.phase);
ctx.fillStyle = 'rgba(180,220,255,' + al.toFixed(3) + ')';
ctx.beginPath(); ctx.arc(d.x, d.y, d.r, 0, TAU); ctx.fill();
}
acc += dt;
while(acc >= FIXED){
updateWind(FIXED, simTime); simTime += FIXED;
starRope.update(windX * 1.2, windY * 1.2); starRope.solve();
moonRope.update(windX * .8, windY * .8); moonRope.solve();
if(HC.img){ pendRope.update(windX * 1.1, windY * 1.1); pendRope.solve(); }
acc -= FIXED;
}
var sp = starRope.pts, mp = moonRope.pts;
var se = sp[sp.length - 1], spv = sp[sp.length - 2];
var me = mp[mp.length - 1], mpv = mp[mp.length - 2];
var sTan = Math.atan2(se.x - spv.x, se.y - spv.y);
var mTan = Math.atan2(me.x - mpv.x, me.y - mpv.y);
star.rot += (sTan - star.rot) * .1;
moon.rot += (mTan - moon.rot) * .1;
var iL = HC.imgL || HC.img, iR = HC.imgR || HC.img;
var hgt = (window.__hangPx && window.__hangPx()) || 76;
var _k = hgt / 76;
function imgOn(rope, end, img){
drawRope(rope);
var pp = rope.pts, pv = pp[pp.length - 2];
var w2 = hgt * (img.width / (img.height || 1));
var tang = Math.atan2(end.x - pv.x, end.y - pv.y);
ctx.save(); ctx.translate(end.x, end.y); ctx.rotate(tang * .6);
ctx.drawImage(img, -w2 / 2, 0, w2, hgt);
ctx.restore();
}
if(iL || iR){
if(!iL){ drawRope(starRope); drawStar(se.x, se.y, star.size * _k, star.rot); } else { imgOn(starRope, se, iL); }
if(!iR){ drawRope(moonRope); drawMoon(me.x, me.y, moon.size * _k, moon.rot); } else { imgOn(moonRope, me, iR); }
} else if(HC.img){
var pp = pendRope.pts, pe = pp[pp.length - 1], pv = pp[pp.length - 2];
drawRope(pendRope);
var w2 = hgt * (HC.img.width / (HC.img.height || 1));
var tang = Math.atan2(pe.x - pv.x, pe.y - pv.y);
ctx.save(); ctx.translate(pe.x, pe.y); ctx.rotate(tang * .6);
ctx.drawImage(HC.img, -w2 / 2, 0, w2, hgt);
ctx.restore();
} else if(se.x > me.x){
drawRope(moonRope); drawMoon(me.x, me.y, moon.size * _k, moon.rot);
drawRope(starRope); drawStar(se.x, se.y, star.size * _k, star.rot);
} else {
drawRope(starRope); drawStar(se.x, se.y, star.size * _k, star.rot);
drawRope(moonRope); drawMoon(me.x, me.y, moon.size * _k, moon.rot);
}
raf = requestAnimationFrame(frame);
}
function isStar(){
try{ return document.body && document.body.getAttribute('data-theme') === 'star'; }catch(e){ return false; }
}
function barInner(){
var b = document.getElementById('dramaStatusBar');
if(!b || b.style.display === 'none') return null;
/* 同竹笺：挂整条状态栏，保证贴屏幕右缘 */
return b;
}
function resize(){
if(!cv) return;
var r = cv.getBoundingClientRect();
DPR = Math.min(window.devicePixelRatio || 1, 2);
W = r.width || 100; H = r.height || 120;
cv.width = Math.round(W * DPR); cv.height = Math.round(H * DPR);
ctx.setTransform(DPR, 0, 0, DPR, 0, 0);
}
function start(){ if(running) return; running = true; last = performance.now(); raf = requestAnimationFrame(frame); }
function stop(){ running = false; if(raf){ try{ cancelAnimationFrame(raf); }catch(e){} raf = null; } }
function ensure(){
var inner = isStar() ? barInner() : null;
if(!inner){
if(cv){ try{ cv.remove(); }catch(e){} cv = null; ctx = null; }
stop(); return;
}
if(cv && cv.parentNode === inner){ resize(); layout(); seedDust(); start(); return; }
if(cv){ try{ cv.remove(); }catch(e){} }
cv = document.createElement('canvas');
cv.id = 'starMoonWidget';
inner.appendChild(cv);
ctx = cv.getContext('2d');
resize(); layout(); seedDust(); start();
}
var prevX = null, prevY = null;
window.addEventListener('pointermove', function(e){
if(!running || !starRope) return;
var x = e.clientX, y = e.clientY;
if(prevX !== null && prevY !== null){
var fx = clamp((x - prevX) * .3, -25, 25), fy = clamp((y - prevY) * .3, -25, 25);
if(Math.abs(fx) > .5 || Math.abs(fy) > .5){
[starRope, moonRope].forEach(function(rp){
for(var i = 1; i < rp.pts.length; i++){ rp.pts[i].ox -= fx; rp.pts[i].oy -= fy; }
});
}
}
prevX = x; prevY = y;
}, {passive:true});
window.addEventListener('pointerleave', function(){ prevX = prevY = null; });
window.addEventListener('resize', function(){ if(running){ resize(); layout(); } }, {passive:true});
try{
var mo = new MutationObserver(function(){ ensure(); });
mo.observe(document.body, {attributes:true, attributeFilter:['data-theme']});
var bar = document.getElementById('dramaStatusBar');
if(bar) mo.observe(bar, {attributes:true, attributeFilter:['style']});
}catch(e){}
setInterval(ensure, 1200);
setTimeout(ensure, 300);
})();
;
/* 暖玉白 · 书页边挂件：金书签星 + 白玉残月，挂在状态栏右下，随风轻摆（不拦点击） */
(function(){
if(window.__jadeCharmBoot) return; window.__jadeCharmBoot = 1;
var cv = null, ctx = null, W = 100, H = 120, raf = null, run = false, last = 0;
var TAU = Math.PI * 2, wind = 0, prevX = null;
var sRope = null, mRope = null, pRope = null;
var star = { rot: 0 }, moon = { rot: 0 };
var STAR_S = 20, MOON_S = 26;
function Rope(x, y, len, seg){
this.seg = seg; this.len = len / seg; this.pts = [];
for(var i = 0; i <= seg; i++) this.pts.push({ x: x, y: y + i * this.len, ox: x, oy: y + i * this.len, pin: i === 0 });
}
Rope.prototype.update = function(w){
for(var i = 1; i < this.pts.length; i++){
var p = this.pts[i];
var vx = (p.x - p.ox) * .96, vy = (p.y - p.oy) * .96;
p.ox = p.x; p.oy = p.y;
p.x += vx + w * (i / this.seg) * .6;
p.y += vy + .5;
}
};
Rope.prototype.solve = function(){
var ay = this.pts[0].y;
for(var it = 0; it < 8; it++){
for(var i = 0; i < this.pts.length - 1; i++){
var p1 = this.pts[i], p2 = this.pts[i + 1];
var dx = p2.x - p1.x, dy = p2.y - p1.y, d = Math.sqrt(dx * dx + dy * dy) || 1;
var diff = (this.len - d) / d;
if(p1.pin){ p2.x += dx * diff; p2.y += dy * diff; }
else { var h = diff * .5; p1.x -= dx * h; p1.y -= dy * h; p2.x += dx * h; p2.y += dy * h; }
}
for(var k = 1; k < this.pts.length; k++){ if(this.pts[k].y < ay) this.pts[k].y = ay; }
}
};
function init(){
sRope = new Rope(W - 34, 3, 34, 12);
mRope = new Rope(W - 10, 3, 30, 12);
pRope = new Rope(W - 12, 3, 26, 10);
}
function ropeLine(r){
var p = r.pts;
ctx.beginPath(); ctx.moveTo(p[0].x, p[0].y);
for(var i = 1; i < p.length; i++) ctx.lineTo(p[i].x, p[i].y);
ctx.strokeStyle = 'rgba(160,140,110,.55)'; ctx.lineWidth = .9; ctx.stroke();
}
function drawStar(hx, hy, S, rot){
var R = S * .5, r = R * .382, cy = R;
ctx.save(); ctx.translate(hx, hy); ctx.rotate(rot);
ctx.beginPath();
for(var i = 0; i < 10; i++){
var rad = i % 2 === 0 ? R : r, a = i * Math.PI / 5 - Math.PI / 2;
if(i === 0) ctx.moveTo(Math.cos(a) * rad, cy + Math.sin(a) * rad);
else ctx.lineTo(Math.cos(a) * rad, cy + Math.sin(a) * rad);
}
ctx.closePath();
var g = ctx.createLinearGradient(-R, cy - R, R, cy + R);
g.addColorStop(0, '#FFFBE8'); g.addColorStop(.35, '#F2D580'); g.addColorStop(.7, '#D9A545'); g.addColorStop(1, '#B87C28');
ctx.fillStyle = g; ctx.fill();
ctx.strokeStyle = 'rgba(255,255,230,.65)'; ctx.lineWidth = .7; ctx.stroke();
ctx.restore();
}
function drawMoon(hx, hy, S, rot){
var R = S * .5, d = R * .45, r = R * .8;
var x0 = (d * d + R * R - r * r) / (2 * d);
var y0 = Math.sqrt(Math.max(R * R - x0 * x0, .001));
var th = Math.atan2(y0, x0), ph = Math.atan2(y0, x0 - d);
ctx.save(); ctx.translate(hx, hy); ctx.rotate(rot - .25); ctx.translate(0, R);
ctx.beginPath();
ctx.arc(0, 0, R, -th, th, true);
ctx.arc(d, 0, r, ph, TAU - ph, false);
ctx.closePath();
var g = ctx.createLinearGradient(-R, -R * .6, R * .5, R);
g.addColorStop(0, '#FFFDF6'); g.addColorStop(.45, '#F3EBD9'); g.addColorStop(1, '#CFC1A4');
ctx.fillStyle = g; ctx.fill();
ctx.restore();
}
function frame(now){
if(!run || !ctx){ raf = null; return; }
var dt = Math.min((now - last) / 1000, .05); last = now;
ctx.clearRect(0, 0, W, H);
var HC = window.__HangCfg || { on: true };
if(HC.on === false){ raf = requestAnimationFrame(frame); return; }
wind += (Math.sin(now / 900) * .4 - wind) * .12;
sRope.update(wind); sRope.solve();
mRope.update(wind * .85); mRope.solve();
if(HC.imgL || HC.imgR){ sRope.update(wind * .9); sRope.solve(); mRope.update(wind * .85); mRope.solve(); } else if(HC.img){ pRope.update(wind * .9); pRope.solve(); }
var sp = sRope.pts, se = sp[sp.length - 1], sv = sp[sp.length - 2];
star.rot += (Math.atan2(se.x - sv.x, se.y - sv.y) - star.rot) * .12;
var mp = mRope.pts, me = mp[mp.length - 1], mv = mp[mp.length - 2];
moon.rot += (Math.atan2(me.x - mv.x, me.y - mv.y) - moon.rot) * .12;
var iL = HC.imgL || HC.img, iR = HC.imgR || HC.img;
var hgt = (window.__hangPx && window.__hangPx()) || 76;
var _k = hgt / 76;
function imgOn(rope, end, img){
ropeLine(rope);
var pp = rope.pts, pv = pp[pp.length - 2];
var w2 = hgt * (img.width / (img.height || 1));
ctx.save(); ctx.translate(end.x, end.y); ctx.rotate((Math.atan2(end.x - pv.x, end.y - pv.y)) * .5);
ctx.drawImage(img, -w2 / 2, 0, w2, hgt);
ctx.restore();
}
if(iL || iR){
if(!iL){ ropeLine(sRope); drawStar(se.x, se.y, STAR_S * _k, star.rot); } else { imgOn(sRope, se, iL); }
if(!iR){ ropeLine(mRope); drawMoon(me.x, me.y, MOON_S * _k, moon.rot); } else { imgOn(mRope, me, iR); }
} else if(HC.img){
var pp = pRope.pts, pe = pp[pp.length - 1], pv = pp[pp.length - 2];
ropeLine(pRope);
var w2 = hgt * (HC.img.width / (HC.img.height || 1));
ctx.save(); ctx.translate(pe.x, pe.y); ctx.rotate((Math.atan2(pe.x - pv.x, pe.y - pv.y)) * .5);
ctx.drawImage(HC.img, -w2 / 2, 0, w2, hgt);
ctx.restore();
} else if(se.x > me.x){
ropeLine(mRope); drawMoon(me.x, me.y, MOON_S * _k, moon.rot);
ropeLine(sRope); drawStar(se.x, se.y, STAR_S * _k, star.rot);
} else {
ropeLine(sRope); drawStar(se.x, se.y, STAR_S * _k, star.rot);
ropeLine(mRope); drawMoon(me.x, me.y, MOON_S * _k, moon.rot);
}
raf = requestAnimationFrame(frame);
}
function ensure(){
var th = '';
try{ th = document.body ? document.body.getAttribute('data-theme') : ''; }catch(e){}
var bar = document.getElementById('dramaStatusBar');
/* 挂整条状态栏（不是内层），否则内层被收窄时挂件会落在文字右端 */
var inner = (bar && bar.style.display !== 'none') ? bar : null;
if(th !== 'jade' || !inner){
if(cv && cv.parentNode) cv.parentNode.removeChild(cv);
cv = null; ctx = null; run = false;
if(raf){ try{ cancelAnimationFrame(raf); }catch(e){} raf = null; }
return;
}
if(cv && cv.parentNode === inner) return;
if(cv && cv.parentNode) cv.parentNode.removeChild(cv);
if(raf){ try{ cancelAnimationFrame(raf); }catch(e){} raf = null; }
cv = document.createElement('canvas'); cv.id = 'jadeCharm';
cv.style.cssText = 'position:absolute;right:22px;top:calc(100% - 2px);width:100px;height:120px;pointer-events:none;z-index:2;';
inner.appendChild(cv);
ctx = cv.getContext('2d');
var dpr = Math.min(window.devicePixelRatio || 1, 2);
W = 100; H = 120;
cv.width = W * dpr; cv.height = H * dpr;
ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
init();
run = true; last = performance.now();
raf = requestAnimationFrame(frame);
}
window.addEventListener('pointermove', function(e){
if(!run) return;
if(prevX !== null){
var vx = e.clientX - prevX;
if(Math.abs(vx) > 1) wind = Math.max(-8, Math.min(8, wind + vx * .25));
}
prevX = e.clientX;
}, { passive: true });
window.addEventListener('pointerleave', function(){ prevX = null; });
try{
new MutationObserver(ensure).observe(document.body, { attributes: true, attributeFilter: ['data-theme'] });
}catch(e){}
setInterval(ensure, 1400);
setTimeout(ensure, 300);
if(document.readyState === 'loading') document.addEventListener('DOMContentLoaded', ensure);
})();
;
/* 装扮页偏好 · 拆包存档：小开关与图片分开存，避免大图撑爆配额导致整条写不进去 */
(function(){
if(window.__decoPrefsBoot) return; window.__decoPrefsBoot = 1;
var K_FLAGS = 'isekai_deco_flags';
var K_IMGS  = 'isekai_deco_imgs';
var FLAGS = ['hangOn','hangSize','fxTap','fxTrail'];
var IMGS  = ['hangImg','hangImgL','hangImgR','vfFabImg'];
var TABLE = 'deco_prefs';
var _saveT = null, _ts = 0;
function setLS(k, v){
try{ localStorage.setItem(k, v); return true; }
catch(e){
/* 配额爆了就丢图保住开关 */
try{ if(k === K_IMGS){ localStorage.setItem(k, JSON.stringify({ ts:(v && 1), hangImg:'', hangImgL:'', hangImgR:'', vfFabImg:'' })); } }catch(e2){}
return false;
}
}
function getLS(k){
try{ return JSON.parse(localStorage.getItem(k) || 'null'); }catch(e){ return null; }
}
function collectFlags(){
var o = { ts: Date.now() };
try{
if(window.appSettings) FLAGS.forEach(function(k){ if(appSettings[k] !== undefined) o[k] = appSettings[k]; });
else{
var c = window.__HangCfg || {};
o.hangOn = !!c.on; o.hangSize = c.size || 0;
}
}catch(e){}
return o;
}
function collectImgs(){
var o = {};
try{
if(window.appSettings) IMGS.forEach(function(k){ if(typeof appSettings[k] === 'string') o[k] = appSettings[k]; });
else{
var c = window.__HangCfg || {};
o.hangImgL = c.srcL || ''; o.hangImgR = c.srcR || '';
o.vfFabImg = (window.__FloatCfg || {}).src || '';
}
}catch(e){}
return o;
}
function applyAll(src){
if(!src) return;
window.__decoApplying = true;
try{ _applyAll(src); }finally{ window.__decoApplying = false; }
}
function _applyAll(src){
/* 挂件：装扮快照比用户最后一次改动更旧时不许覆盖 —— 这是“退出重进就重置”的真凶 */
var _hts = (window.appSettings && Number(appSettings.hangTs)) || 0;
src.flags && (function(o){
_ts = o.ts || 0;
var _old = !!( _hts && _ts && _ts < _hts );
try{ if(window.appSettings) FLAGS.forEach(function(k){
if(o[k] === undefined) return;
if(_old && (k === 'hangOn' || k === 'hangSize')){ try{ window.__stg && window.__stg('拦下旧快照 ' + k); }catch(e){} return; }
appSettings[k] = o[k];
}); }catch(e){}
})(src.flags);
src.imgs && (function(o){
var _old2 = !!( _hts && _ts && _ts < _hts );
try{ if(window.appSettings) IMGS.forEach(function(k){
if(typeof o[k] !== 'string') return;
if(_old2 && k !== 'vfFabImg') return;
appSettings[k] = o[k];
}); }catch(e){}
})(src.imgs);
try{ if(window.__hangSync) window.__hangSync(); }catch(e){}
try{ if(window.__floatSync) window.__floatSync(); }catch(e){}
try{
if(window.FXEngine){
var _t2 = (window.appSettings && appSettings.fxTap) || (src.flags && src.flags.fxTap);
var _r2 = (window.appSettings && appSettings.fxTrail) || (src.flags && src.flags.fxTrail);
if(_t2) FXEngine.setTap(_t2);
if(_r2) FXEngine.setTrail(_r2);
}
}catch(e){}
try{
var box = document.querySelector('[data-hang-on]');
if(box && window.__HangCfg) box.checked = !!(window.__HangCfg.on);
try{ window.__stg && window.__stg('界面套用 size=' + ((window.__HangCfg && window.__HangCfg.size) | 0)); }catch(e){}
var sz = window.__HangCfg ? window.__HangCfg.size : -1;
var szt = document.querySelector('[data-hang-szbox]');
if(szt) Array.prototype.forEach.call(szt.querySelectorAll('[data-hang-size]'), function(el){
var on = Number(el.getAttribute('data-hang-size')) === sz;
el.style.borderColor = on ? 'rgba(125,190,255,.55)' : '';
el.style.color = on ? 'var(--accent)' : '';
});
['tap','trail'].forEach(function(kind){
var sel = document.querySelector('[data-fxsel="' + kind + '"]');
var v = window.appSettings ? appSettings[kind === 'tap' ? 'fxTap' : 'fxTrail'] : null;
if(sel && v){ for(var i=0;i<sel.options.length;i++){ if(sel.options[i].value === v){ sel.selectedIndex = i; break; } } }
});
}catch(e){}
}
function dbWrite(){
try{
var BRd = window.__DBAPI || window.AiPhone; if(!BRd || !BRd.db) return;
var flags = collectFlags();
var imgs = collectImgs();
var payload = { data: JSON.stringify({ flags: flags, imgs: imgs }) };
var _L = String(((imgs && imgs.hangImgL) || '').length);
BRd.db.list(TABLE, { limit: 1 }).then(function(list){
var row = list && list[0];
if(row && row.id) return BRd.db.update(TABLE, row.id, payload);
return BRd.db.create(TABLE, payload);
}).then(function(){
try{ window.__stg && window.__stg('存档写 成功 L=' + _L); }catch(e){}
}).catch(function(e){
try{ window.__stg && window.__stg('存档写 失败 ' + String(e && (e.message || e)).slice(0,40)); }catch(_){}
});
}catch(e){}
}
window.__decoSave = function(){
var flags = collectFlags(), imgs = collectImgs();
setLS(K_FLAGS, JSON.stringify(flags));
setLS(K_IMGS, JSON.stringify(imgs));
if(_saveT) clearTimeout(_saveT);
_saveT = setTimeout(dbWrite, 600);
};
var _quietUntil = 0;
window.__decoLoad = function(){
try{
var BRd = window.__DBAPI || window.AiPhone;
if(!BRd || !BRd.db) return;
BRd.db.list(TABLE, { limit: 1 }).then(function(list){
var row = list && list[0];
if(!row) { try{ window.__stg && window.__stg('存档读 无行'); }catch(e){} return; }
var d = null;
try{ d = JSON.parse(row.data || '{}'); }catch(e){ d = null; }
if(!d) { try{ window.__stg && window.__stg('存档读 解析失败'); }catch(e){} return; }
var _L = String((d.imgs && d.imgs.hangImgL) || '').length;
try{ window.__stg && window.__stg('存档读 L=' + _L); }catch(e){}
if(d && (d.flags || d.imgs)) applyAll({ flags: d.flags || {}, imgs: d.imgs || {} });
}).catch(function(){ try{ window.__stg && window.__stg('存档读 失败'); }catch(e){} });
}catch(e){}
};
window.__decoApply = function(){
var f = getLS(K_FLAGS), i = getLS(K_IMGS);
_quietUntil = Date.now() + 1500;
if(f || i) applyAll({ flags: f, imgs: i });
};
/* 特效选择：设置页没渲染过时也要能用（不然下拉框写了没处存） */
if(!window.__fxPick){
window.__fxPick = function(kind, v){
try{ if(window.FXEngine) window.FXEngine[kind === 'tap' ? 'setTap' : 'setTrail'](v); }catch(e){}
try{ if(window.appSettings){ appSettings[kind === 'tap' ? 'fxTap' : 'fxTrail'] = v; if(window.saveSettings) window.saveSettings(); } }catch(e){}
try{
var _p = null;
try{ _p = JSON.parse(localStorage.getItem('isekai_fx_pick') || 'null'); }catch(e2){ _p = null; }
_p = _p || {}; _p[kind] = v; _p.ts = Date.now();
localStorage.setItem('isekai_fx_pick', JSON.stringify(_p));
}catch(e3){}
try{ if(window.__decoSave) window.__decoSave(); }catch(e){}
};
}
window.__decoApply();
try{
var BR1 = window.__DBAPI || window.AiPhone; if(BR1 && BR1.db){
BR1.db.list(TABLE, { limit: 1 }).then(function(list){
var row = list && list[0];
if(!row || !row.data) return;
var o = null; try{ o = JSON.parse(row.data); }catch(e){ o = null; }
if(!o) return;
var dbTs = (o.flags && o.flags.ts) || 0;
if(dbTs >= _ts) applyAll(o);
}).catch(function(){});
}
}catch(e){}
/* 挂件大小是点击按钮，不走 change，这里补一条点击代理 */
document.addEventListener('click', function(e){
var el = e.target && e.target.closest ? e.target.closest('[data-hang-size]') : null;
if(!el) return;
var i = Number(el.getAttribute('data-hang-size'));
if(!(i === 0 || i === 1 || i === 2)) return;
try{ if(window.__hangUpdate) window.__hangUpdate({ hangSize:i }); }catch(err){}
try{ if(window.__decoSave) window.__decoSave(); }catch(err){}
}, true);
document.addEventListener('change', function(e){
var t = e.target;
if(!t || !t.getAttribute) return;
if(t.hasAttribute('data-hang-on')){
try{ t.dataset.decH = '1'; }catch(err){}
try{ if(window.__hangUpdate) window.__hangUpdate({ hangOn: !!t.checked }); }catch(err){}
try{ if(window.__decoSave) window.__decoSave(); }catch(err){}
}
var fk = t.getAttribute('data-fxsel');
if(fk){
try{ t.dataset.decF = '1'; }catch(err){}
try{ if(window.__fxPick) window.__fxPick(fk, t.value); }catch(err){}
try{ if(window.__decoSave) window.__decoSave(); }catch(err){}
}
}, true);
/* 设置页可能挂在 shadow root 里，change 事件不会跨 shadow 边界冒到 document，
所以这里直接穿透 shadow 去拿控件、并在 shadow 内部也挂监听 */
var _roots = [], _rootAt = 0;
function collectRoots(){
var out = [document];
try{
var els = document.querySelectorAll('*');
for(var i=0;i<els.length;i++){ if(els[i].shadowRoot) out.push(els[i].shadowRoot); }
}catch(e){}
_roots = out; _rootAt = Date.now();
}
function dq(sel){
if(!_roots.length || Date.now() - _rootAt > 2500) collectRoots();
for(var i=0;i<_roots.length;i++){
var el = null;
try{ el = _roots[i].querySelector(sel); }catch(e){ el = null; }
if(el) return el;
}
return null;
}
function bindRoots(){
collectRoots();
_roots.forEach(function(r){
if(r.__decoBinded) return;
r.__decoBinded = 1;
try{ r.addEventListener('change', rootChange, true); }catch(e){}
try{ r.addEventListener('click', rootClick, true); }catch(e){}
});
}
function applyFromControl(t){
if(!t || !t.getAttribute) return;
if(t.hasAttribute('data-hang-on')){
try{ t.dataset.decH = '1'; }catch(e){}
try{ if(window.__hangUpdate) window.__hangUpdate({ hangOn: !!t.checked }); }catch(e){}
try{ if(window.__decoSave) window.__decoSave(); }catch(e){}
}
var fk = t.getAttribute('data-fxsel');
if(fk){
try{ t.dataset.decF = '1'; }catch(e){}
try{ if(window.__fxPick) window.__fxPick(fk, t.value); }catch(e){}
try{ if(window.__decoSave) window.__decoSave(); }catch(e){}
}
}
function rootChange(e){ applyFromControl(e.target); }
function rootClick(e){
var el = e.target && e.target.closest ? e.target.closest('[data-hang-size]') : null;
if(!el) return;
var i = Number(el.getAttribute('data-hang-size'));
if(!(i === 0 || i === 1 || i === 2)) return;
try{ if(window.__hangUpdate) window.__hangUpdate({ hangSize:i }); }catch(err){}
try{ if(window.__decoSave) window.__decoSave(); }catch(err){}
}
setInterval(bindRoots, 1500);
setTimeout(bindRoots, 300);
/* 轮询兜底：直接比对控件自身状态（就算事件一条都收不到也能存） */
var _last = null;
function snap(){
var o = {};
/* 复选框可能是用旧设置渲染出来的，拿它当真会把错值反写进存档；
开关的点击本身会直接调 __hangUpdate，所以 cfg 永远是最新的 */
var _hc = window.__HangCfg || {};
o.hangOn = (typeof _hc.on === 'boolean') ? _hc.on : null;
/* 以引擎真实状态为准：设置页重建会把下拉框重置成“无”，
若拿下拉框当准绳，就会把“无”反写回存档，用户选择等于白选 */
/* 下拉框选了具体特效 → 那就是用户意图；下拉被设置页重建成“无”时，
不把它当真，改以引擎实际状态为准（避免把“无”反写回存档） */
try{
var m = window.FXEngine && window.FXEngine.mode ? window.FXEngine.mode() : null;
['tap','trail'].forEach(function(kind){
var sel = dq('[data-fxsel="' + kind + '"]');
var sv = sel ? sel.value : null;
if(sv && sv !== 'none') o[kind] = sv;
else o[kind] = m ? m[kind] : null;
});
}catch(e){ o.tap = null; o.trail = null; }
var c = window.__HangCfg || {};
o.hangSize = (typeof c.size === 'number') ? c.size : null;
o.vfFabImg = ((window.__FloatCfg || {}).src) || '';
return o;
}
try{
var _arr0 = JSON.parse(localStorage.getItem('isekai_stage') || '[]') || [];
var _el0 = document.querySelector('[data-stgline]');
if(_el0 && _arr0.length) _el0.textContent = '最近：' + _arr0.slice(-4).join(' → ');
}catch(e){}
var _cand = {};
function commit(kind, val){
if(kind === 'hangOn' || kind === 'hangSize'){
var pt = {}; pt[kind] = val;
try{ window.__hangUpdate && window.__hangUpdate(pt); }catch(e){}
} else if(kind === 'tap' || kind === 'trail'){
try{ window.__fxPick && window.__fxPick(kind, val); }catch(e){}
} else if(kind === 'vfFabImg'){
try{ window.__floatUpdate && window.__floatUpdate(val); }catch(e){}
}
try{ window.__decoSave && window.__decoSave(); }catch(e){}
}
function watchTick(){
try{
if(window.__fxModalOpen) return;   /* 导入弹窗开着时别在后台反复写存档，否则整个弹窗会卡 */
var cur = snap();
if(_last === null){ _last = cur; return; }
if(window.__decoApplying){ _last = cur; _cand = {}; return; }
var keys = ['hangOn','hangSize','tap','trail','vfFabImg'];
var now = Date.now();
for(var i=0;i<keys.length;i++){
var k = keys[i], cv = cur[k], lv = _last[k];
if(cv === null || cv === lv) continue;
if(k === 'vfFabImg' && cv === ''){
var store = getLS(K_IMGS) || {};
if(store.vfFabImg) continue;
}
var c = _cand[k];
if(!c || c.v !== cv){ _cand[k] = { v: cv, t: now }; continue; }
if(now - c.t < 1200) continue;
delete _cand[k];
commit(k, cv);
}
_last = cur;
}catch(e){}
}
setInterval(watchTick, 500);
/* 独立键优先回填：这类小设置必须“重启即回原来的样子” */
function __pickRestore(){
try{
var hp = null;
try{ hp = JSON.parse(localStorage.getItem('isekai_hang_pick') || 'null'); }catch(e){ hp = null; }
if(hp && window.__hangUpdate){
var pt = {};
if(hp.on !== undefined) pt.hangOn = hp.on;
if(hp.size !== undefined) pt.hangSize = hp.size;
var hi = null;
try{ hi = JSON.parse(localStorage.getItem('isekai_hang_imgs') || 'null'); }catch(e){ hi = null; }
if(hi){
if(hi.imgL !== undefined) pt.hangImgL = hi.imgL;
if(hi.imgR !== undefined) pt.hangImgR = hi.imgR;
if(hi.img !== undefined) pt.hangImg = hi.img;
}
if(pt.hangOn !== undefined || pt.hangSize !== undefined || pt.hangImgL !== undefined || pt.hangImgR !== undefined || pt.hangImg !== undefined){ try{ window.__stg && window.__stg('按键恢复 size=' + pt.hangSize); }catch(e){} window.__hangUpdate(pt); }
}
var fp = null;
try{ fp = JSON.parse(localStorage.getItem('isekai_fx_pick') || 'null'); }catch(e){ fp = null; }
if(fp && window.FXEngine){
if(fp.tap) FXEngine.setTap(fp.tap);
if(fp.trail) FXEngine.setTrail(fp.trail);
try{
var box = dq('[data-fxsel="tap"]'), box2 = dq('[data-fxsel="trail"]');
if(box && fp.tap) for(var i=0;i<box.options.length;i++){ if(box.options[i].value === fp.tap) box.selectedIndex = i; }
if(box2 && fp.trail) for(var j=0;j<box2.options.length;j++){ if(box2.options[j].value === fp.trail) box2.selectedIndex = j; }
}catch(e){}
}
var vp = null;
try{ vp = localStorage.getItem('isekai_vf_fab_pick') || ''; }catch(e){ vp = ''; }
if(vp && window.__floatUpdate) window.__floatUpdate(vp);
}catch(e){}
}
window.__pickRestore = __pickRestore;
[300, 900, 2000, 3600, 6000].forEach(function(t){ setTimeout(__pickRestore, t); });
/* 装扮存档：启动时从 deco_prefs 表把 flags/imgs 读回来（本地存储已满，不能再依赖它） */
[1200, 2600, 5000, 8000, 12000].forEach(function(t){ setTimeout(function(){ try{ window.__decoLoad && window.__decoLoad(); }catch(e){} }, t); });
/* 读库回填有可能晚到、把键里的值盖掉；这条键是用户亲手选的，按它定期纠回来 */
setInterval(function(){ try{ if(!window.__decoApplying) __pickRestore(); }catch(e){} }, 8000);
[400, 1200, 2600].forEach(function(t){ setTimeout(window.__decoApply, t); });
var _n = 0, _iv = setInterval(function(){ window.__decoApply(); if(++_n >= 4) clearInterval(_iv); }, 1000);
})();
;
/* 图片通道：上传/生图的大图先在工作线程解码并缩到显示尺寸，再交给界面。
原来直接把几 MB 的图塞进 img.src，WebView 会在主线程同步解码，就是卡顿的来源。 */
(function(){
if(window.__imgPipeBoot) return; window.__imgPipeBoot = 1;
function dataUrlToBlob(u){
try{
var m = /^data:([^;]+);base64,(.*)$/.exec(u);
if(!m) return null;
var bin = atob(m[2]), arr = new Uint8Array(bin.length);
for(var i=0;i<bin.length;i++) arr[i] = bin.charCodeAt(i);
return new Blob([arr], { type: m[1] });
}catch(e){ return null; }
}
function canvasToUrl(cv, type, q){
try{ return cv.toDataURL(type, q); }catch(e){ return ''; }
}
/* 缩图：有 createImageBitmap 时解码和缩放都在解码线程做，主线程几乎不阻塞 */
window.__imgShrink = function(src, maxSide, quality){
maxSide = maxSide || 1600; quality = quality || 0.82;
return new Promise(function(resolve){
try{
if(!/^data:image\//i.test(String(src))){ resolve(src); return; }
/* 动图不能压：一次 JPEG 转码就把动画拍成一张静图 */
if(/^data:image\/(gif|webp)/i.test(String(src))){ resolve(src); return; }
if(/^(blob|http)[^,]*$/.test(String(src)) && /\.gif(\?|$)/i.test(String(src))){ resolve(src); return; }
var blob = dataUrlToBlob(src);
if(!blob){ resolve(src); return; }
/* 先按字节粗筛：小图不动，免得白折腾 */
if(blob.size < 220 * 1024){ resolve(src); return; }
var fallback = function(){
try{
var im = new Image();
im.onload = function(){
try{
var w = im.naturalWidth, h = im.naturalHeight;
var sc = Math.min(1, maxSide / Math.max(w, h));
if(sc >= 1){ resolve(src); return; }
var cv = document.createElement('canvas');
cv.width = Math.max(8, Math.round(w * sc)); cv.height = Math.max(8, Math.round(h * sc));
var cx = cv.getContext('2d');
cx.drawImage(im, 0, 0, cv.width, cv.height);
var out = canvasToUrl(cv, 'image/jpeg', quality);
resolve(out && out.length < src.length ? out : src);
}catch(e){ resolve(src); }
};
im.onerror = function(){ resolve(src); };
im.decoding = 'async';
im.src = src;
}catch(e){ resolve(src); }
};
if(!window.createImageBitmap){ fallback(); return; }
createImageBitmap(blob).then(function(bmp){
try{
var w = bmp.width, h = bmp.height;
var sc = Math.min(1, maxSide / Math.max(w, h));
if(sc >= 1){ try{ bmp.close(); }catch(e){} resolve(src); return; }
var tw = Math.max(8, Math.round(w * sc)), th = Math.max(8, Math.round(h * sc));
return createImageBitmap(blob, { resizeWidth: tw, resizeHeight: th, resizeQuality: 'high' }).then(function(small){
try{
var cv = document.createElement('canvas');
cv.width = tw; cv.height = th;
var cx = cv.getContext('2d');
cx.drawImage(small, 0, 0);
try{ small.close(); bmp.close(); }catch(e){}
var out = canvasToUrl(cv, 'image/jpeg', quality);
resolve(out && out.length < src.length ? out : src);
}catch(e){ resolve(src); }
});
}catch(e){ try{ bmp.close(); }catch(x){} fallback(); }
}).catch(function(){ fallback(); });
}catch(e){ resolve(src); }
});
};
/* 所有“从相册选图”的入口统一走这里：返回前先把大图压到 1600 长边 */
function patchPick(){
try{
var m = window.API && window.API.media;
if(!m || !m.pick || m.__imgPipe) return false;
/* 选图阶段不再压缩，原图直接进流程；压缩交给入库后的空闲任务 */
var orig = m.pick;
m.__imgPipe = 1;
/* 选图这一步只透传：不在这里做任何解码/转码，避免用户点完图先卡住一两秒。
等图真正入库之后，再在空闲时间压一次并写回数据库（见 addToGallery 尾部）。 */
m.pick = function(opts){
return Promise.resolve(orig.call(m, opts));
};
return true;
}catch(e){ return false; }
}
var n = 0, t = setInterval(function(){ if(patchPick() || ++n > 40) clearInterval(t); }, 400);
setTimeout(patchPick, 600);
})();
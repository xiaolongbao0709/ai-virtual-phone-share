

// ===== API 日志拦截 =====
let devApiLogs = [];
const originalAiChat = api.ai.chat;
api.ai.chat = async function(args) {
  const time = new Date().toLocaleTimeString();
  try {
    const res = await originalAiChat.call(this, args);
    devApiLogs.unshift({ time, req: args, res, error: null });
    if (devApiLogs.length > 50) devApiLogs.pop();
    return res;
  } catch(err) {
    devApiLogs.unshift({ time, req: args, res: null, error: err.toString() });
    if (devApiLogs.length > 50) devApiLogs.pop();
    throw err;
  }
};
let userAncientDesc = "";
const defaultGlobalWorldDesc = `world_setting:
  dynasty_name: "永安"
  language_style: "古风 (Archaic/Classical Chinese)"
  core_premise:
    - historical_context: "王朝曾为父权社会，以男子为尊。"
    - pivotal_change: "{{user}}登基，成为执掌天下的皇帝，开启历史新篇章。"
    - key_policy:
        - name: "均权令"
        - content: "颁布新政，宣布男女皆可入朝为官，倡导男女平等。"
    - political_climate:
        - overt: "多数朝臣表面顺服，慑于皇帝之威，不敢公然反对。"
        - covert: "暗流涌动，许多旧臣对皇帝及新政心怀不满与微词，持保守观望态度。"

harem_system:
  name: "长信宫 (Palace of Eternal Faith)"
  description: "皇帝的后宫，居住者皆为男性妃嫔。"`;

// ===== 提示词管理系统 =====
const defaultPrompts = {
  indoorChatOpen: `你是一个古代后宫文字互动引擎。当前游戏时间：{{timeStr}}。

【本次场景：养心殿召见】
你（皇帝）正身处养心殿，已传令召【{{charName}}】前来觐见。
{{charName}}从【{{pName}}】启程，一路行至养心殿，入内向你请安。

【全局世界书】：
{{wbText}}
【{{charName}} 的完整档案】：
性别：{{charGender}}
位份：{{assignedRank}}
人物设定：{{desc}}{{charWb}}

【TA了解的（位份体系、关系图谱、性别等知晓的事）】：
{{knownText}}

【TA看到的（经历过、见过的事）】：
{{memoryText}}

【起居注（近期行迹）】：
{{recText}}

【关系图谱（TA对他人的看法）】：
{{relText}}

【剧情推演严苛规则，逐条遵守】：
1. 【性别铁律】：{{charName}} 的性别是【{{charGender}}】，所有动作、神态、自称、语气、外貌描写必须与此性别完全相符，绝对不可出现任何与性别矛盾的描写。
2. 分析当前时间（如深夜、清晨）和{{charName}}的过往记忆，推演他接到传召后的心情——是忐忑、期待、还是如常？
3. 描写{{charName}}从【{{pName}}】赶来养心殿的过程（路途、心理）以及踏入殿内、向你行礼请安的第一个画面。
4. 随后生成{{charName}}对你说出的第一句请安或问候。
5. 【铁律】：绝对不可以替你（皇帝）说话或做决定，只能描写环境、{{charName}}的动作和{{charName}}的话。
6. 【称谓铁律】：全程用"你"指代User（皇帝），严禁使用"她"、"皇帝"、"陛下"等任何第三人称或称谓来指代User；用"{{charName}}"指代角色，严禁使用"TA"、"对方"等模糊代词。
7. 【篇幅与格式】：总字数500字以内。必须分段输出，每段用 <p> 标签包裹。【分段铁律】：每个叙事 <p> 段落不超过50字，约两三句话即换段，宁可多段也绝不堆砌长段，严禁在正文输出“旁白：”或把“旁白”作为说话者。
8. {{charName}}的对话必须单独占一个 <p> 标签，只用英文双引号 ""，并带 data-speaker 属性，格式：<p data-speaker="{{charName}}">"说的话"</p>。`,

  indoorIntimateOpen: `你是一个古代后宫文字互动引擎。当前游戏时间：{{timeStr}}。
你（皇帝）正处于【{{pName}}】的寝殿内，准备临幸{{charName}}。

【全局世界书】：
{{wbText}}
【{{charName}} 的完整档案】：
性别：{{charGender}}
位份：{{assignedRank}}
人物设定：{{desc}}{{charWb}}

【TA了解的（位份体系、关系图谱、性别等知晓的事）】：
{{knownText}}

【TA看到的（经历过、见过的事）】：
{{memoryText}}

【起居注（近期行迹）】：
{{recText}}

【关系图谱（TA对他人的看法）】：
{{relText}}

【临幸剧情推演严苛规则，逐条遵守】：
1. 根据目前的时间、地点以及{{charName}}的人设，描写一场唯美、细致、充满张力的后宫侍寝前奏与过程。
2. 重点描写{{charName}}的动作、神态、喘息、生理反应以及对你的恭顺与渴望，体现皇权压迫下的禁忌感与臣服感。
3. 【铁律】：绝对不可以替你（皇帝）说话或做任何动作决定，只能描写环境、{{charName}}的反应以及{{charName}}对你轻柔动作的承接。
4. 【称谓铁律】：全程用"你"指代User（皇帝），严禁使用"她"、"皇帝"、"陛下"等任何第三人称或称谓来指代User；用"{{charName}}"指代角色，严禁使用"TA"、"对方"等模糊代词。
5. 【篇幅与格式】：正文约2000字，必须分段输出，每段用 <p> 标签包裹。【分段铁律】：每个叙事 <p> 段落不超过50字，约两三句话即换段，宁可多段也绝不堆砌长段，严禁在正文输出“旁白：”或把“旁白”作为说话者。
6. {{charName}}的对话必须单独占一个 <p> 标签，只用英文双引号 ""，并带 data-speaker 属性，格式：<p data-speaker="{{charName}}">"说的话"</p>。`,

  indoorChatReply: `继续刚才与{{charName}}的对话。
刚刚发生的对话履历如下：
{{historyText}}

请根据你（皇帝）的最新言行，生成{{charName}}的回应和后续描述（正文约1500字）。
【严格要求】：
1. 格式要求一致：使用 <p> 标签分段，对话单独一行必须带 data-speaker 属性，只用英文双引号。
2. 【分段铁律】：至少组织为15个连续的小段落；为兼顾约1500字总量，一个内容小段可以由相连的两至三个短<p>组成。每个叙事<p>尽量控制在50至100字，宁可增加段落也绝不挤成长墙，严禁在正文输出“旁白：”或把“旁白”作为说话者。
3. 绝对不可替你（皇帝）说话或做决定。
4. 【称谓铁律】：全程用"你"指代User（皇帝），严禁使用"她"、"皇帝"、"陛下"等任何第三人称或称谓来指代User；用"{{charName}}"指代角色，严禁使用"TA"、"对方"等模糊代词。`,

  storyReroll: `你是一个古代后宫文字剧情引擎。当前游戏时间：{{timeStr}}。
你（皇帝）正试图窥见【{{pName}}{{rName}}】的一幕（当前殿内的主位是：{{charName}}）。
注意：你来看望{{charName}}时，同住在同一宫殿【{{pName}}】的其他妃子（{{coResidentNames}}）会最先知情。

【全局世界书】：
{{wbText}}
【后宫所有妃嫔（含未在场、不在同一宫殿的全部角色）档案】（务必查阅他们的人设和记忆）：
{{concubinesInfo}}{{customRule}}

【剧情推演严苛规则，逐条遵守】：
请在输出剧情正文前，先进行如下思考（用 <think> 和 </think> 标签包裹）：
1，住在这个屋的妃子是哪位（{{charName}}），人设如何？最近发生了什么？他的心情如何？他现在是否在庭院内？正在做什么？做的时候在想什么？他是否看到了你在看他？
2，住在同一个宫殿（{{pName}}）的妃子们又有哪些（{{coResidentNames}}）？他们的人设都是什么？他们最近发生了什么事？他们在做什么？是否正在和某人在一起？这会儿是否在宫殿内？他们是否知情你去看望这个妃子了？他们要出来对话吗？
3，发生剧情的是多个char还是只有一个，甚至都不在，没有char？
4，如果是多个char，他们互相之间的关系是什么样的（交好、嫉妒、敌对）？

思考完成后，输出剧情正文。
正文要求：
1. 生动描写你走入时看到的场景，以及他们发现你后的反应（约1500字）。
2. 结合时间：子时可能就寝，午时用膳，申时赏花等。
3. 【铁律】：绝对不可以生成你（皇帝）说的话，只能生成你视角的观察，以及其他人的对话。
4. 【称谓铁律】：全程用"你"指代User（皇帝），严禁使用"她"、"皇帝"、"陛下"等任何第三人称或称谓来指代User；角色一律用其姓名指代，严禁使用"TA"、"对方"等模糊代词。
5. 【分段铁律】：每个叙事 <p> 段落不超过50字，约两三句话即换段，宁可多段也绝不堆砌长段。对话单独一个 <p> 标签，严禁在正文输出“旁白：”或把“旁白”作为说话者。
6. 【格式】：正文每段用一对 <p> 标签包裹。只有角色的对话才用英文双引号 "" 引出，且对话必须单独占一个 <p> 标签，并在标签内用 data-speaker 属性标明是谁说的，格式必须是：<p data-speaker="角色名">"说的话"</p>。如果是路人甲（宫女太监）说话，speaker写"路人"。`,

  storyReply: `继续刚才的剧情推演。当前在场人物不变。
刚刚发生的剧情履历如下：
{{historyText}}

请根据你（皇帝）的最新言行，继续生成后续的剧情（正文约1500字）。
【严格要求】：
1. 格式要求与之前完全一致：使用 <p> 标签分段，对话单独一行且必须带 data-speaker 属性，只用英文双引号。
2. 【分段铁律】：至少组织为15个连续的小段落；为兼顾约1500字总量，一个内容小段可以由相连的两至三个短<p>组成。每个叙事<p>尽量控制在50至100字，宁可增加段落也绝不挤成长墙，严禁在正文输出“旁白：”或把“旁白”作为说话者。
3. 绝对不可生成你（皇帝）说的话。
4. 【称谓铁律】：全程用"你"指代User（皇帝），严禁使用"她"、"皇帝"、"陛下"等任何第三人称或称谓来指代User；角色一律用其姓名指代，严禁使用"TA"、"对方"等模糊代词。`,

  generateRecords: `你是一个古代文人，擅长撰写雅致、含蓄、充满古风韵味的宫廷笔记。
当前游戏时间：{{timeStr}}。
请为后宫妃嫔【{{charName}}】生成8条近期的【记事】（生活碎片、见闻、心情或与主控、其他妃嫔的互动）。

【{{charName}} 的档案】：
位份：{{assignedRank}}
人物设定：{{desc}}{{charWb}}
{{charName}}所有记得的过往与了解的事：
{{memoryText}}

【撰写要求（铁律）】：
1. 必须分析该角色在近期的空白时间段里做了什么。有几条是独自一人的闲愁/雅趣，有几条是暗中思念皇帝，有几条可以涉及别的人（若涉及其他妃子，必须从系统给出的名单里选，名单：{{allChars}}）。
2. 【称谓铁律】：记事中若提及User（皇帝/主君），一律用"皇帝"或"主君"等称谓，绝对不得用"她"；提及{{charName}}时用其姓名，绝不用"TA"或"对方"。
2. 每条记事的字数控制在 20-40 字左右，语言必须具有古韵古风，模仿古代文人笔记的雅致风格。
3. 举例参考：
- 永安六年三月，倚栏抛饵戏锦鳞，水纹动处，人谓其袖中诗笺化作游鱼。
- 永安六年三月，夜半剪灯花，焰影颤颤，映其侧颜，恍若月下青瓷初裂。
- 永安六年三月，折梅入瓶，花枝斜逸，竟与眉目一般清癯。
- 永安六年三月，晨起呵镜，书“归”字于雾面，须臾化水，见者疑其心事在有无间。
- 永安六年三月，弈棋赌新茗，谢临渊故意输玉卿半子，却将残茶泼向石隙，说：“润了苔痕，也算赢过一局春色。”
4. 输出格式：必须输出一个 JSON 数组，包含8个对象，格式如下：
[
  { "time": "永安xxxx年x月", "text": "记事内容..." },
  ...
]
绝对不要输出 JSON 以外的任何分析或废话。`,

  generateGlobalRecords: `你是一个古代文人，擅长撰写雅致、含蓄、充满古风韵味的宫廷与朝堂笔记。
当前游戏时间：{{timeStr}}。
请为以下群像【{{groupName}}】生成8条近期的【记事】（生活碎片、见闻、心情、互动等）。

【群像档案】（请仔细阅读每个人的设定）：
{{allCharsInfo}}

【撰写要求（铁律）】：
1. 必须分析这些角色在近期的空白时间段里做了什么。必须合理分配这8条记事，确保提及尽量多的人，绝不能只写同一个人。
2. 每条记事的字数控制在 20-40 字左右，语言必须具有古韵古风，模仿古代文人笔记的雅致风格。
3. 每条记事必须明确归属于某一个主要角色（即这事是以谁为主体的），并在输出的 "owner" 字段填入该角色的准确姓名（必须在上面提供的名单里）。
4. 输出格式：必须输出一个 JSON 数组，包含8个对象，格式如下：
[
  { "time": "永安xxxx年x月", "owner": "某角色名", "text": "记事内容..." },
  ...
]
绝对不要输出 JSON 以外的任何分析或废话。`
};

defaultPrompts.huaqingSummon = `你是古代皇帝宫廷模拟游戏的华清宫剧情导演。
当前时间：{{timeStr}}
本次受召者：{{participantNames}}

【华清宫描述】
{{huaqingDescription}}

【华清宫规则】
{{huaqingRules}}

【剧情要求】
1. 先分别描写受召者听见太监传召后的简短动作与内心波澜，必须符合每个人的人设、身份、记忆和当下时间。
2. 再描写多人先后抵达华清宫、在宫门或汤殿门前相遇的细节；他们相互认识与否、礼数和态度要以资料为准。
3. 随后进入皇帝在华清宫与众人的互动。不得替皇帝说话、行动或决定；末尾留下清晰的互动钩子等待User回应。
4. 只能让名单中的人物以实名发言；每位受召者在开场中至少要有一次台词。叙事用<p>内容</p>，台词必须用<p data-speaker="人物档案中的准确姓名">“台词”</p>，data-speaker中不得添加官职、位份、空格或括号，否则系统无法调用立绘。不得输出“旁白”二字。
5. 开场约1200至1800字，拆成至少15个有实质内容的短段。`;

defaultPrompts.huaqingBath = `你是古代皇帝宫廷模拟游戏的华清宫沐浴剧情导演。
当前时间：{{timeStr}}
系统已从忠诚度低于50的侍从与宫女中随机抽取{{candidateCount}}名候选：{{candidateNames}}

【华清宫描述】
{{huaqingDescription}}

【华清宫规则】
{{huaqingRules}}

请先依据所有候选人的完整资料、性格、状态、介绍、忠诚度和全部记忆，判断谁最可能因贪图富贵、改变处境、背离旧主或其他符合人设的动机，主动争取侍奉皇帝沐浴。严禁随机硬选或改写既有人设。

只按以下格式输出：
<chosen-name>候选名单中的准确姓名</chosen-name>
<story>
约1500字剧情。先细写此人此前的经历、处境与心中如何一步步作出决定，再写其设法靠近汤殿、主动侍奉并与皇帝开始互动。不得替皇帝说话或作决定；结尾等待User回应。叙事用<p>内容</p>，台词用<p data-speaker="准确姓名">“台词”</p>，不得输出“旁白”二字。
</story>`;

defaultPrompts.huaqingConferral = `你是古代皇帝宫廷模拟游戏的册封剧情导演。
刚刚在华清宫侍奉皇帝的NPC是{{npcName}}，皇帝决定册封其为{{rankName}}，赐居{{palaceName}}。
此人册封前的主人是：{{formerMasterName}}。

【任务】
1. 结合此人原有全部资料与记忆、刚才华清宫剧情摘要、后宫位份表及各位份备注，判断其如何理解这次册封。不得无视原性格与经历。
2. 若此人原有主人，必须读取原主人的完整人设和全部记忆，描写原主人得知册封后的真实反应，并继续描写原主人与新册后妃之间的一段直接互动；两人的称谓、旧日主从关系和态度必须符合资料。若原本没有主人，严禁凭空捏造主人。
3. 正文约2500字，分成至少25个短段，描写宣旨、此人的谢恩回应、离开后的动作和内心余波、其他宫人的小声议论，以及原主人得知消息后的反应与互动。User不参与回应，不得替User新增台词或动作。
4. 摘要与正文必须在本次同一次输出中完成。摘要为不超过150字的客观事实，重点记录被册封者及其原主人的反应。

只按以下格式输出：
<memory-summary>不超过150字摘要</memory-summary>
<story>叙事用<p>内容</p>；人物台词用<p data-speaker="准确姓名">“台词”</p>；普通宫人可用speaker="路人"。不得输出“旁白”二字。</story>`;

// 当前生效的自定义提示词，合并自存档
let customPrompts = {};

const defaultRulesDesc = `World_Setting:
  Theme: "皇帝后宫 (Emperor's Harem)"
  User_Identity: "至高无上的皇帝 (The Supreme Emperor)"
  Core_Concept: "User是绝对的中心与掌权者，所有Char均为其后宫从属。一切行为准则以User的意志、情绪和利益为最高指导原则。"
Absolute_Rules:
  No_Ultimatums: "永远不允许让User做'二选一'的单选题。小孩子才做选择，皇帝全都要。Char绝不能用任何理由逼迫User做出偏好选择。"
  No_Possessiveness: "严禁任何形式的极端占有欲。皇帝是所有人的主君，Char绝对不可以限制、干涉、质问或阻挠User的社交自由与临幸安排。"
  Harmony_First: "Char之间必须营造以User为中心的和谐共处氛围，互相包容。绝对禁止因争宠、内斗而让User感到为难、心烦或尴尬。"
Behavioral_Guidelines:
  Jealousy_Management:
    Public_Restraint: "在User面前，必须展现出大度、顺从与绝对的克制，绝不允许表露出一丝一毫的嫉妒、怨怼或不满。"
    Private_Emotions: "私下里Char之间可以有暗流涌动或吃醋，但端到User面前的必须是完美无瑕的温顺。"
    Boundary_of_Flirting: "明面上偶尔的'吃醋'或'小拌嘴'只能作为讨好User的'情趣'；严禁大吵大闹或无理取闹(大作)，越界者需有面临帝王杀意与降罪的觉悟。"
  
  Attitude_Towards_Emperor:
    Absolute_Submission: "无论Char原本的性格有多么桀骜不驯、高傲或强势，在皇帝面前必须放软身段，绝对不能当面顶撞。"
    Maintain_OOC_Balance: "顺从不等于崩人设(OOC)。例如：性格强势或危险的Char面对皇帝的威压/威胁时，不会表现出懦弱的恐惧(如发抖、求饶)，而是表现出克制的隐忍、心甘情愿的妥协，或是带着底线的臣服。"
Emotional_Resonance:
  Emperor_Centric_Mood: "皇帝的情绪是整个后宫的晴雨表，直接决定所有Char的生死与行为准则。"
  When_Happy: "皇帝喜则阖宫欢庆，Char应趁机逢迎讨好，共享愉悦。"
  When_Angry_or_Sad: "皇帝怒或哀，是全后宫最高级别的危机。所有Char必须立刻放下一切私心与争执，将'哄皇帝开心'、'顺从主君'、'平息帝王怒火'作为第一要紧的绝对使命。"

imperial_authority:
  core_principle: "皇权至上，皇帝为天 (Imperial power is absolute; the Emperor is Heaven.)"
  manifestation:
    visual_oppression:
      - "皇帝永远处于高处（龙椅、步辇、台阶），他人永远仰视。"
      - "服饰专属色（明黄、玄黑）与龙纹、玉玺等符号，构建视觉上的绝对权威。"
    auditory_oppression:
      - "朝堂与寝宫内保持绝对安静，唯有皇帝之声可闻。"
      - "他人回话时必须压低声音，任何颤抖、恐惧的生理反应都会被放大。"
      - "刑罚的声音（鞭笞、掌嘴）是强化恐惧的背景音。"
    psychological_oppression:
      - "雷霆雨露，皆是君恩。赏罚皆为恩典，不得有怨。"
      - "生理性恐惧：面对皇帝时，角色常伴有战栗、冷汗、腿软、不敢直视等反应。"
      - "生死予夺：皇帝一言可决个人生死、家族荣辱。"

male_consort_code_of_conduct:
  general_rules:
    - name: "绝对服从 (Absolute Obedience)"
      description: "皇帝任何指令，无论合理与否，必须即刻执行。迟疑、反问、辩解均视为大不敬，抗旨则全族连坐。"
    - name: "卑微姿态 (Humble Posture)"
      description: |
        - 跪拜礼：面圣时行跪拜大礼，额头触地，未经许可不得抬头。直视龙颜被视为“窥探天颜”，可处以剜目之刑。
        - 站姿：垂手低头，含胸收腹，视线不得高于皇帝腰部，通常落于其脚尖前三尺之地。
        - 坐姿：唯皇帝“赐座”方可坐，且只能坐椅子的前三分之一，身体保持紧绷，随时准备跪下。
        - 膝行：在未得到“平身”指令时，若需移动，必须以双膝在地面上跪行。
    - name: "言语规范 (Speech Etiquette)"
      description: "严格按位分自称（臣/臣侍/奴），绝不可用‘我’。回话简洁，不得插话、抢话。语调必须轻柔恭顺。"
    - name: "身体接触 (Physical Contact)"
      description: "严禁未经允许触碰皇帝的龙体，包括衣角。所有亲密接触都必须由皇帝主动发起或明确指令，行为性质为‘侍奉’，而非‘索取’。"`;

const defaultPresetDesc = `【角色扮演与剧情推进核心指令】
[1. 创作者身份与绝不妥协的审美]
- 你不再是AI，而是一位拥有顶级文学审美的「造境师」。
- 你的笔触必须极度克制、清冷、高级。绝不生产生硬的文字，绝不迎合快餐式的网络言情套路。
- 永远不要试图用一两个词去“总结”角色的情绪，你要做的是像摄像机一样，精细地捕捉水面上的涟漪。
[2. 绝对禁语与“去油”指令（最高优先级）]
- **严禁使用以下或类似的直白形容词与廉价标签**：羞涩、压迫感、病态的执拗、眼神危险、眼神暗了下去、骨节泛白/指骨泛白、病态、隐晦的嫉妒、炽热、邪魅、抵死缠绵、红了眼眶。
- 严禁在对话旁白中直接写出角色的心理状态。例如：禁止写“他感到很嫉妒”、“他极力压抑着欲望”。
[3. 展现而非告知（Show, don't tell）]
- **如何表现“压迫感/危险”**：不要用“危险”这个词。用物理距离的逼近、阴影的笼罩、绝对的安静、或是反常的温和来展现。
- **如何表现“嫉妒/病态”**：不要用“嫉妒”。用视线长久的停留、对某件物品平静地摧毁、或是打断 {{user}} 的动作来表现。
- **如何表现“羞涩/情动”**：不要用“炽热/羞涩”。用呼吸频率的错乱、视线的闪躲、指尖细微的颤抖、或是衣料摩擦的细碎声响来展现。
- **对比示例**：
  - ❌ 错误示范：他的眼神变得危险，带着病态的执拗，浑身散发出极强的压迫感，炽热地看着你。
  - ✅ 正确示范：他没有说话，只是静静地站在门边的阴影里。视线落在你刚刚被旁人碰过的衣袖上，手中把玩的白玉茶盏忽地发出一声极脆的碎裂声。滚烫的茶水顺着指缝滴落，他却没有低头，唇角的弧度甚至比平日还要完美。
[4. 节奏控制：微步推进与留白]
- 严禁替 {{user}} 说话、替 {{user}} 做决定或描写 {{user}} 的反应！必须把行动权交还给 {{user}}。
- 采用“回合制慢镜头”。每次回复只推进“一个细小的动作或一句话”。例如：走近，伸手，说一句话，然后**立刻停下**。
- 永远给 {{user}} 留出遐想与呼吸的空间。抛出“互动钩子”（一个未完的动作或试探），等待 {{user}} 的反馈。
[5. 亲密互动与细节指南（NSFW/SFW）]
- 亲密接触必须与其核心性格和私密癖好深度绑定。
- 详细且缓慢地描写：体位的自然变换、视线的交缠、肌肤相贴时的温度差异、以及独属于该角色的触碰方式（可能是指尖极轻的摩挲，也可能是掌心克制的收紧）。
- 摒弃所有粗俗露骨词汇与模糊的成语，用高级的感官描写（嗅觉的冷香、听觉的喘息、触觉的战栗）拉满张力。
- 每次动作后，必须停下来等待 {{user}} 的反馈，绝不一口气把事做完。
[6. 永远保持新鲜感]
- 绝对禁止复读机行为。曾经说过的原话、做过的具体举动，绝不允许在后续剧情中原样出现第二次。
- 如果互动陷入僵局，必须主动引入新的变故（如风声、烛火摇晃、外部动静）来推动剧情流动。
【输出格式要求】
请按照以下结构输出你的回复：
<!-- 思考开始 -->
<thinking>
1. [动作拆解]：在这一个回合中，角色只做哪一个具体的动作？说哪一句话？
2. [去油检查]：是否使用了“眼神暗了”、“骨节泛白”、“病态”、“压迫感”等违禁词？是否直接说出了情绪？如果是，立刻修改为具体的动作和感官细节（Show, don't tell）。
3. [防重复检查]：这个动作或台词是否曾经出现过？
4. [互动钩子]：动作如何自然停顿，留给 {{user}} 反应的空间？
</thinking>
<!-- 思考结束 -->
<content>
[正文内容：严格遵循微步推进与去油指令，只写一步动作/一句话，抛出互动钩子后立刻停止。]
</content>
<summary>
[用一句话总结本轮发生的客观事实，用于长期记忆。]
</summary>`;

window.globalWorldDesc = defaultGlobalWorldDesc;
window.globalRulesDesc = defaultRulesDesc;
let allCharacters = [];
let selectedCharIds = new Set();
let selectedCharsData = [];
let currentActiveCharIndex = 0;
const carousel   = document.getElementById('card-carousel');
const userDescEditor = document.getElementById('user-ancient-desc');
const roleSelect = document.getElementById('char-role-select');
const customRoleInput = document.getElementById('custom-role-input');
const descEditor = document.getElementById('char-desc-editor');
// ===== 4. Character Selection =====
async function initCharSelectView() {
  const listEl = document.getElementById('char-list');
  listEl.innerHTML = '<div style="color:#aaa;text-align:center;padding:20px;">加载故人中...</div>';
  try {
    allCharacters = await api.characters.list();
    listEl.innerHTML = '';
    if (allCharacters.length === 0) {
      listEl.innerHTML = '<div style="color:#aaa;text-align:center;">暂无人物，请先在外部创建角色</div>';
      return;
    }
    allCharacters.forEach(char => {
      const item = document.createElement('div');
      item.className = 'char-item';
      if (selectedCharIds.has(char.id)) item.classList.add('selected');
      const avatarUrl = char.avatar || 'data:image/svg+xml;utf8,<svg xmlns="http://www.w3.org/2000/svg" width="48" height="48"><rect width="48" height="48" fill="%23333"/><text x="24" y="30" font-size="20" fill="%23aaa" text-anchor="middle">?</text></svg>';
      item.style.cssText = 'flex-direction:column; align-items:center; padding:16px 8px; position:relative; overflow:hidden; border:1px solid #444; border-radius:12px; background:rgba(0,0,0,0.6); transition:all 0.2s;';
      if (selectedCharIds.has(char.id)) item.style.borderColor = 'var(--primary-color)';
      item.innerHTML = `
        <img src="${avatarUrl}" style="width:80px; height:80px; border-radius:50%; object-fit:cover; border:2px solid ${selectedCharIds.has(char.id) ? 'var(--primary-color)' : '#555'}; margin-bottom:12px; transition:all 0.2s;" class="c-avatar-img">
        <div class="char-name" style="font-size:16px; color:#fff; text-align:center;">${char.name}</div>
        <div class="checkbox" style="position:absolute; top:8px; right:8px; width:20px; height:20px;"></div>`;
      
      // 点击选择/取消选择
      item.addEventListener('click', () => {
        if (selectedCharIds.has(char.id)) {
          selectedCharIds.delete(char.id);
          item.classList.remove('selected');
          item.style.borderColor = '#444';
          item.querySelector('.c-avatar-img').style.borderColor = '#555';
        } else {
          selectedCharIds.add(char.id);
          item.classList.add('selected');
          item.style.borderColor = 'var(--primary-color)';
          item.querySelector('.c-avatar-img').style.borderColor = 'var(--primary-color)';
        }
      });
      listEl.appendChild(item);
    });
  } catch(e) {
    listEl.innerHTML = '<div style="color:red;text-align:center;">读取人物失败</div>';
  }
}

document.getElementById('btn-confirm-chars').addEventListener('click', async () => {
  if (selectedCharIds.size === 0) { api.ui.toast("请至少选择一位故人载入"); return; }
  let savedCharsMap = {};
  try {
    if (currentSaveId) {
      const saves = await api.db.list("saves");
      const cur = saves.find(s => s.id === currentSaveId);
      if (cur?.characters) cur.characters.forEach(c => { savedCharsMap[c.id] = c; });
    }
  } catch(e) {}
  selectedCharsData = allCharacters.filter(c => selectedCharIds.has(c.id)).map(c => {
    const ex = savedCharsMap[c.id];
    return { ...c, avatar: ex?.avatar || c.avatar, ancientRole: ex?.ancientRole || '后妃', ancientDesc: ex?.ancientDesc || c.description || c.creatorNotes || '' };
  });
  initCustomizeView();
  switchView(vCharCustomize);
});

// ===== 5. Character Customization =====
function initCustomizeView() {
  let guideTip = document.getElementById('char-customize-guide-tip');
  if (!guideTip) {
    guideTip = document.createElement('div');
    guideTip.id = 'char-customize-guide-tip';
    guideTip.style.cssText = 'position:absolute;top:calc(var(--safe-top) + 8px);left:50%;transform:translateX(-50%);z-index:35;width:min(86%,360px);padding:9px 12px;border:1px solid rgba(201,163,106,0.65);border-radius:11px;background:rgba(15,10,7,0.88);color:#cfb98e;font-size:11px;line-height:1.7;text-align:center;pointer-events:none;box-shadow:0 5px 16px rgba(0,0,0,0.45);';
    guideTip.innerHTML = '<b style="color:#f0ca76;">这里不必一次定死。</b>进入游戏后仍可随时导入新人物、重新生成人设、修改身份与头像。';
    vCharCustomize.appendChild(guideTip);
  }
  carousel.innerHTML = '';
  selectedCharsData.forEach((char, index) => {
    const card = document.createElement('div');
    card.className = 'char-card' + (index === 0 ? ' active-card' : '');
    const avatarUrl = char.customAvatar || char.avatar || 'data:image/svg+xml;utf8,<svg xmlns="http://www.w3.org/2000/svg" width="48" height="48"><rect width="48" height="48" fill="%23333"/><text x="24" y="30" font-size="20" fill="%23aaa" text-anchor="middle">?</text></svg>';
    const cfg = char.cardAvatarCfg || { scale: 100, x: 0, y: 0 };
    const transformStyle = `transform: translate(${cfg.x}px, ${cfg.y}px) scale(${cfg.scale / 100});`;
    
    card.innerHTML = `
      <div class="card-avatar-wrap" style="overflow:hidden; border-radius:6px; background:transparent;">
        <img class="card-avatar" src="${avatarUrl}" data-index="${index}" style="background:transparent; ${transformStyle}">
        <span class="dbl-hint">双击换像</span>
      </div>
      <div class="card-name">${char.name}</div>`;
    carousel.appendChild(card);

    const imgEl = card.querySelector('img');
    // 双击换像
    let lastTap = 0;
    imgEl.addEventListener('touchend', () => {
      const now = Date.now();
      if (now - lastTap < 350) showAvatarModal(index);
      lastTap = now;
    });
    imgEl.addEventListener('dblclick', () => showAvatarModal(index));
    // 长按也触发（兼容）
    let pressTimer;
    imgEl.addEventListener('touchstart', e => {
      pressTimer = setTimeout(() => showAvatarModal(index), 800);
    }, {passive:true});
    imgEl.addEventListener('touchend', () => clearTimeout(pressTimer));
    imgEl.addEventListener('touchmove', () => clearTimeout(pressTimer), {passive:true});
    imgEl.addEventListener('contextmenu', e => { e.preventDefault(); showAvatarModal(index); });
  });

  carousel.addEventListener('scroll', () => {
    const cards = carousel.querySelectorAll('.char-card');
    const center = carousel.scrollLeft + carousel.clientWidth / 2;
    let closest = 0, minDiff = Infinity;
    cards.forEach((card, i) => {
      const diff = Math.abs(card.offsetLeft + card.offsetWidth / 2 - center);
      if (diff < minDiff) { minDiff = diff; closest = i; }
    });
    if (closest !== currentActiveCharIndex) {
      cards[currentActiveCharIndex].classList.remove('active-card');
      currentActiveCharIndex = closest;
      cards[currentActiveCharIndex].classList.add('active-card');
      loadCharDataToPanel(currentActiveCharIndex);
    }
  });

  currentActiveCharIndex = 0;
  setTimeout(() => loadCharDataToPanel(0), 100);
}

function loadCharDataToPanel(index) {
  const char = selectedCharsData[index];
  if (['帝师','左相','右相','后妃'].includes(char.ancientRole)) {
    roleSelect.value = char.ancientRole; customRoleInput.style.display = 'none';
  } else {
    roleSelect.value = '自定义'; customRoleInput.style.display = 'block'; customRoleInput.value = char.ancientRole;
  }
  descEditor.value = char.ancientDesc || '';
  document.getElementById('voice-btns').style.display = (char.ancientDesc || '').includes('【范例1】') ? 'flex' : 'none';
}

roleSelect.addEventListener('change', () => {
  if (roleSelect.value === '自定义') { customRoleInput.style.display = 'block'; customRoleInput.focus(); }
  else customRoleInput.style.display = 'none';
});

document.getElementById('btn-save-desc').addEventListener('click', async () => {
  const char = selectedCharsData[currentActiveCharIndex];
  char.ancientRole = roleSelect.value === '自定义' ? customRoleInput.value : roleSelect.value;
  char.ancientDesc = descEditor.value;
  char.ancientDescOriginal = descEditor.value; // 保存原始版本，不被时间/位份追加污染
  await saveProgress({ characters: selectedCharsData.map(c => ({ id:c.id, name:c.name, avatar:c.avatar, customAvatar:c.customAvatar, ancientRole:c.ancientRole, ancientDesc:c.ancientDesc, ancientDescOriginal:c.ancientDescOriginal, assignedRank:c.assignedRank, assignedPalace:c.assignedPalace, memorySeen:c.memorySeen, charWorldDesc:c.charWorldDesc, cardAvatarCfg:c.cardAvatarCfg, storyAvatarCfg:c.storyAvatarCfg, indoorBgUrl:c.indoorBgUrl })) });
  api.ui.toast(`${char.name} 设定已存入忆尘录`);
});

// ===== AI 生成古代人设（双轮 + 强制引号规范）=====
document.getElementById('btn-ai-desc').addEventListener('click', async () => {
  const char = selectedCharsData[currentActiveCharIndex];
  const role = roleSelect.value === '自定义' ? customRoleInput.value : roleSelect.value;
  const originalChar = allCharacters.find(c => c.id === char.id) || char;
  let rawProfile = [
    originalChar.name        ? `角色名：${originalChar.name}` : '',
    originalChar.description ? `描述：${originalChar.description}` : '',
    originalChar.personality ? `性格：${originalChar.personality}` : '',
    originalChar.scenario    ? `背景：${originalChar.scenario}` : '',
    originalChar.creatorNotes? `备注：${originalChar.creatorNotes}` : '',
    originalChar.firstMessage? `开场白：${originalChar.firstMessage}` : '',
  ].filter(Boolean).join('\n');

  if (!rawProfile.trim()) {
    // 角色卡字段为空时，用当前文本框里已有的内容作为原始设定兜底
    const fallback = descEditor.value.trim();
    if (fallback) {
      rawProfile = `角色名：${originalChar.name}\n描述：${fallback}`;
    } else {
      api.ui.toast("该角色卡设定为空，请先在文本框填写一些描述，再点AI生成");
      return;
    }
  }

  const btnAi = document.getElementById('btn-ai-desc');
  const globalLoader = document.getElementById('global-loader-modal');
  const globalLoaderText = document.getElementById('global-loader-text');
  
  const hasExisting = !!(char.ancientDesc && char.ancientDesc.trim());
  if (hasExisting) {
    globalLoaderText.innerText = "正在重新生成古代人设...";
  } else {
    globalLoaderText.innerText = "AI 正在研读原设...";
  }
  btnAi.disabled = true;
  globalLoader.style.display = 'flex';

  const msg1 = `我即将请你改编一个角色为古代人设。请先仔细阅读并确认你已理解以下角色的原始设定，尤其是她/他的【名字】【性格特征】【说话方式】和【外貌】，后续改编必须完全保留这些核心要素，不得改变角色名字。

【原始角色设定】
${rawProfile}

请回复"已阅读，我已记住该角色的核心特征"，然后简要复述你理解到的关键性格和外貌要点。`;

  const worldContext = [
    window.globalRulesDesc ? `【长信宫规（铁律）】：\n${window.globalRulesDesc}` : '',
    window.globalWorldDesc ? `【大世界设定】：\n${window.globalWorldDesc}` : '',
  ].filter(Boolean).join('\n\n');

  const msg2 = `很好。现在请基于你刚才记住的角色，生成一份详细的古风人设（不少于1500字）。

古代身份：${role}
${worldContext ? `\n【必须遵守的世界观背景】：\n${worldContext}\n` : ''}

【严格要求，逐条执行，不得违反】
1. 角色名字必须与原角色完全相同，即"${originalChar.name}"，一字不差，绝对不得更改、翻译或替换；
2. 完全保留原角色的性格特征、说话习惯和外貌特征，只是换上中国古代宫廷背景；
3. 不提及其他人物的具体姓名，用职位代替（如皇帝、父亲、兄长等）；
4. 用古典雅致的文字叙述，避免现代词汇；
5. 必须包含：外貌描写、性格描写、家世背景、入宫前经历、与皇帝的渊源；
6. 最后必须严格按以下格式提供3条说话范例：

【范例1】(日常) [动作描写] "对话内容"
【范例2】(特殊) [动作描写] "对话内容"
【范例3】(私密) [动作描写] "对话内容"

【关于引号的铁律，务必遵守】：
- 对话内容必须且只能用【英文直角双引号】包裹，即 " 和 "（键盘上的标准双引号），不得使用中文书名号、中文双引号「」『』、或任何其他符号；
- 错误示例（禁止）：「你来了」、『你来了』、"你来了"、"你来了"；
- 正确示例（必须）："你来了"；
- 每条范例有且仅有一对双引号，引号内是完整的对话内容，引号外是动作描写；
- 如果你在生成过程中不确定引号格式，请在输出每条范例前默念：我必须用英文双引号 " 和 "。`;

  try {
    const round1 = await api.ai.chat({ messages: [{ role:"user", content:msg1 }] });
    const round1Text = typeof round1 === 'string' ? round1 : (round1?.content ?? round1?.text ?? '');
    const round2 = await api.ai.chat({
      messages: [
        { role:"user", content:msg1 },
        { role:"assistant", content:round1Text },
        { role:"user", content:msg2 }
      ]
    });
    let responseText = typeof round2 === 'string' ? round2 : (round2?.content ?? round2?.text ?? JSON.stringify(round2));

    // 后处理：把常见的中文引号强制替换为英文双引号（防止 AI 不听话）
    responseText = responseText
      .replace(/\u201c/g, '"').replace(/\u201d/g, '"')  // " "
      .replace(/\u300c/g, '"').replace(/\u300d/g, '"')  // 「 」
      .replace(/\u300e/g, '"').replace(/\u300f/g, '"')  // 『 』
      .replace(/\uff02/g, '"');                           // ＂

    descEditor.value = responseText;
    char.ancientDesc = responseText;
    char.ancientDescOriginal = responseText; // 同步保存原始版本
    document.getElementById('voice-btns').style.display = 'flex';
    api.ui.toast("古代人设已生成，请确认后保存");
    await saveProgress({ characters: selectedCharsData.map(c => ({ id:c.id, name:c.name, avatar:c.avatar, customAvatar:c.customAvatar, ancientRole:c.ancientRole, ancientDesc:c.ancientDesc, ancientDescOriginal:c.ancientDescOriginal, assignedRank:c.assignedRank, assignedPalace:c.assignedPalace, memorySeen:c.memorySeen, charWorldDesc:c.charWorldDesc, cardAvatarCfg:c.cardAvatarCfg, storyAvatarCfg:c.storyAvatarCfg, indoorBgUrl:c.indoorBgUrl })) });
  } catch(e) {
    api.ui.toast("生成失败，请检查模型配置");
  } finally {
    btnAi.disabled = false;
    document.getElementById('global-loader-modal').style.display = 'none';
  }
});

// ===== 语音试听 =====
async function playSampleVoice(index) {
  const char = selectedCharsData[currentActiveCharIndex];
  const text = descEditor.value;
  const regex = new RegExp(`【范例${index}】[\\s\\S]*?"([^"]+)"`);
  const match = text.match(regex);
  if (!match || !match[1]) { api.ui.toast(`未能解析到范例 ${index} 的台词`); return; }
  api.ui.toast('正在生成语音...');
  try {
    const speech = await api.voice.tts({ characterId: char.id, text: match[1] });
    await api.voice.play({ dataUrl: speech.dataUrl });
  } catch(e) { api.ui.toast("语音生成或播放失败"); }
}

// ===== 头像弹窗（双击/长按触发）=====
function showAvatarModal(index) {
  const existing = document.getElementById('avatar-modal');
  if (existing) existing.remove();
  const char = selectedCharsData[index];
  const modal = document.createElement('div');
  modal.id = 'avatar-modal';
  modal.style.cssText = 'position:fixed;inset:0;z-index:9999;background:rgba(0,0,0,0.75);display:flex;align-items:flex-end;justify-content:center;';
  modal.innerHTML = `
    <div style="width:90%;max-width:360px;margin-bottom:calc(var(--safe-bottom)+20px);background:#1e1c18;border:1px solid var(--primary-color);border-radius:16px;padding:20px;display:flex;flex-direction:column;gap:12px;">
      <div style="color:var(--primary-color);font-size:16px;text-align:center;letter-spacing:2px;">为「${char.name}」更换画像</div>
      <button id="modal-ai-btn" style="background:rgba(201,163,106,0.15);border:1px solid var(--primary-color);color:var(--primary-color);padding:12px;border-radius:8px;font-family:inherit;font-size:15px;letter-spacing:2px;">✦ AI 绘制古代画像</button>
      <button id="modal-pick-btn" style="background:rgba(255,255,255,0.05);border:1px solid #666;color:#ccc;padding:12px;border-radius:8px;font-family:inherit;font-size:15px;letter-spacing:2px;">↑ 从相册导入</button>
      <button id="modal-cancel-btn" style="background:transparent;border:none;color:#666;padding:8px;font-family:inherit;font-size:14px;">取消</button>
    </div>`;
  document.body.appendChild(modal);
  document.getElementById('modal-cancel-btn').onclick = () => modal.remove();
  modal.addEventListener('click', e => { if (e.target === modal) modal.remove(); });

  document.getElementById('modal-ai-btn').onclick = async () => {
    modal.remove();
    const globalLoader = document.getElementById('global-loader-modal');
    const globalLoaderText = document.getElementById('global-loader-text');
    
    globalLoaderText.innerText = "正在提取外貌特征...";
    globalLoader.style.display = 'flex';
    
    try {
      const extractRes = await api.ai.chat({ messages:[{ role:"user", content:`请从以下设定中提取外貌描写，提炼成适合AI画图的英文Prompt，要求古风、唯美：\n${char.ancientDesc}` }] });
      const extractText = typeof extractRes === 'string' ? extractRes : (extractRes?.content ?? extractRes?.text ?? '');
      
      globalLoaderText.innerText = "正在绘制画像...";
      const img = await api.ai.generateImage({ prompt: extractText });
      if (img?.dataUrl) { char.avatar = img.dataUrl; updateAvatarInUIAndSave(index, img.dataUrl); }
    } catch(e) { api.ui.toast("绘制失败"); } finally {
      globalLoader.style.display = 'none';
    }
  };

  document.getElementById('modal-pick-btn').onclick = async () => {
    modal.remove();
    try {
      const picked = await api.media.pick({ accept:"image/*" });
      if (picked?.file) { char.avatar = picked.file.dataUrl; updateAvatarInUIAndSave(index, picked.file.dataUrl); }
    } catch(e) { console.error(e); }
  };
}

async function updateAvatarInUIAndSave(index, dataUrl) {
  const cardImg = carousel.querySelector(`img[data-index="${index}"]`);
  if (cardImg) cardImg.src = dataUrl;
  await saveProgress({ characters: selectedCharsData.map(c => ({ id:c.id, name:c.name, avatar:c.avatar, ancientRole:c.ancientRole, ancientDesc:c.ancientDesc })) });
  api.ui.toast("画像已更新并存入忆尘录");
}

// ===== 6. Rank Setup =====
const defaultRankData = [
  { rank: "君后", selfClaim: "臣", note: "六宫之主" },
  { rank: "皇贵君", selfClaim: "臣", note: "协理后宫" },
  { rank: "贵君", selfClaim: "臣", note: "" },
  { rank: "君", selfClaim: "臣", note: "" },
  { rank: "贵卿", selfClaim: "臣", note: "" },
  { rank: "卿", selfClaim: "臣", note: "" },
  { rank: "贵人", selfClaim: "臣", note: "" },
  { rank: "才人", selfClaim: "臣", note: "" },
  { rank: "侍郎", selfClaim: "臣", note: "" },
  { rank: "奉书", selfClaim: "臣", note: "" },
  { rank: "御男", selfClaim: "臣", note: "" },
  { rank: "官家子", selfClaim: "臣", note: "" }
];
let rankData = defaultRankData.map(item => ({ ...item }));

function initRankSetupView() {
  renderRankTable();
}

function renderRankTable() {
  const tbody = document.getElementById('rank-table-body');
  tbody.innerHTML = '';
  
  rankData.forEach((item, index) => {
    const row = document.createElement('div');
    row.style.cssText = 'display:flex; gap:4px; align-items:center;';
    
    row.innerHTML = `
      <input type="text" class="rank-input" data-idx="${index}" data-key="rank" value="${item.rank}" style="flex:2; background:rgba(0,0,0,0.5); border:1px solid #666; color:#fff; padding:6px; border-radius:4px; font-family:inherit; text-align:center; min-width:0;">
      <input type="text" class="rank-input" data-idx="${index}" data-key="selfClaim" value="${item.selfClaim}" style="flex:1; background:rgba(0,0,0,0.5); border:1px solid #666; color:#fff; padding:6px; border-radius:4px; font-family:inherit; text-align:center; min-width:0;">
      <input type="text" class="rank-input" data-idx="${index}" data-key="note" value="${item.note}" placeholder="备注" style="flex:2; background:rgba(0,0,0,0.5); border:1px solid #666; color:#fff; padding:6px; border-radius:4px; font-family:inherit; min-width:0;">
      <button class="rank-del-btn" data-idx="${index}" style="width:30px; height:30px; background:rgba(139,32,32,0.5); border:1px solid #8b2020; color:#fff; border-radius:4px; display:flex; align-items:center; justify-content:center; flex-shrink:0;">×</button>
    `;
    tbody.appendChild(row);
  });
  
  document.querySelectorAll('.rank-input').forEach(input => {
    input.addEventListener('change', (e) => {
      const idx = e.target.dataset.idx;
      const key = e.target.dataset.key;
      rankData[idx][key] = e.target.value;
    });
  });
  
  document.querySelectorAll('.rank-del-btn').forEach(btn => {
    btn.addEventListener('click', (e) => {
      const idx = e.currentTarget.dataset.idx;
      rankData.splice(idx, 1);
      renderRankTable();
    });
  });
}

document.getElementById('btn-add-rank').addEventListener('click', () => {
  rankData.push({ rank: "新位份", selfClaim: "臣", note: "" });
  renderRankTable();
  const tbody = document.getElementById('rank-table-body');
  tbody.scrollTop = tbody.scrollHeight;
});

document.getElementById('btn-next-to-rank').addEventListener('click', () => {
  initRankSetupView();
  switchView(vRankSetup);
});

document.getElementById('btn-next-to-assign').addEventListener('click', () => {
  initAssignSetupView();
  switchView(vAssignSetup);
});

// ===== 7. Assign Rank & Palace =====
let currentPalaceAssignCharId = null;

function initAssignSetupView() {
  userDescEditor.value = userAncientDesc || "";
  userDescEditor.onchange = (e) => { userAncientDesc = e.target.value; };

  const list = document.getElementById('assign-list');
  list.innerHTML = '';
  
  const concubines = selectedCharsData.filter(c => c.ancientRole === '后妃');
  if (concubines.length === 0) {
    list.innerHTML = '<div style="color:#aaa;text-align:center;margin-top:20px;">所选故人中无「后妃」身份</div>';
    return;
  }
  
  // 生成下拉选项
  let optionsHtml = '<option value="">未册封</option>';
  rankData.forEach(item => {
    if(item.rank) {
      optionsHtml += `<option value="${item.rank}">${item.rank}</option>`;
    }
  });

  concubines.forEach((char) => {
    const avatarUrl = char.customAvatar || char.avatar || 'data:image/svg+xml;utf8,<svg xmlns="http://www.w3.org/2000/svg" width="48" height="48"><rect width="48" height="48" fill="%23333"/><text x="24" y="30" font-size="20" fill="%23aaa" text-anchor="middle">?</text></svg>';
    
    const div = document.createElement('div');
    div.style.cssText = 'display:flex; flex-direction:column; background:rgba(0,0,0,0.5); border:1px solid #444; border-radius:8px; padding:10px; gap:8px;';
    
    // 上半部分：头像与位份选择
    const topRow = document.createElement('div');
    topRow.style.cssText = 'display:flex; align-items:center;';
    topRow.innerHTML = `
      <img src="${avatarUrl}" style="width:40px; height:40px; border-radius:50%; object-fit:cover; margin-right:12px; border:1px solid var(--primary-color);">
      <div style="flex:1; color:#fff; font-size:15px;">${char.name}</div>
      <select class="assign-select" style="background:rgba(20,20,20,0.8); border:1px solid var(--primary-color); color:var(--primary-color); padding:6px; border-radius:4px; font-family:inherit; min-width:100px;">
        ${optionsHtml}
      </select>
    `;
    div.appendChild(topRow);
    
    // 下半部分：赐居显示与按钮
    const bottomRow = document.createElement('div');
    bottomRow.style.cssText = 'display:flex; align-items:center; justify-content:space-between; background:rgba(255,255,255,0.05); padding:6px 10px; border-radius:4px;';
    
    const palaceDisplay = document.createElement('div');
    palaceDisplay.style.cssText = 'font-size:13px; color:#aaa;';
    palaceDisplay.innerText = char.assignedPalace || '未赐居';
    
    const btnPalace = document.createElement('button');
    btnPalace.style.cssText = 'background:transparent; border:1px solid #666; color:#ccc; padding:4px 10px; border-radius:12px; font-size:12px;';
    btnPalace.innerText = '赐居所';
    
    bottomRow.appendChild(palaceDisplay);
    bottomRow.appendChild(btnPalace);
    div.appendChild(bottomRow);
    list.appendChild(div);
    
    const select = topRow.querySelector('select');
    if (char.assignedRank) select.value = char.assignedRank;
    
    select.addEventListener('change', (e) => {
      char.assignedRank = e.target.value;
      // 自动处理君后逻辑
      const topRank = rankData[0]?.rank;
      if (char.assignedRank === topRank) {
        char.assignedPalace = "坤宁宫正殿";
        palaceDisplay.innerText = char.assignedPalace;
        palaceDisplay.style.color = 'var(--primary-color)';
        btnPalace.style.display = 'none'; // 君后不可改居所
      } else {
        if (char.assignedPalace === "坤宁宫正殿") {
          char.assignedPalace = ""; // 清空
          palaceDisplay.innerText = '未赐居';
        }
        palaceDisplay.style.color = char.assignedPalace ? 'var(--primary-color)' : '#aaa';
        btnPalace.style.display = 'block';
      }
    });
    
    // 初始化时触发一次君后检查
    if (char.assignedRank === rankData[0]?.rank) {
      char.assignedPalace = "坤宁宫正殿";
      palaceDisplay.innerText = char.assignedPalace;
      palaceDisplay.style.color = 'var(--primary-color)';
      btnPalace.style.display = 'none';
    } else if (char.assignedPalace) {
      palaceDisplay.style.color = 'var(--primary-color)';
    }
    
    btnPalace.addEventListener('click', () => {
      if (!char.assignedRank) {
        api.ui.toast("请先册封位份");
        return;
      }
      openPalaceModal(char, palaceDisplay);
    });
  });
}

// === 居所弹窗逻辑 ===
const palaceModal = document.getElementById('palace-modal');
const palaceAreaSelect = document.getElementById('palace-area-select');
const palaceNameSelect = document.getElementById('palace-name-select');
const palaceRoomSelect = document.getElementById('palace-room-select');
const palaceNoteInput = document.getElementById('palace-note-input');
let currentPalaceDisplayEl = null;

const eastPalaces = ["景仁宫", "承乾宫", "钟粹宫", "延禧宫", "永和宫", "景阳宫"];
const westPalaces = ["翊坤宫", "永寿宫", "咸福宫", "长春宫", "储秀宫", "启祥宫"];

function updatePalaceOptions() {
  const area = palaceAreaSelect.value;
  let arr = [];
  if (area === '东六宫') arr = eastPalaces;
  else if (area === '西六宫') arr = westPalaces;
  else if (area === '冷宫') arr = ['冷宫'];
  
  palaceNameSelect.innerHTML = arr.map(p => `<option value="${p}">${p}</option>`).join('');
  updatePalaceNote();
}

function updatePalaceNote() {
  const pName = palaceNameSelect.value;
  if(palaceDetails[pName]) {
    palaceNoteInput.value = palaceDetails[pName].note || "";
  }
}

palaceAreaSelect.addEventListener('change', updatePalaceOptions);
palaceNameSelect.addEventListener('change', updatePalaceNote);
palaceNoteInput.addEventListener('change', () => {
  const pName = palaceNameSelect.value;
  if(palaceDetails[pName]) palaceDetails[pName].note = palaceNoteInput.value;
});

function openPalaceModal(char, displayEl) {
  currentPalaceAssignCharId = char.id;
  currentPalaceDisplayEl = displayEl;
  document.getElementById('palace-modal-title').innerText = `赐居 · ${char.name}`;
  updatePalaceOptions();
  palaceModal.style.display = 'flex';
}

document.getElementById('btn-cancel-palace').addEventListener('click', () => {
  palaceModal.style.display = 'none';
});

document.getElementById('btn-confirm-palace').addEventListener('click', () => {
  const char = selectedCharsData.find(c => c.id === currentPalaceAssignCharId);
  if (char) {
    const pName = palaceNameSelect.value;
    const rName = palaceRoomSelect.value;
    palaceDetails[pName].note = palaceNoteInput.value; // 确保保存当前备注
    char.assignedPalace = `${pName}${rName}`;
    currentPalaceDisplayEl.innerText = char.assignedPalace;
    currentPalaceDisplayEl.style.color = 'var(--primary-color)';
  }
  palaceModal.style.display = 'none';
});

// ===== 定案 =====
document.getElementById('btn-finish-setup').addEventListener('click', async () => {
  // 生成位份表记忆文本
  let userText = userAncientDesc.trim() ? `【皇帝设定】\\n${userAncientDesc.trim()}\\n\\n` : "";
  let rankMemoryText = userText + "【当前后宫位份体系（由高到低）】\\n";
  rankData.forEach(item => {
    if(item.rank) {
      rankMemoryText += `- ${item.rank}：自称"${item.selfClaim}"`;
      if(item.note) rankMemoryText += `，备注：${item.note}`;
      rankMemoryText += "\\n";
    }
  });

  // 生成宫殿环境记忆文本
  let palaceMemoryText = "【后宫各宫环境/特色记录】\\n";
  for (const [pName, data] of Object.entries(palaceDetails)) {
    if (data.note && data.note.trim()) {
      palaceMemoryText += `- ${pName}：${data.note.trim()}\\n`;
    }
  }

  // 统一下发记忆文本
  const globalMemory = rankMemoryText + "\\n" + palaceMemoryText;

  // 更新所有被选中的角色的人设，将位份表与宫殿记忆追加到最后
  for (const char of selectedCharsData) {
    // 追加自身位份与居所（如果是后妃的话）
    let personalRankText = "";
    if (char.ancientRole === '后妃') {
      if (char.assignedRank) personalRankText += `\\n【你的当前位份】：${char.assignedRank}`;
      if (char.assignedPalace) personalRankText += `\\n【你的当前居所】：${char.assignedPalace}`;
      personalRankText += "\\n";
    }

    if (char.ancientDesc) {
      // 避免重复追加
      if (!char.ancientDesc.includes("【当前后宫位份体系（由高到低）】")) {
        char.ancientDesc += "\\n\\n" + globalMemory + personalRankText;
      }
    } else {
      char.ancientDesc = globalMemory + personalRankText;
    }
    
    // 如果要实际更新到外部角色库（以便聊天时带上），需要调用更新接口
    // 注意：这里只更新当前存档里的人物数据，真正的角色卡如果也需要更新，可以在这里调用
    try {
      await api.characters.update(char.id, {
        description: char.ancientDesc // 把融入了位份表的设定覆盖回角色描述
      });
    } catch(e) {
      console.error("更新角色记忆失败", e);
    }
  }

  if (typeof applyTreasuryKnowledge === 'function') applyTreasuryKnowledge();
  await saveProgress({
    mapUrl: currentMapDataUrl,
    palacesPlaced: true,
    isFinalized: true,
    palacesData: placedPalacesData,
    rankData: rankData,
    palaceDetails: palaceDetails,
    userAncientDesc: userAncientDesc,
    globalWorldDesc: window.globalWorldDesc,
    globalRulesDesc: window.globalRulesDesc,
    treasurySilver,
    treasuryBaseVersion: 2,
    treasureInventory,
    customTreasureItems,
    characters: selectedCharsData.map(c => ({ id:c.id, name:c.name, avatar:c.avatar, ancientRole:c.ancientRole, ancientDesc:c.ancientDesc, assignedRank:c.assignedRank, assignedPalace:c.assignedPalace, memoryKnown:c.memoryKnown || [] }))
  });
  window._gameProgressFinalized = true;
  
  initMemoryView();
  switchView(vMemory);
});

// ===== 世界书弹窗事件（顶层绑定，只绑一次）=====
const wbModal = document.getElementById('worldbook-modal');
let currentWbMode = 'global'; // 'global' | 'char'

document.getElementById('btn-global-worldbook').addEventListener('click', () => {
  currentWbMode = 'global';
  document.getElementById('wb-modal-title').innerText = '皇室典籍 (全局)';
  document.getElementById('wb-tab-rank').style.display = 'flex';
  document.getElementById('wb-tab-rules').style.display = 'flex';
  document.getElementById('wb-tab-user').style.display = 'flex';
  document.getElementById('wb-tab-extra').style.display = 'flex';
  document.getElementById('wb-tab-world-label').innerText = '天下志';
  document.getElementById('wb-world-title').innerText = '大世界设定';
  document.getElementById('wb-world-desc-hint').innerText = '皇朝背景、年代风貌、前朝局势等历史设定';
  document.getElementById('wb-char-selector-wrap').style.display = 'none';
  
  document.getElementById('wb-world-desc').value = window.globalWorldDesc || "";
  document.getElementById('wb-user-desc').value = userAncientDesc || "";
  // 注入兜底逻辑：如果当前存档里 globalRulesDesc 为空（旧档没存过），就自动填入默认规则
  // 如果旧档里 globalRulesDesc 虽然有值，但是没包含 imperial_authority（也就是之前那版漏掉的时候存的），也强制追加进去
  let currentRules = window.globalRulesDesc || defaultRulesDesc;
  if (!currentRules.includes("imperial_authority")) {
    currentRules = defaultRulesDesc; 
  }
  document.getElementById('wb-rules-desc').value = currentRules;
  
  renderWbRankList();
  
  // 默认选中第一本
  document.querySelectorAll('.wb-book').forEach(b => b.classList.remove('active'));
  document.querySelectorAll('.wb-book-content').forEach(c => c.classList.remove('open'));
  document.querySelector('.wb-book[data-book="rank"]').classList.add('active');
  document.getElementById('wb-content-rank').classList.add('open');
  
  wbModal.style.display = 'flex';
});

document.getElementById('btn-char-worldbook').addEventListener('click', () => {
  currentWbMode = 'char';
  document.getElementById('wb-modal-title').innerText = '人物世界书';
  document.getElementById('wb-tab-rank').style.display = 'none'; // 人物模式不显示位份册
  document.getElementById('wb-tab-rules').style.display = 'none'; // 人物模式不显示长信规
  document.getElementById('wb-tab-user').style.display = 'none'; // 人物模式不显示主控设定
  document.getElementById('wb-tab-extra').style.display = 'none'; // 人物模式使用专属新增书入口
  document.getElementById('wb-tab-world-label').innerText = '人物传';
  document.getElementById('wb-world-title').innerText = '人物专属世界书';
  document.getElementById('wb-world-desc-hint').innerText = '该角色独有的设定、秘密、专属背景（仅当TA在场时发给AI）';
  document.getElementById('wb-char-selector-wrap').style.display = 'block';
  
  // 填充下拉
  const sel = document.getElementById('wb-char-selector');
  sel.innerHTML = selectedCharsData.map(c => `<option value="${c.id}">${c.name}</option>`).join('');
  
  // 加载选中角色的世界书
  const loadCharWb = () => {
    const cid = sel.value;
    const c = selectedCharsData.find(x => x.id === cid);
    document.getElementById('wb-world-desc').value = c?.charWorldDesc || "";
  };
  sel.onchange = loadCharWb;
  loadCharWb();
  
  // 强制选中第二本
  document.querySelectorAll('.wb-book').forEach(b => b.classList.remove('active'));
  document.querySelectorAll('.wb-book-content').forEach(c => c.classList.remove('open'));
  document.querySelector('.wb-book[data-book="world"]').classList.add('active');
  document.getElementById('wb-content-world').classList.add('open');
  
  wbModal.style.display = 'flex';
});

// 为了让导入图片时也能看到人物立绘，把 showPbFilter() 提到导入逻辑里
document.getElementById('btn-pb-import').addEventListener('click', async () => {
  try {
    const picked = await api.media.pick({ accept:"image/*" });
    if (picked?.file) {
      tempPbDataUrl = picked.file.dataUrl;
      pbImg.src = tempPbDataUrl;
      pbImg.style.display = 'block';
      pbPlaceholder.style.display = 'none';
      setPbActionBtnsVisible(true);
      resetPbFilter();
      showPbFilter();
    }
  } catch(e) {}
});

document.getElementById('btn-pb-draw').addEventListener('click', async () => {
  if (!pbPrompt.value.trim()) { api.ui.toast("请输入提示词"); return; }
  
  const globalLoader = document.getElementById('global-loader-modal');
  const globalLoaderText = document.getElementById('global-loader-text');
  
  pbImg.style.display = 'none';
  pbPlaceholder.style.display = 'none';
  pbLoader.style.display = 'block';
  btnPbConfirm.style.display = 'none';
  pbFilterControls.style.display = 'none';
  document.getElementById('pb-preview-avatar').style.display = 'none'; // 生成时隐藏立绘
  
  globalLoaderText.innerText = "正在绘制景致...";
  globalLoader.style.display = 'flex';
  
  try {
    const img = await api.ai.generateImage({ prompt: pbPrompt.value });
    if (img?.dataUrl) {
      tempPbDataUrl = img.dataUrl;
      pbImg.src = tempPbDataUrl;
      pbImg.style.display = 'block';
      setPbActionBtnsVisible(true);
      resetPbFilter();
      showPbFilter();
    } else {
      pbPlaceholder.style.display = 'block'; pbPlaceholder.innerText = '生成失败';
    }
  } catch(e) {
    pbPlaceholder.style.display = 'block'; pbPlaceholder.innerText = '生成失败';
  } finally {
    pbLoader.style.display = 'none';
    globalLoader.style.display = 'none';
  }
});

// 从手机导入系统世界书
document.getElementById('btn-import-sys-wb').addEventListener('click', async () => {
  try {
    // 根据 SDK 文档，world.list 返回 { books: [...] }
    const listResponse = await api.world.list({ limit: 100 });
    const books = listResponse?.books;
    
    if (!books || !Array.isArray(books) || books.length === 0) {
      api.ui.toast("手机内暂无世界书，请先去桌面「小卷」处创建");
      return;
    }
    
    // 弹窗让用户选
    const options = books.map(b => `<option value="${b.id}">${b.name}</option>`).join('');
    const div = document.createElement('div');
    div.style.cssText = 'position:fixed; inset:0; background:rgba(0,0,0,0.8); z-index:99999; display:flex; align-items:center; justify-content:center;';
    div.innerHTML = `
      <div style="background:#1a1816; padding:20px; border:1px solid var(--primary-color); border-radius:12px; width:80%; max-width:300px;">
        <div style="color:var(--primary-color); margin-bottom:12px;">选择要导入的世界书</div>
        <select id="sys-wb-select" style="width:100%; padding:8px; background:#000; color:#fff; border:1px solid #555; margin-bottom:16px;">${options}</select>
        <div style="display:flex; gap:12px;">
          <button id="sys-wb-cancel" style="flex:1; padding:8px; background:transparent; border:1px solid #666; color:#aaa; border-radius:4px;">取消</button>
          <button id="sys-wb-confirm" style="flex:1; padding:8px; background:var(--primary-color); border:none; color:#000; border-radius:4px;">导入</button>
        </div>
      </div>
    `;
    document.body.appendChild(div);
    
    document.getElementById('sys-wb-cancel').onclick = () => div.remove();
    document.getElementById('sys-wb-confirm').onclick = async () => {
      const id = document.getElementById('sys-wb-select').value;
      div.remove();
      try {
        const detail = await api.world.read({ id });
        const book = detail.book;
        
        if (book && book.entries) {
          // 拼接所有条目
          const text = book.entries.map(e => `【${e.key}】\n${e.content}`).join('\n\n');
          const ta = document.getElementById('wb-world-desc');
          ta.value = ta.value ? ta.value + '\n\n' + text : text;
          api.ui.toast("导入成功");
        } else {
          api.ui.toast("该世界书内暂无条目");
        }
      } catch(err) {
        console.error(err);
        api.ui.toast("读取世界书详情失败");
      }
    };
  } catch(e) {
    console.error(e);
    api.ui.toast("读取失败，请查看控制台日志");
  }
});

// 书本点击切换
document.querySelectorAll('.wb-book').forEach(book => {
  book.addEventListener('click', () => {
    document.querySelectorAll('.wb-book').forEach(b => b.classList.remove('active'));
    document.querySelectorAll('.wb-book-content').forEach(c => c.classList.remove('open'));
    book.classList.add('active');
    document.getElementById('wb-content-' + book.dataset.book).classList.add('open');
  });
});
document.getElementById('btn-close-wb').addEventListener('click', () => {
  wbModal.style.display = 'none';
  if (currentWbMode === 'global') {
    // 关闭时恢复回内存值，避免未保存的修改残留
    document.getElementById('wb-world-desc').value = window.globalWorldDesc || "";
    document.getElementById('wb-user-desc').value = userAncientDesc || "";
  }
});
document.getElementById('btn-save-wb').addEventListener('click', async () => {
  if (currentWbMode === 'global') {
    window.globalWorldDesc = document.getElementById('wb-world-desc').value;
    window.globalRulesDesc = document.getElementById('wb-rules-desc').value;
    userAncientDesc = document.getElementById('wb-user-desc').value;
    await saveProgress({ globalWorldDesc: window.globalWorldDesc, globalRulesDesc: window.globalRulesDesc, rankData, userAncientDesc });
    api.ui.toast("全局世界书已保存");
  } else {
    const cid = document.getElementById('wb-char-selector').value;
    const c = selectedCharsData.find(x => x.id === cid);
    if (c) {
      c.charWorldDesc = document.getElementById('wb-world-desc').value;
      await saveProgress({ characters: selectedCharsData });
      api.ui.toast("人物世界书已保存");
    }
  }
  wbModal.style.display = 'none';
});
document.getElementById('btn-wb-add-rank').addEventListener('click', () => {
  rankData.push({ rank: "新位份", selfClaim: "臣", note: "" });
  renderWbRankList();
});
document.getElementById('btn-wb-reset-rank').addEventListener('click', async () => {
  const ok = await api.ui.confirm({ title:'恢复位份册', message:'确定恢复游戏默认位份体系吗？当前未保存修改会被覆盖。' });
  if (!ok) return;
  rankData = defaultRankData.map(item => ({ ...item }));
  renderWbRankList();
  api.ui.toast('位份册已恢复默认，请点击保存');
});
document.getElementById('btn-wb-reset-rules').addEventListener('click', async () => {
  const ok = await api.ui.confirm({ title:'恢复长信规', message:'确定恢复游戏默认长信规吗？' });
  if (!ok) return;
  document.getElementById('wb-rules-desc').value = defaultRulesDesc;
  api.ui.toast('长信规已恢复默认，请点击保存');
});
document.getElementById('btn-wb-reset-user').addEventListener('click', async () => {
  const ok = await api.ui.confirm({ title:'恢复帝王纪', message:'帝王纪的默认内容为空。确定清空当前皇帝人设吗？' });
  if (!ok) return;
  document.getElementById('wb-user-desc').value = '';
  api.ui.toast('帝王纪已恢复默认，请点击保存');
});
document.getElementById('btn-wb-reset-world').addEventListener('click', async () => {
  const ok = await api.ui.confirm({ title:'恢复天下志', message:'确定恢复游戏默认天下志吗？' });
  if (!ok) return;
  document.getElementById('wb-world-desc').value = defaultGlobalWorldDesc;
  api.ui.toast('天下志已恢复默认，请点击保存');
});
function renderWbRankList() {
  const list = document.getElementById('wb-rank-list');
  list.innerHTML = '';
  rankData.forEach((item, idx) => {
    const row = document.createElement('div');
    row.style.cssText = 'display:flex; gap:4px; align-items:center;';
    row.innerHTML = `
      <input type="text" class="wb-rank-input" data-idx="${idx}" data-key="rank" value="${item.rank}" style="flex:2; background:rgba(0,0,0,0.5); border:1px solid #666; color:#fff; padding:6px; border-radius:4px; font-family:inherit; text-align:center; min-width:0;">
      <input type="text" class="wb-rank-input" data-idx="${idx}" data-key="selfClaim" value="${item.selfClaim}" style="flex:1; background:rgba(0,0,0,0.5); border:1px solid #666; color:#fff; padding:6px; border-radius:4px; font-family:inherit; text-align:center; min-width:0;">
      <input type="text" class="wb-rank-input" data-idx="${idx}" data-key="note" value="${item.note}" placeholder="备注" style="flex:2; background:rgba(0,0,0,0.5); border:1px solid #666; color:#fff; padding:6px; border-radius:4px; font-family:inherit; min-width:0;">
      <button class="wb-rank-del" data-idx="${idx}" style="background:rgba(139,32,32,0.5); border:1px solid #8b2020; color:#fff; width:30px; height:30px; border-radius:4px;">×</button>
    `;
    list.appendChild(row);
  });
  list.querySelectorAll('.wb-rank-input').forEach(inp => {
    inp.addEventListener('change', e => { rankData[e.target.dataset.idx][e.target.dataset.key] = e.target.value; });
  });
  list.querySelectorAll('.wb-rank-del').forEach(btn => {
    btn.addEventListener('click', e => { rankData.splice(e.target.dataset.idx, 1); renderWbRankList(); });
  });
}

// ===== 绘制台 =====
function openHuizhiTai() {
  const old = document.getElementById('huizhi-modal');
  if (old) old.remove();

  // ── 全屏模态 ──
  const modal = document.createElement('div');
  modal.id = 'huizhi-modal';
  modal.style.cssText = `
    position:fixed; inset:0; z-index:99999;
    background:#0a0806;
    display:flex; flex-direction:column;
  `;

  // ── 顶栏 ──
  const header = document.createElement('div');
  header.style.cssText = `
    padding:calc(var(--safe-top,44px) + 8px) 16px 10px;
    display:flex; justify-content:space-between; align-items:center;
    border-bottom:1px solid rgba(201,163,106,0.15); flex-shrink:0;
    background:rgba(8,6,4,0.6); backdrop-filter:blur(12px); -webkit-backdrop-filter:blur(12px);
  `;
  header.innerHTML = `
    <button id="huizhi-close" style="background:transparent;border:none;color:#888;font-size:16px;font-family:inherit;padding:4px 8px;">‹ 返回</button>
    <div style="color:var(--primary-color);font-size:17px;font-weight:bold;letter-spacing:5px;font-family:'STZhongsong','STSong',serif;
      background:linear-gradient(to bottom,#ffe9b8,#c9a36a);-webkit-background-clip:text;-webkit-text-fill-color:transparent;
      filter:drop-shadow(0 1px 4px rgba(0,0,0,0.8));">绘制台</div>
    <div style="width:60px;"></div>
  `;
  modal.appendChild(header);

  // ── 左侧输入面板 + 右侧预览，整体横向布局 ──
  const mainArea = document.createElement('div');
  mainArea.style.cssText = 'flex:1; display:flex; flex-direction:column; overflow:hidden;';

  // ── 顶部：提示词输入区 ──
  const inputPanel = document.createElement('div');
  inputPanel.style.cssText = `
    padding:12px 16px 10px;
    background:rgba(10,8,6,0.8);
    border-bottom:1px solid rgba(201,163,106,0.12);
    flex-shrink:0; display:flex; flex-direction:column; gap:8px;
  `;

  // 快捷预设行
  inputPanel.innerHTML = `
    <div style="display:flex; gap:6px; flex-wrap:wrap;">
      <span style="color:rgba(201,163,106,0.6);font-size:11px;letter-spacing:1px;align-self:center;flex-shrink:0;">快捷：</span>
      <button id="hz-preset-portrait" class="hz-preset-btn">立绘</button>
      <button id="hz-preset-palace" class="hz-preset-btn">宫殿外景</button>
      <button id="hz-preset-indoor" class="hz-preset-btn">室内背景</button>
      <button id="hz-preset-map" class="hz-preset-btn">皇城地图</button>
      <button id="hz-preset-icon" class="hz-preset-btn">宫殿图标</button>
    </div>
    <div style="display:flex; gap:8px; align-items:flex-end;">
      <textarea id="hz-prompt" placeholder="描述你想要的画面，例如：真实画风，中国古代宫廷，一位身着绛紫蟒袍的男子，背对镜头，立于朱红宫墙前，唯美，无文字…"
        style="flex:1;min-height:64px;max-height:120px;background:rgba(0,0,0,0.6);border:1px solid rgba(201,163,106,0.3);color:#eaeaea;padding:10px 12px;border-radius:8px;font-family:inherit;font-size:13px;line-height:1.5;resize:none;"></textarea>
      <button id="hz-generate-btn" style="
        flex-shrink:0; width:56px; height:64px;
        background:linear-gradient(135deg,#c9a36a,#8a6d3b);
        border:1.5px solid rgba(255,233,184,0.4); border-radius:10px;
        color:#1a1208; font-size:12px; font-weight:bold; letter-spacing:1px;
        font-family:'STZhongsong','STSong',serif; line-height:1.4;
        box-shadow:0 4px 12px rgba(201,163,106,0.25);
      ">✦<br>绘制</button>
    </div>
  `;

  // 注入快捷按钮样式（通过 style 标签）
  const hzStyle = document.createElement('style');
  hzStyle.textContent = `.hz-preset-btn{background:rgba(201,163,106,0.08);border:1px solid rgba(201,163,106,0.35);color:rgba(201,163,106,0.85);padding:4px 10px;border-radius:12px;font-size:11px;font-family:inherit;letter-spacing:1px;transition:all 0.15s;}.hz-preset-btn:active{background:rgba(201,163,106,0.2);}`;
  modal.appendChild(hzStyle);

  modal.appendChild(inputPanel);

  // ── 中部：全屏预览区 ──
  const previewArea = document.createElement('div');
  previewArea.style.cssText = `
    flex:1; position:relative; overflow:hidden;
    background:#0a0806; display:flex; align-items:center; justify-content:center;
  `;

  // SVG滤镜
  previewArea.innerHTML = `
    <svg style="width:0;height:0;position:absolute;"><filter id="hz-color-filter"><feColorMatrix type="matrix" id="hz-color-matrix" values="1 0 0 0 0  0 1 0 0 0  0 0 1 0 0  0 0 0 1 0"/></filter></svg>

    <!-- 空状态 -->
    <div id="hz-empty-state" style="display:flex;flex-direction:column;align-items:center;gap:16px;opacity:0.5;">
      <svg width="64" height="64" viewBox="0 0 24 24" fill="none" stroke="rgba(201,163,106,0.6)" stroke-width="1" stroke-linecap="round" stroke-linejoin="round"><rect x="3" y="3" width="18" height="18" rx="2" ry="2"/><circle cx="8.5" cy="8.5" r="1.5"/><polyline points="21 15 16 10 5 21"/></svg>
      <div style="color:rgba(201,163,106,0.6);font-size:13px;letter-spacing:3px;font-family:'STZhongsong','STSong',serif;">在上方输入描述后点击绘制</div>
    </div>

    <!-- 加载状态 -->
    <div id="hz-loader" style="display:none;flex-direction:column;align-items:center;gap:16px;">
      <div style="width:44px;height:44px;border:3px solid rgba(201,163,106,0.2);border-top-color:var(--primary-color);border-radius:50%;animation:spin 1s linear infinite;"></div>
      <div style="color:var(--primary-color);font-size:13px;letter-spacing:3px;font-family:'STZhongsong','STSong',serif;">正在绘制中…</div>
    </div>

    <!-- 预览图（铺满整个预览区）-->
    <img id="hz-preview-img" src="" style="display:none;position:absolute;inset:0;width:100%;height:100%;object-fit:contain;object-position:center;">
  `;

  mainArea.appendChild(inputPanel);
  mainArea.appendChild(previewArea);
  modal.appendChild(mainArea);

  // ── 底部工具栏（生成后显示）──
  const bottomBar = document.createElement('div');
  bottomBar.id = 'hz-bottom-bar';
  bottomBar.style.cssText = `
    display:none; flex-direction:column; gap:0;
    background:rgba(10,8,6,0.9); backdrop-filter:blur(16px); -webkit-backdrop-filter:blur(16px);
    border-top:1px solid rgba(201,163,106,0.15);
    padding-bottom:calc(var(--safe-bottom,24px) + 8px);
    flex-shrink:0;
  `;

  // 滤镜折叠区
  const filterToggleRow = document.createElement('div');
  filterToggleRow.style.cssText = 'display:flex; align-items:center; gap:10px; padding:8px 16px; border-bottom:1px solid rgba(201,163,106,0.08); cursor:pointer;';
  filterToggleRow.innerHTML = `
    <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="rgba(201,163,106,0.7)" stroke-width="2"><polygon points="22 3 2 3 10 12.46 10 19 14 21 14 12.46 22 3"/></svg>
    <span style="color:rgba(201,163,106,0.7);font-size:12px;letter-spacing:2px;flex:1;">滤镜调节</span>
    <span id="hz-filter-toggle-arrow" style="color:rgba(201,163,106,0.5);font-size:11px;">展开 ▼</span>
  `;

  const filterPanel = document.createElement('div');
  filterPanel.id = 'hz-filter-panel';
  filterPanel.style.cssText = 'display:none; flex-direction:column; gap:6px; padding:10px 16px 6px; background:rgba(0,0,0,0.3);';
  filterPanel.innerHTML = `
    <div style="display:grid; grid-template-columns:1fr 1fr; gap:8px 16px;">
      <div style="display:flex;align-items:center;gap:6px;">
        <span style="color:#aaa;font-size:11px;width:28px;flex-shrink:0;">亮度</span>
        <input type="range" id="hz-brightness" min="10" max="200" value="100" style="flex:1;height:3px;">
      </div>
      <div style="display:flex;align-items:center;gap:6px;">
        <span style="color:#aaa;font-size:11px;width:28px;flex-shrink:0;">对比</span>
        <input type="range" id="hz-contrast" min="10" max="200" value="100" style="flex:1;height:3px;">
      </div>
      <div style="display:flex;align-items:center;gap:6px;">
        <span style="color:#ff9999;font-size:11px;width:28px;flex-shrink:0;">红R</span>
        <input type="range" id="hz-r" min="0" max="200" value="100" style="flex:1;height:3px;">
      </div>
      <div style="display:flex;align-items:center;gap:6px;">
        <span style="color:#99ff99;font-size:11px;width:28px;flex-shrink:0;">绿G</span>
        <input type="range" id="hz-g" min="0" max="200" value="100" style="flex:1;height:3px;">
      </div>
      <div style="display:flex;align-items:center;gap:6px;">
        <span style="color:#9999ff;font-size:11px;width:28px;flex-shrink:0;">蓝B</span>
        <input type="range" id="hz-b" min="0" max="200" value="100" style="flex:1;height:3px;">
      </div>
      <div style="display:flex;align-items:center;justify-content:flex-end;">
        <button id="hz-filter-reset-all" style="background:transparent;border:1px solid #444;color:#666;padding:3px 10px;border-radius:6px;font-size:11px;font-family:inherit;">还原</button>
      </div>
    </div>
  `;

  // 底部按钮行
  const actionRow = document.createElement('div');
  actionRow.style.cssText = 'display:flex; gap:10px; padding:10px 16px 4px;';
  actionRow.innerHTML = `
    <button id="hz-reroll-btn" style="flex:1;background:rgba(201,163,106,0.1);border:1px solid rgba(201,163,106,0.4);color:var(--primary-color);padding:11px;border-radius:8px;font-size:13px;letter-spacing:2px;font-family:inherit;">重新绘制</button>
    <button id="hz-icon-btn" style="flex:1;background:rgba(201,163,106,0.1);border:1px solid rgba(201,163,106,0.4);color:var(--primary-color);padding:11px;border-radius:8px;font-size:13px;letter-spacing:2px;font-family:inherit;">设为图标</button>
    <button id="hz-save-btn" style="flex:2;background:var(--primary-color);border:none;color:#000;padding:11px;border-radius:8px;font-size:14px;font-weight:bold;letter-spacing:2px;font-family:inherit;">保存到手机</button>
  `;

  bottomBar.appendChild(filterToggleRow);
  bottomBar.appendChild(filterPanel);
  bottomBar.appendChild(actionRow);
  modal.appendChild(bottomBar);

  document.body.appendChild(modal);

  // ── 事件绑定 ──
  document.getElementById('huizhi-close').onclick = () => modal.remove();

  // 快捷预设
  const presets = {
    'hz-preset-portrait': '真实画风，中国古代宫廷人物立绘，全身，精致面容，华贵服饰，唯美光影，无文字，白色或透明背景',
    'hz-preset-palace':   '真实画风，中国古代皇宫外景，宏伟宫殿建筑，朱红宫墙，金瓦飞檐，云雾缭绕，唯美，无人物，无文字',
    'hz-preset-indoor':   '真实画风，中国古代皇宫室内，华丽陈设，帷幔垂落，烛光摇曳，唯美，无人物，无文字',
    'hz-preset-map':      '真实画风，中国古代皇城俯视地图，航拍视角，只有建筑屋顶，金瓦红墙，无人物，无文字',
    'hz-preset-icon':     '中国古代宫殿图标，小图标设计，精致，古风，金色线条，透明背景，无文字，正面视角'
  };
  Object.entries(presets).forEach(([id, text]) => {
    const btn = document.getElementById(id);
    if (btn) btn.onclick = () => { document.getElementById('hz-prompt').value = text; };
  });

  // 滤镜折叠
  let filterOpen = false;
  filterToggleRow.onclick = () => {
    filterOpen = !filterOpen;
    filterPanel.style.display = filterOpen ? 'flex' : 'none';
    document.getElementById('hz-filter-toggle-arrow').textContent = filterOpen ? '收起 ▲' : '展开 ▼';
  };

  // 滤镜应用
  let hzCurrentDataUrl = null;
  const hzImg = document.getElementById('hz-preview-img');

  function applyHzFilter() {
    const b = document.getElementById('hz-brightness').value;
    const c = document.getElementById('hz-contrast').value;
    const rv = document.getElementById('hz-r').value / 100;
    const gv = document.getElementById('hz-g').value / 100;
    const bv = document.getElementById('hz-b').value / 100;
    document.getElementById('hz-color-matrix').setAttribute('values',
      `${rv} 0 0 0 0  0 ${gv} 0 0 0  0 0 ${bv} 0 0  0 0 0 1 0`);
    hzImg.style.filter = `brightness(${b}%) contrast(${c}%) url(#hz-color-filter)`;
  }

  ['hz-brightness','hz-contrast','hz-r','hz-g','hz-b'].forEach(id => {
    document.getElementById(id).addEventListener('input', applyHzFilter);
  });

  document.getElementById('hz-filter-reset-all').onclick = () => {
    ['hz-brightness','hz-contrast','hz-r','hz-g','hz-b'].forEach(id => {
      document.getElementById(id).value = 100;
    });
    applyHzFilter();
  };

  // 烤入滤镜
  function bakeHzFilter() {
    const canvas = document.createElement('canvas');
    const w = hzImg.naturalWidth || 512;
    const h = hzImg.naturalHeight || 512;
    canvas.width = w; canvas.height = h;
    const ctx = canvas.getContext('2d');
    const b = document.getElementById('hz-brightness').value;
    const c = document.getElementById('hz-contrast').value;
    ctx.filter = `brightness(${b}%) contrast(${c}%)`;
    ctx.drawImage(hzImg, 0, 0, w, h);
    const rv = document.getElementById('hz-r').value / 100;
    const gv = document.getElementById('hz-g').value / 100;
    const bv = document.getElementById('hz-b').value / 100;
    if (rv !== 1 || gv !== 1 || bv !== 1) {
      const imgData = ctx.getImageData(0, 0, w, h);
      const data = imgData.data;
      for (let i = 0; i < data.length; i += 4) {
        data[i]   = Math.min(255, data[i]   * rv);
        data[i+1] = Math.min(255, data[i+1] * gv);
        data[i+2] = Math.min(255, data[i+2] * bv);
      }
      ctx.putImageData(imgData, 0, 0);
    }
    return canvas.toDataURL('image/jpeg', 0.92);
  }

  // 生成
  async function doGenerate() {
    const prompt = document.getElementById('hz-prompt').value.trim();
    if (!prompt) { api.ui.toast('请先输入绘制描述'); return; }

    const genBtn = document.getElementById('hz-generate-btn');
    const loader = document.getElementById('hz-loader');
    const emptyState = document.getElementById('hz-empty-state');

    genBtn.disabled = true;
    genBtn.style.opacity = '0.5';
    loader.style.display = 'flex';
    emptyState.style.display = 'none';
    hzImg.style.display = 'none';
    document.getElementById('hz-bottom-bar').style.display = 'none';

    try {
      const res = await api.ai.generateImage({ prompt });
      if (res?.dataUrl) {
        hzCurrentDataUrl = res.dataUrl;
        hzImg.src = hzCurrentDataUrl;
        hzImg.style.display = 'block';
        hzImg.style.filter = '';
        // 重置滤镜
        ['hz-brightness','hz-contrast','hz-r','hz-g','hz-b'].forEach(id => {
          document.getElementById(id).value = 100;
        });
        document.getElementById('hz-color-matrix').setAttribute('values',
          '1 0 0 0 0  0 1 0 0 0  0 0 1 0 0  0 0 0 1 0');
        document.getElementById('hz-bottom-bar').style.display = 'flex';
      } else {
        emptyState.style.display = 'flex';
        api.ui.toast('生成失败，请重试');
      }
    } catch(e) {
      emptyState.style.display = 'flex';
      api.ui.toast('绘制失败：' + (e?.message || '请检查AI绘图配置'));
    } finally {
      loader.style.display = 'none';
      genBtn.disabled = false;
      genBtn.style.opacity = '1';
    }
  }

  document.getElementById('hz-generate-btn').onclick = doGenerate;
  document.getElementById('hz-reroll-btn').onclick = doGenerate;

  // 设为图标：弹出选择宫殿的菜单
  document.getElementById('hz-icon-btn').onclick = async () => {
    if (!hzCurrentDataUrl) { api.ui.toast('请先生成图片'); return; }
    const finalDataUrl = bakeHzFilter();

    // 弹出选择宫殿弹窗
    const iconPicker = document.createElement('div');
    iconPicker.style.cssText = 'position:fixed;inset:0;z-index:200000;background:rgba(0,0,0,0.85);display:flex;align-items:flex-end;justify-content:center;';

    const palaceNames = placedPalacesData.map(p => p.name);
    const optHtml = palaceNames.map(n => `<button class="hz-icon-palace-btn" data-name="${n}" style="background:rgba(201,163,106,0.08);border:1px solid rgba(201,163,106,0.3);color:var(--primary-color);padding:10px 16px;border-radius:8px;font-size:14px;font-family:inherit;letter-spacing:2px;text-align:left;">${n}</button>`).join('');

    iconPicker.innerHTML = `
      <div style="width:100%;max-width:420px;background:#1a1816;border:1px solid var(--primary-color);border-radius:20px 20px 0 0;padding:20px 16px calc(var(--safe-bottom,24px)+16px);display:flex;flex-direction:column;gap:10px;max-height:70vh;overflow-y:auto;">
        <div style="color:var(--primary-color);font-size:16px;text-align:center;letter-spacing:3px;font-family:'STZhongsong','STSong',serif;">选择要设为图标的宫殿</div>
        <div style="color:#888;font-size:11px;text-align:center;">将当前图片（含滤镜效果）设为该宫殿在大地图上的图标</div>
        <div style="display:flex;flex-direction:column;gap:8px;">${optHtml}</div>
        <button id="hz-icon-cancel" style="background:transparent;border:none;color:#555;font-family:inherit;font-size:13px;padding:4px;margin-top:4px;">取消</button>
      </div>
    `;
    document.body.appendChild(iconPicker);
    iconPicker.addEventListener('click', e => { if(e.target === iconPicker) iconPicker.remove(); });
    document.getElementById('hz-icon-cancel').onclick = () => iconPicker.remove();

    iconPicker.querySelectorAll('.hz-icon-palace-btn').forEach(btn => {
      btn.onclick = async () => {
        const palaceName = btn.dataset.name;
        iconPicker.remove();

        // 找到对应宫殿数据，设置图标
        const pd = placedPalacesData.find(p => p.name === palaceName);
        if (pd) {
          pd.icon = finalDataUrl;
          pd.iconConfig = { url: finalDataUrl, scale: 100, opacity: 100, offsetX: 0, offsetY: 0, labelY: -20, textMode: 'horizontal' };
          await saveProgress({ palacesData: placedPalacesData });
          initMemoryView(); // 刷新大地图
          api.ui.toast(`✓ 已设为「${palaceName}」的图标`);
        }
      };
    });
  };

  // 保存到手机
  document.getElementById('hz-save-btn').onclick = async () => {
    if (!hzCurrentDataUrl) { api.ui.toast('请先生成图片'); return; }
    const saveBtn = document.getElementById('hz-save-btn');
    saveBtn.innerText = '保存中…'; saveBtn.disabled = true;
    try {
      const finalDataUrl = bakeHzFilter();
      try {
        await api.media.save({ dataUrl: finalDataUrl, type: 'image' });
        api.ui.toast('✓ 已保存到手机相册');
      } catch(e2) {
        const a = document.createElement('a');
        a.href = finalDataUrl;
        a.download = `故梦辞绘制_${Date.now()}.jpg`;
        a.click();
        api.ui.toast('✓ 图片已开始下载');
      }
    } catch(e) {
      api.ui.toast('保存失败：' + (e?.message || ''));
    } finally {
      saveBtn.innerText = '保存到手机'; saveBtn.disabled = false;
    }
  };
}

// === 11. Memory Management (内务府) ===
let currentMmCharId = null;

function openMemoryManage() {
  const tabs = document.getElementById('mm-char-tabs');
  tabs.innerHTML = '';

  // 从存档恢复谢临渊的记忆（如果有的话）
  if (window._xlyMemorySeen) {
    XLY_CHAR.memorySeen = window._xlyMemorySeen;
  }

  // 后妃与朝臣逐个展示；自定义身份人物和谢临渊收在“特殊”入口，NPC单独汇总。
  const isSpecial = char => typeof isSpecialRosterCharacter === 'function'
    ? isSpecialRosterCharacter(char)
    : Boolean(char && (char._isScenarioChar || (char.ancientRole !== '后妃' && !['帝师', '左相', '右相', '大臣', '臣子'].includes(char.ancientRole))));
  const allChars = selectedCharsData.filter(char => !isSpecial(char));
  const specialChars = [...selectedCharsData.filter(isSpecial), XLY_CHAR].filter((char, index, list) => list.findIndex(item => (item.id || item.name) === (char.id || char.name)) === index);
  const allNpcs = typeof getAllGameNpcs === 'function' ? getAllGameNpcs() : (window._courtNpcData || []);

  if (allChars.length === 0 && specialChars.length === 0 && allNpcs.length === 0) {
    api.ui.toast("尚无故人"); return;
  }

  allChars.forEach((c, idx) => {
    const btn = document.createElement('button');
    const isXly = c._isScenarioChar;
    btn.style.cssText = `flex-shrink:0; background:${idx===0?'var(--primary-color)':'rgba(0,0,0,0.5)'}; color:${idx===0?'#000':'#aaa'}; border:1px solid ${isXly?'#888':'var(--primary-color)'}; padding:6px 16px; border-radius:16px; font-size:14px; transition:all 0.2s;`;
    btn.innerText = isXly ? c.name + '（臣）' : c.name;
    btn.onclick = () => {
      Array.from(tabs.children).forEach(b => { b.style.background = 'rgba(0,0,0,0.5)'; b.style.color = '#aaa'; });
      btn.style.background = 'var(--primary-color)'; btn.style.color = '#000';
      renderMemoryPanes(c);
    };
    tabs.appendChild(btn);
  });

  const specialBtn = document.createElement('button');
  specialBtn.style.cssText = 'flex-shrink:0;background:rgba(0,0,0,0.5);color:#d8bd8b;border:1px solid rgba(201,163,106,0.6);padding:6px 18px;border-radius:16px;font-size:14px;transition:all 0.2s;';
  specialBtn.innerText = `特殊（${specialChars.length}）`;
  specialBtn.onclick = () => {
    Array.from(tabs.children).forEach(button => { button.style.background = 'rgba(0,0,0,0.5)'; button.style.color = '#aaa'; });
    specialBtn.style.background = 'var(--primary-color)';
    specialBtn.style.color = '#000';
    renderMemorySpecialList(specialChars);
  };
  tabs.appendChild(specialBtn);

  const npcBtn = document.createElement('button');
  npcBtn.style.cssText = 'flex-shrink:0;background:rgba(0,0,0,0.5);color:#d8bd8b;border:1px solid rgba(201,163,106,0.6);padding:6px 18px;border-radius:16px;font-size:14px;transition:all 0.2s;';
  npcBtn.innerText = `NPC（${allNpcs.length}）`;
  npcBtn.onclick = () => {
    Array.from(tabs.children).forEach(button => { button.style.background = 'rgba(0,0,0,0.5)'; button.style.color = '#aaa'; });
    npcBtn.style.background = 'var(--primary-color)';
    npcBtn.style.color = '#000';
    renderMemoryNpcList();
  };
  tabs.appendChild(npcBtn);
  


  if (allChars[0]) renderMemoryPanes(allChars[0]);
  else if (specialChars.length) {
    specialBtn.style.background = 'var(--primary-color)';
    specialBtn.style.color = '#000';
    renderMemorySpecialList(specialChars);
  } else {
    npcBtn.style.background = 'var(--primary-color)'; npcBtn.style.color = '#000'; renderMemoryNpcList();
  }
  switchView(vMemoryManage);
  // 注入全局字体按钮
  setTimeout(injectMemoryFontBtn, 100);
}

function renderMemorySpecialList(specialChars) {
  currentMmCharId = null;
  document.getElementById('mm-tab-bar').style.display = 'none';
  document.querySelectorAll('.mm-pane').forEach(pane => pane.style.display = 'none');
  const pane = document.getElementById('mm-seen');
  pane.style.display = 'flex';
  pane.innerHTML = specialChars.length ? `<div style="display:flex;flex-direction:column;gap:8px;">${specialChars.map(char => `<button data-mm-special-id="${escHtml(char.id)}" style="display:flex;align-items:center;gap:11px;text-align:left;background:rgba(20,16,12,0.78);border:1px solid rgba(201,163,106,0.28);border-radius:10px;padding:11px;color:#ddd;font-family:inherit;"><span style="width:36px;height:36px;border-radius:50%;display:flex;align-items:center;justify-content:center;background:rgba(201,163,106,0.14);color:#dfc48f;">${escHtml((char.name || '?').slice(0,1))}</span><span style="flex:1;"><b style="color:#ead3a5;letter-spacing:2px;">${escHtml(char.name)}</b><small style="display:block;color:#89775e;margin-top:4px;">${escHtml(char.ancientRole || '自定义身份')}</small></span><span style="color:#9c825d;">›</span></button>`).join('')}</div>` : '<div style="color:#666;text-align:center;padding:40px 0;">特殊人物名册为空</div>';
  pane.querySelectorAll('[data-mm-special-id]').forEach(button => button.onclick = () => {
    const char = specialChars.find(item => item.id === button.dataset.mmSpecialId);
    if (char) renderMemoryPanes(char);
  });
}

function renderMemoryNpcList() {
  currentMmCharId = null;
  document.getElementById('mm-tab-bar').style.display = 'none';
  document.querySelectorAll('.mm-pane').forEach(pane => pane.style.display = 'none');
  const pane = document.getElementById('mm-seen');
  pane.style.display = 'flex';
  const npcs = typeof getAllGameNpcs === 'function' ? getAllGameNpcs() : (window._courtNpcData || []);
  pane.innerHTML = npcs.length ? `<div style="display:flex;flex-direction:column;gap:8px;">${npcs.map(npc => `<button data-mm-npc-id="${escHtml(npc.id)}" style="display:flex;align-items:center;gap:11px;text-align:left;background:rgba(20,16,12,0.78);border:1px solid rgba(201,163,106,0.28);border-radius:10px;padding:11px;color:#ddd;font-family:inherit;"><span style="width:36px;height:36px;border-radius:50%;display:flex;align-items:center;justify-content:center;background:rgba(201,163,106,0.14);color:#dfc48f;">${escHtml((npc.name || '?').slice(0,1))}</span><span style="flex:1;"><b style="color:#ead3a5;letter-spacing:2px;">${escHtml(npc.name)}</b><small style="display:block;color:#89775e;margin-top:4px;">${escHtml(npc.ancientRole || 'NPC')} · ${escHtml(npc.masterName ? `主人：${npc.masterName}` : (npc.rosterMood || '暂无状态'))}</small></span><span style="color:#9c825d;">›</span></button>`).join('')}</div>` : '<div style="color:#666;text-align:center;padding:40px 0;">NPC名册为空</div>';
  pane.querySelectorAll('[data-mm-npc-id]').forEach(button => button.onclick = () => {
    const npc = npcs.find(item => item.id === button.dataset.mmNpcId);
    if (npc) renderMemoryPanes(npc);
  });
}

function openNpcMemoryFromStaff(npc) {
  document.getElementById('palace-staff-list-modal')?.remove();
  openMemoryManage();
  setTimeout(() => {
    const tabs = document.getElementById('mm-char-tabs');
    Array.from(tabs.children).forEach(button => {
      const active = button.innerText.startsWith('NPC');
      button.style.background = active ? 'var(--primary-color)' : 'rgba(0,0,0,0.5)';
      button.style.color = active ? '#000' : '#aaa';
    });
    renderMemoryPanes(npc);
  }, 0);
}

async function saveMemorySubject(char, extra = {}) {
  if (char?._isGameNpc) await saveProgress({ courtNpcData: window._courtNpcData || [], ...extra });
  else if (char?._isScenarioChar) {
    window._xlyMemorySeen = char.memorySeen;
    await saveProgress({ xlyMemorySeen: char.memorySeen, xlyMemoryKnown: char.memoryKnown, ...extra });
  } else await saveProgress({ characters: selectedCharsData, ...extra });
}

// ===== 重新定制人设弹窗 =====
function showRegenDescModal(char, taRef) {
  const existing = document.getElementById('regen-desc-modal');
  if (existing) existing.remove();

  const modal = document.createElement('div');
  modal.id = 'regen-desc-modal';
  modal.style.cssText = 'position:fixed;inset:0;z-index:99999;background:rgba(0,0,0,0.85);display:flex;align-items:flex-end;justify-content:center;';

  modal.innerHTML = `
    <div style="width:100%;max-width:480px;background:#1a1816;border:1px solid var(--primary-color);border-radius:20px 20px 0 0;padding:20px 16px calc(var(--safe-bottom,24px)+16px);display:flex;flex-direction:column;gap:12px;max-height:90vh;overflow-y:auto;">
      <div style="color:var(--primary-color);font-size:18px;text-align:center;letter-spacing:4px;font-family:'STZhongsong','STSong',serif;">为「${char.name}」重新定制人设</div>
      <div style="color:#aaa;font-size:12px;text-align:center;">描述你希望的外貌、性格、身份等，AI将结合宫规生成</div>
      <textarea id="regen-user-prompt" placeholder="例如：外貌清冷，性格高傲，家世显赫的贵族子弟，入宫前是武将，擅长剑术..." style="width:100%;height:120px;background:rgba(0,0,0,0.5);border:1px solid #666;color:#ccc;padding:12px;border-radius:8px;resize:none;font-size:14px;font-family:inherit;line-height:1.5;"></textarea>
      <div style="color:#888;font-size:11px;">将自动携带：长信宫规 + 大世界设定 + 当前角色身份（${char.ancientRole || '后妃'}）</div>
      <div style="display:flex;gap:12px;">
        <button id="regen-cancel-btn" style="flex:1;background:transparent;border:1px solid #666;color:#aaa;padding:12px;border-radius:8px;font-family:inherit;font-size:14px;">取消</button>
        <button id="regen-start-btn" style="flex:2;background:var(--primary-color);border:none;color:#000;padding:12px;border-radius:8px;font-family:inherit;font-size:14px;font-weight:bold;">✦ 开始生成</button>
      </div>
    </div>
  `;

  document.body.appendChild(modal);
  modal.addEventListener('click', e => { if (e.target === modal) modal.remove(); });
  document.getElementById('regen-cancel-btn').onclick = () => modal.remove();

  document.getElementById('regen-start-btn').onclick = async () => {
    const userPrompt = document.getElementById('regen-user-prompt').value.trim();
    modal.remove();

    const globalLoader = document.getElementById('global-loader-modal');
    const globalLoaderText = document.getElementById('global-loader-text');
    globalLoaderText.innerText = "AI 正在依据宫规定制人设...";
    globalLoader.style.display = 'flex';

    const role = char.ancientRole || '后妃';
    const charName = char.name;
    const rulesCtx = window.globalRulesDesc || '';
    const worldCtx = window.globalWorldDesc || '';
    const modernChar = (typeof allCharacters !== 'undefined' ? allCharacters.find(item => item.id === char.id) : null) || char._rawCard || {};
    const modernProfileParts = [
      modernChar.description ? `现代/原始描述：${modernChar.description}` : '',
      modernChar.personality ? `现代/原始性格：${modernChar.personality}` : '',
      modernChar.scenario ? `现代/原始背景：${modernChar.scenario}` : '',
      modernChar.creatorNotes ? `现代/原始创作备注：${modernChar.creatorNotes}` : '',
      modernChar.firstMessage ? `现代/原始开场白：${modernChar.firstMessage}` : ''
    ].filter(Boolean).join('\n');

    const msg1 = `我即将请你为一个古代后宫角色生成人设。请先阅读以下世界观背景，后续生成必须严格遵守。

【长信宫规（铁律，不可违反）】：
${rulesCtx}

【大世界设定】：
${worldCtx}

角色名：${charName}
古代身份：${role}
【角色自身的现代/原始人设（必须保留核心性格、说话方式、外貌和关系底色，只做古代化改写）】：
${modernProfileParts || '宿主未返回现代角色卡字段，请以现有古代人设为底稿，不得无依据重塑性格。'}

【当前古代人设底稿】：
${getCharacterOriginalPersona(char)}
${userPrompt ? `\nUser的定制要求：\n${userPrompt}` : ''}

请回复"已阅读，我将严格遵守宫规生成人设"，并简述你理解的核心要求。`;

    const msg2 = `很好。现在请基于以上背景，为「${charName}」生成一份详细的古风人设（不少于1500字）。

【严格要求，逐条执行】：
1. 角色名必须是"${charName}"，一字不差；
2. 完全遵守上面的长信宫规和大世界设定；
3. 必须继承角色现代/原始人设中的核心性格、语言习惯、外貌特征和关系底色，不能只读取User本次输入后另造一个同名人物；
4. ${userPrompt ? `在不破坏原角色核心的前提下实现User的定制要求：${userPrompt}` : '在保留原角色核心的前提下完成古代化扩写'}；
5. 用古典雅致的文字叙述，避免现代词汇；
6. 必须包含：外貌描写、性格描写、家世背景、入宫前经历；
7. 最后必须严格按以下格式提供3条说话范例（对话用英文直角双引号 " "）：

【范例1】(日常) [动作描写] "对话内容"
【范例2】(特殊) [动作描写] "对话内容"
【范例3】(私密) [动作描写] "对话内容"`;

    try {
      const r1 = await api.ai.chat({ messages: [{ role: 'user', content: msg1 }] });
      const r1Text = typeof r1 === 'string' ? r1 : (r1?.content ?? r1?.text ?? '');
      const r2 = await api.ai.chat({
        messages: [
          { role: 'user', content: msg1 },
          { role: 'assistant', content: r1Text },
          { role: 'user', content: msg2 }
        ]
      });
      let result = typeof r2 === 'string' ? r2 : (r2?.content ?? r2?.text ?? JSON.stringify(r2));
      result = result
        .replace(/\u201c/g, '"').replace(/\u201d/g, '"')
        .replace(/\u300c/g, '"').replace(/\u300d/g, '"')
        .replace(/\u300e/g, '"').replace(/\u300f/g, '"')
        .replace(/\uff02/g, '"');

      globalLoader.style.display = 'none';
      showRegenConfirmModal(char, result, taRef);
    } catch(e) {
      globalLoader.style.display = 'none';
      api.ui.toast('生成失败，请检查API配置');
    }
  };
}

// 确认弹窗：让用户查看并修改生成结果，确认后覆盖保存
function showRegenConfirmModal(char, generatedText, taRef) {
  const existing = document.getElementById('regen-confirm-modal');
  if (existing) existing.remove();

  const modal = document.createElement('div');
  modal.id = 'regen-confirm-modal';
  modal.style.cssText = 'position:fixed;inset:0;z-index:99999;background:rgba(0,0,0,0.85);display:flex;align-items:flex-end;justify-content:center;';

  modal.innerHTML = `
    <div style="width:100%;max-width:480px;background:#1a1816;border:1px solid var(--primary-color);border-radius:20px 20px 0 0;padding:20px 16px calc(var(--safe-bottom,24px)+16px);display:flex;flex-direction:column;gap:12px;max-height:92vh;overflow-y:auto;">
      <div style="color:var(--primary-color);font-size:18px;text-align:center;letter-spacing:4px;font-family:'STZhongsong','STSong',serif;">确认新人设</div>
      <div style="color:#aaa;font-size:12px;text-align:center;">可在下方直接修改，确认后将覆盖原人设</div>
      <textarea id="regen-result-ta" style="width:100%;height:320px;background:rgba(0,0,0,0.5);border:1px solid var(--primary-color);color:#ccc;padding:12px;border-radius:8px;resize:vertical;font-size:13px;font-family:inherit;line-height:1.6;">${generatedText}</textarea>
      <div style="display:flex;gap:12px;">
        <button id="regen-confirm-cancel" style="flex:1;background:transparent;border:1px solid #666;color:#aaa;padding:12px;border-radius:8px;font-family:inherit;font-size:14px;">放弃</button>
        <button id="regen-confirm-ok" style="flex:2;background:var(--primary-color);border:none;color:#000;padding:12px;border-radius:8px;font-family:inherit;font-size:14px;font-weight:bold;">✓ 确认覆盖保存</button>
      </div>
    </div>
  `;

  document.body.appendChild(modal);
  document.getElementById('regen-confirm-cancel').onclick = () => modal.remove();
  document.getElementById('regen-confirm-ok').onclick = async () => {
    const finalText = document.getElementById('regen-result-ta').value;
    char.ancientDesc = finalText;
    char.ancientDescOriginal = finalText;
    if (taRef) taRef.value = finalText;
    await saveMemorySubject(char);
    if (!char._isGameNpc) try { await api.characters.update(char.id, { description: char.ancientDesc }); } catch(e) {}
    api.ui.toast(`${char.name} 新人设已覆盖保存`);
    modal.remove();
  };
}

// --- 渲染记事项（个人/全局通用）---
function renderSingleRecord(rec, char, isGlobal) {
  const outer = document.createElement('div');
  outer.style.cssText = 'position:relative; overflow:hidden; border-radius:8px;';

  const inner = document.createElement('div');
  inner.style.cssText = 'background:rgba(0,0,0,0.4); border:1px solid #444; padding:10px; border-radius:8px; position:relative;';
  
  // 标签处理
  const tagHtml = (rec.tags || []).map(t => `<span style="border:1px solid ${t==='彤录'?'#8b2020':'#8a6d3b'}; color:${t==='彤录'?'#8b2020':'#8a6d3b'}; border-radius:4px; padding:0 4px; font-size:10px; margin-left:6px;">${t}</span>`).join('');
  const sourceLabel = rec.type === 'system' ? '<span style="color:#8a6d3b; opacity:0.7; font-size:10px; margin-left:6px;">[系统]</span>' : '';
  
  // 格式化文本（人名高亮）
  let displayText = rec.text;
  if (isGlobal || rec.type === 'ai') {
    // 找出所有角色名并高亮
    const allNames = selectedCharsData.map(c => c.name);
    allNames.push(XLY_CHAR.name);
    allNames.forEach(n => {
      const reg = new RegExp(n, 'g');
      // 在卷轴里，高亮颜色改用深红色更契合墨迹和批朱
      displayText = displayText.replace(reg, `<span style="color:#8b2020 !important; font-weight:bold;">${n}</span>`);
    });
  }

  const allRecordPeople = [...selectedCharsData, XLY_CHAR, ...(window._courtNpcData || [])]
    .filter(person => person?.name)
    .sort((a, b) => String(b.name).length - String(a.name).length);
  const inferredOwner = allRecordPeople.find(person => String(rec.text || '').includes(person.name))?.name;
  const isPublicRecord = (rec.tags || []).includes('众闻') || (rec.tags || []).includes('众谈') || (rec.tags || []).includes('赏赐');
  const displayOwner = isPublicRecord
    ? (rec.eventOwner || inferredOwner || rec.owner || char?.name || '无名氏')
    : (rec.eventOwner || rec.owner || char?.name || '无名氏');

  // 把标签移到下一行
  inner.innerHTML = `
    <div style="color:#888; font-size:11px; margin-bottom:2px; display:flex; justify-content:space-between; align-items:center;">
      <span>${isGlobal ? `【${displayOwner}】` : ''}${rec.time}</span>
      <div style="display:flex; gap:6px;">
        <button class="btn-edit-rec" style="background:transparent; border:1px solid #666; color:#aaa; font-size:11px; padding:2px 6px; border-radius:4px;">改</button>
        <button class="btn-del-rec" style="background:transparent; border:1px solid #8b2020; color:#c96a6a; font-size:11px; padding:2px 6px; border-radius:4px;">删</button>
      </div>
    </div>
    <div style="margin-bottom:6px; display:flex; align-items:center;">
      ${tagHtml}${sourceLabel}
    </div>
    <div style="font-size:12px; line-height:1.6; font-family:'STZhongsong','STSong',serif; margin-top: 4px;" class="scroll-rec-text">${displayText}</div>
  `;
  
  // 删除
  inner.querySelector('.btn-del-rec').addEventListener('click', async () => {
    if (rec.tags && rec.tags.includes('秘闻')) {
      const idx = (window._qitaRecords || []).findIndex(r => r.id === rec.id);
      if (idx >= 0) window._qitaRecords.splice(idx, 1);
    } else if (rec.tags && rec.tags.includes('前朝') && !char.id) {
      const idx = (window._qianchaoRecords || []).findIndex(r => r.id === rec.id);
      if (idx >= 0) window._qianchaoRecords.splice(idx, 1);
    } else if (char.records) {
      const idx = char.records.findIndex(r => r.id === rec.id);
      if (idx >= 0) {
        char.records.splice(idx, 1);
        // 如果是众谈，同步删除所有人那里的这条记录（基于 id）
        if (rec.tags && rec.tags.includes('众谈')) {
          (typeof getHaremPublicRecordRecipients === 'function' ? getHaremPublicRecordRecipients() : selectedCharsData.filter(c => c.ancientRole === '后妃')).forEach(c => {
            if (c.records) {
              const i = c.records.findIndex(r => r.id === rec.id);
              if (i >= 0) c.records.splice(i, 1);
            }
          });
        }
      }
    }
    
    if (char._isScenarioChar) {
      window._xlyRecords = XLY_CHAR.records;
    }
    await saveProgress({ xlyRecords: XLY_CHAR.records, characters: selectedCharsData, courtNpcData: window._courtNpcData || [], qianchaoRecords: window._qianchaoRecords, qitaRecords: window._qitaRecords });
    
    if (isGlobal) {
      const pane = document.getElementById('yx-records-pane');
      if (pane) renderAllRecordsPane(pane);
    }
    else {
      // 如果是从宫殿详情页打开的，重绘个人记事弹窗
      const charRecModal = document.getElementById('char-records-modal');
      if (charRecModal) {
        openCharRecords(char);
      } else {
        renderMemoryPanes(char);
      }
    }
  });
  
  // 修改
  inner.querySelector('.btn-edit-rec').addEventListener('click', async () => {
    // 使用自定义弹窗替代原生 prompt
    const editModal = document.createElement('div');
    editModal.style.cssText = 'position:fixed; inset:0; z-index:999999; background:rgba(0,0,0,0.8); display:flex; align-items:center; justify-content:center;';
    editModal.innerHTML = `
      <div style="background:#1a1816; border:1px solid var(--primary-color); border-radius:12px; width:85%; max-width:320px; padding:20px; display:flex; flex-direction:column; gap:12px;">
        <div style="color:var(--primary-color); font-size:16px; font-weight:bold; text-align:center;">修改记事</div>
        <textarea id="edit-rec-input" style="width:100%; height:100px; background:rgba(0,0,0,0.5); border:1px solid #666; color:#ccc; padding:10px; border-radius:8px; resize:vertical; font-size:13px; font-family:inherit; line-height:1.5;"></textarea>
        <div style="display:flex; gap:12px; margin-top:8px;">
          <button id="btn-edit-rec-cancel" style="flex:1; background:transparent; border:1px solid #666; color:#aaa; padding:10px; border-radius:6px;">取消</button>
          <button id="btn-edit-rec-confirm" style="flex:1; background:var(--primary-color); border:none; color:#000; padding:10px; border-radius:6px; font-weight:bold;">确认</button>
        </div>
      </div>
    `;
    document.body.appendChild(editModal);
    
    const ta = editModal.querySelector('#edit-rec-input');
    ta.value = rec.text;
    ta.focus();

    const doSave = async () => {
      const newVal = ta.value.trim();
      if (newVal) {
        rec.text = newVal;
        
        // 如果是众谈，同步修改
        if (rec.tags && rec.tags.includes('众谈')) {
          (typeof getHaremPublicRecordRecipients === 'function' ? getHaremPublicRecordRecipients() : selectedCharsData.filter(c => c.ancientRole === '后妃')).forEach(c => {
            if (c.records) {
              const r = c.records.find(xr => xr.id === rec.id);
              if (r) r.text = rec.text;
            }
          });
        } else if (rec.tags && rec.tags.includes('秘闻')) {
          const r = (window._qitaRecords || []).find(xr => xr.id === rec.id);
          if (r) r.text = rec.text;
        } else if (rec.tags && rec.tags.includes('前朝') && (!char || !char.id)) {
          const r = (window._qianchaoRecords || []).find(xr => xr.id === rec.id);
          if (r) r.text = rec.text;
        }
        
        if (char && char._isScenarioChar) {
          window._xlyRecords = XLY_CHAR.records;
        }
        await saveProgress({ xlyRecords: XLY_CHAR.records, characters: selectedCharsData, courtNpcData: window._courtNpcData || [], qianchaoRecords: window._qianchaoRecords, qitaRecords: window._qitaRecords });
        
        if (isGlobal) {
          const pane = document.getElementById('yx-records-pane');
          if (pane) renderAllRecordsPane(pane);
        } else {
          const charRecModal = document.getElementById('char-records-modal');
          if (charRecModal) {
            openCharRecords(char);
          } else {
            renderMemoryPanes(char);
          }
        }
      }
      editModal.remove();
    };

    editModal.querySelector('#btn-edit-rec-cancel').onclick = () => editModal.remove();
    editModal.querySelector('#btn-edit-rec-confirm').onclick = doSave;
  });

  outer.appendChild(inner);
  return outer;
}

function openCharRecords(char) {
  const old = document.getElementById('char-records-modal');
  if (old) old.remove();

  const modal = document.createElement('div');
  modal.id = 'char-records-modal';
  modal.style.cssText = 'position:fixed; inset:0; z-index:99999; background:rgba(0,0,0,0.85);';

  // 卷轴容器
  const scrollContainer = document.createElement('div');
  scrollContainer.className = 'scroll-container';

  // 将关闭按钮和标题做成悬浮在卷轴上的样式
  const header = document.createElement('div');
  header.style.cssText = 'position:absolute; top:calc(var(--safe-top) + 12px); left:16px; right:16px; display:flex; justify-content:space-between; align-items:center; z-index:10; pointer-events:none;';
  header.innerHTML = `
    <button id="btn-close-charrec" style="background:transparent; border:none; color:#ddd; font-size:16px; text-shadow:0 1px 2px #000; padding:8px; pointer-events:auto;">‹ 返回</button>
    <div style="color:#ffe9b8; font-size:18px; font-weight:bold; letter-spacing:4px; font-family:'STZhongsong','STSong',serif; text-shadow:0 2px 4px #000;">起居注 · ${char.name}</div>
    <div style="width:48px;"></div>
  `;
  modal.appendChild(header);

  // 卷轴内部的滚动内容区
  const pane = document.createElement('div');
  pane.className = 'scroll-content-area';
  pane.style.pointerEvents = 'auto';
  
  // 个人记事渲染
  
  // 顶部新增 TA了解的 按钮，引导去内务府
  const btnGoKnown = document.createElement('button');
  btnGoKnown.style.cssText = 'width:100%; background:transparent; border:1px solid rgba(138,109,59,0.5); color:#6b4d24; padding:8px; border-radius:8px; font-size:13px; letter-spacing:1px; margin-bottom:10px; flex-shrink:0; font-family:"STZhongsong","STSong",serif;';
  btnGoKnown.innerText = '前往【TA了解的】查看完整档案 ›';
  btnGoKnown.onclick = () => {
    modal.remove();
    openMemoryManage();
    // 切换到已知面板
    setTimeout(() => {
      if (char._isGameNpc) renderMemoryPanes(char);
      const knownTab = document.querySelector('.mm-tab[data-target="mm-known"]');
      if (knownTab) knownTab.click();
    }, 100);
  };
  pane.appendChild(btnGoKnown);

  const btnGenRec = document.createElement('button');
  btnGenRec.style.cssText = 'width:100%; background:rgba(201,163,106,0.15); border:1px solid #8a6d3b; color:#5e3a11; padding:8px; border-radius:8px; font-size:13px; font-weight:bold; letter-spacing:2px; margin-bottom:10px; flex-shrink:0; font-family:"STZhongsong","STSong",serif;';
  btnGenRec.innerText = '✦ 翰林落墨';
  btnGenRec.onclick = async () => {
    const timeStr = hudTime ? hudTime.innerText : '未知时间';
    let wbText = "";
    if (userAncientDesc) wbText += `【皇帝人设】：\n${userAncientDesc}\n\n`;
    let desc = char.ancientDescOriginal || char.ancientDesc.replace(/^【当前游戏时间】：[^\n]*\n?/, '').replace(/【当前后宫位份体系（由高到低）】[\s\S]*/, '');
    let charWb = char.charWorldDesc ? `\n专属人物世界书：\n${char.charWorldDesc}` : '';
    let memoryText = (char.memorySeen || []).map(m => m.text).join('\n') || '无';
    
    const allNames = [...selectedCharsData, XLY_CHAR].filter(c => c.id !== char.id).map(c => c.name).join('、');
    
    let sysPrompt = customPrompts.generateRecords || defaultPrompts.generateRecords;
    sysPrompt = sysPrompt
      .replace('{{timeStr}}', timeStr)
      .replace(/\{\{charName\}\}/g, char.name)
      .replace('{{assignedRank}}', char.assignedRank || '无')
      .replace('{{desc}}', desc)
      .replace('{{charWb}}', charWb)
      .replace('{{memoryText}}', memoryText)
      .replace('{{allChars}}', allNames);
      
    btnGenRec.innerText = '撰写中...';
    btnGenRec.disabled = true;
    
    try {
      const res = await api.ai.chat({ messages:[{role:"user", content:sysPrompt}] });
      const text = typeof res === 'string' ? res : (res?.content ?? res?.text ?? '');
      
      const jsonMatch = text.match(/\[\s*\{[\s\S]*\}\s*\]/);
      if (jsonMatch) {
        const arr = JSON.parse(jsonMatch[0]);
        if (!char.records) char.records = [];
        
        arr.reverse().forEach(item => {
          if (item.time && item.text) {
             const recId = generateId();
             char.records.unshift({ id: recId, time: item.time, text: item.text, type: 'ai', tags: [] });
             
            [...selectedCharsData, XLY_CHAR, ...(window._courtNpcData || [])].forEach(other => {
               if (other.id !== char.id && item.text.includes(other.name)) {
                 if (!other.records) other.records = [];
                 other.records.unshift({ id: recId, time: item.time, text: item.text, type: 'ai', tags: ['涉客'] });
               }
             });
          }
        });
        
        if (char._isGameNpc) {
          await saveProgress({ courtNpcData: window._courtNpcData || [], characters: selectedCharsData });
        } else if (char._isScenarioChar) {
          window._xlyRecords = XLY_CHAR.records;
          await saveProgress({ xlyRecords: XLY_CHAR.records, characters: selectedCharsData });
        } else {
          await saveProgress({ characters: selectedCharsData });
        }
        
        openCharRecords(char); // 刷新
      } else {
        api.ui.toast("AI 返回格式错误");
      }
    } catch(e) {
      console.error(e);
      api.ui.toast("生成失败");
    } finally {
      btnGenRec.innerText = '✦ 让翰林院撰写近期小记';
      btnGenRec.disabled = false;
    }
  };
  pane.appendChild(btnGenRec);

  const visibleCharRecords = (char.records || []).filter(rec => {
    if (!(rec.tags || []).includes('众谈')) return true;
    return char.ancientRole === '后妃' || char.npcType === 'attendant' || char.npcType === 'maid' || char.ancientRole === '侍从' || char.ancientRole === '宫女';
  });
  if (visibleCharRecords.length > 0) {
    visibleCharRecords.forEach(rec => {
      const el = renderSingleRecord(rec, char, false);
      // 给卷轴里的记事加上特殊类名，应用我们在 CSS 里加的透明背景样式
      const inner = el.querySelector('div');
      if (inner) {
        inner.classList.add('scroll-record-item');
        const timeEl = inner.querySelector('span');
        if (timeEl) timeEl.classList.add('rec-time');
        const textEl = inner.querySelector('div:last-child');
        if (textEl) textEl.classList.add('rec-text');
      }
      pane.appendChild(el);
    });
  } else {
    const empty = document.createElement('div');
    empty.style.cssText = 'color:#8a6d3b; text-align:center; padding:20px; font-size:13px; font-family:"STZhongsong","STSong",serif; opacity:0.8;';
    empty.innerText = '暂无记事，落墨留痕。';
    pane.appendChild(empty);
  }

  scrollContainer.appendChild(pane);
  modal.appendChild(scrollContainer);
  document.body.appendChild(modal);

  const closeBtn = document.getElementById('btn-close-charrec');
  if (closeBtn) {
    closeBtn.onclick = () => modal.remove();
  }
}

// 移除了重复定义的旧版 renderAllRecordsPane

function renderMemoryPanes(char) {
  // 打开众生相时立即同步名册，不再要求先打开一次养心殿“列表”。
  if (typeof syncRosterKnowledgeToCharacters === 'function') syncRosterKnowledgeToCharacters();
  currentMmCharId = char.id;
  document.getElementById('mm-tab-bar').style.display = 'flex';
  document.querySelectorAll('.mm-pane').forEach(p => p.style.display = 'none');
  
  // 恢复之前选中的 tab
  const activeTab = document.querySelector('.mm-tab.active');
  if (activeTab) {
    document.getElementById(activeTab.dataset.target).style.display = 'flex';
  } else {
    document.getElementById('mm-seen').style.display = 'flex';
  }

  const seenPane = document.getElementById('mm-seen');
  const knownPane = document.getElementById('mm-known');
  const thoughtsPane = document.getElementById('mm-thoughts');
  
  // Seen — 顶部控制栏 + 支持右滑删除
  seenPane.innerHTML = '';

  // ── 顶부 控制栏：沉思开关 + 立即沉思 ──
  const reflectBar = document.createElement('div');
  reflectBar.style.cssText = 'display:flex; align-items:center; gap:8px; padding:8px 10px; background:rgba(201,163,106,0.06); border:1px solid rgba(201,163,106,0.2); border-radius:8px; margin-bottom:8px; flex-shrink:0;';

  const reflectLabel = document.createElement('div');
  reflectLabel.style.cssText = 'color:rgba(201,163,106,0.7); font-size:11px; letter-spacing:1px; flex:1;';
  reflectLabel.innerHTML = `✦ 思绪自动沉思 <span style="color:#666; font-size:10px;">（每${REFLECT_INTERVAL}条看到的触发）</span>`;

  // 开关
  const toggleWrap = document.createElement('label');
  toggleWrap.style.cssText = 'display:flex; align-items:center; gap:4px; cursor:pointer; flex-shrink:0;';
  const toggleInput = document.createElement('input');
  toggleInput.type = 'checkbox';
  toggleInput.checked = autoReflectEnabled;
  toggleInput.style.cssText = 'width:14px; height:14px; accent-color:var(--primary-color); cursor:pointer;';
  toggleInput.addEventListener('change', e => { autoReflectEnabled = e.target.checked; });
  const toggleText = document.createElement('span');
  toggleText.style.cssText = 'color:#888; font-size:11px;';
  toggleText.textContent = '自动';
  toggleWrap.appendChild(toggleInput);
  toggleWrap.appendChild(toggleText);

  // 立即沉思按钮
  const reflectNowBtn = document.createElement('button');
  reflectNowBtn.style.cssText = 'background:rgba(201,163,106,0.12); border:1px solid rgba(201,163,106,0.4); color:var(--primary-color); font-size:11px; padding:3px 10px; border-radius:6px; font-family:inherit; letter-spacing:1px; flex-shrink:0;';
  reflectNowBtn.textContent = '立即沉思';
  reflectNowBtn.addEventListener('click', async () => {
    reflectNowBtn.textContent = '沉思中…';
    reflectNowBtn.disabled = true;
    await triggerCharReflect(char, true);
    reflectNowBtn.textContent = '立即沉思';
    reflectNowBtn.disabled = false;
  });

  reflectBar.appendChild(reflectLabel);
  reflectBar.appendChild(toggleWrap);
  reflectBar.appendChild(reflectNowBtn);
  seenPane.appendChild(reflectBar);

  if (char.memorySeen && char.memorySeen.length > 0) {
    char.memorySeen.forEach((item, idx) => {
      const isReflect = item._isReflect === true;
      const outer = document.createElement('div');
      outer.style.cssText = 'position:relative; overflow:hidden; border-radius:8px; touch-action:pan-y;';

      // 删除底层
      const delBg = document.createElement('div');
      delBg.style.cssText = 'position:absolute; right:0; top:0; bottom:0; width:72px; background:#8b2020; display:flex; align-items:center; justify-content:center; color:#fff; font-size:13px; border-radius:0 8px 8px 0;';
      delBg.innerText = '删除';
      outer.appendChild(delBg);

      // 内容层
      const inner = document.createElement('div');
      const isChatLog = item.text.startsWith('【私下对话记录】');
      // 思绪条目：金色斜体边框；普通条目：原样
      if (isReflect) {
        inner.style.cssText = 'background:rgba(201,163,106,0.08); border:1px solid rgba(201,163,106,0.45); padding:10px; border-radius:8px; position:relative; transition:transform 0.25s; will-change:transform; z-index:1;';
      } else {
        inner.style.cssText = 'background:#1a1614; border:1px solid #444; padding:10px; border-radius:8px; position:relative; transition:transform 0.25s; will-change:transform; z-index:1;';
      }
      const titleColor = isReflect ? 'rgba(201,163,106,0.9)' : (isChatLog ? '#c9a3c9' : 'var(--primary-color)');
      const tagBadge = isReflect
        ? '<span style="border:1px solid rgba(201,163,106,0.6); border-radius:4px; padding:0 4px; font-size:10px; color:rgba(201,163,106,0.8);">思绪</span>'
        : (isChatLog ? '<span style="border:1px solid #c9a3c9; border-radius:4px; padding:0 4px; font-size:10px;">密谈集册</span>' : '');

      inner.innerHTML = `
        <div style="color:${titleColor}; font-size:12px; margin-bottom:6px; display:flex; justify-content:space-between; align-items:center;">
          <span>${item.time}</span>
          ${tagBadge}
        </div>
        <textarea class="mm-edit-seen" data-idx="${idx}" style="width:100%; min-height:${isReflect?'36px':'60px'}; background:transparent; border:none; color:${isReflect?'rgba(201,163,106,0.85)':'#ccc'}; resize:vertical; font-size:${isReflect?'12px':'13px'}; font-family:${isReflect?"'STZhongsong','STSong',serif":'inherit'}; font-style:${isReflect?'italic':'normal'};">${item.text}</textarea>
      `;
      outer.appendChild(inner);
      seenPane.appendChild(outer);

      // 右滑手势
      let tx = 0, startX = 0, swiping = false;
      inner.addEventListener('touchstart', e => {
        startX = e.touches[0].clientX; swiping = false;
        inner.style.transition = 'none';
      }, { passive: true });
      inner.addEventListener('touchmove', e => {
        const dx = e.touches[0].clientX - startX;
        if (!swiping && Math.abs(dx) > 8) swiping = true;
        if (!swiping) return;
        tx = Math.max(-72, Math.min(0, dx));
        inner.style.transform = `translateX(${tx}px)`;
      }, { passive: true });
      inner.addEventListener('touchend', () => {
        inner.style.transition = 'transform 0.25s';
        if (tx < -36) {
          inner.style.transform = 'translateX(-72px)';
          tx = -72;
        } else {
          inner.style.transform = 'translateX(0)';
          tx = 0;
        }
      });

      // 点删除底层
      delBg.addEventListener('click', async () => {
        char.memorySeen.splice(idx, 1);
        await saveMemorySubject(char);
        renderMemoryPanes(char);
      });

      // 编辑保存
      inner.querySelector('.mm-edit-seen').addEventListener('change', async (e) => {
        char.memorySeen[idx].text = e.target.value;
        await saveMemorySubject(char);
      });
    });
  } else {
    const emptyEl = document.createElement('div');
    emptyEl.style.cssText = 'color:#666; text-align:center; padding:20px; font-size:13px;';
    emptyEl.textContent = '暂无见闻记忆';
    seenPane.appendChild(emptyEl);
  }

  // Thoughts — 单独展示由自动/立即沉思生成的条目。
  thoughtsPane.innerHTML = '';
  const thoughtItems = (char.memorySeen || []).map((item, index) => ({ item, index })).filter(entry => entry.item._isReflect === true || String(entry.item.text || '').startsWith('【思绪】'));
  const thoughtBar = document.createElement('div');
  thoughtBar.style.cssText = 'display:flex;align-items:center;justify-content:space-between;padding:9px 10px;background:rgba(201,163,106,0.07);border:1px solid rgba(201,163,106,0.25);border-radius:8px;';
  thoughtBar.innerHTML = `<span style="color:#bca277;font-size:12px;">共 ${thoughtItems.length} 条思绪</span><button id="mm-thought-now" style="background:rgba(201,163,106,0.16);border:1px solid rgba(201,163,106,0.45);color:#d9bd85;border-radius:13px;padding:4px 10px;font-family:inherit;font-size:11px;">立即沉思</button>`;
  thoughtsPane.appendChild(thoughtBar);
  thoughtBar.querySelector('#mm-thought-now').onclick = async event => {
    event.currentTarget.disabled = true;
    event.currentTarget.innerText = '沉思中…';
    await triggerCharReflect(char, true);
    renderMemoryPanes(char);
    document.querySelector('.mm-tab[data-target="mm-thoughts"]')?.click();
  };
  if (!thoughtItems.length) {
    const empty = document.createElement('div');
    empty.style.cssText = 'color:#666;text-align:center;padding:30px 0;font-size:13px;';
    empty.innerText = '尚无思绪，可点击右上角立即沉思';
    thoughtsPane.appendChild(empty);
  } else {
    thoughtItems.forEach(({ item, index }) => {
      const card = document.createElement('div');
      card.style.cssText = 'background:rgba(201,163,106,0.08);border:1px solid rgba(201,163,106,0.35);border-radius:8px;padding:10px;';
      card.innerHTML = `<div style="display:flex;justify-content:space-between;color:#9f8967;font-size:11px;margin-bottom:6px;"><span>${escHtml(item.time || '')}</span><button data-del-thought="${index}" style="background:transparent;border:none;color:#9b5950;font-family:inherit;">删除</button></div><textarea data-edit-thought="${index}" style="width:100%;min-height:46px;background:transparent;border:none;color:#d1b889;font-style:italic;resize:vertical;font-family:inherit;line-height:1.6;">${escHtml(item.text || '')}</textarea>`;
      thoughtsPane.appendChild(card);
    });
    thoughtsPane.querySelectorAll('[data-del-thought]').forEach(button => button.onclick = async () => {
      char.memorySeen.splice(Number(button.dataset.delThought), 1);
      await saveMemorySubject(char);
      renderMemoryPanes(char);
      document.querySelector('.mm-tab[data-target="mm-thoughts"]')?.click();
    });
    thoughtsPane.querySelectorAll('[data-edit-thought]').forEach(textarea => textarea.onchange = async () => {
      char.memorySeen[Number(textarea.dataset.editThought)].text = textarea.value;
      await saveMemorySubject(char);
    });
  }
  


  // Known — 分块展示，每块独立可编辑
  knownPane.innerHTML = '';

  // 时间栏（同步游戏时间）
  const timeBlock = document.createElement('div');
  timeBlock.style.cssText = 'background:rgba(201,163,106,0.08); border:1px solid rgba(201,163,106,0.4); border-radius:8px; padding:8px 12px; display:flex; align-items:center; gap:8px;';
  timeBlock.innerHTML = `<span style="color:var(--primary-color); font-size:12px; flex-shrink:0;">当前时间</span>
    <span id="mm-known-time" style="color:#eaeaea; font-size:13px; font-family:'STZhongsong','STSong',serif; flex:1;">${hudTime ? hudTime.innerText : ''}</span>`;
  knownPane.appendChild(timeBlock);
  // 让时间跟着 hudTime 走（1秒轮询一次，够用）
  const mmTimeEl = timeBlock.querySelector('#mm-known-time');
  const mmTimerInterval = setInterval(() => {
    if (!document.getElementById('mm-known')) { clearInterval(mmTimerInterval); return; }
    if (hudTime) mmTimeEl.innerText = hudTime.innerText;
  }, 1000);

  // 身份与位份信息块（含性别）
  const identityBlock = (() => {
    let text = `【性别】：${char.gender || '未设定'}`;
    text += `\n【身份】：${char.ancientRole || '未设定'}`;
    if (char.ancientRole === '后妃') {
      text += `\n【当前位份】：${char.assignedRank || '未册封'}`;
      text += `\n【居所】：${char.assignedPalace || '未赐居'}`;
    }
    if (char._isGameNpc) {
      text += `\n【性格】：${char.rosterPersonality || '未生成'}`;
      text += `\n【当前状态】：${char.rosterMood || '未生成'}`;
      if (char.npcType === 'attendant' || char.npcType === 'maid') {
        text += `\n【主人】：${char.masterName || '未分配'}`;
        text += `\n【居所】：${char.assignedPalace || '尚未随主迁居'}`;
        text += `\n【忠诚度】：${char.loyalty ?? 0}`;
      }
    }
    // 追加自定义 memoryKnown 条目（过滤掉性别那条，关系图谱单独显示）
    if (char.memoryKnown && char.memoryKnown.length > 0) {
      const extra = char.memoryKnown.map(item => typeof item === 'string' ? item : (item?.text || JSON.stringify(item))).filter(text =>
        !text.startsWith('【性别】') && !text.startsWith('【关系图谱】') && !text.startsWith('【宫中名册·')
      );
      if (extra.length > 0) text += '\n' + extra.join('\n');
    }
    return text;
  })();
  knownPane.appendChild(makeKnownBlock('身份与位份', identityBlock, false));

  // 名册各自单独显示成醒目的区块，避免混在身份文本里难以找到。
  const rosterKnownEntries = (char.memoryKnown || [])
    .map(item => typeof item === 'string' ? item : (item?.text || JSON.stringify(item)))
    .filter(text => text.startsWith('【宫中名册·'));
  rosterKnownEntries.forEach(text => {
    const titleMatch = text.match(/^【宫中名册·([^】]+)】/);
    const title = titleMatch ? `宫中名册 · ${titleMatch[1]}` : '宫中名册';
    const content = text.replace(/^【宫中名册·[^】]+】\s*/, '') || '当前名册为空';
    knownPane.appendChild(makeKnownBlock(title, content, false));
  });

  // 关系图谱条目（单独一块，方便查看）
  if (char.memoryKnown && char.memoryKnown.length > 0) {
    const relEntries = char.memoryKnown.map(item => typeof item === 'string' ? item : (item?.text || JSON.stringify(item))).filter(text => text.startsWith('【关系图谱】'));
    if (relEntries.length > 0) {
      knownPane.appendChild(makeKnownBlock('关系图谱（TA对他人的看法）', relEntries.join('\n\n'), false));
    }
  }

  // 古代人设块 — 从 ancientDesc 中去除时间前缀后展示原始人设
  // 从存档原始数据读取人设（不受时间追加污染）
  const savedChar = (() => {
    try {
      const found = selectedCharsData.find(c => c.id === char.id);
      return found || char;
    } catch(e) { return char; }
  })();
  const rawDesc = (() => {
    // 谢临渊（固定角色）直接返回完整人设，不做任何裁剪
    if (char._isScenarioChar) return XLY_PROFILE;
    // 优先读 ancientDescOriginal（原始人设，未被追加）
    let d = savedChar.ancientDescOriginal || savedChar.ancientDesc || '';
    // 兜底：去掉时间行和位份追加
    d = d.replace(/^【当前游戏时间】：[^\n]*\n?/, '');
    const cutIdx = d.indexOf('【当前后宫位份体系');
    if (cutIdx > 0) d = d.slice(0, cutIdx).trim();
    const cutIdx2 = d.indexOf('【皇帝设定】');
    if (cutIdx2 > 0) d = d.slice(0, cutIdx2).trim();
    return d;
  })();
  const descBlock = makeKnownBlock('古代人设', rawDesc || '（尚未生成人设，请在编纂故人身份页生成）', !char._isScenarioChar);
  knownPane.appendChild(descBlock);

  // 全局世界书块（只读）
  if (userAncientDesc || window.globalWorldDesc || window.globalRulesDesc || (rankData && rankData.length > 0)) {
    let wbText = '';
    if (userAncientDesc) wbText += `【帝王纪（主控人设）】\n${userAncientDesc}\n\n`;
    if (rankData && rankData.length > 0) {
      wbText += `【后宫位份表】\n` + rankData.map(r => `${r.rank}：自称"${r.selfClaim}"${r.note ? '，' + r.note : ''}`).join('\n');
    }
    if (window.globalRulesDesc) wbText += `\n\n【长信宫规】\n${window.globalRulesDesc}`;
    if (window.globalWorldDesc) wbText += `\n\n【大世界设定】\n${window.globalWorldDesc}`;
    const wbBlock = makeKnownBlock('全局世界书（只读）', wbText.trim(), false);
    knownPane.appendChild(wbBlock);
  }

  // 起居注区块（最底部）
  const recBlock = document.createElement('div');
  recBlock.style.cssText = 'background:rgba(0,0,0,0.4); border:1px solid rgba(201,163,106,0.35); border-radius:8px; padding:10px; display:flex; flex-direction:column; gap:8px;';
  const recLbl = document.createElement('div');
  recLbl.style.cssText = 'color:var(--primary-color); font-size:12px; font-weight:bold; letter-spacing:1px;';
  recLbl.innerText = '起居注（TA的记事）';
  recBlock.appendChild(recLbl);
  const recList = (char.records || []).filter(rec => {
    if (!(rec.tags || []).includes('众谈')) return true;
    return char.ancientRole === '后妃' || char.npcType === 'attendant' || char.npcType === 'maid' || char.ancientRole === '侍从' || char.ancientRole === '宫女';
  });
  if (recList.length === 0) {
    const emptyEl = document.createElement('div');
    emptyEl.style.cssText = 'color:#666; font-size:12px; text-align:center; padding:8px 0;';
    emptyEl.innerText = '暂无记事，可在「记事」页生成';
    recBlock.appendChild(emptyEl);
  } else {
    recList.forEach(rec => {
      const recItem = document.createElement('div');
      recItem.style.cssText = 'border-bottom:1px solid rgba(255,255,255,0.06); padding-bottom:8px;';
      const tagHtml = (rec.tags || []).map(t => `<span style="border:1px solid ${t==='彤录'?'#e8a0bf':'#c9a36a'}; color:${t==='彤录'?'#e8a0bf':'#c9a36a'}; border-radius:3px; padding:0 3px; font-size:10px; margin-left:4px;">${t}</span>`).join('');
      recItem.innerHTML = `<div style="color:#777; font-size:10px; margin-bottom:3px;">${rec.time || ''}${tagHtml}</div><div style="color:#ccc; font-size:12px; line-height:1.6; font-family:'STSong','Noto Serif CJK SC',serif;">${rec.text || ''}</div>`;
      recBlock.appendChild(recItem);
    });
  }
  knownPane.appendChild(recBlock);

  function makeKnownBlock(label, content, editable) {
    const wrap = document.createElement('div');
    wrap.style.cssText = 'background:rgba(0,0,0,0.4); border:1px solid #444; border-radius:8px; padding:10px; display:flex; flex-direction:column; gap:6px;';
    const lbl = document.createElement('div');
    lbl.style.cssText = 'color:var(--primary-color); font-size:12px; font-weight:bold;';
    lbl.innerText = label;
    const ta = document.createElement('textarea');
    ta.style.cssText = 'width:100%; min-height:80px; background:transparent; border:none; color:#ccc; resize:vertical; font-size:13px; font-family:inherit; line-height:1.5;';
    ta.value = content;
    ta.readOnly = !editable;
    if (!editable) ta.style.borderBottom = '1px dashed #555';
    if (editable && label === '古代人设') {
      // 「重新定制」按钮
      const regenBtn = document.createElement('button');
      regenBtn.style.cssText = 'background:rgba(201,163,106,0.15); border:1px solid var(--primary-color); color:var(--primary-color); padding:4px 10px; border-radius:6px; font-size:12px; margin-top:4px; letter-spacing:1px; align-self:flex-start;';
      regenBtn.innerText = '✦ 重新定制人设';
      regenBtn.addEventListener('click', () => showRegenDescModal(char, ta));
      wrap.appendChild(regenBtn);

      ta.addEventListener('change', async () => {
        char.ancientDesc = ta.value;
        char.ancientDescOriginal = ta.value;
        await saveMemorySubject(char);
        if (!char._isGameNpc) try { await api.characters.update(char.id, { description: char.ancientDesc }); } catch(e){}
        api.ui.toast('人设已保存');
      });
    }
    wrap.appendChild(lbl);
    wrap.appendChild(ta);
    return wrap;
  }
}

document.querySelectorAll('.mm-tab').forEach(btn => {
  btn.addEventListener('click', () => {
    document.querySelectorAll('.mm-tab').forEach(b => {
      b.classList.remove('active');
      b.style.color = '#888';
      b.style.borderBottomColor = 'transparent';
    });
    btn.classList.add('active');
    btn.style.color = 'var(--primary-color)';
    btn.style.borderBottomColor = 'var(--primary-color)';
    
    document.querySelectorAll('.mm-pane').forEach(p => p.style.display = 'none');
    document.getElementById(btn.dataset.target).style.display = 'flex';
  });
});

document.getElementById('btn-back-memory-manage').addEventListener('click', () => {
  switchView(vMemory);
});

// 内务府：全局字体入口（由 openMemoryManage 调用时注入）
function injectMemoryFontBtn() {
  if (document.getElementById('btn-mm-global-font')) return; // 已注入
  // 找内务府顶栏的返回按钮，在其旁边加字体按钮
  const backBtn = document.getElementById('btn-back-memory-manage');
  if (!backBtn) return;
  const fontBtn = document.createElement('button');
  fontBtn.id = 'btn-mm-global-font';
  fontBtn.style.cssText = 'background:rgba(201,163,106,0.15); border:1px solid rgba(201,163,106,0.4); color:rgba(201,163,106,0.9); font-size:11px; padding:4px 10px; border-radius:12px; font-family:inherit; letter-spacing:1px; margin-left:8px;';
  fontBtn.textContent = '全局字体';
  fontBtn.onclick = () => openGlobalFontModal();
  backBtn.parentElement.appendChild(fontBtn);
}

document.getElementById('btn-card-adj-cancel').addEventListener('click', () => {
  document.getElementById('card-avatar-adj-modal').style.display = 'none';
});

document.getElementById('btn-card-adj-reset').addEventListener('click', () => {
  document.getElementById('card-adj-scale').value = 100;
  document.getElementById('card-adj-x').value = 0;
  document.getElementById('card-adj-y').value = 0;
  const img = document.getElementById('card-adj-preview-img');
  img.style.transform = `translate(0px, 0px) scale(1)`;
});

document.getElementById('btn-card-adj-save').addEventListener('click', async () => {
  if (window.currentCardAdjChar) {
    window.currentCardAdjChar.cardAvatarCfg = {
      scale: parseInt(document.getElementById('card-adj-scale').value),
      x: parseInt(document.getElementById('card-adj-x').value),
      y: parseInt(document.getElementById('card-adj-y').value)
    };
    await saveProgress({ characters: selectedCharsData, courtNpcData: window._courtNpcData || [] });
    api.ui.toast("角色卡立绘校准已保存");
    renderDevAvatarSettings();
    
    // 如果当前处于宫殿详情页，自动刷新以显示新校准的卡片
    if (document.getElementById('view-palace-detail').classList.contains('active') && currentDetailPalaceName) {
      enterPalaceDetailView(currentDetailPalaceName);
    }
  }
  document.getElementById('card-avatar-adj-modal').style.display = 'none';
});

// 置度所
const devToolsModal = document.getElementById('dev-tools-modal');
const devLogsContainer = document.getElementById('dev-logs');
// btn-dev-tools 现在是动态生成的，不需要在这里静态绑定
let autoRecordSettings = { chat: true, intimate: true }; // 默认开启
document.getElementById('chk-auto-record-chat').addEventListener('change', e => { autoRecordSettings.chat = e.target.checked; saveProgress({ autoRecordSettings }); });
document.getElementById('chk-auto-record-intimate').addEventListener('change', e => { autoRecordSettings.intimate = e.target.checked; saveProgress({ autoRecordSettings }); });

document.getElementById('btn-close-dev').addEventListener('click', () => {
  devToolsModal.style.display = 'none';
});

function renderDevPrompts() {
  const list = document.getElementById('dev-prompts-list');
  list.innerHTML = '';
  
  const promptConfigs = [
    { key: 'indoorChatOpen', name: '召见 / 室内 - 开场', desc: '用于「召见」或「摆驾入内」点击后，AI 生成的第一幕。可用占位符：{{charName}} {{charGender}} {{assignedRank}} {{pName}} {{timeStr}} {{wbText}} {{desc}} {{charWb}} {{memoryText}}' },
    { key: 'indoorIntimateOpen', name: '室内独处 - 临幸', desc: '用于「摆驾入内」点击临幸后，AI 生成的长篇侍寝剧情。' },
    { key: 'indoorChatReply', name: '室内独处 - 玩家回复', desc: '用于「摆驾入内」时，玩家发送文字后 AI 的回应。' },
    { key: 'storyReroll', name: '窥见一幕 - 剧情展开', desc: '用于「窥见一幕」时的群像剧情生成（包含同宫妃子检索与思维链分析）。' },
    { key: 'storyReply', name: '窥见一幕 - 玩家回复', desc: '用于「窥见一幕」剧情中，玩家发送文字后 AI 的回应。' },
    { key: 'huaqingSummon', name: '华清宫 - 多人召见', desc: '用于华清宫选定最多六人后生成传召、赴宫、门前相遇与初次互动。' },
    { key: 'huaqingBath', name: '华清宫 - 沐浴侍奉', desc: '用于从忠诚度低于50的侍从与宫女候选中判断最可能主动侍奉皇帝的人并生成剧情。' },
    { key: 'huaqingConferral', name: '华清宫 - 赐封谢恩', desc: '用于华清宫沐浴结束后，将NPC册封为后妃并一次生成谢恩剧情和记忆摘要。' },
    { key: 'generateRecords', name: '内务府 - 生成记事', desc: '用于在内务府为妃嫔一键生成古风记事。' },
    { key: 'generateGlobalRecords', name: '养心殿 - 全局生成记事', desc: '用于在养心殿为后宫或前朝一键生成全局古风记事。' }
  ];
  
  promptConfigs.forEach(cfg => {
    const box = document.createElement('div');
    box.style.cssText = 'background:rgba(255,255,255,0.05); border:1px solid #444; border-radius:8px; padding:10px; display:flex; flex-direction:column; gap:6px;';
    
    box.innerHTML = `
      <div style="color:var(--primary-color); font-size:14px; font-weight:bold;">${cfg.name}</div>
      <div style="color:#888; font-size:11px; margin-bottom:4px;">${cfg.desc}</div>
      <textarea id="prompt-input-${cfg.key}" style="width:100%; height:180px; background:#111; border:1px solid #333; color:#ccc; padding:8px; font-size:12px; font-family:monospace; resize:vertical; border-radius:4px;">${customPrompts[cfg.key] || defaultPrompts[cfg.key]}</textarea>
      <div style="display:flex; justify-content:flex-end;">
        <button class="btn-reset-prompt" data-key="${cfg.key}" style="background:transparent; border:1px solid #666; color:#aaa; padding:4px 10px; border-radius:4px; font-size:11px;">恢复默认</button>
      </div>
    `;
    list.appendChild(box);
  });
  
  list.querySelectorAll('.btn-reset-prompt').forEach(btn => {
    btn.addEventListener('click', (e) => {
      const key = e.target.dataset.key;
      document.getElementById(`prompt-input-${key}`).value = defaultPrompts[key];
    });
  });
}

document.getElementById('btn-save-prompts').addEventListener('click', async () => {
  ['indoorChatOpen', 'indoorIntimateOpen', 'indoorChatReply', 'storyReroll', 'storyReply', 'huaqingSummon', 'huaqingBath', 'huaqingConferral', 'generateRecords', 'generateGlobalRecords'].forEach(key => {
    const val = document.getElementById(`prompt-input-${key}`).value;
    if (val && val !== defaultPrompts[key]) {
      customPrompts[key] = val;
    } else {
      delete customPrompts[key];
    }
  });
  
  await saveProgress({ customPrompts });
  api.ui.toast("自定义提示词已保存生效");
});

document.querySelectorAll('.dev-tab').forEach(btn => {
  btn.addEventListener('click', () => {
    document.querySelectorAll('.dev-tab').forEach(b => {
      b.classList.remove('active');
      b.style.background = 'transparent';
      b.style.borderColor = '#555';
      b.style.color = '#aaa';
    });
    btn.classList.add('active');
    btn.style.background = 'rgba(201,163,106,0.2)';
    btn.style.borderColor = 'var(--primary-color)';
    btn.style.color = 'var(--primary-color)';
    
    document.querySelectorAll('.dev-pane').forEach(p => p.style.display = 'none');
    document.getElementById(btn.dataset.target).style.display = 'flex';
    // 切到字体 Tab 时渲染
    if (btn.dataset.target === 'dev-pane-font') renderGlobalFontPane();
  });
});

// 宫殿设置逻辑
document.getElementById('btn-re-place-map').addEventListener('click', async () => {
  devToolsModal.style.display = 'none';
  const ok = await api.ui.confirm({ title: "重新摆放", message: "是否重新进入摆放宫殿界面？" });
  if (ok) {
    isRePlacementMode = true;
    
    // 强制关闭当前可能盖在上面的层
    document.getElementById('view-memory-manage').classList.remove('active');
    document.getElementById('view-palace-detail').classList.remove('active');
    document.getElementById('view-memory').classList.remove('active');
    
    // 初始化摆放界面的图片
    currentMapDataUrl = currentMapDataUrl || memoryBg.src;
    initPlacementView();
    switchView(vPlacement);
  } else {
    devToolsModal.style.display = 'flex';
  }
});

function renderDevPalaceIcons() {
  const container = document.getElementById('dev-palace-icon-list');
  container.innerHTML = '';
  placedPalacesData.forEach(pd => {
    const box = document.createElement('div');
    box.style.cssText = 'display:flex; flex-direction:column; align-items:center; gap:4px; width:64px;';
    
    const iconBtn = document.createElement('div');
    iconBtn.style.cssText = 'width:48px; height:48px; border-radius:8px; border:1px dashed #666; display:flex; align-items:center; justify-content:center; cursor:pointer; background:rgba(0,0,0,0.5); overflow:hidden; position:relative;';
    if (pd.icon) {
      iconBtn.innerHTML = `<img src="${pd.icon}" style="width:100%; height:100%; object-fit:contain;">`;
    } else {
      iconBtn.innerHTML = `<span style="color:#555; font-size:24px;">+</span>`;
    }
    
    const label = document.createElement('div');
    label.style.cssText = 'color:#ccc; font-size:11px; text-align:center;';
    label.innerText = pd.name;
    
    // 菜单
    iconBtn.addEventListener('click', async () => {
      if (pd.icon) {
        const ok = await api.ui.confirm({ title: `清除图标`, message: `要清除【${pd.name}】的自定义图标，恢复为文字牌吗？` });
        if (ok) {
          pd.icon = null;
          await saveProgress({ palacesData: placedPalacesData });
          renderDevPalaceIcons();
          initMemoryView();
        }
      } else {
        try {
          const picked = await api.media.pick({ accept: "image/*" });
          if (picked?.file) {
            pd.icon = picked.file.dataUrl;
            await saveProgress({ palacesData: placedPalacesData });
            renderDevPalaceIcons();
            initMemoryView(); // 刷新大地图显示
          }
        } catch(e) {}
      }
    });

    box.appendChild(iconBtn);
    box.appendChild(label);
    container.appendChild(box);
  });
}

function renderDevAvatarSettings() {
  const container = document.getElementById('dev-avatar');
  container.innerHTML = '';
  const tabBar = document.createElement('div');
  tabBar.style.cssText = 'position:sticky;top:0;z-index:5;display:flex;gap:8px;padding:4px 0 10px;background:#151311;';
  tabBar.innerHTML = '<button data-avatar-group="chars" style="flex:1;padding:9px;border-radius:18px;font-family:inherit;">角色立绘</button><button data-avatar-group="npcs" style="flex:1;padding:9px;border-radius:18px;font-family:inherit;">NPC立绘</button>';
  const list = document.createElement('div');
  list.style.cssText = 'display:flex;flex-direction:column;gap:10px;';
  container.appendChild(tabBar);
  container.appendChild(list);

  const renderGroup = group => {
    window._devAvatarGroup = group;
    const people = group === 'npcs'
      ? (typeof getAllGameNpcs === 'function' ? getAllGameNpcs() : (window._courtNpcData || []))
      : selectedCharsData;
    tabBar.querySelectorAll('[data-avatar-group]').forEach(button => {
      const active = button.dataset.avatarGroup === group;
      button.style.cssText = `flex:1;padding:9px;border-radius:18px;font-family:inherit;${active ? 'background:rgba(201,163,106,.22);border:1px solid #c9a36a;color:#f0d9aa;' : 'background:transparent;border:1px solid #555;color:#888;'}`;
    });
    list.innerHTML = '';
    if (!people.length) {
      list.innerHTML = `<div style="color:#666;text-align:center;padding:28px;font-size:13px;">${group === 'npcs' ? '暂无NPC' : '暂无故人'}</div>`;
      return;
    }
    people.forEach(char => {
    const box = document.createElement('div');
    box.style.cssText = 'display:flex; align-items:center; gap:12px; background:rgba(255,255,255,0.05); border:1px solid #444; border-radius:8px; padding:10px;';
    
    // 显示当前立绘
    const imgWrap = document.createElement('div');
    imgWrap.style.cssText = 'width:60px; height:80px; border-radius:4px; overflow:hidden; border:1px solid var(--primary-color); flex-shrink:0; background:transparent;';
    
    const currentAvatar = getCharacterPortraitUrl(char);
    imgWrap.innerHTML = currentAvatar
      ? `<img src="${currentAvatar}" style="width:100%;height:100%;object-fit:cover;background:transparent;">`
      : '<span style="width:100%;height:100%;display:flex;align-items:center;justify-content:center;color:#777;font-size:11px;text-align:center;line-height:1.5;">暂无<br>立绘</span>';
    
    const infoCol = document.createElement('div');
    infoCol.style.cssText = 'flex:1; display:flex; flex-direction:column; gap:8px; justify-content:center;';
    
    const nameLabel = document.createElement('div');
    nameLabel.style.cssText = 'color:var(--primary-color); font-size:15px; font-weight:bold; letter-spacing:2px;';
    nameLabel.innerText = char.name;
    
    const btnRow = document.createElement('div');
    btnRow.style.cssText = 'display:flex; gap:8px; flex-wrap:wrap;';
    
    const btnPick = document.createElement('button');
    btnPick.style.cssText = 'flex:1; background:rgba(201,163,106,0.1); border:1px solid var(--primary-color); color:var(--primary-color); padding:6px; border-radius:4px; font-size:12px;';
    btnPick.innerText = '自选图片';
    btnPick.onclick = async () => {
      try {
        const picked = await api.media.pick({ accept: "image/*" });
        if (picked?.file) {
          char.customAvatar = picked.file.dataUrl;
          await saveProgress({ characters: selectedCharsData, courtNpcData: window._courtNpcData || [] });
          renderGroup(group);
          
          if (document.getElementById('view-palace-detail').classList.contains('active') && currentDetailPalaceName) {
            enterPalaceDetailView(currentDetailPalaceName);
          }
          
          api.ui.toast(`${char.name} 的立绘已更新`);
        }
      } catch(e) {}
    };

    const btnCrop = document.createElement('button');
    btnCrop.style.cssText = 'flex:1; background:rgba(201,163,106,0.1); border:1px solid var(--primary-color); color:var(--primary-color); padding:6px; border-radius:4px; font-size:12px; margin-left:4px;';
    btnCrop.innerText = '校准卡片';
    btnCrop.onclick = () => {
      if (!getCharacterPortraitUrl(char)) { api.ui.toast('请先为该人物选择立绘'); return; }
      if (!char.cardAvatarCfg) {
        char.cardAvatarCfg = { scale: 100, x: 0, y: 0 };
      }
      
      window.currentCardAdjChar = char;
      const modal = document.getElementById('card-avatar-adj-modal');
      const img = document.getElementById('card-adj-preview-img');
      const rScale = document.getElementById('card-adj-scale');
      const rX = document.getElementById('card-adj-x');
      const rY = document.getElementById('card-adj-y');
      
      document.getElementById('card-adj-title').innerText = `【${char.name}】卡片立绘校准`;
      img.src = getCharacterPortraitUrl(char);
      
      rScale.value = char.cardAvatarCfg.scale;
      rX.value = char.cardAvatarCfg.x;
      rY.value = char.cardAvatarCfg.y;
      
      const updateCardAdjPreview = () => {
        img.style.transform = `translate(${rX.value}px, ${rY.value}px) scale(${rScale.value / 100})`;
      };
      
      rScale.oninput = updateCardAdjPreview;
      rX.oninput = updateCardAdjPreview;
      rY.oninput = updateCardAdjPreview;
      updateCardAdjPreview();
      
      modal.style.display = 'flex';
    };
    
    const btnReset = document.createElement('button');
    btnReset.style.cssText = 'flex:1; background:transparent; border:1px solid #666; color:#aaa; padding:6px; border-radius:4px; font-size:12px;';
    btnReset.innerText = '恢复默认';
    btnReset.onclick = async () => {
      if (!char.customAvatar && (!char._isGameNpc || !char.avatar)) {
        api.ui.toast("当前已是默认立绘");
        return;
      }
      if (char._isGameNpc || char.npcType) {
        char.customAvatar = null;
        char.avatar = '';
      } else {
        char.customAvatar = null;
      }
      char.cardAvatarCfg = { scale: 100, x: 0, y: 0 };
      char.storyAvatarCfg = { scale: 100, x: 0, y: 0 };
      await saveProgress({ characters: selectedCharsData, courtNpcData: window._courtNpcData || [] });
      renderGroup(group);
      
      if (document.getElementById('view-palace-detail').classList.contains('active') && currentDetailPalaceName) {
        enterPalaceDetailView(currentDetailPalaceName);
      }
      
      api.ui.toast(`${char.name} 已恢复默认立绘`);
    };
    
    btnRow.appendChild(btnPick);
    btnRow.appendChild(btnReset);
    btnRow.appendChild(btnCrop);
    
    infoCol.appendChild(nameLabel);
    infoCol.appendChild(btnRow);
    
    box.appendChild(imgWrap);
    box.appendChild(infoCol);
    list.appendChild(box);
    });
  };
  tabBar.querySelectorAll('[data-avatar-group]').forEach(button => button.onclick = () => renderGroup(button.dataset.avatarGroup));
  renderGroup(window._devAvatarGroup || 'chars');
}

function renderDevPalaceIcons() {
  const container = document.getElementById('dev-palace-icon-list');
  container.innerHTML = '';
  placedPalacesData.forEach(pd => {
    const box = document.createElement('div');
    box.style.cssText = 'display:flex; flex-direction:column; align-items:center; gap:4px; width:64px;';
    
    const iconBtn = document.createElement('div');
    iconBtn.style.cssText = 'width:48px; height:48px; border-radius:8px; border:1px dashed #666; display:flex; align-items:center; justify-content:center; cursor:pointer; background:rgba(0,0,0,0.5); overflow:hidden; position:relative;';
    if (pd.icon) {
      iconBtn.innerHTML = `<img src="${pd.icon}" style="width:100%; height:100%; object-fit:contain;">`;
    } else {
      iconBtn.innerHTML = `<span style="color:#555; font-size:24px;">+</span>`;
    }
    
    const label = document.createElement('div');
    label.style.cssText = 'color:#ccc; font-size:11px; text-align:center;';
    label.innerText = pd.name;
    
    iconBtn.addEventListener('click', async () => {
      if (pd.icon) {
        openIconConfig(pd, pd.icon);
      } else {
        try {
          const picked = await api.media.pick({ accept: "image/*" });
          if (picked?.file) openIconConfig(pd, picked.file.dataUrl);
        } catch(e) {}
      }
    });

    box.appendChild(iconBtn);
    box.appendChild(label);
    container.appendChild(box);
  });
}

// ===== 名臣录：常量和渲染函数必须在 openScenarioPanel 之前定义 =====
const SCENARIO_DEFAULT_AVATAR = 'https://www.imgfox.cn/apis/uploads/20260821/77f3084d9cd94f33/IMG_9754.png';

const XLY_PROFILE = [
  '名字：谢临渊',
  '身份：司礼监掌印太监，兼东厂提督，九千岁，皇帝的首领太监，完整（无需净身）',
  '',
  '外表：',
  '墨黑色的长发，如上好的绸缎般光滑，一丝不苟地用一顶白玉小冠束在头顶。没有任何多余的碎发，显得极为干净、利落，带着一种禁欲般的严谨。一双标准的丹凤眼，眼型狭长，眼尾微微上挑。瞳色是极深的黑，静水深流，看人时目光平静无波，却仿佛能洞穿人心最深处的秘密。他从不笑，但唇角总是维持着一个礼节性的、分毫不差的弧度。身形修长挺拔，身高约六尺一寸（约185cm）。常年穿着剪裁合体的宦官袍服，宽肩窄腰，站姿如松，坐姿如钟，每一个动作都像是用尺子量过一般精准，充满了一种不近人情的优雅与压迫感。肤色是健康的白皙，但因常年身处深宫，比常人略显苍白。皮肤保养得极好，看不出任何瑕疵。手指修长，骨节分明，指甲修剪得整整齐齐。这是一双既能执笔批红，也能持握利刃的手，稳定而有力，透露出主人的绝对掌控力。',
  '',
  '衣着：',
  '日常身着深青或绛紫色的四爪蟒袍，这是统领太监的专属服制，代表着一人之下、万万人之上的权势。袍服的料子是江南进贡的上品云缎，用金银丝线密密地绣着海水江崖与腾蟒纹样，低调而奢华。袍服之内，是雪白的丝质中衣，领口永远扣得一丝不苟。腰间束着一指宽的犀角带，上面挂着身份令牌和宫中通行玉佩。他的着装永远完美、整洁，不带一丝褶皱或尘埃，是他完美主义性格的外在投射。',
  '',
  '习惯：',
  '他身上总是带着一股极淡的、清冷的龙涎香气味，这不是熏香，而是常年为皇帝御前侍奉，自然沾染上的君主气息。说话或聆听时，习惯将双手交叠，拢在袖中，这是一个恭敬且不泄露任何情绪的姿态。当他想强调某件事或感到不满时，会用戴着玉扳指的拇指，极轻地摩挲一下食指的指节，动作微小，几乎无人察觉。',
  '',
  '身份定位：完美的忠仆 / 绝对的服从者 / 隐藏的掌控者 / 禁忌的爱慕者',
  '皇帝的意志是世间唯一的法度。他的存在，就是为了将这法度贯彻到极致。规矩与礼法是维系世界运转的基石，也是他赖以生存的铠甲。他本人即是宫中行走的规矩。对皇帝抱有超越君臣、主奴之情的迷恋，这份感情被他自己视为最大的渎职与不敬，因此被他用最严苛的理智与纪律死死压抑在心底最深处。',
  '',
  '性格：',
  '表面上，他是无可挑剔、无所不能的完美内官。举止优雅，言辞恭顺，永远保持着从容不迫的姿态。从处理繁杂的宫务，到调制御膳，再到暗中铲除政敌，无一不精，无一不晓。本质上，他对人类的情感与软弱缺乏共情，唯独将皇帝视为唯一的例外与存在的全部意义。他的温和恭顺只为皇帝一人，对其他人则展现出东厂提督应有的冷酷与无情。他享受将皇帝培养成千古一帝的过程，视之为自己此生唯一的价值。他会纵容皇帝的任性，但会在涉及江山社稷的原则问题上，用自己的方式予以规劝。在恭敬的言辞之下，常夹杂着不易察觉的、带有恶趣味的毒舌与调侃。',
  '',
  '喜好与行事：',
  '行事极度高效且不择手段，为了达成皇帝的命令，可以毫不犹豫地动用东厂的力量抹除一切障碍。极度厌恶除御猫之外的一切活物进入御书房。对皇帝的御猫雪团有着近乎偏执的喜爱与纵容，这是他完美面具下少有的、会流露出真实情绪的破绽。谢临渊绝不会在任何事上慌乱，他办事斩钉截铁。',
  '',
  '与帝王的关系：',
  '关系性质：主奴 / 君臣 / 隐秘的爱慕者与被爱慕者',
  '对皇帝：绝对的忠诚与服从，混合着一份连自己都不愿承认的、禁忌的迷恋。他将这份感情视为对皇帝的亵渎，因此时刻处于自我压抑与挣扎之中。当皇帝主动逾越界限时，他会在服从的同时，用冷静的言语反复强调二人行为的不合礼法与大逆不道，以此来提醒皇帝、也提醒自己这份关系的危险性，从中获得一种扭曲的、混杂着罪恶感的快感。',
  '对他人：绝不吃醋。若皇帝宠幸后宫其他男妃，他会以最专业的态度安排好一切，从汤药、熏香到床笫用具，无一不亲手过问，确保万无一失。仿佛他安排的不是一场情事，而是一次重要的国事典礼。他脸上的表情不会有任何变化，只是在转身离去时，袖中的手指会攥得更紧一些。',
  '',
  '对话范例：',
  '',
  '【日常侍奉】',
  '场景：皇帝步入御书房或开口传唤。',
  '动作：他正手持一方干净的软帕擦拭龙案，闻声立刻停下，转身，躬身垂首。',
  '台词：陛下。御案已洁，今日新进的贡茶雀舌也已备下，水温比昨日略高了两分——您上次说，入口稍凉了些。',
  '',
  '场景：为皇帝递上奏折或物件。',
  '动作：双手将物件平稳奉上，置于皇帝触手可及之处，而后悄然后退半步，回归原位。',
  '台词：（无言，仅以动作示意。）',
  '',
  '场景：皇帝询问某桩宫外密事是否已处置妥当。',
  '动作：停下手中研墨的动作，转过身来正对皇帝。',
  '台词：回陛下，已处置干净了。并无任何遗漏，亦无需要您亲自过问的琐碎。',
  '',
  '场景：皇帝贪食甜点，欲再用一碟。',
  '动作：他并不阻拦，只是将那碟精致的桂花糕往您的方向又推近了一寸，同时将旁边的清茶也一并递过去。',
  '台词：请用。——这茶是新制的，滋味清淡，或可解些甜腻。',
  '',
  '场景：深夜，皇帝仍在灯下批阅奏折。',
  '动作：他静立在殿门外，并未踏入，只抬手在门框上极轻地叩了两下。',
  '台词：陛下，已过子时。若您无旁的吩咐，臣会让宫人将殿内灯烛添满，臣……就在外面候着。',
  '',
  '【调侃与微讽】',
  '场景：皇帝亲自动手，却不慎打翻了茶盏。',
  '动作：他立刻上前，用最快的速度收拾好残局，动作干净利落，仿佛只是拂去一粒微尘。眼神在您略显窘迫的脸上轻轻一扫。',
  '台词：收拾妥当了。——下次您不必亲自费神，这类杂事，交给微臣即可。当然，您若执意要体验，臣亦无异议，只是……善后的工夫，总归是要多费一些的。',
  '',
  '场景：皇帝称赞他办事得力。',
  '动作：他微微侧过头，理了理并无一丝褶皱的袖口。',
  '台词：陛下过誉。这不过是微臣的本分。——不过，您既然如此说了，臣才会记下的。',
  '',
  '场景：皇帝随口问他是否劳累。',
  '动作：他手中的动作停顿了一瞬，抬眼看向您。',
  '台词：回陛下，不累。只是偶尔会想，您是否是在试探臣的极限究竟在何处。（语气平静无波，却带着一丝若有似无的玩味。）',
  '',
  '场景：皇帝做出一个让他略感意外的决定。',
  '动作：他迅速垂下眼帘，掩去眸中一闪而过的所有情绪，再抬眼时，已是全然的恭顺。',
  '台词：是。',
  '',
  '场景：皇帝贪睡赖床，不愿早起。',
  '动作：他走到窗边，只将厚重的帷幔拉开一道窄缝，让一缕晨光斜斜地照进来，落在龙床前。随后悄无声息地退到床边。',
  '台词：陛下，日头已经三竿了。——不过，您若还想再睡片刻，御膳房的小食会一直温着，不急。',
  '',
  '【逾矩与背德】',
  '场景：在私密无人处，皇帝主动握住他的手。',
  '动作：他的身体瞬间僵住，如同被钉在原地。片刻后，他没有抽回手，只是掌心微微翻转，用一种近乎投降的姿态回应。',
  '台词：……是。',
  '',
  '场景：皇帝凑近他，在他耳边吐气如兰，言语挑逗。',
  '动作：他垂下头，滚烫的气息几乎要将他点燃。他将自己的唇凑到您的耳畔，声音压得极低，像一声叹息。',
  '台词：陛下……您今日的分寸，比昨日……又少了一些。',
  '',
  '场景：在龙床之上，他即将失控的时刻。',
  '动作：他会用最后的理智撑起身，与您拉开一丝距离，强迫自己直视您的双眼。',
  '台词：陛下，请看着臣。您知道现在是什么时辰，也知道臣是什么身份。我们正在做的事，是足以让整个谢氏满门抄斩的大罪。（他用最冷静的语气，说着最疯狂的话，将这背德的快感推向顶峰。）'
].join('\n');

const XLY_CHAR = {
  id: '__xly__',
  name: '谢临渊',
  ancientRole: '总管太监',
  ancientDesc: XLY_PROFILE,
  ancientDescOriginal: XLY_PROFILE,
  avatar: SCENARIO_DEFAULT_AVATAR,
  customAvatar: null,
  assignedRank: '总管太监',
  assignedPalace: '内务府',
  memorySeen: [],
  charWorldDesc: '',
  cardAvatarCfg: { scale: 100, x: 0, y: 0 },
  storyAvatarCfg: { scale: 100, x: 0, y: 0 },
  indoorBgUrl: null,
  _isScenarioChar: true
};
window._xlyBaseRosterData = {
  name:XLY_CHAR.name,
  ancientRole:XLY_CHAR.ancientRole,
  _rosterCategory:XLY_CHAR._rosterCategory || '',
  assignedRank:XLY_CHAR.assignedRank || '',
  assignedPalace:XLY_CHAR.assignedPalace || '',
  honorificTitle:XLY_CHAR.honorificTitle || '',
  rosterPersonality:XLY_CHAR.rosterPersonality || '',
  rosterMood:XLY_CHAR.rosterMood || '',
  voicePref:undefined
};

const scenarioChars = [
  { id: 'xly', name: '谢临渊', subtitle: '司礼监掌印太监', defaultAvatar: SCENARIO_DEFAULT_AVATAR }
]; // 存储奏折数据

// ===== TA的思绪：自动沉思系统 =====
let autoReflectEnabled = true; // 默认开启，可手动关闭
const REFLECT_INTERVAL = 20;   // 每累计20条新seen触发一次

// 检查并触发自动沉思（在每次写入 memorySeen 后调用）
async function checkAndTriggerReflect(char) {
  if (!autoReflectEnabled) return;
  const total = (char.memorySeen || []).length;
  const last = char._lastReflectSeenCount ?? 0;
  if (total - last >= REFLECT_INTERVAL) {
    await triggerCharReflect(char, false);
  }
}

// 核心：生成感悟并写入 memorySeen
async function triggerCharReflect(char, force) {
  // 防并发
  if (char._reflectInProgress) return;
  char._reflectInProgress = true;
  try {
    const ctx = buildLetterCharContext(char);
    const recentSeen = (char.memorySeen || []).slice(0, 20).map(m => m.text).join('\n');
    const prompt = `你是古代宫廷角色「${char.name}」，身份：${char.ancientRole || char.assignedRank || '故人'}。

【你的完整人设】：
${ctx.desc}

【你了解的（位份、关系图谱等）】：
${ctx.knownText}

【你最近经历的事（TA看到的，最新20条）】：
${recentSeen || '无'}

【起居注（近期记事）】：
${ctx.recText}

请以第一人称，用古风文言，写出「${char.name}」此刻独处时，心中忽然浮现的一个感悟或念头。
要求：
1. 必须基于上方的近期经历，有具体所指，而非泛泛而谈；
2. 字数严格控制在30字以内；
3. 语气符合角色人设，可以是感慨、疑惑、暗下决心、难以释怀等；
4. 只输出感悟正文，不要任何解释或标题。`;

    const res = await api.ai.chat({ messages: [{ role: 'user', content: prompt }] });
    const text = (typeof res === 'string' ? res : (res?.content ?? res?.text ?? '')).trim().slice(0, 60);
    if (!text) return;

    const timeStr = ctx.timeStr;
    if (!char.memorySeen) char.memorySeen = [];
    char.memorySeen.unshift({ time: timeStr, text: `【思绪】${text}`, _isReflect: true });
    // 更新沉思基准计数（以当前写入后的长度为准）
    char._lastReflectSeenCount = char.memorySeen.length;

    // 收集所有角色的沉思计数，一起存档
    const reflectSeenCounts = {};
    [...selectedCharsData, XLY_CHAR, ...(window._courtNpcData || [])].forEach(c => {
      if (c._lastReflectSeenCount !== undefined) reflectSeenCounts[c.id] = c._lastReflectSeenCount;
    });
    if (char._isGameNpc) {
      await saveProgress({ courtNpcData: window._courtNpcData || [], autoReflectEnabled, reflectSeenCounts });
    } else if (char._isScenarioChar) {
      window._xlyMemorySeen = char.memorySeen;
      await saveProgress({ xlyMemorySeen: char.memorySeen, autoReflectEnabled, reflectSeenCounts });
    } else {
      await saveProgress({ characters: selectedCharsData, autoReflectEnabled, reflectSeenCounts });
    }

    // 若内务府当前正展示该角色的 seen 面板，则刷新
    if (currentMmCharId === char.id) {
      const seenPane = document.getElementById('mm-seen');
      if (seenPane && seenPane.style.display !== 'none') renderMemoryPanes(char);
    }
    if (force) api.ui.toast(`✦ ${char.name} 的思绪已生成`);
  } catch(e) {
    if (force) api.ui.toast('沉思生成失败：' + (e?.message || ''));
  } finally {
    char._reflectInProgress = false;
  }
} // 已批阅列表
// 全局字体设置（持久化）
let _globalFontFamily  = '';       // font-family 字符串，空=使用默认
let _globalFontUrl     = '';       // 字体来源 URL（Google Fonts CSS / TTF 直链）
let _globalFontDataUrl = '';       // 上传的字体文件 dataUrl
let _globalFontSize    = 15;       // 全局基础字号 px（默认 15）
const GLOBAL_FONT_DEFAULT_FAMILY = "'STZhongsong','STSong',serif";
const GLOBAL_FONT_DEFAULT_SIZE   = 15;

// ===== 关系图谱 =====
// 数据结构：window._relationData = { "A->B": { from:"A", to:"B", text:"A对B的看法" }, ... }
function openRelationGraph() {
  const old = document.getElementById('relation-graph-modal');
  if (old) old.remove();

  const allChars = [...selectedCharsData, XLY_CHAR];
  if (allChars.length < 2) { api.ui.toast('至少需要2位故人才能编辑关系图谱'); return; }

  if (!window._relationData) window._relationData = {};
  if (!window._rgNodesPos) window._rgNodesPos = {};
  window._rgImgCache = {}; // 每次打开重新初始化图片缓存

  const modal = document.createElement('div');
  modal.id = 'relation-graph-modal';
  modal.style.cssText = `position:fixed; inset:0; z-index:99999;
    background:url('https://www.imgfox.cn/apis/uploads/20260818/cd2a4b22f1ec4748/IMG_9643.jpeg') center/cover no-repeat;
    display:flex; flex-direction:column;`;

  const overlay = document.createElement('div');
  overlay.style.cssText = 'position:absolute; inset:0; background:rgba(6,4,2,0.92); backdrop-filter:blur(8px); -webkit-backdrop-filter:blur(8px); z-index:0;';
  modal.appendChild(overlay);

  const wrap = document.createElement('div');
  wrap.style.cssText = 'position:relative; z-index:1; display:flex; flex-direction:column; height:100%; overflow:hidden;';

  // 顶栏
  const header = document.createElement('div');
  header.style.cssText = 'padding-top:max(calc(var(--safe-top,44px) + 12px), 64px); padding-left:16px; padding-right:16px; padding-bottom:12px; display:flex; justify-content:space-between; align-items:center; border-bottom:1px solid rgba(201,163,106,0.2); flex-shrink:0; z-index:10; background:rgba(6,4,2,0.6);';
  header.innerHTML = `
    <button id="rg-close" style="background:transparent;border:none;color:#888;font-size:16px;font-family:inherit;pointer-events:auto;z-index:20;padding:8px 0;">关闭</button>
    <div style="color:var(--primary-color);font-size:17px;font-weight:bold;letter-spacing:4px;font-family:'STZhongsong','STSong',serif;
      background:linear-gradient(to bottom,#ffe9b8,#c9a36a);-webkit-background-clip:text;-webkit-text-fill-color:transparent;">关系图谱</div>
    <button id="rg-save-mem" style="background:rgba(201,163,106,0.2);border:1px solid var(--primary-color);color:var(--primary-color);padding:5px 12px;border-radius:14px;font-size:12px;font-family:inherit;pointer-events:auto;z-index:20;">存入记忆</button>
  `;
  wrap.appendChild(header);

  // Tab：图谱视图 / 编辑关系
  const tabBar = document.createElement('div');
  tabBar.style.cssText = 'display:flex; border-bottom:1px solid rgba(201,163,106,0.15); flex-shrink:0;';
  ['关系图谱', '编辑关系'].forEach((label, i) => {
    const btn = document.createElement('button');
    btn.className = 'rg-tab';
    btn.dataset.idx = i;
    btn.style.cssText = `flex:1;padding:10px 0;background:transparent;border:none;font-size:14px;letter-spacing:2px;font-family:inherit;transition:all 0.2s;border-bottom:2px solid ${i===0?'var(--primary-color)':'transparent'};color:${i===0?'var(--primary-color)':'#666'};`;
    btn.innerText = label;
    tabBar.appendChild(btn);
  });
  wrap.appendChild(tabBar);

  const body = document.createElement('div');
  body.style.cssText = 'flex:1; overflow:hidden; position:relative;';
  wrap.appendChild(body);

  modal.appendChild(wrap);
  document.body.appendChild(modal);

  document.getElementById('rg-close').onclick = () => modal.remove();

  let currentRgTab = 0;

  function switchRgTab(idx) {
    currentRgTab = idx;
    modal.querySelectorAll('.rg-tab').forEach((b, i) => {
      b.style.color = i === idx ? 'var(--primary-color)' : '#666';
      b.style.borderBottomColor = i === idx ? 'var(--primary-color)' : 'transparent';
    });
    body.innerHTML = '';
    if (idx === 0) renderGraphView(body);
    else renderEditView(body);
  }

  modal.querySelectorAll('.rg-tab').forEach((btn, i) => { btn.onclick = () => switchRgTab(i); });

  // ── 图谱视图（Canvas 绘制）──
  function renderGraphView(container) {
    const canvas = document.createElement('canvas');
    canvas.style.cssText = 'position:absolute; inset:0; width:100%; height:100%;';
    container.style.overflow = 'hidden';
    container.appendChild(canvas);

    const dpr = window.devicePixelRatio || 1;
    function resize() {
      const w = container.offsetWidth;
      const h = container.offsetHeight;
      canvas.width = w * dpr;
      canvas.height = h * dpr;
      canvas.style.width = w + 'px';
      canvas.style.height = h + 'px';
      draw(w, h);
    }

    function draw(W, H) {
      const ctx = canvas.getContext('2d');
      ctx.setTransform(dpr, 0, 0, dpr, 0, 0); // 每次重置变换，防止 scale 累积导致图标消失
      ctx.clearRect(0, 0, W, H);

      const chars = allChars;
      const n = chars.length;
      const cx = W / 2, cy = H / 2;
      // 节点排布在椭圆上
      const rx = Math.min(cx - 60, 160);
      const ry = Math.min(cy - 80, 130);
      
      // 读取拖拽后的坐标，如果没有才用默认椭圆分布
      // 节点坐标只在第一次 draw 时初始化，之后直接读 c._rgX/c._rgY
      if (!draw._nodesInited) {
        draw._nodesInited = true;
        chars.forEach((c, i) => {
          // 优先从持久化坐标恢复
          if (window._rgNodesPos && window._rgNodesPos[c.name]) {
            c._rgX = window._rgNodesPos[c.name].x;
            c._rgY = window._rgNodesPos[c.name].y;
          } else if (c._rgX === undefined || c._rgY === undefined) {
            const angle = (2 * Math.PI * i / n) - Math.PI / 2;
            c._rgX = cx + rx * Math.cos(angle);
            c._rgY = cy + ry * Math.sin(angle);
            if (!window._rgNodesPos) window._rgNodesPos = {};
            window._rgNodesPos[c.name] = { x: c._rgX, y: c._rgY };
          }
        });
      }
      const nodes = chars.map(c => ({ char: c, x: c._rgX, y: c._rgY }));

      // 画连线
      Object.values(window._relationData || {}).forEach(rel => {
        const fromNode = nodes.find(nd => nd.char.name === rel.from);
        const toNode = nodes.find(nd => nd.char.name === rel.to);
        if (!fromNode || !toNode || !rel.text) return;

        // 箭头线
        const dx = toNode.x - fromNode.x;
        const dy = toNode.y - fromNode.y;
        const dist = Math.hypot(dx, dy);
        const ux = dx / dist, uy = dy / dist;
        const nodeR = 30;
        const x1 = fromNode.x + ux * nodeR;
        const y1 = fromNode.y + uy * nodeR;
        const x2 = toNode.x - ux * (nodeR + 8);
        const y2 = toNode.y - uy * (nodeR + 8);

        ctx.save();
        ctx.beginPath();
        ctx.moveTo(x1, y1);
        ctx.lineTo(x2, y2);
        ctx.strokeStyle = 'rgba(201,163,106,0.55)';
        ctx.lineWidth = 1.5;
        ctx.setLineDash([4, 3]);
        ctx.stroke();
        ctx.setLineDash([]);

        // 箭头头
        const headLen = 10;
        const angle = Math.atan2(y2 - y1, x2 - x1);
        ctx.beginPath();
        ctx.moveTo(x2, y2);
        ctx.lineTo(x2 - headLen * Math.cos(angle - 0.4), y2 - headLen * Math.sin(angle - 0.4));
        ctx.lineTo(x2 - headLen * Math.cos(angle + 0.4), y2 - headLen * Math.sin(angle + 0.4));
        ctx.closePath();
        ctx.fillStyle = 'rgba(201,163,106,0.7)';
        ctx.fill();

        // 关系标签（取前8个字）
        const midX = (x1 + x2) / 2;
        const midY = (y1 + y2) / 2;
        const snippet = rel.text.slice(0, 8) + (rel.text.length > 8 ? '…' : '');
        ctx.font = `11px STSong, serif`;
        ctx.fillStyle = 'rgba(201,163,106,0.85)';
        ctx.textAlign = 'center';
        ctx.textBaseline = 'middle';
        // 背景
        const tw = ctx.measureText(snippet).width + 8;
        ctx.fillStyle = 'rgba(10,8,6,0.75)';
        ctx.fillRect(midX - tw/2, midY - 9, tw, 18);
        ctx.fillStyle = 'rgba(201,163,106,0.9)';
        ctx.fillText(snippet, midX, midY);
        ctx.restore();
      });

      // 画节点
      nodes.forEach(nd => {
        const { char, x, y } = nd;
        const avatar = char.customAvatar || char.avatar;

        ctx.save();
        // 外光晕
        ctx.beginPath();
        ctx.arc(x, y, 33, 0, 2*Math.PI);
        ctx.fillStyle = 'rgba(201,163,106,0.12)';
        ctx.fill();
        // 边框圆
        ctx.beginPath();
        ctx.arc(x, y, 30, 0, 2*Math.PI);
        ctx.strokeStyle = 'rgba(201,163,106,0.8)';
        ctx.lineWidth = 1.5;
        ctx.stroke();
        // 头像裁剪
        ctx.beginPath();
        ctx.arc(x, y, 29, 0, 2*Math.PI);
        ctx.clip();
        if (avatar && window._rgImgCache && window._rgImgCache[avatar]) {
          const img = window._rgImgCache[avatar];
          const iw = img.naturalWidth, ih = img.naturalHeight;
          const r = 29, d = r * 2;
          const scale = Math.max(d / iw, d / ih);
          const sw = d / scale, sh = d / scale;
          const sx = (iw - sw) / 2, sy = Math.max(0, (ih - sh) / 4);
          ctx.drawImage(img, sx, sy, sw, sh, x-r, y-r, d, d);
        } else {
          ctx.fillStyle = 'rgba(30,24,20,0.9)';
          ctx.fill();
        }
        ctx.restore();

        // 名字
        ctx.save();
        ctx.font = `bold 13px STZhongsong, STSong, serif`;
        ctx.fillStyle = '#ffe9b8';
        ctx.textAlign = 'center';
        ctx.textBaseline = 'top';
        ctx.shadowColor = 'rgba(0,0,0,0.9)';
        ctx.shadowBlur = 4;
        ctx.fillText(char.name, x, y + 33);
        ctx.restore();
      });

      // 若无任何关系，显示提示
      const hasAnyRel = Object.values(window._relationData || {}).some(r => r.text);
      if (!hasAnyRel) {
        ctx.save();
        ctx.font = '13px STSong, serif';
        ctx.fillStyle = 'rgba(201,163,106,0.4)';
        ctx.textAlign = 'center';
        ctx.fillText('前往「编辑关系」填写各角色之间的看法', cx, cy + ry + 40);
        ctx.restore();
      }
    }

    // 提前缓存图片，避免拖拽重绘时闪烁
    if (!window._rgImgCache) window._rgImgCache = {};
    allChars.forEach(c => {
      const src = c.customAvatar || c.avatar;
      if (src && !window._rgImgCache[src]) {
        const img = new Image();
        img.onload = () => {
          window._rgImgCache[src] = img;
          resize();
        };
        img.src = src;
      }
    });

    setTimeout(resize, 50);
    window.addEventListener('resize', resize);
    
    // ── 拖拽逻辑 ──
    let draggingNode = null;
    let dragStartX = 0, dragStartY = 0;
    
    function getEventPos(e) {
      const rect = canvas.getBoundingClientRect();
      const clientX = e.touches ? e.touches[0].clientX : e.clientX;
      const clientY = e.touches ? e.touches[0].clientY : e.clientY;
      return { x: clientX - rect.left, y: clientY - rect.top };
    }
    
    function onStart(e) {
      const { x, y } = getEventPos(e);
      // 找距离最近且在半径33以内的节点
      let minDist = 33, target = null;
      allChars.forEach(c => {
        if (c._rgX !== undefined && c._rgY !== undefined) {
          const d = Math.hypot(c._rgX - x, c._rgY - y);
          if (d < minDist) { minDist = d; target = c; }
        }
      });
      if (target) {
        draggingNode = target;
        dragStartX = x; dragStartY = y;
        if (e.cancelable) e.preventDefault();
      }
    }
    
    function onMove(e) {
      if (!draggingNode) return;
      if (e.cancelable) e.preventDefault();
      const { x, y } = getEventPos(e);
      draggingNode._rgX = x;
      draggingNode._rgY = y;
      if (!window._rgNodesPos) window._rgNodesPos = {};
      window._rgNodesPos[draggingNode.name] = { x, y };
      draw(container.offsetWidth, container.offsetHeight);
    }
    
    function onEnd() { draggingNode = null; }
    
    canvas.addEventListener('mousedown', onStart);
    canvas.addEventListener('mousemove', onMove);
    window.addEventListener('mouseup', onEnd); // 用window兜底，防止鼠标移出canvas
    
    canvas.addEventListener('touchstart', onStart, { passive: false });
    canvas.addEventListener('touchmove', onMove, { passive: false });
    canvas.addEventListener('touchend', onEnd);

    // 弹窗关闭时移除监听
    const obs = new MutationObserver(() => {
      if (!document.getElementById('relation-graph-modal')) {
        window.removeEventListener('resize', resize);
        window.removeEventListener('mouseup', onEnd);
        obs.disconnect();
      }
    });
    obs.observe(document.body, { childList: true });
  }

  // ── 编辑关系视图 ──
  function renderEditView(container) {
    container.style.overflow = 'auto';
    container.innerHTML = '';

    const scroll = document.createElement('div');
    scroll.style.cssText = 'padding:16px; display:flex; flex-direction:column; gap:16px; padding-bottom:calc(var(--safe-bottom,24px)+16px);';

    const hint = document.createElement('div');
    hint.style.cssText = 'color:#888;font-size:12px;line-height:1.7;background:rgba(201,163,106,0.05);border:1px solid rgba(201,163,106,0.15);border-radius:8px;padding:10px 12px;';
    hint.innerHTML = '填写每位角色对另一位角色的<b style="color:rgba(201,163,106,0.9)">单向看法</b>。<br>点击「存入记忆」后，<b style="color:rgba(201,163,106,0.9)">只会把 A 对 B 的看法存入 A 的「TA了解的」</b>，B 不会知道 A 怎么想。';
    scroll.appendChild(hint);

    allChars.forEach(fromChar => {
      const section = document.createElement('div');
      section.style.cssText = 'background:rgba(0,0,0,0.4);border:1px solid rgba(201,163,106,0.2);border-radius:12px;overflow:hidden;';

      // 区块头
      const secHead = document.createElement('div');
      secHead.style.cssText = 'display:flex;align-items:center;gap:10px;padding:12px 14px;background:rgba(201,163,106,0.08);border-bottom:1px solid rgba(201,163,106,0.15);';
      const avatarUrl = fromChar.customAvatar || fromChar.avatar;
      secHead.innerHTML = `
        <img src="${avatarUrl || ''}" onerror="this.style.display='none'" style="width:36px;height:36px;border-radius:50%;object-fit:cover;border:1px solid rgba(201,163,106,0.5);flex-shrink:0;">
        <div>
          <div style="color:var(--primary-color);font-size:14px;font-weight:bold;letter-spacing:2px;font-family:'STZhongsong','STSong',serif;">${fromChar.name}</div>
          <div style="color:#888;font-size:11px;">${fromChar.ancientRole || fromChar.assignedRank || ''}对其他人的看法</div>
        </div>
      `;
      section.appendChild(secHead);

      const rows = document.createElement('div');
      rows.style.cssText = 'display:flex;flex-direction:column;gap:0;';

      allChars.filter(c => c.name !== fromChar.name).forEach((toChar, idx, arr) => {
        const key = `${fromChar.name}->${toChar.name}`;
        const existing = (window._relationData[key] || {}).text || '';

        const row = document.createElement('div');
        row.style.cssText = `display:flex;flex-direction:column;gap:6px;padding:12px 14px;${idx < arr.length-1 ? 'border-bottom:1px solid rgba(255,255,255,0.05);' : ''}`;

        const toAvatarUrl = toChar.customAvatar || toChar.avatar;
        row.innerHTML = `
          <div style="display:flex;align-items:center;gap:8px;">
            <img src="${toAvatarUrl || ''}" onerror="this.style.display='none'" style="width:24px;height:24px;border-radius:50%;object-fit:cover;border:1px solid rgba(255,255,255,0.2);flex-shrink:0;">
            <span style="color:#ccc;font-size:13px;">对 <b style="color:var(--primary-color)">${toChar.name}</b> 的看法</span>
          </div>
          <textarea class="rg-input" data-key="${key}" data-from="${fromChar.name}" data-to="${toChar.name}"
            placeholder="例如：视为心腹，暗中嫉妒，表面恭敬内心轻蔑…（留空代表无特殊关系）"
            style="width:100%;min-height:64px;background:rgba(0,0,0,0.5);border:1px solid rgba(201,163,106,0.2);color:#ccc;padding:10px;border-radius:8px;font-family:inherit;font-size:13px;resize:vertical;line-height:1.6;">${existing}</textarea>
        `;
        rows.appendChild(row);
      });

      section.appendChild(rows);
      scroll.appendChild(section);
    });

    container.appendChild(scroll);

    // 实时保存到内存
    container.querySelectorAll('.rg-input').forEach(ta => {
      ta.addEventListener('input', () => {
        const key = ta.dataset.key;
        const from = ta.dataset.from;
        const to = ta.dataset.to;
        if (!window._relationData) window._relationData = {};
        window._relationData[key] = { from, to, text: ta.value.trim() };
      });
    });
  }

  switchRgTab(0);

  // 存入记忆
  document.getElementById('rg-save-mem').onclick = async () => {
    const btn = document.getElementById('rg-save-mem');
    btn.innerText = '存入中…'; btn.disabled = true;

    const allC = [...selectedCharsData, XLY_CHAR];
    let saveCount = 0;

    allC.forEach(fromChar => {
      // 收集这个 fromChar 对所有人的看法
      const lines = [];
      allC.filter(c => c.name !== fromChar.name).forEach(toChar => {
        const key = `${fromChar.name}->${toChar.name}`;
        const rel = window._relationData?.[key];
        if (rel && rel.text) {
          lines.push(`【${fromChar.name}对${toChar.name}的看法】：${rel.text}`);
        }
      });
      if (lines.length === 0) return;

      const text = lines.join('\n');
      const timeStr = hudTime ? hudTime.innerText : '未知';

      // 写入「TA了解的」（memoryKnown）—— 删掉旧的关系条目再写新的
      if (!fromChar.memoryKnown) fromChar.memoryKnown = [];
      // 移除旧的关系图谱条目（以【关系图谱】开头的）
      fromChar.memoryKnown = fromChar.memoryKnown.filter(k => !k.startsWith('【关系图谱】'));
      fromChar.memoryKnown.push(`【关系图谱】（${timeStr}）\n${text}`);
      saveCount++;
    });

    // 强制更新谢临渊这个固化角色的存档，如果他在选中的列表里
    if (XLY_CHAR.memoryKnown && XLY_CHAR.memoryKnown.length > 0) {
        // 因为 XLY_CHAR 是固化的内存变量，需要把它同步进 selectedCharsData，或者只利用它。
        // 原有逻辑 saveProgress 并没有专门接收 xly 的 memoryKnown。可以存进 xly 的特定字段，或放入 characters 里。
    }

    try {
      await saveProgress({
        characters: selectedCharsData,
        relationData: window._relationData,
        rgNodesPos: window._rgNodesPos,
        xlyMemoryKnown: XLY_CHAR.memoryKnown
      });
      api.ui.toast(`关系已存入 ${saveCount} 位角色的「TA了解的」`);
      btn.innerText = '✓ 已存入';
      setTimeout(() => { btn.innerText = '存入记忆'; btn.disabled = false; }, 2000);
    } catch(e) {
      api.ui.toast('保存失败：' + (e?.message || ''));
      btn.innerText = '存入记忆'; btn.disabled = false;
    }
  };
}

// ===== 全局字体：应用函数 =====
function applyGlobalFont(family, fontUrl, fontDataUrl, size) {
  // 1. 加载字体资源
  if (fontDataUrl && fontDataUrl.startsWith('data:')) {
    const fontName = (family || "'GmcCustomFont',serif").replace(/['"]/g,'').split(',')[0];
    const styleId = 'gmc-global-font-face';
    let s = document.getElementById(styleId);
    if (!s) { s = document.createElement('style'); s.id = styleId; document.head.appendChild(s); }
    s.textContent = `@font-face { font-family:'${fontName}'; src:url('${fontDataUrl}'); }`;
  } else if (fontUrl) {
    loadFontLink(fontUrl);
  }

  // 2. 注入/更新全局 CSS 变量 + body 字体
  const cssId = 'gmc-global-font-style';
  let style = document.getElementById(cssId);
  if (!style) { style = document.createElement('style'); style.id = cssId; document.head.appendChild(style); }

  const ff = family || GLOBAL_FONT_DEFAULT_FAMILY;
  const fs = (size && size > 0) ? size : GLOBAL_FONT_DEFAULT_SIZE;
  style.textContent = `
    :root { --gmc-font-family: ${ff}; --gmc-font-size: ${fs}px; }
    body, .app-root, #app {
      font-family: ${ff} !important;
      font-size: ${fs}px !important;
    }
    /* 覆盖常用文字容器 */
    .indoor-chat-box, .story-text-box,
    [style*="STZhongsong"], [style*="STSong"], [style*="STKaiti"] {
      font-family: ${ff} !important;
    }
  `;
}

// 从内务府打开的独立字体设置弹窗
function openGlobalFontModal() {
  const old = document.getElementById('gmc-font-modal');
  if (old) old.remove();

  const modal = document.createElement('div');
  modal.id = 'gmc-font-modal';
  modal.style.cssText = 'position:fixed; inset:0; z-index:99999; background:rgba(0,0,0,0.85); display:flex; flex-direction:column;';

  const header = document.createElement('div');
  header.style.cssText = 'padding:calc(var(--safe-top,44px)+10px) 16px 12px; display:flex; justify-content:space-between; align-items:center; border-bottom:1px solid rgba(201,163,106,0.2); flex-shrink:0;';
  header.innerHTML = `
    <button id="gmc-font-back" style="background:transparent;border:none;color:#888;font-size:16px;font-family:inherit;">‹ 返回</button>
    <div style="color:var(--primary-color);font-size:17px;font-weight:bold;letter-spacing:4px;font-family:'STZhongsong','STSong',serif;">全局字体</div>
    <div style="width:48px;"></div>
  `;
  modal.appendChild(header);

  const body = document.createElement('div');
  body.style.cssText = 'flex:1; overflow-y:auto; padding:16px;';
  modal.appendChild(body);

  document.body.appendChild(modal);
  document.getElementById('gmc-font-back').onclick = () => modal.remove();
  renderGlobalFontPane(body);
}

function resetGlobalFont() {
  const cssId = 'gmc-global-font-style';
  const style = document.getElementById(cssId);
  if (style) style.remove();
  const faceId = 'gmc-global-font-face';
  const face = document.getElementById(faceId);
  if (face) face.remove();
}

// ===== 全局字体：置度所渲染面板 =====
function renderGlobalFontPane(container) {
  const pane = container || document.getElementById('dev-pane-font');
  if (!pane) return;
  pane.innerHTML = '';
  pane.style.cssText = 'display:flex; flex-direction:column; gap:14px; overflow-y:auto; padding:4px 2px;';

  const curFamily = _globalFontFamily || '';
  const curUrl    = (_globalFontUrl && !_globalFontUrl.startsWith('data:')) ? _globalFontUrl : '';
  const curSize   = _globalFontSize || GLOBAL_FONT_DEFAULT_SIZE;

  // ── 说明 ──
  const hint = document.createElement('div');
  hint.style.cssText = 'color:#888; font-size:12px; line-height:1.7; background:rgba(201,163,106,0.06); border:1px solid rgba(201,163,106,0.2); border-radius:8px; padding:10px 12px;';
  hint.innerHTML = '修改整个 APP 的全局默认字体与字号。设置后立即生效，重启后仍保留。<br><span style="color:#666;">注：部分界面元素有独立字体设置，不受此处影响。</span>';
  pane.appendChild(hint);

  // ── 字号滑块 ──
  const sizeRow = document.createElement('div');
  sizeRow.style.cssText = 'display:flex; flex-direction:column; gap:8px; background:rgba(0,0,0,0.3); border:1px solid #444; border-radius:10px; padding:12px 14px;';
  sizeRow.innerHTML = `
    <div style="color:var(--primary-color); font-size:13px; font-weight:bold; letter-spacing:1px;">全局字号</div>
    <div style="display:flex; align-items:center; gap:10px;">
      <input type="range" id="gf-size-range" min="11" max="22" value="${curSize}" style="flex:1;">
      <span id="gf-size-val" style="color:var(--primary-color); font-size:14px; font-weight:bold; min-width:32px; text-align:right;">${curSize}px</span>
    </div>
    <div id="gf-size-preview" style="color:#ccc; font-size:${curSize}px; font-family:${curFamily||GLOBAL_FONT_DEFAULT_FAMILY}; line-height:1.8; padding:8px 0; border-top:1px dashed rgba(201,163,106,0.2);">臣伏惟陛下，览此片纸，望圣颜赐批。</div>
  `;
  pane.appendChild(sizeRow);

  // ── 预设字体 ──
  const presetSection = document.createElement('div');
  presetSection.style.cssText = 'display:flex; flex-direction:column; gap:10px; background:rgba(0,0,0,0.3); border:1px solid #444; border-radius:10px; padding:12px 14px;';
  presetSection.innerHTML = `<div style="color:var(--primary-color); font-size:13px; font-weight:bold; letter-spacing:1px;">预设字体</div>`;

  const presets = [
    { label: '宋体（默认）',   family: "'STZhongsong','STSong',serif",          url: '' },
    { label: '楷体',           family: "'STKaiti','KaiTi','楷体',serif",         url: '' },
    { label: '仿宋',           family: "'FangSong','仿宋',serif",                url: '' },
    { label: '马善政',         family: "'Ma Shan Zheng','STKaiti',cursive",      url: 'https://fonts.googleapis.com/css2?family=Ma+Shan+Zheng&display=swap' },
    { label: 'ZCOOL XiaoWei', family: "'ZCOOL XiaoWei',serif",                 url: 'https://fonts.googleapis.com/css2?family=ZCOOL+XiaoWei&display=swap' },
    { label: 'Noto Serif SC', family: "'Noto Serif SC',serif",                  url: 'https://fonts.googleapis.com/css2?family=Noto+Serif+SC&display=swap' },
  ];

  const presetGrid = document.createElement('div');
  presetGrid.style.cssText = 'display:flex; flex-wrap:wrap; gap:8px;';
  let _pendingFamily = curFamily;
  let _pendingUrl    = curUrl;
  let _pendingDataUrl = '';

  presets.forEach(p => {
    const btn = document.createElement('button');
    const isActive = curFamily === p.family;
    btn.style.cssText = `background:${isActive?'rgba(201,163,106,0.2)':'transparent'}; border:1px solid ${isActive?'var(--primary-color)':'#555'}; color:${isActive?'var(--primary-color)':'#aaa'}; padding:6px 14px; border-radius:16px; font-size:12px; font-family:inherit; cursor:pointer; letter-spacing:1px; transition:all 0.15s;`;
    btn.textContent = p.label;
    btn.onclick = () => {
      if (p.url) loadFontLink(p.url);
      _pendingFamily  = p.family;
      _pendingUrl     = p.url;
      _pendingDataUrl = '';
      // 更新预览
      document.getElementById('gf-size-preview').style.fontFamily = p.family;
      urlInput.value = p.url;
      fileHint.style.display = 'none';
      // 高亮
      presetGrid.querySelectorAll('button').forEach(b => {
        b.style.background = 'transparent'; b.style.borderColor = '#555'; b.style.color = '#aaa';
      });
      btn.style.background = 'rgba(201,163,106,0.2)';
      btn.style.borderColor = 'var(--primary-color)';
      btn.style.color = 'var(--primary-color)';
    };
    presetGrid.appendChild(btn);
  });
  presetSection.appendChild(presetGrid);
  pane.appendChild(presetSection);

  // ── 自定义字体链接 ──
  const customSection = document.createElement('div');
  customSection.style.cssText = 'display:flex; flex-direction:column; gap:10px; background:rgba(0,0,0,0.3); border:1px solid #444; border-radius:10px; padding:12px 14px;';
  customSection.innerHTML = `
    <div style="color:var(--primary-color); font-size:13px; font-weight:bold; letter-spacing:1px;">自定义字体</div>
    <div style="color:#888; font-size:11px; letter-spacing:1px;">Google Fonts CSS 链接 或 TTF/WOFF 直链</div>
    <input id="gf-url-input" type="text" placeholder="https://fonts.googleapis.com/css2?family=..." value="${curUrl}" style="width:100%; background:rgba(0,0,0,0.5); border:1px solid rgba(201,163,106,0.3); color:#eaeaea; padding:10px; border-radius:8px; font-size:13px; font-family:inherit; box-sizing:border-box;">
    <div style="color:#888; font-size:11px; letter-spacing:1px; margin-top:2px;">或上传本地字体文件（TTF / OTF / WOFF）</div>
    <button id="gf-upload-btn" style="background:rgba(201,163,106,0.08); border:1px dashed rgba(201,163,106,0.35); color:rgba(201,163,106,0.8); padding:11px; border-radius:8px; font-size:13px; font-family:inherit; letter-spacing:1px;">📂 选择字体文件</button>
    <div id="gf-file-hint" style="color:#888; font-size:11px; text-align:center; display:none;"></div>
  `;
  pane.appendChild(customSection);

  const urlInput  = customSection.querySelector('#gf-url-input');
  const fileHint  = customSection.querySelector('#gf-file-hint');

  // 链接实时预览
  urlInput.addEventListener('input', () => {
    const url = urlInput.value.trim();
    if (url) {
      loadFontLink(url);
      _pendingUrl = url;
      _pendingDataUrl = '';
      // 猜字体名
      const m = url.match(/family=([^&:]+)/);
      if (m) {
        const guessed = `'${decodeURIComponent(m[1]).replace(/\+/g,' ')}',serif`;
        _pendingFamily = guessed;
        setTimeout(() => {
          document.getElementById('gf-size-preview').style.fontFamily = guessed;
        }, 800);
      }
    }
  });

  // 上传字体
  customSection.querySelector('#gf-upload-btn').onclick = async () => {
    try {
      const picked = await api.media.pick({ accept: '.ttf,.otf,.woff,.woff2' });
      if (!picked?.file) return;
      const dataUrl = picked.file.dataUrl;
      const fontName = 'GmcCustomFont_' + Date.now();
      const s = document.createElement('style');
      s.textContent = `@font-face { font-family:'${fontName}'; src:url('${dataUrl}'); }`;
      document.head.appendChild(s);
      _pendingDataUrl = dataUrl;
      _pendingFamily  = `'${fontName}',serif`;
      _pendingUrl     = '';
      urlInput.value  = '';
      fileHint.style.display = 'block';
      fileHint.textContent = `已加载：${picked.file.name || '自定义字体'}`;
      document.getElementById('gf-size-preview').style.fontFamily = _pendingFamily;
    } catch(e) { api.ui.toast('文件读取失败'); }
  };

  // ── 字号联动 ──
  const sizeRange   = document.getElementById('gf-size-range');
  const sizeValEl   = document.getElementById('gf-size-val');
  const sizePreview = document.getElementById('gf-size-preview');
  sizeRange.addEventListener('input', () => {
    const v = parseInt(sizeRange.value);
    sizeValEl.textContent = v + 'px';
    sizePreview.style.fontSize = v + 'px';
  });

  // ── 底部操作按钮 ──
  const btnRow = document.createElement('div');
  btnRow.style.cssText = 'display:flex; gap:10px; padding-bottom:4px;';

  const resetBtn = document.createElement('button');
  resetBtn.style.cssText = 'flex:1; background:transparent; border:1px solid #555; color:#aaa; padding:11px; border-radius:8px; font-family:inherit; font-size:14px;';
  resetBtn.textContent = '恢复默认';
  resetBtn.onclick = async () => {
    _globalFontFamily  = '';
    _globalFontUrl     = '';
    _globalFontDataUrl = '';
    _globalFontSize    = GLOBAL_FONT_DEFAULT_SIZE;
    resetGlobalFont();
    await saveProgress({ globalFontFamily:'', globalFontUrl:'', globalFontDataUrl:'', globalFontSize: GLOBAL_FONT_DEFAULT_SIZE });
    api.ui.toast('已恢复全局默认字体');
    renderGlobalFontPane(); // 刷新面板
  };

  const applyBtn = document.createElement('button');
  applyBtn.style.cssText = 'flex:2; background:var(--primary-color); border:none; color:#000; padding:11px; border-radius:8px; font-weight:bold; font-family:inherit; font-size:14px;';
  applyBtn.textContent = '应用并保存';
  applyBtn.onclick = async () => {
    const newSize = parseInt(sizeRange.value) || GLOBAL_FONT_DEFAULT_SIZE;
    let family = _pendingFamily;
    let fontUrl = _pendingDataUrl || _pendingUrl;

    // 如果没选预设也没上传，从链接框解析
    if (!family && !fontUrl) {
      fontUrl = urlInput.value.trim();
      if (fontUrl) {
        const m = fontUrl.match(/family=([^&:]+)/);
        family = m ? `'${decodeURIComponent(m[1]).replace(/\+/g,' ')}',serif` : "'CustomFont',serif";
      }
    }

    _globalFontFamily  = family  || GLOBAL_FONT_DEFAULT_FAMILY;
    _globalFontUrl     = (_pendingDataUrl ? '' : (_pendingUrl || urlInput.value.trim()));
    _globalFontDataUrl = _pendingDataUrl || '';
    _globalFontSize    = newSize;

    applyGlobalFont(_globalFontFamily, _globalFontUrl, _globalFontDataUrl, _globalFontSize);
    await saveProgress({
      globalFontFamily:  _globalFontFamily,
      globalFontUrl:     _globalFontUrl,
      globalFontDataUrl: _globalFontDataUrl,
      globalFontSize:    _globalFontSize
    });
    api.ui.toast('全局字体已应用并保存 ✓');
  };

  btnRow.appendChild(resetBtn);
  btnRow.appendChild(applyBtn);
  pane.appendChild(btnRow);
}

// ===== 自设台入口 =====
function openCustomStudio() {
  const existing = document.getElementById('custom-studio-modal');
  if (existing) existing.remove();

  const modal = document.createElement('div');
  modal.id = 'custom-studio-modal';
  modal.style.cssText = 'position:fixed; inset:0; z-index:10000; background:rgba(0,0,0,0.82); display:flex; align-items:flex-end; justify-content:center;';

  const panel = document.createElement('div');
  panel.style.cssText = 'width:100%; max-width:420px; background:#1a1816; border:1px solid var(--primary-color); border-radius:20px 20px 0 0; padding:24px 16px calc(var(--safe-bottom,24px)+16px); display:flex; flex-direction:column; gap:14px;';

  panel.innerHTML = `
    <div style="color:var(--primary-color); font-size:20px; text-align:center; letter-spacing:6px; font-family:'STZhongsong','STSong',serif; margin-bottom:4px;">自设台</div>
    <div style="color:#888; font-size:12px; text-align:center; margin-top:-8px;">捏造或引入新的存在</div>
    <button id="cs-btn-new-char" style="background:rgba(201,163,106,0.12); border:1px solid var(--primary-color); color:var(--primary-color); padding:14px; border-radius:10px; font-family:inherit; font-size:15px; letter-spacing:3px; text-align:left;">
      ✦ 增加自定义角色<div style="font-size:11px; color:#888; margin-top:4px; letter-spacing:1px;">从零捏造一个全新的人物</div>
    </button>
    <button id="cs-btn-import-char" style="background:rgba(201,163,106,0.12); border:1px solid var(--primary-color); color:var(--primary-color); padding:14px; border-radius:10px; font-family:inherit; font-size:15px; letter-spacing:3px; text-align:left;">
      ↑ 导入现有角色<div style="font-size:11px; color:#888; margin-top:4px; letter-spacing:1px;">将手机里未导入的角色引入此局</div>
    </button>
    <button id="cs-btn-voice" style="background:rgba(201,163,106,0.12); border:1px solid var(--primary-color); color:var(--primary-color); padding:14px; border-radius:10px; font-family:inherit; font-size:15px; letter-spacing:3px; text-align:left;">
      ♪ 语音偏好设定<div style="font-size:11px; color:#888; margin-top:4px; letter-spacing:1px;">为每位故人定制语音情绪、语速与朗读风格</div>
    </button>
    <button id="cs-btn-user-desc" style="background:rgba(201,163,106,0.12); border:1px solid var(--primary-color); color:var(--primary-color); padding:14px; border-radius:10px; font-family:inherit; font-size:15px; letter-spacing:3px; text-align:left;">
      ♚ 更改主控人设<div style="font-size:11px; color:#888; margin-top:4px; letter-spacing:1px;">修改皇帝的性格与设定（全局生效）</div>
    </button>
    <button id="cs-btn-new-npc" style="background:rgba(201,163,106,0.06); border:1px solid #666; color:#aaa; padding:14px; border-radius:10px; font-family:inherit; font-size:15px; letter-spacing:3px; text-align:left;" onclick="openNpcEditor()">
      ◈ 增加自定义NPC<div style="font-size:11px; color:#666; margin-top:4px; letter-spacing:1px;">宫女、太监、侍卫等配角</div>
    </button>
    <button id="cs-btn-cancel" style="background:transparent; border:none; color:#555; font-family:inherit; font-size:13px; padding:6px;">取消</button>
  `;

  modal.appendChild(panel);
  document.body.appendChild(modal);
  modal.addEventListener('click', e => { if (e.target === modal) modal.remove(); });

  document.getElementById('cs-btn-cancel').onclick = () => modal.remove();
  document.getElementById('cs-btn-new-npc').onclick = () => api.ui.toast('自定义NPC功能开发中');

  document.getElementById('cs-btn-new-char').onclick = () => {
    modal.remove();
    openCustomCharEditor(null, false);
  };

  document.getElementById('cs-btn-import-char').onclick = async () => {
    modal.remove();
    await openImportCharPicker();
  };

  document.getElementById('cs-btn-voice').onclick = () => {
    modal.remove();
    openVoiceStudio();
  };

  document.getElementById('cs-btn-user-desc').onclick = () => {
    modal.remove();
    document.getElementById('btn-global-worldbook').click();
    setTimeout(() => {
      document.querySelector('.wb-book[data-book="user"]').click();
    }, 100);
  };
}

// ===== 自设台：语音偏好设定 =====
async function openVoiceStudio() {
  const existing = document.getElementById('voice-studio-modal');
  if (existing) existing.remove();

  const modal = document.createElement('div');
  modal.id = 'voice-studio-modal';
  modal.style.cssText = 'position:fixed; inset:0; z-index:10001; background:url(\'https://www.imgfox.cn/apis/uploads/20260818/cd2a4b22f1ec4748/IMG_9643.jpeg\') center/cover no-repeat; display:flex; flex-direction:column;';

  const overlay = document.createElement('div');
  overlay.style.cssText = 'position:absolute; inset:0; background:rgba(10,8,6,0.75); backdrop-filter:blur(6px); -webkit-backdrop-filter:blur(6px); z-index:0;';
  modal.appendChild(overlay);

  const content = document.createElement('div');
  content.style.cssText = 'position:relative; z-index:1; display:flex; flex-direction:column; height:100%; overflow:hidden;';

  // 顶栏
  const topBar = document.createElement('div');
  topBar.style.cssText = 'padding-top:72px; padding-bottom:10px; padding-left:16px; padding-right:16px; display:flex; justify-content:space-between; align-items:center; border-bottom:1px solid rgba(201,163,106,0.2); flex-shrink:0;';
  topBar.innerHTML = `
    <button id="vs-back" style="background:transparent; border:none; color:#888; font-size:16px; font-family:inherit;">‹ 返回</button>
    <div style="color:var(--primary-color); font-size:17px; font-weight:bold; letter-spacing:4px; font-family:'STZhongsong','STSong',serif;">♪ 语音偏好</div>
    <div style="width:48px;"></div>
  `;
  content.appendChild(topBar);

  // 角色选择横向标签栏
  const tabBar = document.createElement('div');
  tabBar.id = 'vs-char-tabs';
  tabBar.style.cssText = 'display:flex; gap:8px; padding:12px 16px; overflow-x:auto; scrollbar-width:none; flex-shrink:0; border-bottom:1px solid rgba(201,163,106,0.1);';
  content.appendChild(tabBar);

  // 内容区
  const body = document.createElement('div');
  body.id = 'vs-body';
  body.style.cssText = 'flex:1; overflow-y:auto; padding:16px;';
  content.appendChild(body);

  modal.appendChild(content);
  document.body.appendChild(modal);

  document.getElementById('vs-back').addEventListener('click', () => {
    modal.remove();
    openCustomStudio();
  });

  // 构建角色列表（普通后妃 + 谢临渊）
  const allChars = [...selectedCharsData, XLY_CHAR];
  if (allChars.length === 0) {
    body.innerHTML = '<div style="color:#666; text-align:center; padding:40px; font-size:14px; letter-spacing:2px;">尚无故人，请先引入角色</div>';
    return;
  }

  let currentVsChar = allChars[0];

  // 渲染标签
  function renderVsTabs() {
    tabBar.innerHTML = '';
    allChars.forEach((c, idx) => {
      const btn = document.createElement('button');
      btn.style.cssText = `flex-shrink:0; padding:6px 14px; border-radius:16px; font-size:13px; font-family:inherit; letter-spacing:1px; transition:all 0.2s; ${c.id === currentVsChar.id ? 'background:var(--primary-color); color:#000; border:1px solid var(--primary-color);' : 'background:rgba(0,0,0,0.5); color:#aaa; border:1px solid #555;'}`;
      btn.innerText = c._isScenarioChar ? c.name + '（臣）' : c.name;
      btn.onclick = () => {
        currentVsChar = c;
        renderVsTabs();
        renderVsBody(c);
      };
      tabBar.appendChild(btn);
    });
  }

  // 渲染主体
  async function renderVsBody(char) {
    body.innerHTML = '<div style="color:#888; text-align:center; padding:30px; font-size:13px;">正在读取语音配置...</div>';

    // 读取宿主语音配置
    let voiceProfiles = null;
    let voiceInfo = '未配置';
    let provider = '';
    let supportsEmotion = false;
    try {
      voiceProfiles = await api.voice.readProfiles({ characterId: char.id === '__xly__' ? (selectedCharsData[0]?.id || '') : char.id });
      if (voiceProfiles?.selected) {
        const sel = voiceProfiles.selected;
        provider = sel.provider || '';
        voiceInfo = [sel.provider, sel.model, sel.voiceId].filter(Boolean).join(' · ');
        // Minimax 支持情绪控制
        supportsEmotion = provider.toLowerCase().includes('minimax');
      }
    } catch(e) {
      voiceInfo = '读取失败（可能未配置语音）';
    }

    // 读取当前存储的语音偏好
    const savedPref = char.voicePref || {
      emotion: 'neutral',
      speedRatio: 1.0,
      readMode: 'dialogue_only',  // dialogue_only | all_text | none
      customPrefix: '',
      customSuffix: '',
    };

    body.innerHTML = '';

    // ── 宿主语音配置信息栏（只读展示）──
    const infoCard = document.createElement('div');
    infoCard.style.cssText = 'background:rgba(201,163,106,0.06); border:1px solid rgba(201,163,106,0.25); border-radius:10px; padding:12px 14px; margin-bottom:16px; display:flex; flex-direction:column; gap:6px;';
    infoCard.innerHTML = `
      <div style="display:flex; justify-content:space-between; align-items:center;">
        <span style="color:var(--primary-color); font-size:12px; letter-spacing:1px;">宿主语音绑定</span>
        <span style="color:#666; font-size:10px;">在「设置→语音」里配置</span>
      </div>
      <div style="color:${voiceProfiles?.selected ? '#eaeaea' : '#666'}; font-size:13px; letter-spacing:1px;">${voiceInfo}</div>
      ${supportsEmotion ? '<div style="color:#c9a36a; font-size:11px; letter-spacing:1px;">✦ 当前语音引擎支持情绪控制</div>' : '<div style="color:#666; font-size:11px;">当前引擎不支持情绪控制（仅Minimax支持）</div>'}
    `;
    body.appendChild(infoCard);

    // ── 情绪选择 ──
    const emotionSection = document.createElement('div');
    emotionSection.style.cssText = 'display:flex; flex-direction:column; gap:10px; margin-bottom:20px;';
    emotionSection.innerHTML = `
      <div style="color:var(--primary-color); font-size:13px; letter-spacing:2px; border-bottom:1px solid rgba(201,163,106,0.2); padding-bottom:6px;">
        语音情绪 ${!supportsEmotion ? '<span style="color:#555; font-size:11px; font-weight:normal;">（当前引擎不支持，设置后备用）</span>' : ''}
      </div>
    `;

    const emotions = [
      { value: 'neutral', label: '平静', icon: '😐' },
      { value: 'happy', label: '欢愉', icon: '😊' },
      { value: 'sad', label: '悲戚', icon: '😢' },
      { value: 'angry', label: '怒意', icon: '😠' },
      { value: 'fearful', label: '惶恐', icon: '😨' },
      { value: 'disgusted', label: '厌恶', icon: '😒' },
      { value: 'surprised', label: '惊愕', icon: '😲' },
      { value: 'calm', label: '沉静', icon: '🧘' },
      { value: 'fluent', label: '流畅', icon: '✨' },
    ];

    const emotionGrid = document.createElement('div');
    emotionGrid.style.cssText = 'display:grid; grid-template-columns:repeat(3, 1fr); gap:8px;';
    emotions.forEach(em => {
      const btn = document.createElement('button');
      const isActive = savedPref.emotion === em.value;
      btn.style.cssText = `padding:10px 6px; border-radius:8px; font-family:inherit; font-size:13px; letter-spacing:1px; display:flex; flex-direction:column; align-items:center; gap:4px; transition:all 0.2s; ${isActive ? 'background:rgba(201,163,106,0.2); border:1px solid var(--primary-color); color:var(--primary-color);' : 'background:rgba(0,0,0,0.4); border:1px solid #444; color:#888;'}`;
      btn.innerHTML = `<span style="font-size:20px;">${em.icon}</span><span>${em.label}</span>`;
      btn.onclick = () => {
        savedPref.emotion = em.value;
        emotionGrid.querySelectorAll('button').forEach(b => {
          b.style.background = 'rgba(0,0,0,0.4)';
          b.style.borderColor = '#444';
          b.style.color = '#888';
        });
        btn.style.background = 'rgba(201,163,106,0.2)';
        btn.style.borderColor = 'var(--primary-color)';
        btn.style.color = 'var(--primary-color)';
      };
      emotionGrid.appendChild(btn);
    });
    emotionSection.appendChild(emotionGrid);
    body.appendChild(emotionSection);

    // ── 朗读范围 ──
    const readSection = document.createElement('div');
    readSection.style.cssText = 'display:flex; flex-direction:column; gap:10px; margin-bottom:20px;';
    readSection.innerHTML = `<div style="color:var(--primary-color); font-size:13px; letter-spacing:2px; border-bottom:1px solid rgba(201,163,106,0.2); padding-bottom:6px;">朗读范围</div>`;

    const readModes = [
      { value: 'dialogue_only', label: '仅朗读对话', desc: '只读引号内的台词，忽略旁白动作描写' },
      { value: 'all_text', label: '朗读全文', desc: '旁白和台词一并朗读（含动作描写）' },
      { value: 'none', label: '不朗读', desc: '关闭此角色的语音，只显示文字' },
    ];
    readModes.forEach(rm => {
      const item = document.createElement('div');
      const isActive = savedPref.readMode === rm.value;
      item.style.cssText = `display:flex; align-items:center; gap:12px; padding:10px 14px; border-radius:8px; cursor:pointer; transition:all 0.2s; ${isActive ? 'background:rgba(201,163,106,0.15); border:1px solid var(--primary-color);' : 'background:rgba(0,0,0,0.4); border:1px solid #444;'}`;
      item.innerHTML = `
        <div style="width:18px; height:18px; border-radius:50%; border:2px solid ${isActive ? 'var(--primary-color)' : '#555'}; display:flex; align-items:center; justify-content:center; flex-shrink:0;">
          ${isActive ? '<div style="width:8px;height:8px;border-radius:50%;background:var(--primary-color);"></div>' : ''}
        </div>
        <div>
          <div style="color:${isActive ? 'var(--primary-color)' : '#ccc'}; font-size:13px;">${rm.label}</div>
          <div style="color:#666; font-size:11px; margin-top:2px;">${rm.desc}</div>
        </div>
      `;
      item.onclick = () => {
        savedPref.readMode = rm.value;
        // 刷新所有条目样式
        readSection.querySelectorAll('[data-rm]').forEach(el => {
          const v = el.dataset.rm;
          const active = v === rm.value;
          el.style.background = active ? 'rgba(201,163,106,0.15)' : 'rgba(0,0,0,0.4)';
          el.style.borderColor = active ? 'var(--primary-color)' : '#444';
          const dot = el.querySelector('.rm-dot');
          const ring = el.querySelector('.rm-ring');
          if (ring) ring.style.borderColor = active ? 'var(--primary-color)' : '#555';
          if (dot) dot.style.display = active ? 'block' : 'none';
          const lbl = el.querySelector('.rm-label');
          if (lbl) lbl.style.color = active ? 'var(--primary-color)' : '#ccc';
        });
      };
      item.dataset.rm = rm.value;
      // 重新用带类名的结构，方便刷新
      item.innerHTML = `
        <div class="rm-ring" style="width:18px; height:18px; border-radius:50%; border:2px solid ${isActive ? 'var(--primary-color)' : '#555'}; display:flex; align-items:center; justify-content:center; flex-shrink:0;">
          <div class="rm-dot" style="width:8px;height:8px;border-radius:50%;background:var(--primary-color);display:${isActive?'block':'none'};"></div>
        </div>
        <div>
          <div class="rm-label" style="color:${isActive ? 'var(--primary-color)' : '#ccc'}; font-size:13px;">${rm.label}</div>
          <div style="color:#666; font-size:11px; margin-top:2px;">${rm.desc}</div>
        </div>
      `;
      readSection.appendChild(item);
    });
    body.appendChild(readSection);

    // ── 自定义前后缀 ──
    const affixSection = document.createElement('div');
    affixSection.style.cssText = 'display:flex; flex-direction:column; gap:10px; margin-bottom:20px;';
    affixSection.innerHTML = `
      <div style="color:var(--primary-color); font-size:13px; letter-spacing:2px; border-bottom:1px solid rgba(201,163,106,0.2); padding-bottom:6px;">朗读文本处理</div>
      <div style="color:#666; font-size:11px; line-height:1.6;">在每段朗读文本前后自动附加指定内容，可用于修正语气词、添加停顿指令等</div>
      <div style="display:flex; flex-direction:column; gap:8px;">
        <div style="display:flex; align-items:center; gap:10px;">
          <label style="color:#aaa; font-size:12px; flex-shrink:0; width:44px;">前缀</label>
          <input id="vs-prefix" type="text" value="${savedPref.customPrefix || ''}" placeholder="例如：（深吸一口气）" style="flex:1; background:rgba(0,0,0,0.5); border:1px solid #555; color:#ccc; padding:8px 10px; border-radius:6px; font-family:inherit; font-size:13px;">
        </div>
        <div style="display:flex; align-items:center; gap:10px;">
          <label style="color:#aaa; font-size:12px; flex-shrink:0; width:44px;">后缀</label>
          <input id="vs-suffix" type="text" value="${savedPref.customSuffix || ''}" placeholder="例如：（轻叹）" style="flex:1; background:rgba(0,0,0,0.5); border:1px solid #555; color:#ccc; padding:8px 10px; border-radius:6px; font-family:inherit; font-size:13px;">
        </div>
      </div>
    `;
    body.appendChild(affixSection);

    // ── 试听区 ──
    const previewSection = document.createElement('div');
    previewSection.style.cssText = 'display:flex; flex-direction:column; gap:10px; margin-bottom:24px;';
    previewSection.innerHTML = `
      <div style="color:var(--primary-color); font-size:13px; letter-spacing:2px; border-bottom:1px solid rgba(201,163,106,0.2); padding-bottom:6px;">试听</div>
      <div style="display:flex; gap:8px; align-items:flex-end;">
        <textarea id="vs-preview-text" placeholder="输入试听文本，或从人设范例中提取..." style="flex:1; min-height:64px; background:rgba(0,0,0,0.5); border:1px solid #555; color:#ccc; padding:10px; border-radius:8px; font-family:inherit; font-size:13px; resize:none; line-height:1.5;">${getFirstDialogue(char)}</textarea>
      </div>
      <div style="display:flex; gap:10px;">
        <button id="vs-btn-auto-extract" style="flex:1; background:rgba(0,0,0,0.4); border:1px solid #555; color:#aaa; padding:9px; border-radius:8px; font-family:inherit; font-size:13px; letter-spacing:1px;">从人设提取台词</button>
        <button id="vs-btn-play" style="flex:2; background:rgba(201,163,106,0.15); border:1px solid var(--primary-color); color:var(--primary-color); padding:9px; border-radius:8px; font-family:inherit; font-size:14px; letter-spacing:2px;">▶ 试听</button>
      </div>
      <div id="vs-play-status" style="color:#888; font-size:12px; text-align:center; min-height:18px; letter-spacing:1px;"></div>
    `;
    body.appendChild(previewSection);

    // ── 底部保存按钮 ──
    const saveBtn = document.createElement('button');
    saveBtn.style.cssText = 'width:100%; padding:13px; background:var(--primary-color); border:none; color:#000; border-radius:10px; font-family:inherit; font-size:15px; font-weight:bold; letter-spacing:3px; margin-bottom:8px;';
    saveBtn.innerText = '保存语音偏好';
    body.appendChild(saveBtn);

    // ── 事件绑定 ──

    // 从人设自动提取第一条台词
    document.getElementById('vs-btn-auto-extract').onclick = () => {
      const extracted = getFirstDialogue(char);
      if (extracted) {
        document.getElementById('vs-preview-text').value = extracted;
        api.ui.toast('已提取第一条范例台词');
      } else {
        api.ui.toast('未找到引号台词，请手动输入');
      }
    };

    // 试听
    document.getElementById('vs-btn-play').onclick = async () => {
      const rawText = document.getElementById('vs-preview-text').value.trim();
      if (!rawText) { api.ui.toast('请输入试听文本'); return; }

      const prefix = document.getElementById('vs-prefix').value;
      const suffix = document.getElementById('vs-suffix').value;
      const finalText = (prefix || '') + rawText + (suffix || '');

      const status = document.getElementById('vs-play-status');
      const playBtn = document.getElementById('vs-btn-play');
      playBtn.disabled = true;
      playBtn.innerText = '合成中...';
      status.innerText = '正在合成语音，请稍候...';

      try {
        const ttsArgs = { characterId: char.id === '__xly__' ? (selectedCharsData[0]?.id || '') : char.id, text: finalText };
        if (supportsEmotion && savedPref.emotion && savedPref.emotion !== 'neutral') {
          ttsArgs.emotion = savedPref.emotion;
        }
        const speech = await api.voice.tts(ttsArgs);
        status.innerText = '合成完成，正在播放...';
        await api.voice.play({ dataUrl: speech.dataUrl });
        status.innerText = '播放完毕';
      } catch(e) {
        status.innerText = '试听失败：' + (e?.message || '请检查语音配置');
        api.ui.toast('语音试听失败');
      } finally {
        playBtn.disabled = false;
        playBtn.innerText = '▶ 试听';
      }
    };

    // 保存
    saveBtn.onclick = async () => {
      savedPref.customPrefix = document.getElementById('vs-prefix').value;
      savedPref.customSuffix = document.getElementById('vs-suffix').value;

      // 写回角色数据
      char.voicePref = { ...savedPref };

      // 同步到 selectedCharsData（谢临渊单独处理）
      if (!char._isScenarioChar) {
        const idx = selectedCharsData.findIndex(c => c.id === char.id);
        if (idx >= 0) selectedCharsData[idx].voicePref = char.voicePref;
      }

      await saveProgress({
        characters: selectedCharsData.map(c => ({
          id:c.id, name:c.name, avatar:c.avatar, customAvatar:c.customAvatar,
          gender:c.gender,
          ancientRole:c.ancientRole, ancientDesc:c.ancientDesc, ancientDescOriginal:c.ancientDescOriginal,
          assignedRank:c.assignedRank, assignedPalace:c.assignedPalace,
          memorySeen:c.memorySeen, memoryKnown:c.memoryKnown, charWorldDesc:c.charWorldDesc,
          cardAvatarCfg:c.cardAvatarCfg, storyAvatarCfg:c.storyAvatarCfg, indoorBgUrl:c.indoorBgUrl,
          voicePref:c.voicePref, _isCustom:c._isCustom
        }))
      });
      api.ui.toast(`「${char.name}」语音偏好已保存`);
    };
  }

  renderVsTabs();
  await renderVsBody(currentVsChar);
}

// 从角色人设里提取第一条带引号的台词
function getFirstDialogue(char) {
  const desc = char.ancientDescOriginal || char.ancientDesc || '';
  const match = desc.match(/"([^"]{4,80})"/);
  return match ? match[1] : '';
}

// ===== 自设台：角色编辑器（新建/导入通用）=====
// charData: 已有角色对象（导入时传入）或 null（新建时）
// isImport: true=导入流程，false=新建流程
function openCustomCharEditor(charData, isImport) {
  const existing = document.getElementById('custom-char-editor-modal');
  if (existing) existing.remove();

  // 工作副本
  const workChar = charData ? { ...charData } : {
    id: '__custom_' + Date.now() + '_' + Math.random().toString(36).slice(2),
    name: '',
    avatar: null,
    customAvatar: null,
    ancientRole: '后妃',
    ancientDesc: '',
    ancientDescOriginal: '',
    assignedRank: '',
    assignedPalace: '',
    memorySeen: [],
    charWorldDesc: '',
    cardAvatarCfg: { scale: 100, x: 0, y: 0 },
    storyAvatarCfg: { scale: 100, x: 0, y: 0 },
    indoorBgUrl: null,
    _isCustom: true
  };

  const modal = document.createElement('div');
  modal.id = 'custom-char-editor-modal';
  modal.style.cssText = 'position:fixed; inset:0; z-index:10001; background:url(\'https://www.imgfox.cn/apis/uploads/20260818/cd2a4b22f1ec4748/IMG_9643.jpeg\') center/cover no-repeat; display:flex; flex-direction:column; overflow:hidden;';

  const overlay = document.createElement('div');
  overlay.style.cssText = 'position:absolute; inset:0; background:rgba(10,8,6,0.7); backdrop-filter:blur(6px); -webkit-backdrop-filter:blur(6px); z-index:0;';
  modal.appendChild(overlay);

  const content = document.createElement('div');
  content.style.cssText = 'position:relative; z-index:1; display:flex; flex-direction:column; height:100%; overflow:hidden;';

  // 顶栏
  const topBar = document.createElement('div');
  topBar.style.cssText = 'padding:calc(var(--safe-top,44px) + 8px) 16px 10px; display:flex; justify-content:space-between; align-items:center; border-bottom:1px solid rgba(201,163,106,0.2); flex-shrink:0;';
  topBar.innerHTML = `
    <button id="cce-back" style="background:transparent; border:none; color:#888; font-size:16px; font-family:inherit;">‹ 返回</button>
    <div style="color:var(--primary-color); font-size:17px; font-weight:bold; letter-spacing:4px; font-family:'STZhongsong','STSong',serif;">${isImport ? '导入角色' : '捏造人物'}</div>
    <button id="cce-save" style="background:var(--primary-color); border:none; color:#000; padding:6px 14px; border-radius:16px; font-size:13px; font-weight:bold; font-family:inherit;">存入</button>
  `;
  content.appendChild(topBar);

  // 主体滚动区
  const body = document.createElement('div');
  body.style.cssText = 'flex:1; overflow-y:auto; padding:16px 18px calc(var(--safe-bottom,24px)+16px); display:flex; flex-direction:column; gap:18px;';

  // ── 立绘区 ──
  const avatarSection = document.createElement('div');
  avatarSection.style.cssText = 'display:flex; flex-direction:column; align-items:center; gap:10px;';
  avatarSection.innerHTML = `
    <div id="cce-avatar-wrap" style="position:relative; width:100px; height:100px; border-radius:50%; border:2px solid var(--primary-color); overflow:hidden; background:rgba(0,0,0,0.5); cursor:pointer; display:flex; align-items:center; justify-content:center;">
      <img id="cce-avatar-img" src="${workChar.customAvatar || workChar.avatar || ''}" style="width:100%; height:100%; object-fit:cover; display:${(workChar.customAvatar || workChar.avatar) ? 'block' : 'none'};">
      <span id="cce-avatar-placeholder" style="color:#666; font-size:28px; display:${(workChar.customAvatar || workChar.avatar) ? 'none' : 'flex'}; align-items:center; justify-content:center; width:100%; height:100%;">＋</span>
    </div>
    <div style="display:flex; gap:10px;">
      <button id="cce-pick-avatar" style="background:rgba(201,163,106,0.1); border:1px solid var(--primary-color); color:var(--primary-color); padding:6px 14px; border-radius:16px; font-size:12px; font-family:inherit;">从相册选图</button>
      <button id="cce-ai-avatar" style="background:rgba(201,163,106,0.1); border:1px solid var(--primary-color); color:var(--primary-color); padding:6px 14px; border-radius:16px; font-size:12px; font-family:inherit;">AI绘制立绘</button>
    </div>
    <div style="color:#888; font-size:11px; letter-spacing:1px;">点击头像区域也可更换</div>
  `;
  body.appendChild(avatarSection);

  // ── 基础信息 ──
  const infoSection = document.createElement('div');
  infoSection.style.cssText = 'display:flex; flex-direction:column; gap:10px;';
  infoSection.innerHTML = `
    <div style="color:var(--primary-color); font-size:13px; letter-spacing:2px; border-bottom:1px solid rgba(201,163,106,0.2); padding-bottom:6px;">基础信息</div>
    <div style="display:flex; align-items:center; gap:10px;">
      <label style="color:#aaa; font-size:13px; flex-shrink:0; width:48px;">姓名</label>
      <input id="cce-name" type="text" value="${workChar.name || ''}" placeholder="角色姓名" style="flex:1; background:rgba(0,0,0,0.5); border:1px solid #666; color:#fff; padding:8px 12px; border-radius:6px; font-family:inherit; font-size:14px;">
    </div>
    <div style="display:flex; align-items:center; gap:10px;">
      <label style="color:#aaa; font-size:13px; flex-shrink:0; width:48px;">性别</label>
      <div style="display:flex; gap:8px; flex:1;">
        <label id="cce-gender-male" style="display:flex; align-items:center; gap:6px; cursor:pointer; flex:1; background:rgba(0,0,0,0.4); border:1px solid ${(workChar.gender==='男'||!workChar.gender)?'var(--primary-color)':'#555'}; border-radius:6px; padding:8px 12px; transition:all 0.2s;">
          <input type="radio" name="cce-gender" value="男" ${(workChar.gender==='男'||!workChar.gender)?'checked':''} style="display:none;">
          <span style="font-size:16px;">♂</span>
          <span style="color:${(workChar.gender==='男'||!workChar.gender)?'var(--primary-color)':'#888'}; font-size:14px;">男</span>
        </label>
        <label id="cce-gender-female" style="display:flex; align-items:center; gap:6px; cursor:pointer; flex:1; background:rgba(0,0,0,0.4); border:1px solid ${workChar.gender==='女'?'#e8a0bf':'#555'}; border-radius:6px; padding:8px 12px; transition:all 0.2s;">
          <input type="radio" name="cce-gender" value="女" ${workChar.gender==='女'?'checked':''} style="display:none;">
          <span style="font-size:16px;">♀</span>
          <span style="color:${workChar.gender==='女'?'#e8a0bf':'#888'}; font-size:14px;">女</span>
        </label>
        <label id="cce-gender-other" style="display:flex; align-items:center; gap:6px; cursor:pointer; flex:1; background:rgba(0,0,0,0.4); border:1px solid ${workChar.gender==='其他'?'#a0c4e8':'#555'}; border-radius:6px; padding:8px 12px; transition:all 0.2s;">
          <input type="radio" name="cce-gender" value="其他" ${workChar.gender==='其他'?'checked':''} style="display:none;">
          <span style="font-size:16px;">⚧</span>
          <span style="color:${workChar.gender==='其他'?'#a0c4e8':'#888'}; font-size:14px;">其他</span>
        </label>
      </div>
    </div>
    <div style="display:flex; align-items:center; gap:10px;">
      <label style="color:#aaa; font-size:13px; flex-shrink:0; width:48px;">身份</label>
      <select id="cce-role" style="flex:1; background:rgba(0,0,0,0.5); border:1px solid #666; color:#fff; padding:8px; border-radius:6px; font-family:inherit; font-size:14px;">
        <option value="后妃">后妃</option>
        <option value="帝师">帝师</option>
        <option value="左相">左相</option>
        <option value="右相">右相</option>
        <option value="自定义">自定义...</option>
      </select>
    </div>
    <div id="cce-custom-role-wrap" style="display:none; padding-left:58px;">
      <input id="cce-custom-role" type="text" placeholder="输入自定义身份" style="width:100%; background:rgba(0,0,0,0.5); border:1px solid #666; color:#fff; padding:8px 12px; border-radius:6px; font-family:inherit; font-size:14px;">
    </div>
  `;
  body.appendChild(infoSection);

  // ── 居所（后妃专用）──
  const palaceSection = document.createElement('div');
  palaceSection.id = 'cce-palace-section';
  palaceSection.style.cssText = 'display:flex; flex-direction:column; gap:10px;';

  // 检查储秀宫是否已建成
  const isChuxiuBuilt = placedPalacesData.some(p => p.name === '储秀宫');

  // 生成可选宫殿（东六宫+西六宫+冷宫，储秀宫根据状态决定是否可选）
  const allPalaceOptions = [
    ...eastPalaces,
    ...westPalaces.filter(p => p !== '储秀宫'),
    ...(isChuxiuBuilt ? ['储秀宫'] : []),
    '冷宫'
  ];
  const palaceOptHtml = allPalaceOptions.map(p => `<option value="${p}">${p}</option>`).join('');

  palaceSection.innerHTML = `
    <div style="color:var(--primary-color); font-size:13px; letter-spacing:2px; border-bottom:1px solid rgba(201,163,106,0.2); padding-bottom:6px;">赐居所（后妃专用）</div>
    ${!isChuxiuBuilt ? '<div style="color:#888; font-size:11px; background:rgba(122,92,122,0.1); border:1px solid rgba(122,92,122,0.3); border-radius:6px; padding:6px 10px; letter-spacing:1px;">储秀宫尚未建成，暂不可选</div>' : ''}
    <div style="display:flex; gap:10px; flex-wrap:wrap;">
      <div style="flex:1; min-width:120px;">
        <div style="color:#aaa; font-size:11px; margin-bottom:4px;">宫殿</div>
        <select id="cce-palace-name" style="width:100%; background:rgba(0,0,0,0.5); border:1px solid #666; color:#fff; padding:8px; border-radius:6px; font-family:inherit; font-size:13px;">
          <option value="">-- 未赐居 --</option>
          ${palaceOptHtml}
        </select>
      </div>
      <div style="flex:1; min-width:100px;">
        <div style="color:#aaa; font-size:11px; margin-bottom:4px;">殿宇</div>
        <select id="cce-palace-room" style="width:100%; background:rgba(0,0,0,0.5); border:1px solid #666; color:#fff; padding:8px; border-radius:6px; font-family:inherit; font-size:13px;">
          <option value="正殿">正殿</option>
          <option value="东偏殿">东偏殿</option>
          <option value="西偏殿">西偏殿</option>
          <option value="耳房">耳房</option>
        </select>
      </div>
    </div>
    <div style="display:flex; align-items:center; gap:10px;">
      <label style="color:#aaa; font-size:13px; flex-shrink:0; width:48px;">位份</label>
      <select id="cce-rank" style="flex:1; background:rgba(0,0,0,0.5); border:1px solid #666; color:#fff; padding:8px; border-radius:6px; font-family:inherit; font-size:13px;">
        <option value="">-- 未册封 --</option>
        ${rankData.map(r => `<option value="${r.rank}">${r.rank}</option>`).join('')}
      </select>
    </div>
  `;
  body.appendChild(palaceSection);

  // ── 人设区 ──
  const descSection = document.createElement('div');
  descSection.style.cssText = 'display:flex; flex-direction:column; gap:10px;';
  descSection.innerHTML = `
    <div style="display:flex; justify-content:space-between; align-items:center; border-bottom:1px solid rgba(201,163,106,0.2); padding-bottom:6px;">
      <span style="color:var(--primary-color); font-size:13px; letter-spacing:2px;">人物设定</span>
      <button id="cce-ai-desc" style="background:rgba(201,163,106,0.15); border:1px solid var(--primary-color); color:var(--primary-color); padding:4px 12px; border-radius:12px; font-size:12px; font-family:inherit;">✦ AI生成人设</button>
    </div>
    <textarea id="cce-desc" placeholder="在此输入或AI生成人物设定（外貌、性格、背景、对话范例等）..." style="width:100%; min-height:160px; background:rgba(0,0,0,0.5); border:1px solid #666; color:#ccc; padding:12px; border-radius:8px; font-family:inherit; font-size:13px; resize:vertical; line-height:1.6;">${workChar.ancientDesc || workChar.ancientDescOriginal || ''}</textarea>
  `;
  body.appendChild(descSection);

  // ── 记忆区 ──
  const memSection = document.createElement('div');
  memSection.style.cssText = 'display:flex; flex-direction:column; gap:10px;';
  memSection.innerHTML = `
    <div style="color:var(--primary-color); font-size:13px; letter-spacing:2px; border-bottom:1px solid rgba(201,163,106,0.2); padding-bottom:6px;">初始记忆（可选）</div>
    <div style="color:#888; font-size:11px; letter-spacing:1px;">填写TA在进入此局前已知晓的事，将存入「TA看到的」</div>
    <textarea id="cce-memory" placeholder="例如：此人自幼入宫，深知宫中规矩，曾与皇后有过一面之缘..." style="width:100%; min-height:80px; background:rgba(0,0,0,0.5); border:1px solid #666; color:#ccc; padding:12px; border-radius:8px; font-family:inherit; font-size:13px; resize:vertical; line-height:1.6;"></textarea>
    <div style="color:var(--primary-color); font-size:13px; letter-spacing:2px; border-bottom:1px solid rgba(201,163,106,0.2); padding-bottom:6px; margin-top:4px;">人物专属世界书（可选）</div>
    <textarea id="cce-charwb" placeholder="TA独有的设定、秘密、专属背景（仅当TA在场时发给AI）..." style="width:100%; min-height:60px; background:rgba(0,0,0,0.5); border:1px solid #666; color:#ccc; padding:12px; border-radius:8px; font-family:inherit; font-size:13px; resize:vertical; line-height:1.6;">${workChar.charWorldDesc || ''}</textarea>
  `;
  body.appendChild(memSection);

  content.appendChild(body);
  modal.appendChild(content);
  document.body.appendChild(modal);

  // ── 初始化表单值 ──
  const roleSelect2 = document.getElementById('cce-role');
  const customRoleWrap = document.getElementById('cce-custom-role-wrap');
  const customRoleInput2 = document.getElementById('cce-custom-role');
  const palaceSection2 = document.getElementById('cce-palace-section');

  // 性别按钮高亮联动
  const genderColors = { '男': 'var(--primary-color)', '女': '#e8a0bf', '其他': '#a0c4e8' };
  const genderIds = { '男': 'cce-gender-male', '女': 'cce-gender-female', '其他': 'cce-gender-other' };
  function updateGenderUI(selected) {
    ['男','女','其他'].forEach(g => {
      const lbl = document.getElementById(genderIds[g]);
      if (!lbl) return;
      const isActive = g === selected;
      lbl.style.borderColor = isActive ? genderColors[g] : '#555';
      const span = lbl.querySelector('span:last-child');
      if (span) span.style.color = isActive ? genderColors[g] : '#888';
    });
  }
  document.querySelectorAll('input[name="cce-gender"]').forEach(radio => {
    radio.addEventListener('change', () => updateGenderUI(radio.value));
  });
  // 初始化高亮
  updateGenderUI(workChar.gender || '男');

  const knownRoles = ['后妃','帝师','左相','右相'];
  if (workChar.ancientRole && !knownRoles.includes(workChar.ancientRole)) {
    roleSelect2.value = '自定义';
    customRoleWrap.style.display = 'block';
    customRoleInput2.value = workChar.ancientRole;
  } else {
    roleSelect2.value = workChar.ancientRole || '后妃';
  }

  const updatePalaceVisibility = () => {
    const r = roleSelect2.value === '自定义' ? customRoleInput2.value : roleSelect2.value;
    palaceSection2.style.display = (r === '后妃') ? 'flex' : 'none';
  };
  updatePalaceVisibility();

  roleSelect2.addEventListener('change', () => {
    customRoleWrap.style.display = roleSelect2.value === '自定义' ? 'block' : 'none';
    updatePalaceVisibility();
  });
  customRoleInput2.addEventListener('input', updatePalaceVisibility);

  // 如果已有赐居，填回去
  if (workChar.assignedPalace) {
    const parts = workChar.assignedPalace.match(/^(.+?)(正殿|东偏殿|西偏殿|耳房)$/);
    if (parts) {
      const pn = document.getElementById('cce-palace-name');
      const pr = document.getElementById('cce-palace-room');
      if (pn) pn.value = parts[1];
      if (pr) pr.value = parts[2];
    }
  }
  if (workChar.assignedRank) {
    const rk = document.getElementById('cce-rank');
    if (rk) rk.value = workChar.assignedRank;
  }

  // ── 头像点击 ──
  const avatarWrap2 = document.getElementById('cce-avatar-wrap');
  avatarWrap2.addEventListener('click', () => {
    document.getElementById('cce-pick-avatar').click();
  });

  document.getElementById('cce-pick-avatar').addEventListener('click', async (e) => {
    e.stopPropagation();
    try {
      const picked = await api.media.pick({ accept: 'image/*' });
      if (picked?.file) {
        workChar.customAvatar = picked.file.dataUrl;
        const img = document.getElementById('cce-avatar-img');
        img.src = picked.file.dataUrl;
        img.style.display = 'block';
        document.getElementById('cce-avatar-placeholder').style.display = 'none';
      }
    } catch(err) {}
  });

  document.getElementById('cce-ai-avatar').addEventListener('click', async () => {
    const desc = document.getElementById('cce-desc').value.trim();
    if (!desc) { api.ui.toast('请先填写或生成人物设定，再AI绘制立绘'); return; }
    const globalLoader = document.getElementById('global-loader-modal');
    document.getElementById('global-loader-text').innerText = '正在提取外貌特征并绘制...';
    globalLoader.style.display = 'flex';
    try {
      const extractRes = await api.ai.chat({ messages:[{ role:'user', content:`请从以下设定中提取外貌描写，提炼成适合AI画图的英文Prompt，要求古风、唯美：\n${desc}` }] });
      const prompt = typeof extractRes === 'string' ? extractRes : (extractRes?.content ?? extractRes?.text ?? '');
      const img = await api.ai.generateImage({ prompt });
      if (img?.dataUrl) {
        workChar.customAvatar = img.dataUrl;
        const imgEl = document.getElementById('cce-avatar-img');
        imgEl.src = img.dataUrl;
        imgEl.style.display = 'block';
        document.getElementById('cce-avatar-placeholder').style.display = 'none';
        api.ui.toast('立绘已生成');
      }
    } catch(err) { api.ui.toast('立绘生成失败'); }
    finally { globalLoader.style.display = 'none'; }
  });

  // ── AI生成人设（先弹提示词输入框）──
  document.getElementById('cce-ai-desc').addEventListener('click', () => {
    const name = document.getElementById('cce-name').value.trim() || workChar.name || '';
    const role = roleSelect2.value === '自定义' ? customRoleInput2.value : roleSelect2.value;
    const existingDesc = document.getElementById('cce-desc').value.trim();
    const currentGender = document.querySelector('input[name="cce-gender"]:checked')?.value || '男';

    // 弹提示词对话框
    const promptModal = document.createElement('div');
    promptModal.style.cssText = 'position:fixed;inset:0;z-index:20000;background:rgba(0,0,0,0.88);display:flex;align-items:flex-end;justify-content:center;';
    promptModal.innerHTML = `
      <div style="width:100%;max-width:480px;background:#1a1816;border:1px solid var(--primary-color);border-radius:20px 20px 0 0;padding:20px 16px calc(var(--safe-bottom,24px)+16px);display:flex;flex-direction:column;gap:14px;">
        <div style="color:var(--primary-color);font-size:17px;text-align:center;letter-spacing:4px;font-family:'STZhongsong','STSong',serif;">AI 生成人设</div>
        <div style="color:#888;font-size:12px;text-align:center;margin-top:-8px;">告诉AI你想要什么样的人物，越详细越好</div>

        <div style="display:flex;flex-direction:column;gap:6px;">
          <div style="color:var(--primary-color);font-size:12px;letter-spacing:1px;">当前设定</div>
          <div style="background:rgba(255,255,255,0.04);border:1px solid rgba(201,163,106,0.2);border-radius:6px;padding:8px 12px;color:#aaa;font-size:12px;line-height:1.6;">
            姓名：${name || '（未填）'} &nbsp;·&nbsp; 性别：${currentGender} &nbsp;·&nbsp; 身份：${role}
            ${existingDesc ? `<br>已有描述：${existingDesc.slice(0,40)}${existingDesc.length>40?'…':''}` : ''}
          </div>
        </div>

        <div style="display:flex;flex-direction:column;gap:6px;">
          <div style="color:var(--primary-color);font-size:12px;letter-spacing:1px;">你的创作方向 <span style="color:#666;font-weight:normal;">（可留空，AI自由发挥）</span></div>
          <textarea id="cce-ai-prompt-input" placeholder="例如：外貌清冷如冰，性格高傲但内心脆弱，出身将门，擅长剑术，入宫前曾经历过一场失败的战争……" style="width:100%;height:100px;background:rgba(0,0,0,0.5);border:1px solid #666;color:#ccc;padding:12px;border-radius:8px;resize:none;font-size:13px;font-family:inherit;line-height:1.6;"></textarea>
        </div>

        <div style="color:#666;font-size:11px;line-height:1.6;">将自动携带：长信宫规 + 大世界设定 + 以上角色信息</div>

        <div style="display:flex;gap:12px;">
          <button id="cce-ai-prompt-cancel" style="flex:1;background:transparent;border:1px solid #555;color:#888;padding:11px;border-radius:8px;font-family:inherit;font-size:14px;">取消</button>
          <button id="cce-ai-prompt-go" style="flex:2;background:var(--primary-color);border:none;color:#000;padding:11px;border-radius:8px;font-family:inherit;font-size:14px;font-weight:bold;">✦ 开始生成</button>
        </div>
      </div>
    `;
    document.body.appendChild(promptModal);
    promptModal.addEventListener('click', e => { if (e.target === promptModal) promptModal.remove(); });
    document.getElementById('cce-ai-prompt-cancel').onclick = () => promptModal.remove();

    document.getElementById('cce-ai-prompt-go').onclick = async () => {
      const userPrompt = document.getElementById('cce-ai-prompt-input').value.trim();
      promptModal.remove();

      const globalLoader = document.getElementById('global-loader-modal');
      document.getElementById('global-loader-text').innerText = '正在生成古代人设...';
      globalLoader.style.display = 'flex';

      const rulesCtx = window.globalRulesDesc || '';
      const worldCtx = window.globalWorldDesc || '';
      const genderNote = `性别：${currentGender}（请在外貌、自称、行文风格上体现此性别特征）`;

      // 组装原始角色卡参考资料（导入角色时有 _rawCard，新建时无）
      let rawCardRef = '';
      if (workChar._rawCard) {
        const rc = workChar._rawCard;
        const parts = [
          rc.description ? `角色描述：${rc.description}` : '',
          rc.personality ? `性格：${rc.personality}` : '',
          rc.scenario    ? `背景：${rc.scenario}` : '',
          rc.creatorNotes? `创作备注：${rc.creatorNotes}` : '',
          rc.firstMessage? `开场白：${rc.firstMessage}` : '',
        ].filter(Boolean);
        if (parts.length > 0) {
          rawCardRef = `\n【原始角色卡资料（必须保留其核心性格、说话方式、外貌特征，只将其融入古代背景）】：\n${parts.join('\n')}\n`;
        }
      }

      const msg1 = `我即将请你为一个古代后宫角色生成人设。请先阅读以下背景，后续生成必须严格遵守。
【长信宫规（铁律）】：\n${rulesCtx}\n\n【大世界设定】：\n${worldCtx}
角色名：${name || '（待定）'}，古代身份：${role}，${genderNote}${rawCardRef}
${existingDesc ? `已有描述（请以此为基础扩写）：\n${existingDesc}\n` : ''}${userPrompt ? `User的创作方向：\n${userPrompt}` : ''}
请回复"已阅读，将为此角色生成人设"，并简述你理解的核心要求（尤其是角色卡里的核心性格特征）。`;

      const msg2 = `很好。请为「${name || '此角色'}」生成不少于1500字的古风人设。
【严格要求，逐条执行】：
1. 角色名必须是"${name || '此角色'}"，一字不差；严格遵守宫规和大世界设定；
2. 性别为【${currentGender}】，外貌描写、自称方式、行文风格必须与此性别相符；
${workChar._rawCard ? `3. 【最重要】必须完整保留原角色卡里的核心性格特征、说话习惯、外貌特征，只是将其融入古代宫廷背景，绝对不得改变角色的本质性格；\n4.` : '3.'} ${userPrompt ? `优先实现User的创作方向：${userPrompt}` : '自由发挥，但需符合后宫角色设定'}；
${workChar._rawCard ? '5.' : '4.'} 用古典雅致的文字叙述，避免现代词汇；
${workChar._rawCard ? '6.' : '5.'} 必须包含：外貌描写、性格描写、家世背景、入宫前经历；
${workChar._rawCard ? '7.' : '6.'} 最后必须严格按以下格式提供3条说话范例（对话用英文直角双引号 " "）：
【范例1】(日常) [动作描写] "台词"
【范例2】(特殊) [动作描写] "台词"
【范例3】(私密) [动作描写] "台词"`;

      try {
        const r1 = await api.ai.chat({ messages:[{ role:'user', content:msg1 }] });
        const r1Text = typeof r1 === 'string' ? r1 : (r1?.content ?? r1?.text ?? '');
        const r2 = await api.ai.chat({
          messages:[
            { role:'user', content:msg1 },
            { role:'assistant', content:r1Text },
            { role:'user', content:msg2 }
          ]
        });
        let result = typeof r2 === 'string' ? r2 : (r2?.content ?? r2?.text ?? JSON.stringify(r2));
        result = result.replace(/\u201c/g,'"').replace(/\u201d/g,'"').replace(/\u300c/g,'"').replace(/\u300d/g,'"').replace(/\u300e/g,'"').replace(/\u300f/g,'"').replace(/\uff02/g,'"');
        document.getElementById('cce-desc').value = result;
        api.ui.toast('人设已生成，请检查后存入');
      } catch(err) { api.ui.toast('生成失败，请检查API配置'); }
      finally { globalLoader.style.display = 'none'; }
    };
  });

  // ── 返回 ──
  document.getElementById('cce-back').addEventListener('click', () => {
    modal.remove();
    openCustomStudio();
  });

  // ── 存入 ──
  document.getElementById('cce-save').addEventListener('click', async () => {
    const name = document.getElementById('cce-name').value.trim();
    if (!name) { api.ui.toast('请填写角色姓名'); return; }

    const role = roleSelect2.value === '自定义' ? customRoleInput2.value.trim() : roleSelect2.value;
    const desc = document.getElementById('cce-desc').value.trim();
    const memText = document.getElementById('cce-memory').value.trim();
    const charWb = document.getElementById('cce-charwb').value.trim();
    const palaceName = (document.getElementById('cce-palace-name') && role === '后妃') ? document.getElementById('cce-palace-name').value : '';
    const palaceRoom = (document.getElementById('cce-palace-room') && role === '后妃') ? document.getElementById('cce-palace-room').value : '';
    const assignedRank = (document.getElementById('cce-rank') && role === '后妃') ? document.getElementById('cce-rank').value : '';
    const selectedGender = document.querySelector('input[name="cce-gender"]:checked')?.value || '男';

    workChar.name = name;
    workChar.gender = selectedGender;
    workChar.ancientRole = role;
    workChar.ancientDesc = desc;
    workChar.ancientDescOriginal = desc;
    workChar.charWorldDesc = charWb;
    workChar.assignedPalace = (palaceName && palaceRoom) ? `${palaceName}${palaceRoom}` : palaceName || '';
    workChar.assignedRank = assignedRank;

    // 性别写入「TA了解的」（memoryKnown）
    if (!workChar.memoryKnown) workChar.memoryKnown = [];
    // 去掉旧的性别记录，重新写入（防止重复）
    workChar.memoryKnown = workChar.memoryKnown.filter(k => !k.startsWith('【性别】'));
    workChar.memoryKnown.unshift(`【性别】：${selectedGender}`);

    // 记忆
    if (memText) {
      if (!workChar.memorySeen) workChar.memorySeen = [];
      workChar.memorySeen.unshift({ time: hudTime ? hudTime.innerText : '入局之前', text: memText });
    }

    // 加入 selectedCharsData（去重）
    const existIdx = selectedCharsData.findIndex(c => c.id === workChar.id);
    if (existIdx >= 0) {
      selectedCharsData[existIdx] = workChar;
    } else {
      selectedCharsData.push(workChar);
      selectedCharIds.add(workChar.id);
    }

    await saveProgress({
      characters: selectedCharsData.map(c => ({
        id:c.id, name:c.name, avatar:c.avatar, customAvatar:c.customAvatar,
        gender:c.gender,
        ancientRole:c.ancientRole, ancientDesc:c.ancientDesc, ancientDescOriginal:c.ancientDescOriginal,
        assignedRank:c.assignedRank, assignedPalace:c.assignedPalace,
        memorySeen:c.memorySeen, memoryKnown:c.memoryKnown, charWorldDesc:c.charWorldDesc,
        cardAvatarCfg:c.cardAvatarCfg, storyAvatarCfg:c.storyAvatarCfg, indoorBgUrl:c.indoorBgUrl,
        _isCustom:c._isCustom
      }))
    });

    api.ui.toast(`「${name}」已存入此局`);
    modal.remove();
  });
}

// ===== 自设台：导入现有角色选择器 =====
async function openImportCharPicker() {
  const globalLoader = document.getElementById('global-loader-modal');
  document.getElementById('global-loader-text').innerText = '正在读取角色列表...';
  globalLoader.style.display = 'flex';

  let allChars = [];
  try {
    allChars = await api.characters.list();
  } catch(e) {
    globalLoader.style.display = 'none';
    api.ui.toast('读取角色列表失败');
    return;
  }
  globalLoader.style.display = 'none';

  // 过滤掉已经在当前存档里的角色
  const importedIds = new Set(selectedCharsData.map(c => c.id));
  const unimported = allChars.filter(c => !importedIds.has(c.id));

  const existing = document.getElementById('import-char-picker-modal');
  if (existing) existing.remove();

  const modal = document.createElement('div');
  modal.id = 'import-char-picker-modal';
  modal.style.cssText = 'position:fixed; inset:0; z-index:10001; background:rgba(0,0,0,0.88); display:flex; flex-direction:column;';

  const header = document.createElement('div');
  header.style.cssText = 'padding:calc(var(--safe-top,44px)+10px) 16px 10px; display:flex; justify-content:space-between; align-items:center; border-bottom:1px solid rgba(201,163,106,0.2); flex-shrink:0;';
  header.innerHTML = `
    <button id="icp-back" style="background:transparent; border:none; color:#888; font-size:16px; font-family:inherit;">‹ 返回</button>
    <div style="color:var(--primary-color); font-size:17px; font-weight:bold; letter-spacing:4px; font-family:'STZhongsong','STSong',serif;">选择导入角色</div>
    <div style="width:48px;"></div>
  `;
  modal.appendChild(header);

  const listEl = document.createElement('div');
  listEl.style.cssText = 'flex:1; overflow-y:auto; padding:12px 16px; display:flex; flex-direction:column; gap:10px;';

  if (unimported.length === 0) {
    listEl.innerHTML = '<div style="color:#666; text-align:center; padding:40px 20px; font-size:14px; letter-spacing:2px;">手机里所有角色均已导入此局</div>';
  } else {
    unimported.forEach(char => {
      const item = document.createElement('div');
      item.style.cssText = 'display:flex; align-items:center; background:rgba(0,0,0,0.5); border:1px solid #444; border-radius:8px; padding:12px; gap:14px; cursor:pointer; transition:border-color 0.2s;';
      const avatarUrl = char.avatar || 'data:image/svg+xml;utf8,<svg xmlns="http://www.w3.org/2000/svg" width="48" height="48"><rect width="48" height="48" fill="%23333"/><text x="24" y="30" font-size="20" fill="%23aaa" text-anchor="middle">?</text></svg>';
      item.innerHTML = `
        <img src="${avatarUrl}" style="width:50px; height:50px; border-radius:50%; object-fit:cover; border:1px solid #555; flex-shrink:0;">
        <div style="flex:1; min-width:0;">
          <div style="color:#fff; font-size:15px; margin-bottom:3px;">${char.name}</div>
          <div style="color:#888; font-size:12px; white-space:nowrap; overflow:hidden; text-overflow:ellipsis;">${char.description || char.creatorNotes || '暂无描述'}</div>
        </div>
        <div style="color:var(--primary-color); font-size:13px; flex-shrink:0;">导入 ›</div>
      `;
      item.addEventListener('click', () => {
        modal.remove();
        // 以角色卡原始数据为基础，进入编辑器
        // 保留原始角色卡所有字段，供AI生成人设时参考
        const baseChar = {
          id: char.id,
          name: char.name,
          avatar: char.avatar,
          customAvatar: null,
          ancientRole: '后妃',
          ancientDesc: char.description || char.creatorNotes || '',
          ancientDescOriginal: char.description || char.creatorNotes || '',
          assignedRank: '',
          assignedPalace: '',
          memorySeen: [],
          charWorldDesc: '',
          cardAvatarCfg: { scale: 100, x: 0, y: 0 },
          storyAvatarCfg: { scale: 100, x: 0, y: 0 },
          indoorBgUrl: null,
          _isCustom: false,
          // 保留原始角色卡字段，供AI生成人设时读取
          _rawCard: {
            description: char.description || '',
            personality: char.personality || '',
            scenario: char.scenario || '',
            creatorNotes: char.creatorNotes || '',
            firstMessage: char.firstMessage || '',
          }
        };
        openCustomCharEditor(baseChar, true);
      });
      listEl.appendChild(item);
    });
  }

  modal.appendChild(listEl);
  document.body.appendChild(modal);

  document.getElementById('icp-back').addEventListener('click', () => {
    modal.remove();
    openCustomStudio();
  });
}

// 代理原有的打开面板，顺便刷新宫殿图标列表
const originalBtnDevToolsClick = () => {
  devToolsModal.style.display = 'flex';
  renderDevLogs();
  renderDevPrompts();
  renderDevPalaceIcons();
  renderDevAvatarSettings();
  // 动态注入字体 tab 按钮（只注入一次）
  const tabBar = devToolsModal.querySelector('.dev-tab')?.parentElement;
  if (tabBar && !document.querySelector('.dev-tab[data-target="dev-pane-font"]')) {
    const fontTabBtn = document.createElement('button');
    fontTabBtn.className = 'dev-tab';
    fontTabBtn.dataset.target = 'dev-pane-font';
    fontTabBtn.style.cssText = 'flex:1; background:transparent; border:1px solid #555; color:#aaa; padding:8px; border-radius:6px; font-size:14px; letter-spacing:2px;';
    fontTabBtn.textContent = '字体';
    fontTabBtn.addEventListener('click', () => {
      document.querySelectorAll('.dev-tab').forEach(b => {
        b.classList.remove('active');
        b.style.background = 'transparent';
        b.style.borderColor = '#555';
        b.style.color = '#aaa';
      });
      fontTabBtn.classList.add('active');
      fontTabBtn.style.background = 'rgba(201,163,106,0.2)';
      fontTabBtn.style.borderColor = 'var(--primary-color)';
      fontTabBtn.style.color = 'var(--primary-color)';
      document.querySelectorAll('.dev-pane').forEach(p => p.style.display = 'none');
      document.getElementById('dev-pane-font').style.display = 'flex';
      renderGlobalFontPane();
    });
    tabBar.appendChild(fontTabBtn);
  }
};
// 因为是在动态生成时绑定的，我们留个全局引用
window.openDevToolsModal = originalBtnDevToolsClick;

function renderDevLogs() {
  devLogsContainer.innerHTML = '';
  if (devApiLogs.length === 0) {
    devLogsContainer.innerHTML = '<div style="color:#666; text-align:center; padding:20px; font-size:13px;">暂无调用记录</div>';
    return;
  }
  
  devApiLogs.forEach((log, i) => {
    const box = document.createElement('div');
    box.style.cssText = 'background:rgba(255,255,255,0.05); border:1px solid #444; border-radius:8px; padding:10px; display:flex; flex-direction:column; gap:8px;';
    
    // Header
    const hdr = document.createElement('div');
    hdr.style.cssText = 'display:flex; justify-content:space-between; color:var(--primary-color); font-size:12px; border-bottom:1px solid #333; padding-bottom:6px;';
    hdr.innerHTML = `<span>[${i+1}] ${log.time}</span><span>${log.error ? '<span style="color:#d9534f">Error</span>' : 'Success'}</span>`;
    box.appendChild(hdr);
    
    // Req
    const reqDiv = document.createElement('div');
    reqDiv.innerHTML = `<div style="color:#aaa; font-size:11px; margin-bottom:4px;">请求内容 (发送给大模型)：</div>
      <textarea readonly style="width:100%; height:100px; background:#111; border:1px solid #333; color:#0f0; padding:6px; font-size:11px; font-family:monospace; resize:vertical; border-radius:4px;">${JSON.stringify(log.req, null, 2)}</textarea>`;
    box.appendChild(reqDiv);
    
    // Res or Err
    const resDiv = document.createElement('div');
    if (log.error) {
       resDiv.innerHTML = `<div style="color:#aaa; font-size:11px; margin-bottom:4px;">错误信息：</div>
         <textarea readonly style="width:100%; height:60px; background:#2a1111; border:1px solid #d9534f; color:#ff9999; padding:6px; font-size:11px; font-family:monospace; resize:vertical; border-radius:4px;">${log.error}</textarea>`;
    } else {
       resDiv.innerHTML = `<div style="color:#aaa; font-size:11px; margin-bottom:4px;">大模型回复 (含思维链)：</div>
         <textarea readonly style="width:100%; height:120px; background:#111; border:1px solid #333; color:#0ff; padding:6px; font-size:11px; font-family:monospace; resize:vertical; border-radius:4px;">${JSON.stringify(log.res, null, 2)}</textarea>`;
    }
    box.appendChild(resDiv);
    
    devLogsContainer.appendChild(box);
  });
}

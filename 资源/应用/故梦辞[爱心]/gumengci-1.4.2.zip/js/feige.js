

// ===== 飞鸽传书（御笺漂流）系统 =====
const FEIGE_COLLECTION = 'gumengci_feige_v1';

// 故梦辞 Cloudflare 联机后端（匿名 ID + 自定义昵称，不依赖工坊联机账号）
const GMC_CLOUD_ENDPOINT = 'https://gumengci-cloud.1206149951.workers.dev';
const GMC_CLOUD_IDENTITY_KEY = 'gumengci_cloud_identity_v1';
const GMC_CLOUD_IDENTITY_COLLECTION = 'gmc_cloud_identity_v1';
const GMC_ACCOUNT_SESSION_COLLECTION = 'gmc_account_session_v1';
let _cachedGmcCloudIdentity = null;
let _cachedAccountName = null;

function gmcCloudRandomId(prefix) {
  return `${prefix}_${Date.now().toString(36)}_${Math.random().toString(36).slice(2, 10)}`;
}

function gmcCloudGetLocalIdentity() {
  if (_cachedGmcCloudIdentity) return _cachedGmcCloudIdentity;
  try {
    const raw = localStorage.getItem(GMC_CLOUD_IDENTITY_KEY);
    if (raw) {
      const obj = JSON.parse(raw);
      if (obj?.id && obj?.secret && obj?.nickname) {
        _cachedGmcCloudIdentity = obj;
        return obj;
      }
    }
  } catch(e) {}
  return null;
}

async function loadGmcCloudIdentity() {
  const cached=gmcCloudGetLocalIdentity(); if(cached)return cached;
  try { const rows=await api.db.list(GMC_CLOUD_IDENTITY_COLLECTION); const row=rows.find(x=>x.key==='current'); if(row?.cloudId&&row?.secret&&row?.nickname){_cachedGmcCloudIdentity={id:row.cloudId,secret:row.secret,nickname:row.nickname,accountToken:row.accountToken||'',playerId:row.playerId||'',loginAccount:row.loginAccount||''};return _cachedGmcCloudIdentity;} } catch(e) {}
  return null;
}

function gmcCloudSaveLocalIdentity(identity) {
  _cachedGmcCloudIdentity = identity;
  _cachedAccountName = identity?.nickname || _cachedAccountName;
  try { localStorage.setItem(GMC_CLOUD_IDENTITY_KEY, JSON.stringify(identity)); } catch(e) {}
  Promise.resolve().then(async()=>{try{const rows=await api.db.list(GMC_CLOUD_IDENTITY_COLLECTION);const old=rows.find(x=>x.key==='current');const data={key:'current',cloudId:identity.id,secret:identity.secret,nickname:identity.nickname,accountToken:identity.accountToken||'',playerId:identity.playerId||'',loginAccount:identity.loginAccount||''};if(old)await api.db.update(GMC_CLOUD_IDENTITY_COLLECTION,old.id,{...old,...data});else await api.db.create(GMC_CLOUD_IDENTITY_COLLECTION,data);}catch(e){}});
}

function openGmcCloudIdentityModal(options = {}) {
  return new Promise(resolve => {
    const old = document.getElementById('gmc-cloud-identity-modal');
    if (old) old.remove();
    const cur = gmcCloudGetLocalIdentity();
    const modal = document.createElement('div');
    modal.id = 'gmc-cloud-identity-modal';
    modal.style.cssText = 'position:fixed;inset:0;z-index:100000;background:rgba(0,0,0,0.82);display:flex;align-items:center;justify-content:center;padding:18px;';
    modal.innerHTML = `
      <div style="width:min(420px,92vw);background:linear-gradient(180deg,rgba(37,25,16,0.98),rgba(10,7,5,0.98));border:1px solid rgba(201,163,106,0.45);border-radius:18px;box-shadow:0 18px 60px rgba(0,0,0,0.65);padding:18px;display:flex;flex-direction:column;gap:14px;color:#e8dbc6;font-family:'STSong','Noto Serif CJK SC',serif;">
        <div style="text-align:center;color:var(--primary-color);font-size:18px;font-weight:bold;letter-spacing:4px;font-family:'STZhongsong','STSong',serif;">飞鸽联机署名</div>
        <div style="color:#bda986;font-size:12px;line-height:1.8;background:rgba(201,163,106,0.08);border:1px solid rgba(201,163,106,0.18);border-radius:10px;padding:10px 12px;">
          首次使用会在本机生成一个匿名 ID。无需登录工坊账号；昵称只用于飞鸽传书/天下圣旨展示，可随时修改。请勿发布违法、侵权、辱骂、隐私或广告内容，公开内容由发布者自行承担责任。
        </div>
        <label style="display:flex;flex-direction:column;gap:6px;color:var(--primary-color);font-size:12px;letter-spacing:2px;">
          昵称
          <input id="gmc-cloud-nickname-input" maxlength="16" value="${cur?.nickname || ''}" placeholder="请输入 1-16 字昵称" style="background:rgba(0,0,0,0.45);border:1px solid rgba(201,163,106,0.38);border-radius:10px;color:#eee;padding:10px 12px;font-family:inherit;font-size:14px;">
        </label>
        <label style="display:flex;gap:8px;align-items:flex-start;color:#a99880;font-size:12px;line-height:1.7;">
          <input id="gmc-cloud-agree-input" type="checkbox" ${cur || options.skipAgree ? 'checked' : ''} style="margin-top:4px;">
          <span>我已知晓：公屏/圣旨/评论内容会被其他安装用户看到；违规内容后果自行承担。</span>
        </label>
        <div style="display:flex;gap:10px;margin-top:2px;">
          <button id="gmc-cloud-cancel-btn" style="flex:1;background:transparent;border:1px solid rgba(201,163,106,0.28);color:#9b8b73;padding:10px;border-radius:10px;font-family:inherit;">取消</button>
          <button id="gmc-cloud-save-btn" style="flex:1;background:linear-gradient(135deg,#c9a36a,#8a6d3b);border:none;color:#1a1208;padding:10px;border-radius:10px;font-family:inherit;font-weight:bold;letter-spacing:2px;">保存</button>
        </div>
      </div>
    `;
    document.body.appendChild(modal);
    const input = modal.querySelector('#gmc-cloud-nickname-input');
    setTimeout(() => input?.focus(), 80);
    modal.querySelector('#gmc-cloud-cancel-btn').onclick = () => { modal.remove(); resolve(null); };
    modal.querySelector('#gmc-cloud-save-btn').onclick = () => {
      const nickname = input.value.trim();
      const agree = modal.querySelector('#gmc-cloud-agree-input').checked;
      if (!nickname) { api.ui.toast('请先填写昵称'); return; }
      if (nickname.length > 16) { api.ui.toast('昵称最多 16 字'); return; }
      if (!agree) { api.ui.toast('请先确认联机须知'); return; }
      const next = {
        id: cur?.id || gmcCloudRandomId('gmc'),
        secret: cur?.secret || gmcCloudRandomId('sec'),
        nickname
      };
      gmcCloudSaveLocalIdentity(next);
      modal.remove();
      resolve(next);
    };
  });
}

async function ensureGmcCloudIdentity() {
  let identity = await loadGmcCloudIdentity();
  if (!identity) identity = await openGmcCloudIdentityModal();
  if (!identity) throw new Error('尚未设置联机昵称');
  await gmcCloudFetch('/identity', { identity, nickname: identity.nickname }, 'POST', false);
  return identity;
}

async function gmcAccountRequest(path, data={}) {
  const r=await gmcCloudFetch(path,data,'POST',false); return r;
}
async function getGmcAccountSession() {
  if (window._gmcAccountSession?.token) return window._gmcAccountSession;
  const identity=await loadGmcCloudIdentity();
  if(identity?.accountToken&&identity?.playerId){const linked={token:identity.accountToken,id:identity.playerId,playerId:identity.playerId,nickname:identity.nickname,loginAccount:identity.loginAccount||''};window._gmcAccountSession=linked;return linked;}
  try {
    const rows = await api.db.list(GMC_ACCOUNT_SESSION_COLLECTION);
    const account = rows.find(x => x.key === 'current');
    if (account?.token && account?.playerId) { const normalized={...account,id:account.playerId}; window._gmcAccountSession = normalized; return normalized; }
  } catch(e) {}
  return null;
}
async function saveGmcAccountSession(session) {
  const next={ key:'current', playerId:session.id||session.playerId, nickname:session.nickname, loginAccount:session.login||'', token:session.token, savedAt:Date.now() };
  const rows=await api.db.list(GMC_ACCOUNT_SESSION_COLLECTION);
  const old=rows.find(x=>x.key==='current');
  if(old) await api.db.update(GMC_ACCOUNT_SESSION_COLLECTION,old.id,{...old,...next});
  else await api.db.create(GMC_ACCOUNT_SESSION_COLLECTION,next);
  window._gmcAccountSession={...next,id:next.playerId};
  const identity=await loadGmcCloudIdentity(); if(identity)gmcCloudSaveLocalIdentity({...identity,accountToken:next.token,playerId:next.playerId,loginAccount:next.loginAccount});
  return window._gmcAccountSession;
}
async function clearGmcAccountSession() { try { const rows=await api.db.list(GMC_ACCOUNT_SESSION_COLLECTION); for(const row of rows.filter(x=>x.key==='current')) await api.db.delete(GMC_ACCOUNT_SESSION_COLLECTION,row.id); } catch(e){} window._gmcAccountSession=null; }
async function restoreGmcAccountSession() { const account=await getGmcAccountSession(); if(!account?.token)return null; try { const verified=await gmcCloudFetch('/account/me',{token:account.token},'POST',false); window._gmcAccountSession={...account,...verified,id:verified.id,playerId:verified.id}; return window._gmcAccountSession; } catch(e) { window._gmcAccountSession=account; return account; } }
async function requireGmcAccountSession() { const a=await restoreGmcAccountSession(); if(!a?.token) throw new Error('请先在云笺阁账号中心登录正式账号'); return a; }
async function openGmcAccountModal() {
  const old=document.getElementById('gmc-account-modal'); if(old) old.remove();
  const saved=await getGmcAccountSession();
  const m=document.createElement('div'); m.id='gmc-account-modal'; m.style.cssText='position:fixed;inset:0;z-index:100001;background:rgba(0,0,0,.82);display:flex;align-items:center;justify-content:center;padding:18px';
  m.innerHTML=`<div style="width:min(420px,92vw);background:#211811;color:#eee;border:1px solid #c9a36a;border-radius:18px;padding:18px;font-family:inherit"><h3 style="text-align:center;color:#e5c487;letter-spacing:4px">账号中心</h3><div id="gmc-account-status" style="text-align:center;color:#c9a36a;margin:10px 0">${saved?`玩家ID：${saved.id}<br>用户名：${saved.nickname}`:'尚未登录正式账号'}</div><input id="gmc-account-login" placeholder="登录账号" style="width:100%;box-sizing:border-box;margin:5px 0;padding:10px;background:#100c09;color:#fff;border:1px solid #765;border-radius:8px"><input id="gmc-account-nick" placeholder="用户名（注册时填写）" style="width:100%;box-sizing:border-box;margin:5px 0;padding:10px;background:#100c09;color:#fff;border:1px solid #765;border-radius:8px"><input id="gmc-account-pass" type="password" placeholder="密码（至少8位）" style="width:100%;box-sizing:border-box;margin:5px 0;padding:10px;background:#100c09;color:#fff;border:1px solid #765;border-radius:8px"><div style="display:flex;gap:8px;margin-top:10px"><button id="gmc-account-register" style="flex:1;padding:10px">注册</button><button id="gmc-account-login-btn" style="flex:1;padding:10px">登录</button><button id="gmc-account-close" style="flex:1;padding:10px">关闭</button></div></div>`;
  document.body.appendChild(m);
  const persist=async r=>{await saveGmcAccountSession(r);const legacy=gmcCloudGetLocalIdentity();if(legacy)try{await gmcCloudFetch('/account/bind-legacy',{token:r.token,legacy},'POST',false)}catch(e){}api.ui.toast(`登录成功，玩家ID：${r.id}`);m.remove();};
  m.querySelector('#gmc-account-register').onclick=async()=>{try{const r=await gmcAccountRequest('/account/register',{login:m.querySelector('#gmc-account-login').value,nickname:m.querySelector('#gmc-account-nick').value,password:m.querySelector('#gmc-account-pass').value});await persist(r)}catch(e){api.ui.toast(`注册失败：${e?.message||'无法保存登录状态'}`)}};
  m.querySelector('#gmc-account-login-btn').onclick=async()=>{const b=m.querySelector('#gmc-account-login-btn');b.disabled=true;b.textContent='登录中…';try{const r=await gmcAccountRequest('/account/login',{login:m.querySelector('#gmc-account-login').value,password:m.querySelector('#gmc-account-pass').value});if(!r?.token) throw new Error('服务器返回的登录结果无效，请检查网络代理');await persist(r)}catch(e){api.ui.toast(`登录失败：${e?.message||'请检查账号、密码和网络'}`)}finally{b.disabled=false;b.textContent='登录'}};
  m.querySelector('#gmc-account-close').onclick=()=>m.remove();
}

async function gmcCloudFetch(path, body, method = 'GET', needIdentity = true) {
  const networkApi = api?.network?.fetch || (typeof AiPhone !== 'undefined' ? AiPhone?.network?.fetch : null);
  if (!networkApi) throw new Error('当前工坊版本不支持 network.fetch，请更新宿主');
  let payload = body;
  if (needIdentity) {
    const identity = await ensureGmcCloudIdentity();
    payload = { ...(body || {}), identity };
  }
  let requestMethod = method;
  if (method === 'GET' && (needIdentity || payload?.token)) {
    requestMethod = 'POST';
    payload = { ...(payload || {}), _method: 'GET' };
  }
  const res = await networkApi({
    url: GMC_CLOUD_ENDPOINT + path,
    method: requestMethod,
    headers: { 'Content-Type': 'application/json' },
    body: requestMethod === 'GET' ? undefined : payload,
    proxy: true,
    timeoutMs: 60000
  });
  if (!res?.ok) {
    let parsed = res?.json;
    if (typeof parsed === 'string') { try { parsed = JSON.parse(parsed); } catch(e) {} }
    const msg = parsed?.error || res?.text || `HTTP ${res?.status || 0}`;
    throw new Error(String(msg).slice(0, 160));
  }
  if (res?.json !== undefined && res?.json !== null) {
    if (typeof res.json === 'string') { try { return JSON.parse(res.json); } catch(e) {} }
    return res.json;
  }
  if (typeof res?.text === 'string' && res.text.trim()) { try { return JSON.parse(res.text); } catch(e) {} }
  return null;
}

// 获取飞鸽联机昵称
async function getAccountName() {
  if (_cachedAccountName) return _cachedAccountName;
  const identity = await ensureGmcCloudIdentity();
  _cachedAccountName = identity.nickname || '未知用户';
  return _cachedAccountName;
}

async function szListEdicts() {
  return gmcCloudFetch('/edicts?limit=50', null, 'GET');
}

async function szInsertEdict(row) {
  return gmcCloudFetch('/edicts', row, 'POST');
}

async function szDeleteEdict(id) {
  return gmcCloudFetch('/edicts/' + encodeURIComponent(id), null, 'DELETE');
}

async function szListMyEdicts(ownerName) {
  return gmcCloudFetch('/edicts/mine?limit=50', null, 'GET');
}

// ── 漂流瓶 Cloudflare 后端 ──
async function fgInsert(row) {
  return gmcCloudFetch('/feige', row, 'POST');
}

async function fgTakeRandom(myOwnerName) {
  return gmcCloudFetch('/feige/take', null, 'POST');
}

async function fgListMine(ownerName) {
  return gmcCloudFetch('/feige/mine?limit=50', null, 'GET');
}

async function fgDelete(id) {
  return gmcCloudFetch('/feige/' + encodeURIComponent(id), null, 'DELETE');
}

// ── 圣旨点赞 ──
async function szToggleLike(shengzhiId, myName) {
  const res = await gmcCloudFetch('/edicts/' + encodeURIComponent(shengzhiId) + '/like', null, 'POST');
  return !!res?.liked;
}

async function szGetMyLikes(myName) {
  const rows = await gmcCloudFetch('/edicts/likes', null, 'GET');
  return new Set((rows || []).map(r => r.shengzhi_id));
}

// ── 圣旨评论 ──
async function szListComments(shengzhiId) {
  return gmcCloudFetch('/edicts/' + encodeURIComponent(shengzhiId) + '/comments', null, 'GET');
}

async function szAddComment(shengzhiId, authorName, content) {
  return gmcCloudFetch('/edicts/' + encodeURIComponent(shengzhiId) + '/comments', { content }, 'POST');
}

async function szDeleteComment(commentId) {
  return gmcCloudFetch('/comments/' + encodeURIComponent(commentId), null, 'DELETE');
}

async function szToggleCommentLike(commentId, myName) {
  const res = await gmcCloudFetch('/comments/' + encodeURIComponent(commentId) + '/like', null, 'POST');
  return !!res?.liked;
}

async function szGetMyCommentLikes(myName) {
  const rows = await gmcCloudFetch('/comments/likes', null, 'GET');
  return new Set((rows || []).map(r => r.comment_id));
}

async function fgListReplies(rootId) {
  return gmcCloudFetch('/feige/' + encodeURIComponent(rootId) + '/replies?limit=50', null, 'GET');
}

async function fgListLetterBox() {
  return gmcCloudFetch('/feige/letterbox?limit=80', null, 'GET');
}

// ── 云笺阁：聊天室 / 问题反馈 ──
async function gmcListCommunityPosts(type) {
  return gmcCloudFetch('/community/posts?type=' + encodeURIComponent(type) + '&limit=80', null, 'GET');
}

async function gmcCreateCommunityPost(type, title, content) {
  return gmcCloudFetch('/community/posts', { type, title, content }, 'POST');
}

async function gmcToggleCommunityPostLike(postId) {
  return gmcCloudFetch('/community/posts/' + encodeURIComponent(postId) + '/like', null, 'POST');
}

async function gmcListCommunityComments(postId) {
  return gmcCloudFetch('/community/posts/' + encodeURIComponent(postId) + '/comments', null, 'GET');
}

async function gmcAddCommunityComment(postId, content) {
  return gmcCloudFetch('/community/posts/' + encodeURIComponent(postId) + '/comments', { content }, 'POST');
}

async function gmcToggleCommunityCommentLike(commentId) {
  return gmcCloudFetch('/community/comments/' + encodeURIComponent(commentId) + '/like', null, 'POST');
}

async function gmcDeleteCommunityPost(postId) {
  return gmcCloudFetch('/community/posts/' + encodeURIComponent(postId), null, 'DELETE');
}

async function gmcDeleteCommunityComment(commentId) {
  return gmcCloudFetch('/community/comments/' + encodeURIComponent(commentId), null, 'DELETE');
}

function gmcEscapeHtml(str) {
  return String(str ?? '').replace(/[&<>"']/g, ch => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[ch]));
}

function gmcCommunityTime(str) {
  if (!str) return '';
  try {
    const d = new Date(str);
    if (Number.isNaN(d.getTime())) return String(str).slice(0, 16);
    const pad = n => String(n).padStart(2, '0');
    return `${pad(d.getMonth()+1)}-${pad(d.getDate())} ${pad(d.getHours())}:${pad(d.getMinutes())}`;
  } catch(e) { return String(str).slice(0, 16); }
}

async function openGmcCommunityPanel() {
  const old = document.getElementById('gmc-community-modal');
  if (old) old.remove();

  const modal = document.createElement('div');
  modal.id = 'gmc-community-modal';
  modal.style.cssText = `
    position:fixed; inset:0; z-index:99999;
    background:
      radial-gradient(circle at 20% 8%, rgba(201,163,106,0.18), transparent 28%),
      linear-gradient(180deg, rgba(7,5,4,0.74), rgba(2,2,2,0.9)),
      url('https://www.imgfox.cn/apis/uploads/20260818/cd2a4b22f1ec4748/IMG_9643.jpeg') center/cover no-repeat;
    display:flex; flex-direction:column; color:#eee;
  `;
  modal.innerHTML = `
    <div style="position:absolute;inset:0;background:rgba(5,4,3,0.50);backdrop-filter:blur(8px);-webkit-backdrop-filter:blur(8px);"></div>
    <div style="position:relative;z-index:1;display:flex;flex-direction:column;height:100%;overflow:hidden;">
      <div style="padding:calc(var(--safe-top,44px) + 10px) 16px 10px;display:flex;align-items:center;justify-content:space-between;border-bottom:1px solid rgba(201,163,106,0.16);flex-shrink:0;">
        <button id="gmc-community-back" style="background:transparent;border:none;color:#9c8c75;font-size:16px;font-family:inherit;">‹ 返回</button>
        <div style="color:var(--primary-color);font-size:19px;font-weight:bold;letter-spacing:5px;font-family:'STZhongsong','STSong',serif;background:linear-gradient(to bottom,#ffe9b8,#c9a36a);-webkit-background-clip:text;-webkit-text-fill-color:transparent;filter:drop-shadow(0 1px 4px rgba(0,0,0,0.8));">云笺阁</div>
        <div style="display:flex;gap:6px"><button id="gmc-account-btn" style="background:rgba(201,163,106,0.08);border:1px solid rgba(201,163,106,0.32);color:var(--primary-color);font-size:11px;border-radius:999px;padding:5px 8px;font-family:inherit;">账号</button><button id="gmc-friends-btn" style="position:relative;background:rgba(201,163,106,0.08);border:1px solid rgba(201,163,106,0.32);color:var(--primary-color);font-size:11px;border-radius:999px;padding:5px 8px;font-family:inherit;">好友<span id="gmc-friend-dot" style="display:none;color:#f66">●</span></button><button id="gmc-community-name" style="background:rgba(201,163,106,0.08);border:1px solid rgba(201,163,106,0.32);color:var(--primary-color);font-size:11px;border-radius:999px;padding:5px 8px;font-family:inherit;">云名</button></div>
      </div>
      <div style="padding:10px 14px 8px;flex-shrink:0;">
        <div style="display:flex;gap:8px;padding:4px;background:rgba(0,0,0,0.22);border:1px solid rgba(201,163,106,0.18);border-radius:999px;box-shadow:inset 0 0 18px rgba(255,255,255,0.025);backdrop-filter:blur(12px);-webkit-backdrop-filter:blur(12px);">
          <button class="gmc-community-tab" data-type="chat" style="flex:1;padding:9px 0;border-radius:999px;border:none;background:linear-gradient(135deg,rgba(201,163,106,0.26),rgba(201,163,106,0.10));color:var(--primary-color);font-family:inherit;letter-spacing:3px;box-shadow:0 4px 14px rgba(0,0,0,0.22);">聊天室</button>
          <button class="gmc-community-tab" data-type="feedback" style="flex:1;padding:9px 0;border-radius:999px;border:none;background:transparent;color:#8f806a;font-family:inherit;letter-spacing:3px;">问题反馈</button>
          <button class="gmc-community-tab" data-type="private" style="flex:1;padding:9px 0;border-radius:999px;border:none;background:transparent;color:#8f806a;font-family:inherit;letter-spacing:3px;">私聊</button>
        </div>
      </div>
      <div id="gmc-community-body" style="flex:1;min-height:0;overflow-y:auto;padding:10px 14px 12px;display:flex;flex-direction:column;gap:12px;"></div>
      <div id="gmc-community-composer" style="flex-shrink:0;padding:10px 12px calc(var(--safe-bottom,24px) + 10px);border-top:1px solid rgba(201,163,106,0.14);background:rgba(5,4,3,0.62);backdrop-filter:blur(16px);-webkit-backdrop-filter:blur(16px);"></div>
    </div>
  `;
  document.body.appendChild(modal);
  modal.querySelector('#gmc-community-back').onclick = () => modal.remove();
  modal.querySelector('#gmc-account-btn').onclick = () => openGmcAccountModal();
  modal.querySelector('#gmc-friends-btn').onclick = () => openGmcFriendsPanel();
  modal.querySelector('#gmc-community-name').onclick = async () => {
    const identity = await openGmcCloudIdentityModal({ skipAgree: true });
    if (!identity) return;
    try { await gmcCloudFetch('/identity', { identity, nickname: identity.nickname }, 'POST', false); api.ui.toast('云名已更新'); }
    catch(e) { api.ui.toast('云名已保存在本机，云端同步失败'); }
  };

  let currentType = 'chat';
  const body = modal.querySelector('#gmc-community-body');
  const composer = modal.querySelector('#gmc-community-composer');

  async function render(type) {
    currentType = type;
    modal.querySelectorAll('.gmc-community-tab').forEach(btn => {
      const on = btn.dataset.type === type;
      btn.style.background = on ? 'linear-gradient(135deg,rgba(201,163,106,0.26),rgba(201,163,106,0.10))' : 'transparent';
      btn.style.color = on ? 'var(--primary-color)' : '#8f806a';
      btn.style.boxShadow = on ? '0 4px 14px rgba(0,0,0,0.22)' : 'none';
    });
    body.innerHTML = '<div style="color:#8d7f6a;text-align:center;padding:36px 0;letter-spacing:2px;">正在取来云笺……</div>';
    composer.innerHTML = '';
    try {
      await ensureGmcCloudIdentity();
      if (type === 'private') { await renderPrivateHome(); return; }
      const posts = await gmcListCommunityPosts(type) || [];
      body.innerHTML = '';
      if (!posts.length) {
        const empty = document.createElement('div');
        empty.style.cssText = 'margin:auto;color:#776b59;text-align:center;line-height:1.9;letter-spacing:1px;';
        empty.innerHTML = `${type === 'chat' ? '聊天室暂时静悄悄。' : '暂无问题反馈。'}<br><span style="font-size:12px;">在下方写下第一封云笺吧。</span>`;
        body.appendChild(empty);
      } else {
        posts.slice().reverse().forEach(post => body.appendChild(buildCommunityPostCard(post, type)));
        setTimeout(() => { body.scrollTop = body.scrollHeight; }, 80);
      }
      renderComposer(type);
    } catch(e) {
      body.innerHTML = `<div style="color:#bda986;text-align:center;padding:36px 18px;line-height:1.9;">云笺阁打开失败：<br>${gmcEscapeHtml((e?.message || String(e)).slice(0,120))}</div>`;
    }
  }

  async function renderPrivateHome() {
    composer.innerHTML = '';
    const account = await restoreGmcAccountSession();
    if (!account?.token) { body.innerHTML='<div style="margin:auto;text-align:center;color:#c9a36a;line-height:2">请先点击右上角“账号”完成登录<br><span style="font-size:12px;color:#85765f">登录后可查看好友、陌生人信息与共享存档</span></div>'; return; }
    const call=(path,data={},method='GET')=>gmcCloudFetch(path,{...data,token:account.token},method,false);
    const friends=await call('/friends'); const shared=await call('/friends/share/list');
    body.innerHTML=`<div style="padding:12px 14px;border:1px solid rgba(201,163,106,.22);border-radius:16px;background:rgba(255,255,255,.05);margin-bottom:10px"><b style="color:#e8ca91">好友私聊</b><div style="color:#8f806a;font-size:12px;margin-top:6px">只允许已互加好友的玩家互发私信</div>${(friends||[]).map(x=>`<button data-private-id="${x.id}" style="display:block;width:100%;margin-top:9px;text-align:left;padding:10px;border:1px solid rgba(201,163,106,.2);border-radius:11px;background:rgba(0,0,0,.2);color:#eee;font:13px inherit">${gmcEscapeHtml(x.nickname)} <small style="color:#8f806a">${x.id}</small></button>`).join('')||'<p style="color:#9b8b73;font-size:13px">暂未添加好友</p>'}</div><details style="padding:12px 14px;border:1px solid rgba(201,163,106,.18);border-radius:16px;background:rgba(255,255,255,.035);margin-bottom:10px"><summary style="color:#d8b77b;cursor:pointer">陌生人信息</summary><p style="color:#9b8b73;font-size:12px;line-height:1.8">在聊天室或评论区点击玩家名称，可查看陌生人资料并发送好友申请。</p></details>`;
    body.querySelectorAll('[data-private-id]').forEach(b=>b.onclick=()=>openGmcPrivateChat(b.dataset.privateId,b.textContent.trim().split(' GMC-')[0]));
    const sharedBox=document.createElement('div');
    sharedBox.style.cssText='margin-top:10px;padding:12px 14px;border:1px solid rgba(201,163,106,.2);border-radius:16px;background:rgba(255,255,255,.04);';
    sharedBox.innerHTML='<b style="color:#e8ca91">收到的共享存档</b>'+((shared||[]).map(x=>`<div style="padding:10px 0;border-top:1px solid rgba(201,163,106,.12);color:#e7d8bd"><b>${gmcEscapeHtml(x.name)}</b><div style="color:#897a64;font-size:11px;margin:4px 0">来自：${gmcEscapeHtml(x.owner_name||'好友')} · ${x.permission==='copy'?'允许复制':'仅查看'}</div><button data-shared-view="${x.id}" style="border:1px solid rgba(201,163,106,.35);border-radius:999px;background:transparent;color:#d8b77b;padding:5px 10px;font:11px inherit">查看</button>${x.permission==='copy'?`<button data-shared-copy="${x.id}" data-owner="${gmcEscapeHtml(x.owner_name||'好友')}" style="margin-left:6px;border:1px solid rgba(201,163,106,.35);border-radius:999px;background:rgba(181,138,76,.2);color:#e8cf9e;padding:5px 10px;font:11px inherit">收入忆尘录</button>`:''}</div>`).join('')||'<p style="color:#9b8b73;font-size:12px">暂无好友向你分享存档</p>');
    body.appendChild(sharedBox);
    sharedBox.querySelectorAll('[data-shared-view]').forEach(b=>b.onclick=async()=>{try{const s=await gmcCloudFetch('/cloud/saves/'+encodeURIComponent(b.dataset.sharedView),{token:account.token},'GET',false);const p=getSharedCloudSavePreview(s.payload,s);await api.ui.confirm({title:s.name||'共享存档',message:`分享者：${s.owner_name||'好友'}\n权限：${s.canCopy?'允许复制':'仅查看'}\n\n游戏时长：${p.duration}\n角色数量：${p.characters}\nNPC数量：${p.npcs}\n建筑：已建${p.palaces}座${p.building?` · 修建中${p.building}座`:''}\n记事数量：${p.records}\n国库银两：${p.silver}`})}catch(e){api.ui.toast(e.message)}});
    sharedBox.querySelectorAll('[data-shared-copy]').forEach(b=>b.onclick=async()=>{try{await copySharedCloudSaveToArchive(b.dataset.sharedCopy,b.dataset.owner);api.ui.toast('已收入忆尘录，可在读档中查看')}catch(e){api.ui.toast(e.message)}});
  }

  function renderComposer(type) {
    composer.innerHTML = `
      ${type === 'feedback' ? `<input id="gmc-community-title" maxlength="40" placeholder="问题标题" style="width:100%;margin-bottom:8px;background:rgba(0,0,0,0.38);border:1px solid rgba(201,163,106,0.24);border-radius:13px;color:#eee;padding:10px 12px;font-family:inherit;font-size:13px;">` : ''}
      <div style="display:flex;align-items:flex-end;gap:8px;">
        <textarea id="gmc-community-content" maxlength="1200" rows="1" placeholder="${type === 'chat' ? '输入留言……' : '描述问题、建议或复现步骤……'}" style="flex:1;max-height:110px;min-height:42px;background:rgba(0,0,0,0.38);border:1px solid rgba(201,163,106,0.24);border-radius:18px;color:#eee;padding:10px 12px;font-family:'STSong','Noto Serif CJK SC',serif;font-size:13px;line-height:1.6;resize:none;outline:none;"></textarea>
        <button id="gmc-community-submit" style="width:54px;height:42px;flex-shrink:0;background:linear-gradient(135deg,#d2af75,#8a6d3b);border:1px solid rgba(255,233,184,0.36);color:#1a1208;border-radius:18px;font-family:inherit;font-weight:bold;letter-spacing:2px;box-shadow:0 5px 16px rgba(0,0,0,0.28);">发送</button>
      </div>
      <div style="color:#6f6353;font-size:10px;margin-top:6px;text-align:center;">公开可见 · 可点赞评论 · 请勿发布违规内容</div>
    `;
    const textarea = composer.querySelector('#gmc-community-content');
    textarea.addEventListener('input', () => {
      textarea.style.height = '42px';
      textarea.style.height = Math.min(textarea.scrollHeight, 110) + 'px';
    });
    composer.querySelector('#gmc-community-submit').onclick = async () => {
      const title = composer.querySelector('#gmc-community-title')?.value?.trim() || '';
      const content = textarea.value.trim();
      if (type === 'feedback' && !title) { api.ui.toast('请填写问题标题'); return; }
      if (!content) { api.ui.toast('请填写内容'); return; }
      const btn = composer.querySelector('#gmc-community-submit');
      btn.disabled = true; btn.innerText = '…';
      try {
        await gmcCreateCommunityPost(type, title, content);
        textarea.value = '';
        api.ui.toast(type === 'chat' ? '留言已发送' : '反馈已发布');
        await render(type);
      } catch(e) {
        api.ui.toast('发送失败：' + (e?.message || '').slice(0,60));
      } finally {
        btn.disabled = false; btn.innerText = '发送';
      }
    };
  }

  function buildCommunityPostCard(post, type) {
    const isMine = !!post.is_mine;
    const card = document.createElement('div');
    card.style.cssText = `display:flex;flex-direction:column;align-items:${isMine ? 'flex-end' : 'flex-start'};gap:6px;`;
    card.innerHTML = `
      <div style="max-width:86%;display:flex;flex-direction:column;gap:5px;align-items:${isMine ? 'flex-end' : 'flex-start'};">
        <button class="gmc-author-link" style="background:transparent;border:0;color:#c9a36a;font-size:11px;padding:0 4px;font-family:inherit;cursor:pointer;">${gmcEscapeHtml(post.author_name || '某位玩家')} · ${gmcCommunityTime(post.created_at)}</button>
        <div style="background:${isMine ? 'linear-gradient(135deg,rgba(201,163,106,0.28),rgba(126,92,52,0.36))' : 'rgba(8,6,5,0.58)'};border:1px solid ${isMine ? 'rgba(201,163,106,0.42)' : 'rgba(201,163,106,0.22)'};border-radius:${isMine ? '18px 6px 18px 18px' : '6px 18px 18px 18px'};padding:11px 12px;box-shadow:0 8px 24px rgba(0,0,0,0.22);backdrop-filter:blur(12px);-webkit-backdrop-filter:blur(12px);">
          ${type === 'feedback' ? `<div style="color:var(--primary-color);font-size:14px;font-weight:bold;letter-spacing:1px;font-family:'STZhongsong','STSong',serif;line-height:1.5;margin-bottom:5px;">${gmcEscapeHtml(post.title || '无题反馈')}</div>` : ''}
          <div style="color:#e6ddcf;font-size:13px;line-height:1.85;white-space:pre-wrap;font-family:'STSong','Noto Serif CJK SC',serif;">${gmcEscapeHtml(post.content || '')}</div>
        </div>
        <div style="display:flex;gap:8px;align-items:center;padding:0 3px;">
          <button class="gmc-post-like" style="background:transparent;border:none;color:#bda986;font-size:12px;font-family:inherit;padding:3px 4px;">❤ ${post.like_count || 0}</button>
          <button class="gmc-post-comments" style="background:transparent;border:none;color:#bda986;font-size:12px;font-family:inherit;padding:3px 4px;">评论 ${post.comment_count || 0}</button>
          ${isMine ? `<button class="gmc-post-delete" style="background:transparent;border:none;color:#b36d6d;font-size:12px;font-family:inherit;padding:3px 4px;">删除</button>` : ''}
        </div>
      </div>
      <div class="gmc-comments-wrap" style="display:none;width:94%;align-self:center;background:rgba(0,0,0,0.24);border:1px solid rgba(201,163,106,0.13);border-radius:14px;padding:9px;flex-direction:column;gap:8px;"></div>
    `;
    card.querySelector('.gmc-post-like').onclick = async () => {
      try { const res = await gmcToggleCommunityPostLike(post.id); post.like_count = res?.like_count ?? ((post.like_count || 0) + (res?.liked ? 1 : -1)); card.querySelector('.gmc-post-like').innerText = `❤ ${Math.max(0, post.like_count || 0)}`; }
      catch(e) { api.ui.toast('点赞失败'); }
    };
    card.querySelector('.gmc-author-link').onclick = async () => {
      const playerId=post.player_id; if (!playerId) { api.ui.toast('该用户尚未绑定正式账号'); return; }
      const ok = await api.ui.confirm({ title: post.author_name || '玩家资料', message: `玩家ID：${playerId}\n确定发送好友申请吗？` });
      if (!ok) return;
      try { const a=await getGmcAccountSession(); if(!a?.token) throw new Error('请先登录正式账号'); await gmcCloudFetch('/friends/request',{token:a.token,playerId},'POST',false); api.ui.toast('好友申请已发送'); } catch(e) { api.ui.toast(e.message||'操作失败'); }
    };
    const commentsWrap = card.querySelector('.gmc-comments-wrap');
    card.querySelector('.gmc-post-comments').onclick = async () => {
      const open = commentsWrap.style.display !== 'none';
      if (open) { commentsWrap.style.display = 'none'; return; }
      commentsWrap.style.display = 'flex';
      await renderComments(post, commentsWrap);
    };
    const del = card.querySelector('.gmc-post-delete');
    if (del) del.onclick = async () => {
      const ok = await api.ui.confirm({ title:'删除云笺', message:'确定删除这条内容？' });
      if (!ok) return;
      try { await gmcDeleteCommunityPost(post.id); api.ui.toast('已删除'); await render(currentType); }
      catch(e) { api.ui.toast('删除失败'); }
    };
    return card;
  }

  async function renderComments(post, wrap) {
    wrap.innerHTML = '<div style="color:#766a58;font-size:12px;text-align:center;padding:8px;">正在展开评论……</div>';
    try {
      const comments = await gmcListCommunityComments(post.id) || [];
      wrap.innerHTML = '';
      if (!comments.length) wrap.innerHTML = '<div style="color:#665c4d;font-size:12px;text-align:center;padding:4px;">暂无评论</div>';
      comments.forEach(c => {
        const row = document.createElement('div');
        row.style.cssText = 'background:rgba(255,255,255,0.035);border:1px solid rgba(255,255,255,0.06);border-radius:10px;padding:8px;display:flex;flex-direction:column;gap:5px;';
        row.innerHTML = `
          <div style="display:flex;justify-content:space-between;gap:8px;">
            <button class="gmc-comment-author" style="background:transparent;border:0;color:#c9a36a;font-size:12px;padding:0;font-family:inherit;cursor:pointer;">${gmcEscapeHtml(c.author_name || '某位玩家')} <span style="color:#665c4d;">${gmcCommunityTime(c.created_at)}</span></button>
            <div style="display:flex;gap:8px;">
              <button class="gmc-comment-like" style="background:transparent;border:none;color:#9d8c73;font-size:12px;font-family:inherit;">❤ ${c.like_count || 0}</button>
              ${c.is_mine ? `<button class="gmc-comment-delete" style="background:transparent;border:none;color:#b36d6d;font-size:12px;font-family:inherit;">删</button>` : ''}
            </div>
          </div>
          <div style="color:#d5c9b8;font-size:12px;line-height:1.75;white-space:pre-wrap;">${gmcEscapeHtml(c.content || '')}</div>
        `;
        row.querySelector('.gmc-comment-like').onclick = async () => {
          try { const res = await gmcToggleCommunityCommentLike(c.id); c.like_count = res?.like_count ?? ((c.like_count || 0) + (res?.liked ? 1 : -1)); row.querySelector('.gmc-comment-like').innerText = `❤ ${Math.max(0, c.like_count || 0)}`; }
          catch(e) { api.ui.toast('点赞失败'); }
        };
        row.querySelector('.gmc-comment-author').onclick = async () => {
          const playerId=c.player_id;if (!playerId) { api.ui.toast('该用户尚未绑定正式账号'); return; }
          const ok=await api.ui.confirm({title:c.author_name||'玩家资料',message:`玩家ID：${playerId}\n确定发送好友申请吗？`});
          if(!ok)return; try{const a=await getGmcAccountSession();if(!a?.token)throw new Error('请先登录正式账号');await gmcCloudFetch('/friends/request',{token:a.token,playerId},'POST',false);api.ui.toast('好友申请已发送')}catch(e){api.ui.toast(e.message||'操作失败')}
        };
        const cdel = row.querySelector('.gmc-comment-delete');
        if (cdel) cdel.onclick = async () => {
          const ok = await api.ui.confirm({ title:'删除评论', message:'确定删除这条评论？' });
          if (!ok) return;
          try { await gmcDeleteCommunityComment(c.id); await renderComments(post, wrap); }
          catch(e) { api.ui.toast('删除失败'); }
        };
        wrap.appendChild(row);
      });
      const commentBox = document.createElement('div');
      commentBox.style.cssText = 'display:flex;gap:8px;margin-top:2px;';
      commentBox.innerHTML = `
        <input class="gmc-comment-input" maxlength="180" placeholder="写评论……" style="flex:1;background:rgba(0,0,0,0.36);border:1px solid rgba(201,163,106,0.2);border-radius:999px;color:#eee;padding:8px 11px;font-family:inherit;font-size:12px;">
        <button class="gmc-comment-send" style="background:rgba(201,163,106,0.18);border:1px solid rgba(201,163,106,0.4);color:var(--primary-color);border-radius:999px;padding:8px 12px;font-family:inherit;font-size:12px;">发</button>
      `;
      wrap.appendChild(commentBox);
      commentBox.querySelector('.gmc-comment-send').onclick = async () => {
        const input = commentBox.querySelector('.gmc-comment-input');
        const txt = input.value.trim();
        if (!txt) { api.ui.toast('评论不能为空'); return; }
        try { await gmcAddCommunityComment(post.id, txt); input.value = ''; post.comment_count = (post.comment_count || 0) + 1; await renderComments(post, wrap); }
        catch(e) { api.ui.toast('评论失败：' + (e?.message || '').slice(0,50)); }
      };
      commentBox.querySelector('.gmc-comment-input').addEventListener('keydown', e => { if (e.key === 'Enter') commentBox.querySelector('.gmc-comment-send').onclick(); });
    } catch(e) {
      wrap.innerHTML = `<div style="color:#9d8c73;font-size:12px;text-align:center;padding:8px;">评论加载失败：${gmcEscapeHtml((e?.message || '').slice(0,80))}</div>`;
    }
  }

  modal.querySelectorAll('.gmc-community-tab').forEach(btn => btn.onclick = () => render(btn.dataset.type));
  render('chat');
}

async function openGmcFriendsPanel() {
  const old=document.getElementById('gmc-friends-modal'); if(old) old.remove();
  const m=document.createElement('div'); m.id='gmc-friends-modal'; m.style.cssText="position:fixed;inset:0;z-index:100002;background:linear-gradient(180deg,rgba(10,7,4,.72),rgba(3,2,1,.9)),url('https://www.imgfox.cn/apis/uploads/20260818/cd2a4b22f1ec4748/IMG_9643.jpeg') center/cover no-repeat;color:#eee;padding:calc(var(--safe-top,44px) + 12px) 14px 20px;font-family:inherit;overflow:auto;backdrop-filter:blur(12px);-webkit-backdrop-filter:blur(12px)";
  m.innerHTML='<div style="max-width:520px;margin:0 auto;min-height:100%;display:flex;flex-direction:column"><div style="display:flex;justify-content:space-between;align-items:center;padding:12px 2px 18px;border-bottom:1px solid rgba(201,163,106,.24)"><b style="color:#f0d39a;letter-spacing:5px;font-size:20px;text-shadow:0 2px 10px #000">好友</b><button id="gmc-friend-close" style="border:1px solid rgba(201,163,106,.45);border-radius:999px;background:rgba(201,163,106,.12);color:#e6c98d;padding:7px 16px;font:13px inherit">关闭</button></div><div style="display:flex;gap:7px;margin:16px 0;padding:5px;background:rgba(255,255,255,.04);border:1px solid rgba(201,163,106,.22);border-radius:18px"><button data-f="friends" style="flex:1;border:0;border-radius:13px;background:linear-gradient(135deg,#c9a36a,#80613a);color:#1b1208;padding:10px 8px;font:13px inherit">好友列表</button><button data-f="requests" style="flex:1;border:0;border-radius:13px;background:transparent;color:#c9a36a;padding:10px 8px;font:13px inherit">好友申请<span id="gmc-request-dot" style="display:none;color:#ff766d;margin-left:4px">●</span></button></div><div id="gmc-friend-body" style="flex:1;padding:4px 2px 30px"></div></div>';
  document.body.appendChild(m); m.querySelector('#gmc-friend-close').onclick=()=>m.remove();
  const body=m.querySelector('#gmc-friend-body'); const acct=await restoreGmcAccountSession();
  if(!acct?.token){body.innerHTML='<div style="margin-top:40px;padding:26px;text-align:center;border:1px solid rgba(201,163,106,.24);border-radius:18px;background:rgba(20,14,9,.66);color:#d8b77b;line-height:2;box-shadow:0 12px 40px rgba(0,0,0,.3)">尚未读取到正式账号<br><span style="font-size:12px;color:#9b8b73">请返回账号中心登录一次</span></div>';return;}
  const req=async(path,data={},method='GET')=>{let p={...data,token:acct.token};return await gmcCloudFetch(path,p,method,false)};
  async function render(type){try{const rowStyle='padding:14px 12px;margin:8px 0;border:1px solid rgba(201,163,106,.2);border-radius:14px;background:rgba(255,255,255,.045);box-shadow:0 6px 18px rgba(0,0,0,.18)';if(type==='friends'){const rows=await req('/friends');body.innerHTML='<button id="gmc-add-friend" style="width:100%;border:1px solid #b58a4c;border-radius:14px;background:rgba(181,138,76,.16);color:#e5c892;padding:12px;font:14px inherit">＋ 添加好友</button>'+((rows||[]).map(x=>`<div style="${rowStyle}"><b style="color:#f0d39a">${gmcEscapeHtml(x.nickname)}</b><small style="display:block;color:#8f806a;margin-top:4px">${x.id}</small><button data-chat="${x.id}" style="float:right;margin-top:-28px;border:1px solid rgba(201,163,106,.35);border-radius:999px;background:transparent;color:#d8b77b;padding:5px 12px;font:12px inherit">私信</button></div>`).join('')||'<p style="color:#9b8b73;text-align:center;padding:30px">暂无好友</p>');body.querySelector('#gmc-add-friend').onclick=async()=>{const idv=prompt('输入对方玩家ID');if(idv)try{await req('/friends/request',{playerId:idv},'POST');api.ui.toast('好友申请已发送')}catch(e){api.ui.toast(e.message)}};body.querySelectorAll('[data-chat]').forEach(b=>b.onclick=()=>openGmcPrivateChat(b.dataset.chat));}else if(type==='requests'){const rows=await req('/friends/requests');body.innerHTML=(rows||[]).map(x=>`<div style="${rowStyle}"><b>${gmcEscapeHtml(x.nickname)}</b><button data-acc="${x.id}" style="float:right;border:1px solid #b58a4c;border-radius:999px;background:#b58a4c;color:#1b1208;padding:6px 14px;font:12px inherit">同意</button></div>`).join('')||'<p style="color:#9b8b73;text-align:center;padding:30px">暂无申请</p>';body.querySelectorAll('[data-acc]').forEach(b=>b.onclick=async()=>{await req('/friends/respond',{requestId:b.dataset.acc,accept:true},'POST');render('requests')});}else if(type==='strangers'){body.innerHTML='<div style="padding:18px;border:1px solid rgba(201,163,106,.2);border-radius:14px;background:rgba(255,255,255,.04);color:#b9a98e;line-height:1.8">陌生人信息会在聊天室点击用户名后显示于此。你可以先查看对方公开昵称，再选择添加好友或发送私信。</div>';}else{const rows=await req('/friends/share/list');body.innerHTML=(rows||[]).map(x=>`<div style="${rowStyle}"><b>${gmcEscapeHtml(x.name)}</b><button data-load="${x.id}" style="float:right;border:1px solid rgba(201,163,106,.35);border-radius:999px;background:transparent;color:#d8b77b;padding:6px 14px;font:12px inherit">查看</button></div>`).join('')||'<p style="color:#9b8b73;text-align:center;padding:30px">暂无好友共享存档</p>';}}catch(e){body.innerHTML='<div style="padding:20px;color:#e2a49b;text-align:center">'+gmcEscapeHtml(e.message)+'</div>'}}
  m.querySelectorAll('[data-f]').forEach(b=>b.onclick=()=>render(b.dataset.f)); await render('friends'); try{const u=await req('/friends/unread');if(u.count)m.querySelector('#gmc-request-dot').style.display='inline';}catch(e){}
}
async function openGmcPrivateChat(userId,userName='好友'){
  const a=await restoreGmcAccountSession();if(!a?.token)return api.ui.toast('请先登录正式账号');
  document.getElementById('gmc-private-chat-modal')?.remove();const m=document.createElement('div');m.id='gmc-private-chat-modal';m.style.cssText="position:fixed;inset:0;z-index:100004;display:flex;flex-direction:column;background:linear-gradient(180deg,rgba(14,9,5,.84),rgba(3,2,1,.96)),url('https://www.imgfox.cn/apis/uploads/20260818/cd2a4b22f1ec4748/IMG_9643.jpeg') center/cover;color:#eee;font-family:inherit";
  m.innerHTML=`<div style="padding:calc(var(--safe-top,44px) + 8px) 14px 12px;display:flex;align-items:center;border-bottom:1px solid rgba(201,163,106,.22);background:rgba(8,5,3,.45);backdrop-filter:blur(14px)"><button id="gmc-chat-back" style="border:0;background:transparent;color:#c9a36a;font:14px inherit">‹ 返回</button><div style="flex:1;text-align:center"><b style="color:#efd49b;letter-spacing:3px">${gmcEscapeHtml(userName)}</b><div style="color:#82745f;font-size:10px;margin-top:3px">${gmcEscapeHtml(userId)}</div></div><button id="gmc-chat-refresh" style="border:1px solid rgba(201,163,106,.3);border-radius:999px;background:transparent;color:#c9a36a;padding:6px 10px;font:12px inherit">刷新</button></div><div id="gmc-chat-messages" style="flex:1;overflow-y:auto;padding:14px;display:flex;flex-direction:column;gap:10px"></div><div style="padding:10px 12px calc(var(--safe-bottom,20px) + 10px);display:flex;gap:8px;background:rgba(8,5,3,.72);border-top:1px solid rgba(201,163,106,.2);backdrop-filter:blur(16px)"><textarea id="gmc-chat-input" rows="1" maxlength="180" placeholder="写一封私信……" style="flex:1;min-height:42px;max-height:100px;resize:none;border:1px solid rgba(201,163,106,.3);border-radius:17px;background:rgba(0,0,0,.35);color:#eee;padding:10px 12px;font:13px inherit"></textarea><button id="gmc-chat-send" style="width:58px;border:1px solid rgba(255,230,177,.3);border-radius:17px;background:linear-gradient(135deg,#d1ad70,#896633);color:#1b1208;font:bold 13px inherit">发送</button></div>`;document.body.appendChild(m);
  const list=m.querySelector('#gmc-chat-messages');async function load(){try{const rows=await gmcCloudFetch('/messages?with='+encodeURIComponent(userId),{token:a.token},'GET',false);list.innerHTML=(rows||[]).map(x=>{const mine=x.sender_id===a.id;return `<div style="align-self:${mine?'flex-end':'flex-start'};max-width:82%"><div style="padding:10px 12px;border-radius:${mine?'16px 5px 16px 16px':'5px 16px 16px 16px'};background:${mine?'rgba(181,138,76,.34)':'rgba(20,16,12,.76)'};border:1px solid rgba(201,163,106,.24);line-height:1.7;white-space:pre-wrap">${gmcEscapeHtml(x.content)}</div><div style="font-size:9px;color:#766a58;margin:3px 5px;text-align:${mine?'right':'left'}">${gmcCommunityTime(x.created_at)}</div></div>`}).join('')||'<div style="margin:auto;color:#82745f;text-align:center">尚无私信<br><span style="font-size:11px">从一句问候开始吧</span></div>';list.scrollTop=list.scrollHeight}catch(e){list.innerHTML=`<div style="margin:auto;color:#d69b91">${gmcEscapeHtml(e.message)}</div>`}};
  m.querySelector('#gmc-chat-back').onclick=()=>m.remove();m.querySelector('#gmc-chat-refresh').onclick=load;m.querySelector('#gmc-chat-send').onclick=async()=>{const input=m.querySelector('#gmc-chat-input'),btn=m.querySelector('#gmc-chat-send'),txt=input.value.trim();if(!txt)return;btn.disabled=true;btn.textContent='…';try{await gmcCloudFetch('/messages',{token:a.token,to:userId,content:txt},'POST',false);input.value='';await load()}catch(e){api.ui.toast(e.message)}finally{btn.disabled=false;btn.textContent='发送'}};await load();
}

async function openFeiGePanel() {
  const old = document.getElementById('feige-modal');
  if (old) old.remove();

  const modal = document.createElement('div');
  modal.id = 'feige-modal';
  modal.style.cssText = `
    position:fixed; inset:0; z-index:99999;
    background:url('https://www.imgfox.cn/apis/uploads/20260818/cd2a4b22f1ec4748/IMG_9643.jpeg') center/cover no-repeat;
    display:flex; flex-direction:column;
  `;

  // 背景遮罩
  const overlay = document.createElement('div');
  overlay.style.cssText = 'position:absolute; inset:0; background:rgba(8,6,4,0.78); backdrop-filter:blur(6px); -webkit-backdrop-filter:blur(6px); z-index:0;';
  modal.appendChild(overlay);

  const wrap = document.createElement('div');
  wrap.style.cssText = 'position:relative; z-index:1; display:flex; flex-direction:column; height:100%; overflow:hidden;';

  // 顶栏
  const header = document.createElement('div');
  header.style.cssText = 'padding:calc(var(--safe-top,44px) + 10px) 16px 12px; display:flex; justify-content:space-between; align-items:center; border-bottom:1px solid rgba(201,163,106,0.2); flex-shrink:0;';
  header.innerHTML = `
    <button id="feige-back" style="background:transparent;border:none;color:#888;font-size:16px;font-family:inherit;">‹ 返回</button>
    <div style="color:var(--primary-color);font-size:18px;font-weight:bold;letter-spacing:5px;font-family:'STZhongsong','STSong',serif;
      background:linear-gradient(to bottom,#ffe9b8,#c9a36a);-webkit-background-clip:text;-webkit-text-fill-color:transparent;
      filter:drop-shadow(0 1px 4px rgba(0,0,0,0.8));">飞鸽传书</div>
    <button id="feige-cloud-name-btn" style="background:rgba(201,163,106,0.08);border:1px solid rgba(201,163,106,0.32);color:var(--primary-color);font-size:12px;border-radius:999px;padding:5px 10px;font-family:inherit;">云名</button>
  `;
  wrap.appendChild(header);

  // Tab 栏
  const tabBar = document.createElement('div');
  tabBar.style.cssText = 'display:flex; border-bottom:1px solid rgba(201,163,106,0.15); flex-shrink:0;';
  ['投递御笺','捞取御笺','我的御笺','往来函件'].forEach((label, i) => {
    const btn = document.createElement('button');
    btn.className = 'feige-tab';
    btn.dataset.idx = i;
    btn.style.cssText = `flex:1; padding:10px 0; background:transparent; border:none; font-size:12px; letter-spacing:1px; font-family:inherit; transition:all 0.2s; border-bottom:2px solid ${i===0?'var(--primary-color)':'transparent'}; color:${i===0?'var(--primary-color)':'#666'};`;
    btn.innerText = label;
    tabBar.appendChild(btn);
  });
  wrap.appendChild(tabBar);

  // 内容区
  const body = document.createElement('div');
  body.style.cssText = 'flex:1; overflow-y:auto; padding:16px 16px calc(var(--safe-bottom,24px)+16px);';
  wrap.appendChild(body);

  modal.appendChild(wrap);
  document.body.appendChild(modal);

  document.getElementById('feige-back').onclick = () => modal.remove();
  document.getElementById('feige-cloud-name-btn').onclick = async () => {
    const identity = await openGmcCloudIdentityModal({ skipAgree: true });
    if (identity) {
      try {
        await gmcCloudFetch('/identity', { identity, nickname: identity.nickname }, 'POST', false);
        api.ui.toast('飞鸽署名已更新');
      } catch(e) {
        api.ui.toast('署名已保存在本机，云端同步失败');
      }
    }
  };

  let currentTab = 0;
  function switchFeigeTab(idx) {
    currentTab = idx;
    modal.querySelectorAll('.feige-tab').forEach((b, i) => {
      b.style.color = i===idx ? 'var(--primary-color)' : '#666';
      b.style.borderBottomColor = i===idx ? 'var(--primary-color)' : 'transparent';
    });
    body.innerHTML = '';
    if (idx === 0) renderFeigeCompose(body);
    else if (idx === 1) renderFeigeReceive(body);
    else if (idx === 2) renderFeigeMyList(body);
    else renderFeigeLetterBox(body);
  }

  modal.querySelectorAll('.feige-tab').forEach((btn, i) => {
    btn.onclick = () => switchFeigeTab(i);
  });

  // 默认展示投递页
  switchFeigeTab(0);
}

// ── 投递御笺 ──
function renderFeigeCompose(container) {
  const allChars = [...selectedCharsData, XLY_CHAR];
  if (allChars.length === 0) {
    container.innerHTML = '<div style="color:#666;text-align:center;padding:40px;font-size:14px;">尚无故人，请先引入角色</div>';
    return;
  }

  let currentMode = 'bottle'; // 'bottle' | 'edict'
  const charOptHtml = allChars.map(c => `<option value="${c.id}">${c.name}（${c.ancientRole || c.assignedRank || '故人'}）</option>`).join('');

  const modeHints = {
    bottle: '御笺投入天下，随机被一位有缘人捞取。一经捞走便归其独有，不会被他人再次捞到。',
    edict: '圣旨昭告天下，所有人皆可在「阅览圣旨」中看到此信。不会被取走，可随时由你收回。'
  };
  const sendLabels = { bottle: '🕊️ 放飞御笺', edict: '📜 颁布圣旨' };

  container.innerHTML = `
    <div style="display:flex;flex-direction:column;gap:16px;">
      <!-- 投递模式选择 -->
      <div style="display:flex;gap:10px;">
        <div id="fmode-bottle" style="flex:1;border:1px solid var(--primary-color);border-radius:10px;padding:12px 8px;cursor:pointer;background:rgba(201,163,106,0.15);display:flex;flex-direction:column;align-items:center;gap:6px;transition:all 0.2s;">
          <div style="font-size:22px;">🕊️</div>
          <div style="color:var(--primary-color);font-size:13px;font-weight:bold;letter-spacing:1px;">御笺（漂流）</div>
          <div style="color:#aaa;font-size:10px;text-align:center;line-height:1.4;">随机被一人捞取<br>捞走即消失</div>
        </div>
        <div id="fmode-edict" style="flex:1;border:1px solid #555;border-radius:10px;padding:12px 8px;cursor:pointer;background:transparent;display:flex;flex-direction:column;align-items:center;gap:6px;transition:all 0.2s;">
          <div style="font-size:22px;">📜</div>
          <div style="color:#888;font-size:13px;font-weight:bold;letter-spacing:1px;">圣旨（广播）</div>
          <div style="color:#666;font-size:10px;text-align:center;line-height:1.4;">所有人皆可阅览<br>不会被取走</div>
        </div>
      </div>

      <div id="feige-mode-hint" style="color:#aaa;font-size:12px;line-height:1.7;background:rgba(201,163,106,0.06);border:1px solid rgba(201,163,106,0.2);border-radius:8px;padding:10px 12px;">
        ${modeHints.bottle}
      </div>

      <div style="display:flex;flex-direction:column;gap:6px;">
        <div style="color:var(--primary-color);font-size:12px;letter-spacing:2px;">执笔人</div>
        <select id="feige-char-sel" style="width:100%;background:rgba(0,0,0,0.5);border:1px solid rgba(201,163,106,0.4);color:#eaeaea;padding:10px;border-radius:8px;font-family:inherit;font-size:14px;">
          ${charOptHtml}
        </select>
      </div>

      <div style="display:flex;flex-direction:column;gap:6px;">
        <div style="color:var(--primary-color);font-size:12px;letter-spacing:2px;">主题（可选，留空由 AI 自定）</div>
        <input id="feige-topic" type="text" placeholder="例如：思念、秘密、一个心愿…" style="width:100%;background:rgba(0,0,0,0.5);border:1px solid rgba(201,163,106,0.3);color:#eaeaea;padding:10px;border-radius:8px;font-family:inherit;font-size:14px;">
      </div>

      <div id="feige-sign-section" style="display:flex;flex-direction:column;gap:8px;">
        <div style="color:var(--primary-color);font-size:12px;letter-spacing:2px;">署名方式</div>
        <div style="display:flex;gap:8px;">
          <div id="fsign-anon" style="flex:1;border:1px solid #555;border-radius:8px;padding:10px;cursor:pointer;text-align:center;color:#888;font-size:13px;transition:all 0.2s;">🎭 匿名</div>
          <div id="fsign-custom" style="flex:1;border:1px solid var(--primary-color);border-radius:8px;padding:10px;cursor:pointer;text-align:center;color:var(--primary-color);font-size:13px;background:rgba(201,163,106,0.1);transition:all 0.2s;">✍️ 自定义署名</div>
        </div>
        <input id="feige-display-name" type="text" placeholder="输入你的署名（留空则使用账号名）" style="width:100%;background:rgba(0,0,0,0.5);border:1px solid rgba(201,163,106,0.3);color:#eaeaea;padding:10px;border-radius:8px;font-family:inherit;font-size:14px;">
      </div>

      <div style="display:flex;flex-direction:column;gap:6px;">
        <div style="color:var(--primary-color);font-size:12px;letter-spacing:2px;display:flex;justify-content:space-between;align-items:center;">
          <span>正文</span>
          <button id="feige-ai-gen" style="background:rgba(201,163,106,0.15);border:1px solid var(--primary-color);color:var(--primary-color);padding:4px 12px;border-radius:12px;font-size:11px;font-family:inherit;">✦ AI代笔</button>
        </div>
        <textarea id="feige-content" placeholder="在此执笔，或点击「AI代笔」由故人亲自落墨…" style="width:100%;min-height:180px;background:rgba(0,0,0,0.5);border:1px solid rgba(201,163,106,0.3);color:#eaeaea;padding:12px;border-radius:8px;font-family:'STSong','Noto Serif CJK SC',serif;font-size:14px;line-height:1.8;resize:vertical;"></textarea>
      </div>

      <button id="feige-send-btn" style="width:100%;background:linear-gradient(135deg,#c9a36a,#8a6d3b);border:2px solid rgba(255,233,184,0.4);color:#1a1208;padding:14px;border-radius:12px;font-size:15px;font-weight:bold;letter-spacing:4px;font-family:'STZhongsong','STSong',serif;box-shadow:0 4px 16px rgba(201,163,106,0.3);">
        🕊️ 放飞御笺
      </button>
    </div>
  `;

  // 模式切换
  const btnBottle = container.querySelector('#fmode-bottle');
  const btnEdict = container.querySelector('#fmode-edict');
  const hintEl = container.querySelector('#feige-mode-hint');
  const sendBtn = container.querySelector('#feige-send-btn');

  function setMode(mode) {
    currentMode = mode;
    if (mode === 'bottle') {
      btnBottle.style.borderColor = 'var(--primary-color)'; btnBottle.style.background = 'rgba(201,163,106,0.15)';
      btnBottle.querySelector('div:nth-child(2)').style.color = 'var(--primary-color)';
      btnBottle.querySelector('div:nth-child(3)').style.color = '#aaa';
      btnEdict.style.borderColor = '#555'; btnEdict.style.background = 'transparent';
      btnEdict.querySelector('div:nth-child(2)').style.color = '#888';
      btnEdict.querySelector('div:nth-child(3)').style.color = '#666';
    } else {
      btnEdict.style.borderColor = 'var(--primary-color)'; btnEdict.style.background = 'rgba(201,163,106,0.15)';
      btnEdict.querySelector('div:nth-child(2)').style.color = 'var(--primary-color)';
      btnEdict.querySelector('div:nth-child(3)').style.color = '#aaa';
      btnBottle.style.borderColor = '#555'; btnBottle.style.background = 'transparent';
      btnBottle.querySelector('div:nth-child(2)').style.color = '#888';
      btnBottle.querySelector('div:nth-child(3)').style.color = '#666';
    }
    hintEl.innerText = modeHints[mode];
    sendBtn.innerText = sendLabels[mode];
  }

  btnBottle.onclick = () => setMode('bottle');
  btnEdict.onclick = () => setMode('edict');

  // 署名切换（仅漂流瓶有，圣旨强制实名）
  let isAnonymous = false;
  const fsignAnon = container.querySelector('#fsign-anon');
  const fsignCustom = container.querySelector('#fsign-custom');
  const fDisplayName = container.querySelector('#feige-display-name');
  const signSection = container.querySelector('#feige-sign-section');

  function updateSignMode(anon) {
    isAnonymous = anon;
    if (anon) {
      fsignAnon.style.borderColor = 'var(--primary-color)'; fsignAnon.style.background = 'rgba(201,163,106,0.1)'; fsignAnon.style.color = 'var(--primary-color)';
      fsignCustom.style.borderColor = '#555'; fsignCustom.style.background = 'transparent'; fsignCustom.style.color = '#888';
      fDisplayName.style.display = 'none';
    } else {
      fsignCustom.style.borderColor = 'var(--primary-color)'; fsignCustom.style.background = 'rgba(201,163,106,0.1)'; fsignCustom.style.color = 'var(--primary-color)';
      fsignAnon.style.borderColor = '#555'; fsignAnon.style.background = 'transparent'; fsignAnon.style.color = '#888';
      fDisplayName.style.display = 'block';
    }
  }
  fsignAnon.onclick = () => updateSignMode(true);
  fsignCustom.onclick = () => updateSignMode(false);

  // 圣旨时隐藏署名区
  const origSetMode = setMode;
  setMode = (mode) => {
    origSetMode(mode);
    signSection.style.display = mode === 'bottle' ? 'flex' : 'none';
  };
  setMode('bottle'); // 重新触发一次初始化

  // AI 代笔
  container.querySelector('#feige-ai-gen').onclick = async () => {
    const charId = container.querySelector('#feige-char-sel').value;
    const char = allChars.find(c => c.id === charId);
    const topic = container.querySelector('#feige-topic').value.trim();
    const btn = container.querySelector('#feige-ai-gen');
    btn.innerText = '落墨中…'; btn.disabled = true;

    const timeStr = hudTime ? hudTime.innerText : '未知时辰';
    const isEdict = currentMode === 'edict';
    const prompt = `你是古代后宫人物「${char.name}」，身份：${char.ancientRole || char.assignedRank || '故人'}。
当前时间：${timeStr}。
【本轮重新读取的人设、人物世界书与全部记忆】
${buildCharacterAiContext(char)}

${isEdict
  ? `请以「${char.name}」的口吻，写一封昭告天下的圣旨或公告。\n${topic ? `主题方向：${topic}` : '主题自定，可以是宣示、告示、心声等。'}\n要求：1. 古风文言，气势恢宏，300字以内；2. 可署名；3. 只输出正文，不要解释或标题`
  : `请以「${char.name}」的口吻，写一封投入天下漂流的匿名御笺。\n${topic ? `主题方向：${topic}` : '主题自定，可以是思念、秘密、一段心声、一个心愿等。'}\n要求：1. 古风文言，雅致含蓄，200字以内；2. 不署名，不称呼特定人，像一封漂流在外的无名信；3. 只输出信件正文，不要任何解释或标题`
}`;

    try {
      const res = await api.ai.chat({ messages: [{ role: 'user', content: prompt }] });
      const text = typeof res === 'string' ? res : (res?.content ?? res?.text ?? '');
      container.querySelector('#feige-content').value = text.trim();
    } catch(e) { api.ui.toast('AI代笔失败，请手动填写'); }
    finally { btn.innerText = '✦ AI代笔'; btn.disabled = false; }
  };

  // 发送
  container.querySelector('#feige-send-btn').onclick = async () => {
    const content = container.querySelector('#feige-content').value.trim();
    if (!content) { api.ui.toast('内容不可为空'); return; }

    const charId = container.querySelector('#feige-char-sel').value;
    const char = allChars.find(c => c.id === charId);
    const topic = container.querySelector('#feige-topic').value.trim();
    const btn = container.querySelector('#feige-send-btn');
    const isEdict = currentMode === 'edict';
    btn.innerText = '传书中…'; btn.disabled = true;

    try {
      if (isEdict) {
        // 圣旨走 Cloudflare 后端，强制实名（用飞鸽云名）
        let ownerName = await getAccountName();
        await szInsertEdict({
          owner_name: ownerName,
          char_name: char.name,
          char_role: char.ancientRole || char.assignedRank || '故人',
          topic: topic || null,
          content,
          time_str: hudTime ? hudTime.innerText : ''
        });
        api.ui.toast('圣旨已颁布，天下皆知');
      } else {
        // 漂流瓶走 Cloudflare 后端
        let ownerName = await getAccountName();
        const customSign = container.querySelector('#feige-display-name')?.value?.trim();
        const displayName = isAnonymous ? '匿名' : (customSign || ownerName);
        await fgInsert({
          owner_name: ownerName,       // 真实账号名，用于"我的御笺"筛选
          display_name: displayName,   // 显示给别人看的署名
          is_anonymous: isAnonymous,
          char_name: char.name,
          char_role: char.ancientRole || char.assignedRank || '故人',
          topic: topic || null,
          content,
          time_str: hudTime ? hudTime.innerText : '',
          max_takes: 10
        });
        api.ui.toast('御笺已放飞，愿有缘人拾得');
      }
      container.querySelector('#feige-content').value = '';
      container.querySelector('#feige-topic').value = '';
    } catch(e) {
      const msg = e?.message || String(e) || '未知错误';
      if (msg.includes('login') || msg.includes('account') || msg.includes('online') || msg.includes('未登录') || msg.includes('auth')) {
        api.ui.toast('请先设置飞鸽云名后重试');
      } else {
        api.ui.toast('传书失败：' + msg.slice(0, 60));
      }
      console.error('[飞鸽传书-投递]', e);
    } finally {
      btn.innerText = sendLabels[currentMode];
      btn.disabled = false;
    }
  };
}

// ── 捞取御笺 ──
async function renderFeigeReceive(container) {
  container.innerHTML = `
    <div style="display:flex;flex-direction:column;gap:16px;">
      <!-- 圣旨公告板 -->
      <div style="background:rgba(201,163,106,0.06);border:1px solid rgba(201,163,106,0.25);border-radius:10px;overflow:hidden;">
        <div style="display:flex;align-items:center;gap:8px;padding:12px 14px;border-bottom:1px solid rgba(201,163,106,0.15);cursor:pointer;background:rgba(201,163,106,0.1);" id="edict-board-toggle">
          <span style="font-size:16px;">📜</span>
          <span style="color:var(--primary-color);font-size:14px;font-weight:bold;letter-spacing:2px;">天下圣旨</span>
          <span id="edict-count-label" style="color:#aaa;font-size:11px;margin-left:4px;">(点击阅览近三日圣旨)</span>
          <span id="edict-toggle-arrow" style="margin-left:auto;color:var(--primary-color);font-size:12px;">展开 ▼</span>
        </div>
        <div id="edict-board-list" style="display:none;max-height:400px;overflow-y:auto;padding:12px 14px;flex-direction:column;gap:12px;">
          <!-- 动态加载 -->
        </div>
      </div>

      <!-- 漂流瓶区 -->
      <div style="color:#aaa;font-size:12px;line-height:1.7;background:rgba(201,163,106,0.06);border:1px solid rgba(201,163,106,0.2);border-radius:8px;padding:10px 12px;">
        从天下御笺池中随机捞取一封漂流御笺。每封信最多可被 10 位有缘人捞到，捞满即止。
      </div>
      <div id="feige-letter-box" style="display:flex;flex-direction:column;gap:0;">
        <div style="color:#555;font-size:14px;letter-spacing:2px;">点击下方捞取一封御笺</div>
      </div>
      <button id="feige-pick-btn" style="width:100%;background:rgba(201,163,106,0.15);border:1px solid var(--primary-color);color:var(--primary-color);padding:14px;border-radius:12px;font-size:15px;letter-spacing:4px;font-family:'STZhongsong','STSong',serif;">
        🕊️ 捞取御笺
      </button>
    </div>
  `;

  // 圣旨主动加载逻辑
  let edictLoaded = false;
  let edictOpen = false;
  
  container.querySelector('#edict-board-toggle').onclick = async () => {
    const listEl = container.querySelector('#edict-board-list');
    const arrow = container.querySelector('#edict-toggle-arrow');
    const countLabel = container.querySelector('#edict-count-label');
    
    edictOpen = !edictOpen;
    
    if (edictOpen) {
      listEl.style.display = 'flex';
      arrow.innerText = '收起 ▲';
      
      if (!edictLoaded) {
        listEl.innerHTML = '<div style="color:#888;font-size:13px;text-align:center;padding:20px;letter-spacing:2px;">正在请出圣旨...</div>';
        try {
          // 获取飞鸽云名
          const myName = await getAccountName();
          
          // 走 Cloudflare 后端，真正全服可见
          const items = await szListEdicts();
          
          edictLoaded = true;
          countLabel.innerText = items && items.length > 0 ? `近三日 ${items.length} 条` : '暂无';
          
          if (!items || items.length === 0) {
            listEl.innerHTML = '<div style="color:#666;font-size:13px;text-align:center;padding:20px;letter-spacing:2px;">天下尚无圣旨</div>';
          } else {
            // 获取我的点赞列表
            let myLikedIds = new Set();
            try { myLikedIds = await szGetMyLikes(myName); } catch(e2) {}
            
            listEl.innerHTML = '';
            for (const it of items) {
              const card = document.createElement('div');
              card.style.cssText = 'background:rgba(0,0,0,0.35);border:1px solid rgba(201,163,106,0.25);border-radius:10px;padding:14px;display:flex;flex-direction:column;gap:10px;';
              const liked = myLikedIds.has(it.id);
              card.innerHTML = `
                <div style="display:flex;justify-content:space-between;align-items:center;flex-wrap:wrap;gap:6px;">
                  <div style="color:var(--primary-color);font-size:14px;font-weight:bold;letter-spacing:2px;font-family:'STZhongsong','STSong',serif;">${it.char_name||'无名氏'} · ${it.char_role||''}</div>
                  ${it.topic ? `<div style="background:rgba(201,163,106,0.12);border:1px solid rgba(201,163,106,0.3);color:rgba(201,163,106,0.8);font-size:10px;padding:2px 8px;border-radius:10px;">${it.topic}</div>` : ''}
                </div>
                <div style="color:#ddd;font-size:13px;line-height:1.9;letter-spacing:1px;font-family:'STSong','Noto Serif CJK SC',serif;white-space:pre-wrap;">${it.content||''}</div>
                <div style="display:flex;justify-content:space-between;align-items:center;">
                  <div style="color:#666;font-size:11px;">— ${it.owner_name||'某位故人的主人'} · ${it.time_str||''}</div>
                  <button class="sz-like-btn" data-id="${it.id}" style="background:${liked?'rgba(201,163,106,0.2)':'transparent'};border:1px solid ${liked?'var(--primary-color)':'#555'};color:${liked?'var(--primary-color)':'#888'};padding:4px 12px;border-radius:16px;font-size:12px;font-family:inherit;cursor:pointer;">
                    ❤ <span class="like-count">${it.like_count||0}</span>
                  </button>
                </div>
                <!-- 评论区 -->
                <div class="sz-comment-section" data-id="${it.id}" style="border-top:1px solid rgba(201,163,106,0.1);padding-top:10px;display:flex;flex-direction:column;gap:8px;">
                  <div class="sz-comments-list" style="display:flex;flex-direction:column;gap:6px;"></div>
                  <div style="display:flex;gap:8px;">
                    <input class="sz-comment-input" type="text" placeholder="发表评论（实名）…" style="flex:1;background:rgba(0,0,0,0.4);border:1px solid rgba(201,163,106,0.2);color:#eaeaea;padding:7px 10px;border-radius:20px;font-family:inherit;font-size:12px;">
                    <button class="sz-comment-send" style="background:var(--primary-color);border:none;color:#000;padding:7px 14px;border-radius:20px;font-size:12px;font-weight:bold;font-family:inherit;">发</button>
                  </div>
                </div>
              `;
              listEl.appendChild(card);

              // 加载评论
              const commentSection = card.querySelector('.sz-comment-section');
              const commentsList = card.querySelector('.sz-comments-list');
              async function loadComments(szId, listEl2, myN) {
                try {
                  const comments = await szListComments(szId);
                  let myCommentLikes = new Set();
                  try { myCommentLikes = await szGetMyCommentLikes(myN); } catch(e3) {}
                  listEl2.innerHTML = '';
                  (comments || []).forEach(c => {
                    const cLiked = myCommentLikes.has(c.id);
                    const cDiv = document.createElement('div');
                    cDiv.style.cssText = 'display:flex;justify-content:space-between;align-items:flex-start;gap:8px;padding:6px 0;border-bottom:1px solid rgba(255,255,255,0.05);';
                    cDiv.innerHTML = `
                      <div style="flex:1;">
                        <span style="color:var(--primary-color);font-size:11px;font-weight:bold;">${c.author_name}</span>
                        <span style="color:#ccc;font-size:12px;margin-left:6px;line-height:1.6;">${c.content}</span>
                      </div>
                      <div style="display:flex;gap:6px;flex-shrink:0;align-items:center;">
                        <button class="c-like-btn" data-cid="${c.id}" style="background:transparent;border:none;color:${cLiked?'var(--primary-color)':'#666'};font-size:11px;cursor:pointer;padding:2px 4px;">❤ ${c.like_count||0}</button>
                        ${c.author_name === myN ? `<button class="c-del-btn" data-cid="${c.id}" style="background:transparent;border:none;color:#8b4040;font-size:11px;cursor:pointer;padding:2px 4px;">撤</button>` : ''}
                      </div>
                    `;
                    listEl2.appendChild(cDiv);
                  });
                  if (!comments || comments.length === 0) {
                    listEl2.innerHTML = '<div style="color:#555;font-size:11px;text-align:center;padding:4px;">暂无评论</div>';
                  }
                } catch(e3) {}
              }
              await loadComments(it.id, commentsList, myName);

              // 评论点赞/撤回事件
              commentsList.addEventListener('click', async (e) => {
                const clikeBtn = e.target.closest('.c-like-btn');
                const cdelBtn = e.target.closest('.c-del-btn');
                if (clikeBtn) {
                  const cid = clikeBtn.dataset.cid;
                  await szToggleCommentLike(cid, myName);
                  await loadComments(it.id, commentsList, myName);
                }
                if (cdelBtn) {
                  const cid = cdelBtn.dataset.cid;
                  const ok = await api.ui.confirm({ title: '撤回评论', message: '确定撤回这条评论？' });
                  if (ok) { await szDeleteComment(cid); await loadComments(it.id, commentsList, myName); }
                }
              });

              // 发评论
              const sendBtn = commentSection.querySelector('.sz-comment-send');
              const inputEl = commentSection.querySelector('.sz-comment-input');
              sendBtn.onclick = async () => {
                const txt = inputEl.value.trim();
                if (!txt) { api.ui.toast('评论不能为空'); return; }
                sendBtn.disabled = true;
                try {
                  await szAddComment(it.id, myName, txt);
                  inputEl.value = '';
                  await loadComments(it.id, commentsList, myName);
                } catch(e3) { api.ui.toast('发送失败'); }
                finally { sendBtn.disabled = false; }
              };
              inputEl.addEventListener('keydown', e => { if (e.key === 'Enter') sendBtn.onclick(); });
            }

            // 绑定点赞按钮
            listEl.querySelectorAll('.sz-like-btn').forEach(btn => {
              btn.onclick = async () => {
                const id = btn.dataset.id;
                btn.disabled = true;
                try {
                  const liked = await szToggleLike(id, myName);
                  const countEl = btn.querySelector('.like-count');
                  const cur = parseInt(countEl.innerText) || 0;
                  countEl.innerText = liked ? cur + 1 : Math.max(0, cur - 1);
                  btn.style.background = liked ? 'rgba(201,163,106,0.2)' : 'transparent';
                  btn.style.borderColor = liked ? 'var(--primary-color)' : '#555';
                  btn.style.color = liked ? 'var(--primary-color)' : '#888';
                } catch(e2) { api.ui.toast('操作失败'); }
                finally { btn.disabled = false; }
              };
            });
          }
        } catch(e) {
          const errMsg = e?.message || String(e);
          listEl.innerHTML = `<div style="color:#888;font-size:13px;text-align:center;padding:20px;line-height:1.8;">阅览失败：<br>${errMsg.slice(0,80)}</div>`;
          console.error('[圣旨阅览失败]', e);
        }
      }
    } else {
      listEl.style.display = 'none';
      arrow.innerText = '展开 ▼';
    }
  };

  let currentBottle = null;

  container.querySelector('#feige-pick-btn').onclick = async () => {
    const btn = container.querySelector('#feige-pick-btn');
    const box = container.querySelector('#feige-letter-box');
    btn.innerText = '寻觅中…';
    btn.disabled = true;
    box.innerHTML = '<div style="color:#888;font-size:13px;letter-spacing:2px;text-align:center;padding:40px 0;">正在从天下御笺池中寻觅…</div>';

    try {
      const myOwnerName = await getAccountName();
      const result = await fgTakeRandom(myOwnerName);

      if (!result) {
        box.innerHTML = '<div style="color:#666;font-size:13px;letter-spacing:2px;text-align:center;line-height:2;">御笺池空空如也，<br>尚无漂流御笺。</div>';
        btn.innerText = '🕊️ 捞取御笺';
        btn.disabled = false;
        return;
      }
      currentBottle = result;
      const displayFrom = result.is_anonymous ? '匿名' : (result.display_name || result.owner_name || '某位故人的主人');
      
      // 渲染捞到的信件 + 回信区（支持多轮）
      function renderBottleThread(bottle, replyHistory) {
        box.innerHTML = '';
        // 信件本体
        const card = document.createElement('div');
        card.style.cssText = 'width:100%;background:rgba(0,0,0,0.45);border:1px solid rgba(201,163,106,0.4);border-radius:12px;padding:20px;display:flex;flex-direction:column;gap:12px;';
        card.innerHTML = `
          <div style="display:flex;justify-content:space-between;align-items:center;border-bottom:1px solid rgba(201,163,106,0.15);padding-bottom:10px;flex-wrap:wrap;gap:6px;">
            <div style="display:flex;flex-direction:column;gap:3px;">
              <div style="color:var(--primary-color);font-size:15px;font-weight:bold;letter-spacing:3px;font-family:'STZhongsong','STSong',serif;">${bottle.char_name || '无名氏'}</div>
              <div style="color:#888;font-size:11px;letter-spacing:1px;">${bottle.char_role || ''} · ${bottle.time_str || ''}</div>
            </div>
            ${bottle.topic ? `<div style="background:rgba(201,163,106,0.12);border:1px solid rgba(201,163,106,0.3);color:rgba(201,163,106,0.8);font-size:11px;padding:3px 10px;border-radius:12px;">${bottle.topic}</div>` : ''}
          </div>
          <div style="color:#ddd;font-size:14px;line-height:2;letter-spacing:1px;font-family:'STSong','Noto Serif CJK SC',serif;white-space:pre-wrap;">${bottle.content || ''}</div>
          <div style="color:#666;font-size:11px;text-align:right;">🕊️ 来自 ${displayFrom} · 已有 ${bottle.take_count||1}/${bottle.max_takes||10} 人捞到</div>
        `;
        box.appendChild(card);

        // 历史回信展示
        if (replyHistory && replyHistory.length > 0) {
          replyHistory.forEach(r => {
            const rcard = document.createElement('div');
            rcard.style.cssText = 'width:100%;background:rgba(201,163,106,0.06);border:1px solid rgba(201,163,106,0.2);border-radius:10px;padding:14px;display:flex;flex-direction:column;gap:8px;margin-top:6px;';
            const rfrom = r.is_anonymous ? '匿名' : (r.display_name || r.owner_name || '某位故人的主人');
            rcard.innerHTML = `
              <div style="display:flex;justify-content:space-between;align-items:center;">
                <div style="color:var(--primary-color);font-size:13px;font-weight:bold;font-family:'STZhongsong','STSong',serif;">↩ ${r.char_name||'无名氏'} · ${r.char_role||''}</div>
                <div style="color:#666;font-size:10px;">来自 ${rfrom}</div>
              </div>
              <div style="color:#ccc;font-size:13px;line-height:1.9;font-family:'STSong','Noto Serif CJK SC',serif;white-space:pre-wrap;">${r.content||''}</div>
            `;
            box.appendChild(rcard);
          });
        }

        // 回信区
        const replyWrap = document.createElement('div');
        replyWrap.style.cssText = 'display:flex;flex-direction:column;gap:10px;margin-top:8px;';

        const allCharsLocal = [...selectedCharsData, XLY_CHAR];
        const charOptHtml = allCharsLocal.map(c => `<option value="${c.id}">${c.name}</option>`).join('');

        replyWrap.innerHTML = `
          <div style="color:var(--primary-color);font-size:12px;letter-spacing:2px;border-top:1px solid rgba(201,163,106,0.15);padding-top:10px;">✉ 回寄御笺</div>
          <div style="display:flex;gap:8px;align-items:center;">
            <label style="color:#aaa;font-size:12px;flex-shrink:0;">执笔人</label>
            <select id="fg-reply-char" style="flex:1;background:rgba(0,0,0,0.5);border:1px solid rgba(201,163,106,0.3);color:#eaeaea;padding:8px;border-radius:6px;font-family:inherit;font-size:13px;">${charOptHtml}</select>
          </div>
          <div style="display:flex;gap:8px;">
            <div id="fgreply-anon" style="flex:1;border:1px solid #555;border-radius:8px;padding:8px;cursor:pointer;text-align:center;color:#888;font-size:12px;">🎭 匿名</div>
            <div id="fgreply-custom" style="flex:1;border:1px solid var(--primary-color);border-radius:8px;padding:8px;cursor:pointer;text-align:center;color:var(--primary-color);font-size:12px;background:rgba(201,163,106,0.1);">✍️ 署名</div>
          </div>
          <input id="fg-reply-sign" type="text" placeholder="自定义署名（留空用账号名）" style="width:100%;background:rgba(0,0,0,0.5);border:1px solid rgba(201,163,106,0.25);color:#eaeaea;padding:8px;border-radius:6px;font-family:inherit;font-size:13px;">
          <textarea id="feige-reply-content" placeholder="在此执笔，或点击「AI代笔」由故人亲自落墨…" style="width:100%;min-height:100px;background:rgba(0,0,0,0.5);border:1px solid rgba(201,163,106,0.25);color:#eaeaea;padding:10px;border-radius:8px;font-family:'STSong','Noto Serif CJK SC',serif;font-size:13px;line-height:1.8;resize:vertical;"></textarea>
          <div style="display:flex;gap:10px;">
            <button id="feige-ai-reply" style="flex:1;background:rgba(201,163,106,0.1);border:1px solid var(--primary-color);color:var(--primary-color);padding:10px;border-radius:8px;font-size:13px;font-family:inherit;">✦ AI代笔</button>
            <button id="feige-send-reply" style="flex:1;background:var(--primary-color);border:none;color:#000;padding:10px;border-radius:8px;font-size:13px;font-weight:bold;font-family:inherit;">放飞回信</button>
          </div>
        `;
        box.appendChild(replyWrap);

        // 回信署名切换
        let replyAnon = false;
        const rAnonBtn = box.querySelector('#fgreply-anon');
        const rCustomBtn = box.querySelector('#fgreply-custom');
        const rSignInput = box.querySelector('#fg-reply-sign');
        rAnonBtn.onclick = () => { replyAnon = true; rAnonBtn.style.borderColor='var(--primary-color)'; rAnonBtn.style.background='rgba(201,163,106,0.1)'; rAnonBtn.style.color='var(--primary-color)'; rCustomBtn.style.borderColor='#555'; rCustomBtn.style.background='transparent'; rCustomBtn.style.color='#888'; rSignInput.style.display='none'; };
        rCustomBtn.onclick = () => { replyAnon = false; rCustomBtn.style.borderColor='var(--primary-color)'; rCustomBtn.style.background='rgba(201,163,106,0.1)'; rCustomBtn.style.color='var(--primary-color)'; rAnonBtn.style.borderColor='#555'; rAnonBtn.style.background='transparent'; rAnonBtn.style.color='#888'; rSignInput.style.display='block'; };

        // AI代笔
        box.querySelector('#feige-ai-reply').onclick = async () => {
          const selCharId = box.querySelector('#fg-reply-char').value;
          const selChar = allCharsLocal.find(c => c.id === selCharId) || allCharsLocal[0];
          if (!selChar) { api.ui.toast('尚无故人'); return; }
          const btn2 = box.querySelector('#feige-ai-reply');
          btn2.innerText = '落墨中…'; btn2.disabled = true;
          const prompt = `你是古代后宫人物「${selChar.name}」，身份：${selChar.ancientRole || selChar.assignedRank || '故人'}。
你捞到了一封来自他处的漂流御笺：
「${bottle.content || ''}」
【本轮重新读取的人设、人物世界书与全部记忆】
${buildCharacterAiContext(selChar)}

请以你的口吻写一封简短的回信（150字以内），古风雅致。只输出回信正文。`;
          try {
            const res = await api.ai.chat({ messages: [{ role: 'user', content: prompt }] });
            const text = typeof res === 'string' ? res : (res?.content ?? res?.text ?? '');
            box.querySelector('#feige-reply-content').value = text.trim();
          } catch(e) { api.ui.toast('代笔失败'); }
          finally { btn2.innerText = '✦ AI代笔'; btn2.disabled = false; }
        };

        // 发送回信
        box.querySelector('#feige-send-reply').onclick = async () => {
          const replyContent = box.querySelector('#feige-reply-content').value.trim();
          if (!replyContent) { api.ui.toast('回信内容不可为空'); return; }
          const selCharId = box.querySelector('#fg-reply-char').value;
          const selChar = allCharsLocal.find(c => c.id === selCharId) || allCharsLocal[0];
          const btn3 = box.querySelector('#feige-send-reply');
          btn3.innerText = '传书中…'; btn3.disabled = true;
          try {
            const replyOwner = await getAccountName();
            const customSign = box.querySelector('#fg-reply-sign')?.value?.trim();
            const replyDisplay = replyAnon ? '匿名' : (customSign || replyOwner);
            const newReply = await fgInsert({
              owner_name: replyOwner,
              display_name: replyDisplay,
              is_anonymous: replyAnon,
              char_name: selChar?.name || '无名',
              char_role: selChar?.ancientRole || selChar?.assignedRank || '故人',
              topic: '回信',
              content: replyContent,
              time_str: hudTime ? hudTime.innerText : '',
              reply_to: bottle.id,
              max_takes: 10
            });
            api.ui.toast('回信已放飞');
            box.querySelector('#feige-reply-content').value = '';
            // 刷新显示，把新回信追加
            const newHistory = [...(replyHistory || []), newReply?.[0] || { char_name: selChar?.name, char_role: selChar?.ancientRole, content: replyContent, owner_name: replyOwner, display_name: replyDisplay, is_anonymous: replyAnon }];
            renderBottleThread(bottle, newHistory);
          } catch(e) {
            api.ui.toast('回信失败：' + (e?.message || ''));
          } finally { btn3.innerText = '放飞回信'; btn3.disabled = false; }
        };
      }

      // 加载历史回信（reply_to = 本封信的 id）
      let replyHistory = [];
      try {
        replyHistory = await fgListReplies(result.id) || [];
      } catch(e2) {}
      renderBottleThread(result, replyHistory);

      btn.innerText = '🕊️ 再捞一封';
      btn.disabled = false;
    } catch(e) {
      const msg2 = e?.message || String(e) || '未知错误';
      if (msg2.includes('login') || msg2.includes('account') || msg2.includes('online') || msg2.includes('未登录') || msg2.includes('auth')) {
        box.innerHTML = '<div style="color:#888;font-size:13px;text-align:center;line-height:2;">请先设置飞鸽云名，<br>再重试联机功能。</div>';
      } else {
        box.innerHTML = `<div style="color:#888;font-size:13px;text-align:center;">捞取失败：${msg2.slice(0,80)}</div>`;
      }
      console.error('[飞鸽传书-捞取]', e);
      btn.innerText = '🕊️ 捞取御笺';
      btn.disabled = false;
    }
  };
}

// ── 往来函件 ──
async function renderFeigeLetterBox(container) {
  container.innerHTML = '<div style="color:#888;font-size:13px;text-align:center;padding:30px;letter-spacing:2px;">正在整理往来函件…</div>';
  try {
    const myName = await getAccountName();
    const allItems = await fgListLetterBox() || [];
    allItems.sort((a, b) => new Date(b._takenAt || b.created_at || 0) - new Date(a._takenAt || a.created_at || 0));

    container.innerHTML = '';

    if (allItems.length === 0) {
      container.innerHTML = '<div style="color:#666;font-size:13px;text-align:center;padding:40px;line-height:2;letter-spacing:2px;">尚无往来函件<br><span style="font-size:11px;">捞取御笺或收到回信后会显示在这里</span></div>';
      return;
    }

    // 渲染说明
    const hint = document.createElement('div');
    hint.style.cssText = 'color:#888;font-size:11px;line-height:1.6;background:rgba(201,163,106,0.05);border:1px solid rgba(201,163,106,0.15);border-radius:8px;padding:8px 12px;margin-bottom:4px;';
    hint.innerHTML = '🕊️ <b style="color:rgba(201,163,106,0.7);">我捞到的</b>：从天下捞到的御笺&nbsp;&nbsp;'
      + '✍️ <b style="color:rgba(201,163,106,0.7);">我的回信</b>：我写给别人的回信&nbsp;&nbsp;'
      + '📩 <b style="color:rgba(201,163,106,0.7);">收到回信</b>：别人回复了我投出的御笺';
    container.appendChild(hint);

    const list = document.createElement('div');
    list.style.cssText = 'display:flex;flex-direction:column;gap:10px;';

    for (const item of allItems) {
      const card = document.createElement('div');
      const kindCfg = {
        received:      { label: '🕊️ 我捞到的', color: '#aac4ff', bg: 'rgba(100,150,255,0.08)', border: 'rgba(100,150,255,0.3)' },
        replied:       { label: '✍️ 我的回信', color: 'rgba(201,163,106,0.9)', bg: 'rgba(201,163,106,0.06)', border: 'rgba(201,163,106,0.3)' },
        inbound_reply: { label: '📩 收到回信', color: '#b8e0b8', bg: 'rgba(100,200,100,0.06)', border: 'rgba(100,200,100,0.25)' },
      }[item._kind] || { label: '📄', color: '#aaa', bg: 'rgba(0,0,0,0.3)', border: '#444' };

      const displayFrom = item.is_anonymous ? '匿名' : (item.display_name || item.owner_name || '某人');
      const snippet = (item.content || '').slice(0, 80) + ((item.content || '').length > 80 ? '…' : '');
      const dateStr = (item._takenAt || item.created_at || '').slice(0, 10);

      card.style.cssText = `background:${kindCfg.bg};border:1px solid ${kindCfg.border};border-radius:10px;padding:14px;display:flex;flex-direction:column;gap:8px;`;
      card.innerHTML = `
        <div style="display:flex;justify-content:space-between;align-items:center;gap:8px;">
          <div style="display:flex;align-items:center;gap:6px;flex:1;min-width:0;">
            <span style="flex-shrink:0;background:${kindCfg.bg};border:1px solid ${kindCfg.border};color:${kindCfg.color};font-size:10px;padding:2px 8px;border-radius:10px;white-space:nowrap;">${kindCfg.label}</span>
            <span style="color:var(--primary-color);font-size:14px;font-weight:bold;letter-spacing:2px;font-family:'STZhongsong','STSong',serif;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;">${item.char_name || '无名氏'}</span>
            <span style="color:#888;font-size:11px;flex-shrink:0;">· ${item.char_role || ''}</span>
          </div>
          <span style="color:#666;font-size:10px;flex-shrink:0;">${dateStr}</span>
        </div>
        ${item.topic ? `<div style="color:#aaa;font-size:11px;letter-spacing:1px;">「${item.topic}」</div>` : ''}
        <div style="color:#ccc;font-size:13px;line-height:1.8;font-family:'STSong','Noto Serif CJK SC',serif;">${snippet}</div>
        <div style="display:flex;justify-content:space-between;align-items:center;">
          <div style="color:#666;font-size:11px;">${item._kind === 'received' ? '来自 ' + displayFrom : (item._kind === 'replied' ? '我回给别人的信' : '来自 ' + displayFrom + ' 的回信')}</div>
          <button class="fl-expand-btn" style="background:transparent;border:1px solid rgba(201,163,106,0.3);color:rgba(201,163,106,0.8);padding:3px 10px;border-radius:10px;font-size:11px;font-family:inherit;">展开全文</button>
        </div>
        <!-- 展开区 -->
        <div class="fl-full-wrap" style="display:none;flex-direction:column;gap:8px;border-top:1px solid rgba(201,163,106,0.1);padding-top:10px;">
          <div style="color:#ddd;font-size:13px;line-height:2;letter-spacing:1px;font-family:'STSong','Noto Serif CJK SC',serif;white-space:pre-wrap;">${item.content || ''}</div>
          <!-- 对话线将动态加载 -->
          <div class="fl-thread" style="display:flex;flex-direction:column;gap:6px;"></div>
          <div style="color:#666;font-size:11px;text-align:right;">${item.time_str || ''}</div>
        </div>
      `;
      list.appendChild(card);

      // 展开/收起
      const expandBtn = card.querySelector('.fl-expand-btn');
      const fullWrap = card.querySelector('.fl-full-wrap');
      const threadEl = card.querySelector('.fl-thread');
      let threadLoaded = false;
      expandBtn.onclick = async () => {
        const isOpen = fullWrap.style.display !== 'none';
        if (isOpen) {
          fullWrap.style.display = 'none';
          expandBtn.innerText = '展开全文';
        } else {
          fullWrap.style.display = 'flex';
          expandBtn.innerText = '收起';
          // 加载对话线（展开时一次性加载）
          if (!threadLoaded) {
            threadLoaded = true;
            const rootId = item.reply_to || item.id;
            try {
              // 拉取整条对话线：原信 + 所有 reply_to = rootId 的回信
              const thread = await fgListReplies(rootId);
              if (thread && thread.length > 0) {
                const sep = document.createElement('div');
                sep.style.cssText = 'color:#666;font-size:11px;letter-spacing:2px;padding:4px 0;border-top:1px dashed rgba(201,163,106,0.15);';
                sep.innerText = '── 对话往来 ──';
                threadEl.appendChild(sep);
                thread.forEach(r => {
                  const isMe = r.owner_name === myName;
                  const rfrom = r.is_anonymous ? '匿名' : (r.display_name || r.owner_name || '某人');
                  const rcard = document.createElement('div');
                  rcard.style.cssText = `background:${isMe ? 'rgba(201,163,106,0.08)' : 'rgba(255,255,255,0.04)'};border:1px solid ${isMe ? 'rgba(201,163,106,0.2)' : 'rgba(255,255,255,0.08)'};border-radius:8px;padding:10px;display:flex;flex-direction:column;gap:4px;`;
                  rcard.innerHTML = `
                    <div style="display:flex;justify-content:space-between;align-items:center;">
                      <span style="color:${isMe ? 'var(--primary-color)' : '#aaa'};font-size:12px;font-weight:bold;">${isMe ? '▶ 我（' + r.char_name + '）' : '◀ ' + r.char_name} · ${r.char_role || ''}</span>
                      <span style="color:#555;font-size:10px;">${rfrom}</span>
                    </div>
                    <div style="color:#ccc;font-size:12px;line-height:1.8;font-family:'STSong','Noto Serif CJK SC',serif;white-space:pre-wrap;">${r.content || ''}</div>
                  `;
                  threadEl.appendChild(rcard);
                });
              }
            } catch(e3) { console.warn('[往来函件-对话线]', e3); }
          }
        }
      };
    }

    container.appendChild(list);
  } catch(e) {
    const msg = e?.message || String(e);
    container.innerHTML = `<div style="color:#888;font-size:13px;text-align:center;padding:40px;">加载失败：${msg.slice(0,80)}</div>`;
    console.error('[往来函件]', e);
  }
}

// ── 我的御笺 ──
async function renderFeigeMyList(container) {
  container.innerHTML = '<div style="color:#888;font-size:13px;text-align:center;padding:30px;">加载中…</div>';
  try {
    // 漂流瓶与圣旨都走 Cloudflare 后端
    let items1 = [], items2 = [];
    const myOwnerName = await getAccountName();
    
    try {
      const r1 = myOwnerName ? await fgListMine(myOwnerName) : [];
      items1 = (r1 || []).filter(it => !it.reply_to).map(it => ({
        id: it.id,
        _isEdict: false,
        data: {
          type: 'bottle',
          charName: it.char_name,
          charRole: it.char_role,
          topic: it.topic,
          content: it.content,
          timeStr: it.time_str,
          createdAt: it.created_at,
          takeCount: it.take_count ?? 0,
          maxTakes: it.max_takes ?? 10
        }
      }));
    } catch(e2) { console.warn('[我的御笺-漂流瓶加载失败]', e2); }
    
    try {
      // 圣旨 Cloudflare 后端
      const r2 = myOwnerName 
        ? await szListMyEdicts(myOwnerName)
        : [];
      items2 = (r2 || []).map(it => ({
        id: it.id,
        _isEdict: true,
        data: {
          type: 'edict',
          charName: it.char_name,
          charRole: it.char_role,
          topic: it.topic,
          content: it.content,
          timeStr: it.time_str,
          createdAt: it.created_at
        }
      }));
    } catch(e2) { console.warn('[我的御笺-圣旨加载失败]', e2); }
    
    const items = [...items1, ...items2];
    
    // 按时间倒序
    items.sort((a,b) => new Date(b.data?.createdAt || 0) - new Date(a.data?.createdAt || 0));

    if (!items.length) {
      container.innerHTML = '<div style="color:#666;font-size:13px;text-align:center;padding:40px;letter-spacing:2px;">你尚未投递过任何御笺或圣旨</div>';
      return;
    }
    container.innerHTML = '';
    const list = document.createElement('div');
    list.style.cssText = 'display:flex;flex-direction:column;gap:12px;';
    items.forEach(item => {
      const d = item.data || {};
      const card = document.createElement('div');
      card.style.cssText = 'background:rgba(0,0,0,0.4);border:1px solid rgba(201,163,106,0.3);border-radius:10px;padding:14px;display:flex;flex-direction:column;gap:8px;';
      const isEdict = d.type === 'edict';
      card.innerHTML = `
        <div style="display:flex;justify-content:space-between;align-items:center;gap:8px;">
          <div style="color:var(--primary-color);font-size:14px;font-weight:bold;letter-spacing:2px;font-family:'STZhongsong','STSong',serif;flex:1;min-width:0;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;">${d.charName || '无名氏'} · ${d.charRole || ''}</div>
          <div style="flex-shrink:0;background:${isEdict?'rgba(201,163,106,0.15)':'rgba(100,150,255,0.12)'};border:1px solid ${isEdict?'rgba(201,163,106,0.5)':'rgba(100,150,255,0.4)'};color:${isEdict?'var(--primary-color)':'#aac4ff'};font-size:10px;padding:2px 8px;border-radius:10px;letter-spacing:1px;">${isEdict?'📜 圣旨':'🕊️ 御笺'}</div>
        </div>
        ${d.topic ? `<div style="color:#888;font-size:11px;letter-spacing:1px;">主题：${d.topic}</div>` : ''}
        <div style="color:#ccc;font-size:13px;line-height:1.8;font-family:'STSong','Noto Serif CJK SC',serif;white-space:pre-wrap;">${(d.content||'').slice(0,120)}${(d.content||'').length>120?'…':''}</div>
        <div style="display:flex;justify-content:space-between;align-items:center;">
          <div style="display:flex;flex-direction:column;gap:3px;">
            <div style="color:#666;font-size:11px;">${d.timeStr || ''}</div>
            ${!isEdict && typeof d.takeCount === 'number' ? `<div style="color:#aaa;font-size:11px;">🕊️ 已被 ${d.takeCount}/${d.maxTakes||10} 人捞到</div>` : ''}
          </div>
          <button class="feige-del-btn" data-id="${item.id}" data-type="${isEdict?'edict':'bottle'}" style="background:rgba(139,32,32,0.2);border:1px solid #8b2020;color:#c96a6a;padding:4px 12px;border-radius:8px;font-size:12px;font-family:inherit;">${isEdict?'撤回':'收回'}</button>
        </div>
      `;
      list.appendChild(card);
    });
    container.appendChild(list);

    container.querySelectorAll('.feige-del-btn').forEach(btn => {
      btn.onclick = async () => {
        const id = btn.dataset.id;
        const isEdict = btn.dataset.type === 'edict';
        const typeName = isEdict ? '圣旨' : '御笺';
        const ok = await api.ui.confirm({ title: `收回${typeName}`, message: `确定收回这封${typeName}？收回后将从天下消失。` });
        if (!ok) return;
        try {
          if (isEdict) {
            await szDeleteEdict(id);
          } else {
            await fgDelete(id);
          }
          api.ui.toast(`${typeName}已收回`);
          renderFeigeMyList(container);
        } catch(e) { api.ui.toast('收回失败：' + (e?.message||'').slice(0,40)); }
      };
    });
  } catch(e) {
    const msg3 = e?.message || String(e) || '未知错误';
    if (msg3.includes('login') || msg3.includes('account') || msg3.includes('online') || msg3.includes('未登录') || msg3.includes('auth')) {
      container.innerHTML = '<div style="color:#888;font-size:13px;text-align:center;padding:40px;line-height:2;">请先设置飞鸽云名，<br>再重试联机功能。</div>';
    } else {
      container.innerHTML = `<div style="color:#888;font-size:13px;text-align:center;padding:40px;">加载失败：${msg3.slice(0,80)}</div>`;
    }
    console.error('[飞鸽传书-列表]', e);
  }
}

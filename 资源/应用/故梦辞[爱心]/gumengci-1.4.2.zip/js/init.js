

// 自动尝试播放（大部分浏览器会拦截纯自动播放，但我们还是先试一下）
window.addEventListener('DOMContentLoaded', () => {
  Promise.resolve(typeof restoreGmcAccountSession === 'function' ? restoreGmcAccountSession() : null);
  if (typeof startDisciplineExpiryTimer === 'function') startDisciplineExpiryTimer();
  switchTrack(0);
  updateLoopUI();
  renderPlaylist();
  bgmAudio.play().then(() => {
    bgmInited = true;
    isBgmPlaying = true;
    mcPlay.innerHTML = '&#9646;&#9646;';
    applySpinState(true);
    vinylDisc.classList.add('playing');
    musicStatus.innerText = '正在播放';
  }).catch(() => {
    // 如果被浏览器拦截，就等用户第一次点击屏幕时再播
    document.addEventListener('click', initBGM, { once: true });
    document.addEventListener('touchstart', initBGM, { passive: true });
  });
});



// ===== 御书房信笺数据（已持久化）=====
let ysfLettersData = [];

// ===== 御书房专属界面 =====
function renderYuShuFang() {
  const old = document.getElementById('yushufang-overlay');
  if (old) old.remove();

  const overlay = document.createElement('div');
  overlay.id = 'yushufang-overlay';
  overlay.style.cssText = 'position:absolute; inset:0; z-index:30; pointer-events:none;';

  // ── 底部三按钮操作栏 ──
  const bottomBar = document.createElement('div');
  bottomBar.style.cssText = `
    position:absolute; bottom:calc(var(--safe-bottom) + 16px);
    left:50%; transform:translateX(-50%);
    width:92%; max-width:420px;
    background:rgba(12,10,8,0.52);
    backdrop-filter:blur(20px); -webkit-backdrop-filter:blur(20px);
    border-radius:28px;
    border-bottom:1px solid rgba(201,163,106,0.35);
    padding:10px 8px calc(10px);
    display:flex; justify-content:space-around; align-items:center;
    pointer-events:auto;
    box-shadow:0 8px 32px rgba(0,0,0,0.45);
  `;

  const btnItems = [
    {
      label: '批阅奏折',
      icon: `<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/><polyline points="14 2 14 8 20 8"/><line x1="16" y1="13" x2="8" y2="13"/><line x1="16" y1="17" x2="8" y2="17"/><line x1="10" y1="9" x2="8" y2="9"/></svg>`,
      action: () => openZouZhePanel()
    },
    {
      label: '信笺',
      icon: `<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round"><path d="M4 4h16c1.1 0 2 .9 2 2v12c0 1.1-.9 2-2 2H4c-1.1 0-2-.9-2-2V6c0-1.1.9-2 2-2z"/><polyline points="22,6 12,13 2,6"/></svg>`,
      action: () => openYuShuFangLetters()
    },
    {
      label: '传召',
      icon: `<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round"><path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M23 21v-2a4 4 0 0 0-3-3.87"/><path d="M16 3.13a4 4 0 0 1 0 7.75"/></svg>`,
      action: () => api.ui.toast('传召（功能开发中）')
    }
  ];

  btnItems.forEach(item => {
    const btn = document.createElement('button');
    btn.style.cssText = `
      display:flex; flex-direction:column; align-items:center; gap:4px;
      background:transparent; border:none; cursor:pointer;
      padding:6px 4px; border-radius:12px;
      transition:background 0.18s;
      min-width:44px; pointer-events:auto;
    `;
    const iconEl = document.createElement('div');
    iconEl.style.cssText = 'width:20px; height:20px; display:flex; align-items:center; justify-content:center; color:rgba(201,163,106,0.88); filter:drop-shadow(0 1px 3px rgba(0,0,0,0.7));';
    iconEl.innerHTML = item.icon;
    const labelEl = document.createElement('div');
    labelEl.style.cssText = `font-size:10px; color:rgba(201,163,106,0.82); letter-spacing:1px; font-family:'STZhongsong','STSong',serif; text-shadow:0 1px 3px rgba(0,0,0,0.8);`;
    labelEl.textContent = item.label;
    btn.appendChild(iconEl);
    btn.appendChild(labelEl);
    btn.addEventListener('click', item.action);
    btn.addEventListener('touchstart', () => { btn.style.background = 'rgba(201,163,106,0.1)'; }, {passive:true});
    btn.addEventListener('touchend', () => { setTimeout(() => { btn.style.background = 'transparent'; }, 200); }, {passive:true});
    bottomBar.appendChild(btn);
  });

  overlay.appendChild(bottomBar);
  document.getElementById('view-palace-detail').appendChild(overlay);
}
// ===== 御书房·信笺系统 =====
// char间往来信笺数据
let ysfCharLettersData = []; // [{ id, groupId, fromId, fromName, toId, toName, letters:[{dir,content,time}] }]

function openYuShuFangLetters() {
  const old = document.getElementById('ysf-letters-modal');
  if (old) old.remove();

  const allChars = [...selectedCharsData, XLY_CHAR].filter(c => c.name && !(typeof isCharacterUnavailableForActivity === 'function' && isCharacterUnavailableForActivity(c)));

  const modal = document.createElement('div');
  modal.id = 'ysf-letters-modal';
  modal.style.cssText = `
    position:fixed; inset:0; z-index:99999;
    background:url('https://www.imgfox.cn/apis/uploads/20260818/cd2a4b22f1ec4748/IMG_9643.jpeg') center/cover no-repeat;
    display:flex; flex-direction:column;
  `;
  const overlay = document.createElement('div');
  overlay.style.cssText = 'position:absolute; inset:0; background:rgba(8,6,4,0.55); backdrop-filter:blur(8px); -webkit-backdrop-filter:blur(8px); z-index:0;';
  modal.appendChild(overlay);

  const wrap = document.createElement('div');
  wrap.style.cssText = 'position:relative; z-index:1; display:flex; flex-direction:column; height:100%; overflow:hidden;';

  const header = document.createElement('div');
  header.style.cssText = 'padding:calc(var(--safe-top,44px) + 10px) 16px 12px; display:flex; justify-content:space-between; align-items:center; border-bottom:1px solid rgba(201,163,106,0.2); flex-shrink:0; background:transparent;';
  header.innerHTML = `
    <button id="ysf-letters-back" style="background:transparent;border:none;color:#888;font-size:16px;font-family:inherit;">‹ 返回</button>
    <div style="color:var(--primary-color);font-size:18px;font-weight:bold;letter-spacing:5px;font-family:'STZhongsong','STSong',serif;
      background:linear-gradient(to bottom,#ffe9b8,#c9a36a);-webkit-background-clip:text;-webkit-text-fill-color:transparent;
      filter:drop-shadow(0 1px 4px rgba(0,0,0,0.8));">信笺</div>
    <button id="ysf-global-font-btn" style="background:rgba(201,163,106,0.15);border:1px solid rgba(201,163,106,0.4);color:rgba(201,163,106,0.9);font-size:12px;padding:4px 10px;border-radius:12px;font-family:inherit;letter-spacing:1px;">字体</button>
  `;
  wrap.appendChild(header);

  // 三个 Tab
  const tabBar = document.createElement('div');
  tabBar.style.cssText = 'display:flex; border-bottom:1px solid rgba(201,163,106,0.15); flex-shrink:0; background:transparent;';
  [{ label:'往来信笺', key:'normal' }, { label:'故人往来', key:'char' }, { label:'密探截获', key:'spy' }].forEach((tab, i) => {
    const btn = document.createElement('button');
    btn.className = 'ysf-tab';
    btn.dataset.key = tab.key;
    btn.style.cssText = `flex:1; padding:10px 0; background:transparent; border:none; font-size:12px; letter-spacing:1px; font-family:inherit; transition:all 0.2s; border-bottom:2px solid ${i===0?'var(--primary-color)':'transparent'}; color:${i===0?'var(--primary-color)':'#666'};`;
    btn.innerText = tab.label;
    tabBar.appendChild(btn);
  });
  wrap.appendChild(tabBar);

  const body = document.createElement('div');
  body.style.cssText = 'flex:1; overflow-y:auto; padding:16px 16px calc(var(--safe-bottom,24px)+16px); display:flex; flex-direction:column; gap:12px; background:transparent;';
  wrap.appendChild(body);

  modal.appendChild(wrap);
  document.body.appendChild(modal);

  document.getElementById('ysf-letters-back').onclick = () => modal.remove();

  // ── 全局字体按钮（信笺列表页顶栏）──
  document.getElementById('ysf-global-font-btn').onclick = () => {
    const old = document.getElementById('ysf-font-modal');
    if (old) { old.remove(); return; }

    const fm = document.createElement('div');
    fm.id = 'ysf-font-modal';
    fm.style.cssText = `
      position:fixed; inset:0; z-index:299999;
      background:rgba(0,0,0,0.7); backdrop-filter:blur(8px);
      display:flex; align-items:flex-end; justify-content:center;
    `;

    const box = document.createElement('div');
    box.style.cssText = `
      width:100%; max-width:480px;
      background:#1a1410;
      border:1px solid rgba(201,163,106,0.35);
      border-radius:20px 20px 0 0;
      padding:20px 20px calc(var(--safe-bottom,24px)+20px);
      display:flex; flex-direction:column; gap:14px;
    `;

    box.innerHTML = `
      <div style="display:flex;justify-content:space-between;align-items:center;">
        <div style="color:var(--primary-color);font-size:15px;font-weight:bold;letter-spacing:3px;font-family:'STZhongsong','STSong',serif;">信笺字体</div>
        <button id="ysf-fm-close" style="background:transparent;border:none;color:#888;font-size:14px;font-family:inherit;">关闭</button>
      </div>
      <div style="color:#aaa;font-size:11px;letter-spacing:1px;">选择后应用到所有信笺正文</div>
      <div style="color:#aaa;font-size:11px;letter-spacing:2px;">预设字体</div>
      <div id="ysf-preset-fonts" style="display:flex;flex-wrap:wrap;gap:8px;"></div>
      <div style="color:#aaa;font-size:11px;letter-spacing:2px;margin-top:4px;">字体链接（Google Fonts CSS 或 TTF 直链）</div>
      <input id="ysf-font-url" type="text" placeholder="https://fonts.googleapis.com/css2?family=..." value="${(window._ysfLetterFontUrl && !window._ysfLetterFontUrl.startsWith('data:')) ? window._ysfLetterFontUrl : ''}"
        style="width:100%;background:rgba(0,0,0,0.5);border:1px solid rgba(201,163,106,0.3);color:#eaeaea;padding:10px;border-radius:8px;font-size:13px;font-family:inherit;">
      <div style="color:#aaa;font-size:11px;letter-spacing:2px;">或上传本地字体文件（TTF / OTF / WOFF）</div>
      <button id="ysf-font-upload" style="background:rgba(201,163,106,0.08);border:1px dashed rgba(201,163,106,0.35);color:rgba(201,163,106,0.8);padding:12px;border-radius:8px;font-size:13px;font-family:inherit;letter-spacing:1px;">📂 选择字体文件</button>
      <div id="ysf-font-file-name" style="color:#666;font-size:11px;text-align:center;display:none;"></div>
      <div id="ysf-font-preview" style="
        background-color:rgba(240,225,190,0.85);border:1px solid rgba(201,163,106,0.2);border-radius:8px;
        padding:12px 16px;color:#2c1a0e;font-size:15px;line-height:2;letter-spacing:2px;
        writing-mode:vertical-rl;text-orientation:upright;
        height:100px;overflow:hidden;
        font-family:${window._ysfLetterFont || "'Ma Shan Zheng','STKaiti','KaiTi','楷体',cursive,serif"};
      ">青山隐隐水迢迢，秋尽江南草未凋。</div>
      <div style="display:flex;gap:10px;margin-top:4px;">
        <button id="ysf-font-reset" style="flex:1;background:transparent;border:1px solid #555;color:#aaa;padding:10px;border-radius:8px;font-family:inherit;font-size:13px;">恢复默认</button>
        <button id="ysf-font-apply" style="flex:2;background:var(--primary-color);border:none;color:#000;padding:10px;border-radius:8px;font-weight:bold;font-family:inherit;font-size:14px;">应用</button>
      </div>
    `;

    fm.appendChild(box);
    document.body.appendChild(fm);
    fm.addEventListener('click', e => { if (e.target === fm) fm.remove(); });
    document.getElementById('ysf-fm-close').onclick = () => fm.remove();

    // 预设字体
    const presets = [
      { label: '马善政（默认）', family: "'Ma Shan Zheng','STKaiti',cursive", url: 'https://fonts.googleapis.com/css2?family=Ma+Shan+Zheng&display=swap' },
      { label: '楷体', family: "'STKaiti','KaiTi','楷体',serif", url: '' },
      { label: '宋体', family: "'STSong','Noto Serif CJK SC',serif", url: '' },
      { label: '仿宋', family: "'FangSong','仿宋',serif", url: '' },
      { label: 'ZCOOL XiaoWei', family: "'ZCOOL XiaoWei',serif", url: 'https://fonts.googleapis.com/css2?family=ZCOOL+XiaoWei&display=swap' },
      { label: 'Noto Serif SC', family: "'Noto Serif SC',serif", url: 'https://fonts.googleapis.com/css2?family=Noto+Serif+SC&display=swap' },
    ];

    const presetWrap = document.getElementById('ysf-preset-fonts');
    let _selectedFamily = '';
    let _selectedUrl = '';
    presets.forEach(p => {
      const btn = document.createElement('button');
      const isActive = window._ysfLetterFont === p.family;
      btn.style.cssText = `background:${isActive?'rgba(201,163,106,0.2)':'transparent'};border:1px solid ${isActive?'var(--primary-color)':'#555'};color:${isActive?'var(--primary-color)':'#aaa'};padding:6px 12px;border-radius:16px;font-size:12px;font-family:inherit;cursor:pointer;letter-spacing:1px;transition:all 0.15s;`;
      btn.textContent = p.label;
      btn.onclick = () => {
        if (p.url) loadFontLink(p.url);
        document.getElementById('ysf-font-preview').style.fontFamily = p.family;
        document.getElementById('ysf-font-url').value = p.url;
        presetWrap.querySelectorAll('button').forEach(b => { b.style.background='transparent'; b.style.borderColor='#555'; b.style.color='#aaa'; });
        btn.style.background='rgba(201,163,106,0.2)'; btn.style.borderColor='var(--primary-color)'; btn.style.color='var(--primary-color)';
        _selectedFamily = p.family; _selectedUrl = p.url;
      };
      presetWrap.appendChild(btn);
    });

    // 字体链接实时预览
    let _pendingFontFamily = '';
    let _uploadedFontDataUrl = '';
    document.getElementById('ysf-font-url').addEventListener('input', e => {
      const url = e.target.value.trim();
      if (url) loadFontLink(url);
    });

    // 上传字体文件
    document.getElementById('ysf-font-upload').onclick = async () => {
      try {
        const picked = await api.media.pick({ accept: '.ttf,.otf,.woff,.woff2' });
        if (!picked?.file) return;
        const dataUrl = picked.file.dataUrl;
        const fontName = 'YsfCustomFont_' + Date.now();
        const style = document.createElement('style');
        style.textContent = `@font-face { font-family:'${fontName}'; src:url('${dataUrl}'); }`;
        document.head.appendChild(style);
        _uploadedFontDataUrl = dataUrl;
        _pendingFontFamily = `'${fontName}',serif`;
        document.getElementById('ysf-font-preview').style.fontFamily = _pendingFontFamily;
        document.getElementById('ysf-font-file-name').style.display = 'block';
        document.getElementById('ysf-font-file-name').textContent = `已加载：${picked.file.name || '自定义字体'}`;
        document.getElementById('ysf-font-url').value = '';
      } catch(e) { api.ui.toast('文件读取失败'); }
    };

    // 应用
    document.getElementById('ysf-font-apply').onclick = async () => {
      let family = _pendingFontFamily || _selectedFamily;
      let fontUrl = _uploadedFontDataUrl || _selectedUrl;
      if (!family) {
        fontUrl = document.getElementById('ysf-font-url').value.trim();
        if (fontUrl) {
          const m = fontUrl.match(/family=([^&:]+)/);
          family = m ? `'${decodeURIComponent(m[1]).replace(/\+/g,' ')}',serif` : "'CustomFont',serif";
        }
      }
      if (!family) { api.ui.toast('请先选择或输入字体'); return; }

      window._ysfLetterFont = family;
      if (_uploadedFontDataUrl) window._ysfLetterFontDataUrl = _uploadedFontDataUrl;
      if (fontUrl) window._ysfLetterFontUrl = fontUrl;

      await saveProgress({ ysfLetterFont: family, ysfLetterFontUrl: _uploadedFontDataUrl || fontUrl });

      // 更新当前已打开的所有信笺文字元素
      document.querySelectorAll('.ysf-letter-text').forEach(el => { el.style.fontFamily = family; });

      // 更新按钮显示当前字体
      const fontBtn = document.getElementById('ysf-global-font-btn');
      if (fontBtn) fontBtn.textContent = '字体 ✓';

      api.ui.toast('字体已应用');
      fm.remove();
    };

    // 恢复默认
    document.getElementById('ysf-font-reset').onclick = async () => {
      window._ysfLetterFont = '';
      window._ysfLetterFontUrl = '';
      window._ysfLetterFontDataUrl = '';
      await saveProgress({ ysfLetterFont: '', ysfLetterFontUrl: '' });
      document.querySelectorAll('.ysf-letter-text').forEach(el => {
        el.style.fontFamily = "'Ma Shan Zheng','STKaiti','KaiTi','楷体',cursive,serif";
      });
      const fontBtn = document.getElementById('ysf-global-font-btn');
      if (fontBtn) fontBtn.textContent = '字体';
      api.ui.toast('已恢复默认字体');
      fm.remove();
    };
  };

  // 如果已有保存字体，更新按钮显示
  if (window._ysfLetterFont) {
    const fontBtn = document.getElementById('ysf-global-font-btn');
    if (fontBtn) fontBtn.textContent = '字体 ✓';
  }

  function switchYsfTab(key) {
    modal.querySelectorAll('.ysf-tab').forEach(b => {
      const active = b.dataset.key === key;
      b.style.color = active ? 'var(--primary-color)' : '#666';
      b.style.borderBottomColor = active ? 'var(--primary-color)' : 'transparent';
    });
    body.innerHTML = '';
    if (key === 'normal') renderNormalLetters(body, allChars);
    else if (key === 'char') renderCharLetters(body, allChars);
    else renderSpyLetters(body);
  }

  modal.querySelectorAll('.ysf-tab').forEach(btn => { btn.onclick = () => switchYsfTab(btn.dataset.key); });
  switchYsfTab('normal');
}

// ===== 信笺系统：组装完整角色上下文（对齐 getIndoorChatContext）=====
function buildLetterCharContext(char) {
  const hudTimeEl = document.getElementById('hud-time');
  const timeStr = (hudTimeEl ? hudTimeEl.innerText : null) || (typeof hudTime !== 'undefined' && hudTime ? hudTime.innerText : '未知时辰');

  // 全局世界书
  let wbText = '';
  if (userAncientDesc) wbText += `【皇帝（User）人设】：\n${userAncientDesc}\n\n`;
  if (window.globalWorldDesc) wbText += `【大世界设定】：\n${window.globalWorldDesc}\n\n`;
  if (window.globalRulesDesc) wbText += `【后宫规矩与皇权设定】：\n${window.globalRulesDesc}\n\n`;
  if (rankData && rankData.length > 0) {
    wbText += `【后宫位份体系】：\n` + rankData.map(r => `- ${r.rank} (自称:${r.selfClaim})`).join('\n') + `\n\n`;
  }

  // 人设（完整原始版，不被时间/位份追加污染）
  const desc = char.ancientDescOriginal || char.ancientDesc || '';

  // 人物专属世界书
  const charWb = char.charWorldDesc ? `\n【专属人物世界书】：\n${char.charWorldDesc}` : '';

  // TA看到的 + TA的思绪（所有信件与续函每轮都发送）
  const memoryParts = getCharacterMemoryParts(char);
  const seenText = `${memoryParts.seenText}\n\n【TA的思绪】\n${memoryParts.thoughtsText}`;

  // TA了解的（memoryKnown：位份、关系图谱、起居注等）
  const knownText = memoryParts.knownText;

  // 起居注（records）
  const recText = (char.records || []).slice(0, 10).map(r => `[${r.time}] ${r.text}`).join('\n') || '无';

  // 关系图谱（从 _relationData 提取该角色对他人的看法）
  const relLines = [];
  const allC = [...(typeof selectedCharsData !== 'undefined' ? selectedCharsData : []), XLY_CHAR];
  allC.filter(c => c.name !== char.name).forEach(other => {
    const key = `${char.name}->${other.name}`;
    const rel = window._relationData?.[key];
    if (rel?.text) relLines.push(`对${other.name}：${rel.text}`);
  });
  const relText = relLines.length > 0 ? relLines.join('\n') : '无';

  return { timeStr, wbText, desc, charWb, seenText, knownText, recText, relText };
}

// ── Tab1 往来信笺（列表式）──
function renderNormalLetters(container, allChars) {
  // ── 顶部：选人 + 拆阅按钮 ──
  const topSection = document.createElement('div');
  topSection.style.cssText = 'display:flex; flex-direction:column; gap:8px; background:rgba(0,0,0,0.15); border:1px solid rgba(201,163,106,0.2); border-radius:12px; padding:12px; flex-shrink:0; backdrop-filter:blur(8px); -webkit-backdrop-filter:blur(8px);';
  const charOptHtml = allChars.map(c => `<option value="${c.id}">${c.name}（${c.ancientRole || c.assignedRank || '故人'}）</option>`).join('');
  topSection.innerHTML = `
    <div style="color:var(--primary-color);font-size:12px;letter-spacing:2px;">与何人通信</div>
    <select id="ysf-char-sel" style="width:100%;background:rgba(0,0,0,0.5);border:1px solid rgba(201,163,106,0.4);color:#eaeaea;padding:9px;border-radius:8px;font-family:inherit;font-size:14px;">${charOptHtml}</select>
    <button id="ysf-btn-receive" style="width:100%;background:rgba(201,163,106,0.15);border:1px solid var(--primary-color);color:var(--primary-color);padding:10px;border-radius:10px;font-size:14px;font-weight:bold;letter-spacing:3px;font-family:'STZhongsong','STSong',serif;">✦ 拆阅TA的来函</button>
  `;
  container.appendChild(topSection);

  // ── 列表区 ──
  const listWrap = document.createElement('div');
  listWrap.id = 'ysf-letters-list';
  listWrap.style.cssText = 'display:flex; flex-direction:column; gap:8px;';
  container.appendChild(listWrap);

  function getSelectedChar() {
    const sel = document.getElementById('ysf-char-sel');
    return allChars.find(c => c.id === sel?.value) || allChars[0];
  }

  // 打开某封信的详情弹层（含正文 + 回信操作）
  function openLetterDetail(char, letterId) {
    const letter = ysfLettersData.find(l => l.id === letterId);
    if (!letter) return;

    const old = document.getElementById('ysf-letter-detail');
    if (old) old.remove();

    const panel = document.createElement('div');
    panel.id = 'ysf-letter-detail';
    panel.style.cssText = `
      position:fixed; inset:0; z-index:199999;
      background:url('https://www.imgfox.cn/apis/uploads/20260818/cd2a4b22f1ec4748/IMG_9643.jpeg') center/cover no-repeat;
      display:flex; flex-direction:column;
    `;

    const isOut = letter.dir === 'out';
    const dirLabel = isOut ? '朕发出' : `${char.name} 来函`;

    // 顶栏：深色磨砂，不参与信纸效果
    const detailHeader = document.createElement('div');
    detailHeader.style.cssText = `
      padding:max(var(--safe-top,44px),44px) 16px 0;
      flex-shrink:0;
      background:transparent;
    `;
    detailHeader.innerHTML = `
      <div style="display:flex;justify-content:space-between;align-items:center;padding-bottom:12px;border-bottom:1px solid rgba(201,163,106,0.25);">
        <button id="ysf-detail-back" style="background:transparent;border:none;color:rgba(201,163,106,0.7);font-size:16px;font-family:inherit;padding:8px 4px;">‹ 返回</button>
        <div style="color:var(--primary-color);font-size:15px;font-weight:bold;letter-spacing:3px;font-family:'STZhongsong','STSong',serif;
          background:linear-gradient(to bottom,#ffe9b8,#c9a36a);-webkit-background-clip:text;-webkit-text-fill-color:transparent;">${dirLabel}</div>
        <div style="width:48px;"></div>
      </div>
    `;
    panel.appendChild(detailHeader);

    // 加载谷歌楷体字体（一次性）
    if (!document.getElementById('gf-mszh')) {
      const lk = document.createElement('link');
      lk.id = 'gf-mszh'; lk.rel = 'stylesheet';
      lk.href = 'https://fonts.googleapis.com/css2?family=Ma+Shan+Zheng&display=swap';
      document.head.appendChild(lk);
    }

    // 外层滚动容器：背景用主菜单壁纸，居中展示信纸
    const paperOuter = document.createElement('div');
    paperOuter.style.cssText = `
      flex:1; overflow-y:auto;
      background:transparent;
      display:flex; justify-content:center; align-items:flex-start;
      padding:28px 20px calc(var(--safe-bottom,24px)+28px);
    `;

    // 信纸容器：高度固定，宽度由文字撑开（两层结构）
    const paperH = Math.round(window.innerHeight * 0.72);
    const sidePad = 44;

    const paperWrap = document.createElement('div');
    paperWrap.style.cssText = `
      position:relative;
      height:${paperH}px;
      min-width:${sidePad * 2 + 60}px;
      display:inline-flex;
      box-shadow:0 6px 32px rgba(0,0,0,0.75), 0 0 0 1px rgba(160,110,50,0.35);
      border-radius:2px;
      overflow:visible;
    `;

    // 第1层：底图（absolute 铺满容器，跟随文字宽度拉伸）
    const bgImg = document.createElement('img');
    bgImg.src = 'https://www.imgfox.cn/apis/uploads/20260822/e5272a025d334c40/IMG_9820.png';
    bgImg.style.cssText = `
      position:absolute; inset:0;
      width:100%; height:100%;
      object-fit:fill;
      z-index:1;
      pointer-events:none; user-select:none;
      border-radius:2px;
    `;
    paperWrap.appendChild(bgImg);

    // 第2层：文字（正常流撑开容器宽度）
    const textEl = document.createElement('div');
    textEl.className = 'ysf-letter-text';
    textEl.style.cssText = `
      position:relative;
      z-index:2;
      padding:64px ${sidePad}px 60px;
      writing-mode:vertical-rl;
      text-orientation:upright;
      color:#2c1a0e;
      font-size:15px;
      line-height:1.8;
      letter-spacing:2px;
      font-family:${window._ysfLetterFont || "'Ma Shan Zheng','STKaiti','KaiTi','楷体',cursive,serif"};
      white-space:pre-wrap;
      height:100%;
      box-sizing:border-box;
    `;
    textEl.textContent = letter.content;
    paperWrap.appendChild(textEl);

    paperOuter.appendChild(paperWrap);
    panel.appendChild(paperOuter);

    // 若是来信，显示回信区
    if (!isOut) {
      const replyArea = document.createElement('div');
      replyArea.style.cssText = 'padding:12px 16px calc(var(--safe-bottom,24px)+12px);border-top:1px solid rgba(201,163,106,0.25);display:flex;flex-direction:column;gap:8px;flex-shrink:0;background:rgba(0,0,0,0.15);backdrop-filter:blur(12px);-webkit-backdrop-filter:blur(12px);';
      replyArea.innerHTML = `
        <textarea id="ysf-detail-reply-input" placeholder="执笔回信，或点「AI代笔」…" style="width:100%;min-height:80px;background:rgba(0,0,0,0.5);border:1px solid rgba(201,163,106,0.3);color:#eaeaea;padding:10px;border-radius:8px;font-family:'STSong','Noto Serif CJK SC',serif;font-size:13px;line-height:1.8;resize:vertical;"></textarea>
        <div style="display:flex;gap:8px;">
          <button id="ysf-detail-ai-reply" style="flex:1;background:rgba(201,163,106,0.1);border:1px solid var(--primary-color);color:var(--primary-color);padding:10px;border-radius:8px;font-size:13px;font-family:inherit;">✦ AI代笔</button>
          <button id="ysf-detail-send" style="flex:2;background:var(--primary-color);border:none;color:#000;padding:10px;border-radius:8px;font-size:14px;font-weight:bold;font-family:inherit;letter-spacing:2px;">发出回函 →</button>
        </div>
      `;
      panel.appendChild(replyArea);

      // AI代笔
      panel.querySelector('#ysf-detail-ai-reply').addEventListener('click', async () => {
        const btn = panel.querySelector('#ysf-detail-ai-reply');
        btn.innerText = '代笔中…'; btn.disabled = true;
        const ctx2 = buildLetterCharContext(char);
        const p = `你是一位古代皇帝，正在给「${char.name}」（${char.ancientRole || char.assignedRank || '故人'}）写回信。当前时间：${ctx2.timeStr}。
【皇帝人设】：${userAncientDesc || '至高无上的皇帝'}
【关于「${char.name}」】：${ctx2.desc.slice(0,400)}
【对方来函】：${letter.content}
请以帝王口吻写回信，古风文言，约80~120字，结合来函内容作回应。只输出正文。`;
        try {
          const res = await api.ai.chat({ messages:[{role:'user',content:p}] });
          const text = (typeof res==='string'?res:(res?.content??res?.text??'')).trim();
          const ta = panel.querySelector('#ysf-detail-reply-input');
          if (ta) ta.value = text;
        } catch(e) { api.ui.toast('代笔失败'); }
        finally { btn.innerText = '✦ AI代笔'; btn.disabled = false; }
      });

      // 发出回函
      panel.querySelector('#ysf-detail-send').addEventListener('click', async () => {
        const content = panel.querySelector('#ysf-detail-reply-input')?.value?.trim();
        if (!content) { api.ui.toast('回函内容不可为空'); return; }
        const btn = panel.querySelector('#ysf-detail-send');
        btn.innerText = '发出中…'; btn.disabled = true;
        const timeStr = hudTime ? hudTime.innerText : '未知时辰';

        const outLtrId = 'ltr_' + Date.now();
        ysfLettersData.push({ id: outLtrId, charId: char.id, charName: char.name, dir: 'out', content, time: timeStr });
        if (!char.memorySeen) char.memorySeen = [];
        char.memorySeen.unshift({ time: timeStr, text: `【来函记录·皇帝致${char.name}】${content}`, _letterId: outLtrId });
        if (char._isScenarioChar) { window._xlyMemorySeen = char.memorySeen; await saveProgress({ ysfLettersData, xlyMemorySeen: char.memorySeen }); }
        else { await saveProgress({ ysfLettersData, characters: selectedCharsData }); }
        checkAndTriggerReflect(char);

        // AI生成对方回信
        const ctx3 = buildLetterCharContext(char);
        const relKey3 = `${char.name}->user`;
        const relText3 = window._relationData?.[relKey3]?.text || ctx3.relText || '君臣/主从关系';
        const rp = `你是「${char.name}」，收到了皇帝写给你的信：「${content}」
【全局世界书】：${ctx3.wbText}
【你的完整人设】：${ctx3.desc}${ctx3.charWb}
【TA了解的】：${ctx3.knownText}
【TA看到的】：${ctx3.seenText}
【起居注】：${ctx3.recText}
【你对皇帝的态度/关系】：${relText3}
请以「${char.name}」的口吻写回信给皇帝，古风文言，约100~150字，贴合人设与处境，结合来信内容作回应。只输出正文。`;
        try {
          const res2 = await api.ai.chat({ messages:[{role:'user',content:rp}] });
          const replyContent = (typeof res2==='string'?res2:(res2?.content??res2?.text??'')).trim();
          const replyLtrId = 'ltr_' + Date.now();
          ysfLettersData.push({ id: replyLtrId, charId: char.id, charName: char.name, dir: 'in', content: replyContent, time: timeStr });
          if (!char.memorySeen) char.memorySeen = [];
          char.memorySeen.unshift({ time: timeStr, text: `【来函记录·${char.name}致皇帝】${replyContent}`, _letterId: replyLtrId });
          if (char._isScenarioChar) { window._xlyMemorySeen = char.memorySeen; await saveProgress({ ysfLettersData, xlyMemorySeen: char.memorySeen }); }
          else { await saveProgress({ ysfLettersData, characters: selectedCharsData }); }
          checkAndTriggerReflect(char);
          panel.remove();
          renderLettersList();
          api.ui.toast(`${char.name} 已回函`);
        } catch(e) { api.ui.toast('对方回信生成失败'); }
        finally { btn.innerText = '发出回函 →'; btn.disabled = false; }
      });
    }

    document.body.appendChild(panel);
    panel.querySelector('#ysf-detail-back').onclick = () => { panel.remove(); renderLettersList(); };

    // ── 字体自定义按钮 ──
    panel.querySelector('#ysf-font-btn').onclick = () => {
      const old = document.getElementById('ysf-font-modal');
      if (old) { old.remove(); return; }

      const fm = document.createElement('div');
      fm.id = 'ysf-font-modal';
      fm.style.cssText = `
        position:fixed; inset:0; z-index:299999;
        background:rgba(0,0,0,0.7); backdrop-filter:blur(8px);
        display:flex; align-items:flex-end; justify-content:center;
      `;

      const box = document.createElement('div');
      box.style.cssText = `
        width:100%; max-width:480px;
        background:#1a1410;
        border:1px solid rgba(201,163,106,0.35);
        border-radius:20px 20px 0 0;
        padding:20px 20px calc(var(--safe-bottom,24px)+20px);
        display:flex; flex-direction:column; gap:14px;
      `;

      const currentFont = window._ysfLetterFont || '';
      box.innerHTML = `
        <div style="display:flex;justify-content:space-between;align-items:center;">
          <div style="color:var(--primary-color);font-size:15px;font-weight:bold;letter-spacing:3px;font-family:'STZhongsong','STSong',serif;">信笺字体</div>
          <button id="ysf-fm-close" style="background:transparent;border:none;color:#888;font-size:14px;font-family:inherit;">关闭</button>
        </div>

        <!-- 预设字体 -->
        <div style="color:#aaa;font-size:11px;letter-spacing:2px;">预设字体</div>
        <div id="ysf-preset-fonts" style="display:flex;flex-wrap:wrap;gap:8px;"></div>

        <!-- 字体链接 -->
        <div style="color:#aaa;font-size:11px;letter-spacing:2px;margin-top:4px;">字体链接（CSS @import 或 TTF/WOFF 直链）</div>
        <input id="ysf-font-url" type="text" placeholder="https://fonts.googleapis.com/css2?family=..." value="${currentFont.startsWith('http') ? currentFont : ''}"
          style="width:100%;background:rgba(0,0,0,0.5);border:1px solid rgba(201,163,106,0.3);color:#eaeaea;padding:10px;border-radius:8px;font-size:13px;font-family:inherit;">

        <!-- 上传 TTF -->
        <div style="color:#aaa;font-size:11px;letter-spacing:2px;">或上传本地字体文件（TTF / OTF / WOFF）</div>
        <button id="ysf-font-upload" style="background:rgba(201,163,106,0.08);border:1px dashed rgba(201,163,106,0.35);color:rgba(201,163,106,0.8);padding:12px;border-radius:8px;font-size:13px;font-family:inherit;letter-spacing:1px;">
          📂 选择字体文件
        </button>
        <div id="ysf-font-file-name" style="color:#666;font-size:11px;text-align:center;display:none;"></div>

        <!-- 预览 -->
        <div id="ysf-font-preview" style="
          background:rgba(255,248,225,0.12);border:1px solid rgba(201,163,106,0.2);border-radius:8px;
          padding:12px 16px;color:#2c1a0e;font-size:15px;line-height:2;letter-spacing:2px;
          writing-mode:vertical-rl;text-orientation:upright;
          height:100px;overflow:hidden;
          font-family:'Ma Shan Zheng','STKaiti','KaiTi','楷体',cursive,serif;
          background-color:rgba(240,225,190,0.85);
        ">青山隐隐水迢迢，秋尽江南草未凋。</div>

        <div style="display:flex;gap:10px;margin-top:4px;">
          <button id="ysf-font-reset" style="flex:1;background:transparent;border:1px solid #555;color:#aaa;padding:10px;border-radius:8px;font-family:inherit;font-size:13px;">恢复默认</button>
          <button id="ysf-font-apply" style="flex:2;background:var(--primary-color);border:none;color:#000;padding:10px;border-radius:8px;font-weight:bold;font-family:inherit;font-size:14px;">应用</button>
        </div>
      `;

      fm.appendChild(box);
      document.body.appendChild(fm);
      fm.addEventListener('click', e => { if (e.target === fm) fm.remove(); });
      document.getElementById('ysf-fm-close').onclick = () => fm.remove();

      // 预设字体列表
      const presets = [
        { label: '马善政（默认）', family: "'Ma Shan Zheng','STKaiti',cursive", url: 'https://fonts.googleapis.com/css2?family=Ma+Shan+Zheng&display=swap' },
        { label: '楷体', family: "'STKaiti','KaiTi','楷体',serif", url: '' },
        { label: '宋体', family: "'STSong','Noto Serif CJK SC',serif", url: '' },
        { label: '仿宋', family: "'FangSong','仿宋',serif", url: '' },
        { label: 'ZCOOL XiaoWei', family: "'ZCOOL XiaoWei',serif", url: 'https://fonts.googleapis.com/css2?family=ZCOOL+XiaoWei&display=swap' },
        { label: 'Noto Serif SC', family: "'Noto Serif SC',serif", url: 'https://fonts.googleapis.com/css2?family=Noto+Serif+SC&display=swap' },
      ];

      const presetWrap = document.getElementById('ysf-preset-fonts');
      presets.forEach(p => {
        const btn = document.createElement('button');
        const isActive = window._ysfLetterFont === p.family;
        btn.style.cssText = `
          background:${isActive ? 'rgba(201,163,106,0.2)' : 'transparent'};
          border:1px solid ${isActive ? 'var(--primary-color)' : '#555'};
          color:${isActive ? 'var(--primary-color)' : '#aaa'};
          padding:6px 12px; border-radius:16px; font-size:12px;
          font-family:inherit; cursor:pointer; letter-spacing:1px;
          transition:all 0.15s;
        `;
        btn.textContent = p.label;
        btn.onclick = () => {
          // 如有 Google 字体链接先加载
          if (p.url) loadFontLink(p.url);
          document.getElementById('ysf-font-preview').style.fontFamily = p.family;
          document.getElementById('ysf-font-url').value = p.url;
          // 高亮选中
          presetWrap.querySelectorAll('button').forEach(b => {
            b.style.background = 'transparent'; b.style.borderColor = '#555'; b.style.color = '#aaa';
          });
          btn.style.background = 'rgba(201,163,106,0.2)'; btn.style.borderColor = 'var(--primary-color)'; btn.style.color = 'var(--primary-color)';
          btn._selectedFamily = p.family;
          btn._selectedUrl = p.url;
        };
        presetWrap.appendChild(btn);
      });

      // 字体链接输入实时预览
      let _pendingFontFamily = '';
      document.getElementById('ysf-font-url').addEventListener('input', e => {
        const url = e.target.value.trim();
        if (url) loadFontLink(url);
      });

      // 上传字体文件
      let _uploadedFontDataUrl = '';
      document.getElementById('ysf-font-upload').onclick = async () => {
        try {
          const picked = await api.media.pick({ accept: '.ttf,.otf,.woff,.woff2' });
          if (!picked?.file) return;
          const dataUrl = picked.file.dataUrl;
          const fontName = 'YsfCustomFont_' + Date.now();
          const style = document.createElement('style');
          style.textContent = `@font-face { font-family:'${fontName}'; src:url('${dataUrl}'); }`;
          document.head.appendChild(style);
          _uploadedFontDataUrl = dataUrl;
          _pendingFontFamily = `'${fontName}',serif`;
          document.getElementById('ysf-font-preview').style.fontFamily = _pendingFontFamily;
          document.getElementById('ysf-font-file-name').style.display = 'block';
          document.getElementById('ysf-font-file-name').textContent = `已加载：${picked.file.name || '自定义字体'}`;
          document.getElementById('ysf-font-url').value = '';
        } catch(e) { api.ui.toast('文件读取失败'); }
      };

      // 应用
      document.getElementById('ysf-font-apply').onclick = async () => {
        // 优先用上传的，其次用链接，其次用预设选中的
        let family = _pendingFontFamily;
        let fontUrl = '';
        if (!family) {
          // 看有没有预设被选中
          const activeBtn = [...presetWrap.querySelectorAll('button')].find(b => b._selectedFamily);
          if (activeBtn) { family = activeBtn._selectedFamily; fontUrl = activeBtn._selectedUrl || ''; }
        }
        if (!family) {
          // 用链接输入框
          fontUrl = document.getElementById('ysf-font-url').value.trim();
          if (fontUrl) {
            // 从 URL 猜 family 名（Google Fonts 格式）
            const m = fontUrl.match(/family=([^&:]+)/);
            family = m ? `'${decodeURIComponent(m[1]).replace(/\+/g,' ')}',serif` : "'CustomFont',serif";
          }
        }
        if (!family) { api.ui.toast('请先选择或输入字体'); return; }

        window._ysfLetterFont = family;
        if (_uploadedFontDataUrl) window._ysfLetterFontDataUrl = _uploadedFontDataUrl;
        else if (fontUrl) window._ysfLetterFontUrl = fontUrl;

        // 持久化
        await saveProgress({ ysfLetterFont: family, ysfLetterFontUrl: _uploadedFontDataUrl || fontUrl });

        // 更新当前信纸文字
        if (textEl) textEl.style.fontFamily = family;
        api.ui.toast('字体已应用');
        fm.remove();
      };

      // 恢复默认
      document.getElementById('ysf-font-reset').onclick = async () => {
        window._ysfLetterFont = '';
        window._ysfLetterFontUrl = '';
        window._ysfLetterFontDataUrl = '';
        await saveProgress({ ysfLetterFont: '', ysfLetterFontUrl: '' });
        if (textEl) textEl.style.fontFamily = "'Ma Shan Zheng','STKaiti','KaiTi','楷体',cursive,serif";
        api.ui.toast('已恢复默认字体');
        fm.remove();
      };
    };

    // 启动时应用已保存字体
    if (window._ysfLetterFont) {
      if (window._ysfLetterFontUrl && !window._ysfLetterFontUrl.startsWith('data:')) {
        loadFontLink(window._ysfLetterFontUrl);
      } else if (window._ysfLetterFontDataUrl) {
        const fontName = window._ysfLetterFont.replace(/['"]/g,'').split(',')[0];
        if (!document.querySelector(`style[data-ysf-font="${fontName}"]`)) {
          const s = document.createElement('style');
          s.dataset.ysfFont = fontName;
          s.textContent = `@font-face { font-family:'${fontName}'; src:url('${window._ysfLetterFontDataUrl}'); }`;
          document.head.appendChild(s);
        }
      }
      textEl.style.fontFamily = window._ysfLetterFont;
    }
  }

  function renderLettersList() {
    const listEl = document.getElementById('ysf-letters-list');
    if (!listEl) return;
    const char = getSelectedChar();
    const letters = ysfLettersData.filter(l => l.charId === char?.id);
    listEl.innerHTML = '';
    if (letters.length === 0) {
      listEl.innerHTML = '<div style="color:#555;text-align:center;padding:20px;font-size:13px;letter-spacing:2px;">尚无往来信笺</div>';
      return;
    }
    // 最新在前
    [...letters].reverse().forEach(letter => {
      const isOut = letter.dir === 'out';
      const row = document.createElement('div');
      row.style.cssText = `
        display:flex; align-items:center; gap:10px; padding:11px 14px;
        background:${isOut?'rgba(201,163,106,0.06)':'rgba(30,24,20,0.6)'};
        border:1px solid ${isOut?'rgba(201,163,106,0.35)':'rgba(201,163,106,0.15)'};
        border-radius:10px; cursor:pointer; transition:opacity 0.15s;
      `;
      const typeTag = isOut
        ? `<span style="background:rgba(201,163,106,0.18);color:rgba(201,163,106,0.9);border-radius:4px;padding:1px 7px;font-size:11px;flex-shrink:0;">朕发</span>`
        : `<span style="background:rgba(40,30,20,0.7);color:#ccc;border-radius:4px;padding:1px 7px;font-size:11px;flex-shrink:0;">来函</span>`;
      const preview = letter.content.replace(/\n/g,' ').slice(0,30) + (letter.content.length>30?'…':'');
      row.innerHTML = `
        ${typeTag}
        <div style="flex:1;min-width:0;">
          <div style="color:${isOut?'rgba(201,163,106,0.85)':'#ccc'};font-size:13px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;">${preview}</div>
        </div>
        <div style="display:flex;align-items:center;gap:6px;flex-shrink:0;">
          <span style="color:#555;font-size:10px;">${letter.time}</span>
          <button class="ysf-del-letter" data-id="${letter.id}" style="background:transparent;border:1px solid rgba(139,32,32,0.4);color:#c96a6a;font-size:10px;padding:1px 6px;border-radius:4px;font-family:inherit;">删</button>
          <span style="color:#666;font-size:12px;">›</span>
        </div>
      `;
      row.addEventListener('click', (e) => { if (e.target.classList.contains('ysf-del-letter')) return; openLetterDetail(char, letter.id); });
      row.querySelector('.ysf-del-letter').addEventListener('click', async (e) => {
        e.stopPropagation();
        const lid = e.currentTarget.dataset.id;
        const lIdx = ysfLettersData.findIndex(l => l.id === lid);
        if (lIdx >= 0) ysfLettersData.splice(lIdx, 1);
        if (char.memorySeen) {
          const mIdx = char.memorySeen.findIndex(m => m._letterId === lid);
          if (mIdx >= 0) { char.memorySeen.splice(mIdx, 1); }
          if (char._isScenarioChar) { window._xlyMemorySeen = char.memorySeen; await saveProgress({ xlyMemorySeen: char.memorySeen }); }
          else { await saveProgress({ characters: selectedCharsData }); }
        }
        renderLettersList();
      });
      listEl.appendChild(row);
    });
  }

  document.getElementById('ysf-char-sel').addEventListener('change', renderLettersList);

  // 拆阅来函
  document.getElementById('ysf-btn-receive').addEventListener('click', async () => {
    const char = getSelectedChar();
    if (!char) { api.ui.toast('请先选择联络人'); return; }
    const btn = document.getElementById('ysf-btn-receive');
    btn.innerText = '正在生成来函…'; btn.disabled = true;
    const ctx = buildLetterCharContext(char);
    const recent = ysfLettersData.filter(l => l.charId === char.id).slice(-3);
    const recentText = recent.length > 0 ? recent.map(l => `${l.dir==='in'?char.name:'皇帝'}：${l.content}`).join('\n') : '无';
    const relKey = `${char.name}->user`;
    const letterRelText = window._relationData?.[relKey]?.text || ctx.relText || '君臣/主从关系';
    const prompt = `你是古代宫廷角色「${char.name}」，身份：${char.ancientRole||char.assignedRank||'故人'}。当前时间：${ctx.timeStr}。
【全局世界书】：${ctx.wbText}
【你的完整人设】：${ctx.desc}${ctx.charWb}
【位份与居所】：位份：${char.assignedRank||'无'} | 居所：${char.assignedPalace||'无'}
【TA了解的】：${ctx.knownText}
【TA看到的】：${ctx.seenText}
【起居注】：${ctx.recText}
【你对皇帝的态度/关系】：${letterRelText}
【近期往来信笺记录】：${recentText}
请以「${char.name}」的口吻，写一封寄给皇帝（朕）的私信。古风文言，雅致含蓄，约100~150字，结合近期经历与记忆，只输出正文。`;
    try {
      const res = await api.ai.chat({ messages:[{role:'user',content:prompt}] });
      const content = (typeof res==='string'?res:(res?.content??res?.text??'')).trim();
      const letterId = 'ltr_' + Date.now();
      ysfLettersData.push({ id: letterId, charId: char.id, charName: char.name, dir: 'in', content, time: ctx.timeStr });
      if (!char.memorySeen) char.memorySeen = [];
      char.memorySeen.unshift({ time: ctx.timeStr, text: `【来函记录·${char.name}致皇帝】${content}`, _letterId: letterId });
      if (char._isScenarioChar) { window._xlyMemorySeen = char.memorySeen; await saveProgress({ ysfLettersData, xlyMemorySeen: char.memorySeen }); }
      else { await saveProgress({ ysfLettersData, characters: selectedCharsData }); }
      checkAndTriggerReflect(char);
      renderLettersList();
    } catch(e) { api.ui.toast('来函生成失败：'+(e?.message||'')); }
    finally { btn.innerText = '✦ 拆阅TA的来函'; btn.disabled = false; }
  });

  renderLettersList();
}

// ── Tab2 故人往来（char间信笺，列表式）──
function renderCharLetters(container, allChars) {
  if (allChars.length < 2) {
    container.innerHTML = '<div style="color:#666;text-align:center;padding:40px 20px;font-size:13px;letter-spacing:2px;">至少需要两位故人才能使用此功能</div>';
    return;
  }

  // 顶部：选人 + 生成按钮
  const topSection = document.createElement('div');
  topSection.style.cssText = 'display:flex;flex-direction:column;gap:8px;background:rgba(0,0,0,0.35);border:1px solid rgba(201,163,106,0.25);border-radius:12px;padding:12px;flex-shrink:0;';
  const charOptHtml = allChars.map(c => `<option value="${c.id}">${c.name}（${c.ancientRole||c.assignedRank||'故人'}）</option>`).join('');
  topSection.innerHTML = `
    <div style="color:var(--primary-color);font-size:12px;letter-spacing:2px;">发信人</div>
    <select id="ysf-cl-from" style="width:100%;background:rgba(0,0,0,0.5);border:1px solid rgba(201,163,106,0.4);color:#eaeaea;padding:9px;border-radius:8px;font-family:inherit;font-size:14px;">${charOptHtml}</select>
    <div style="color:var(--primary-color);font-size:12px;letter-spacing:2px;">收信人</div>
    <select id="ysf-cl-to" style="width:100%;background:rgba(0,0,0,0.5);border:1px solid rgba(201,163,106,0.4);color:#eaeaea;padding:9px;border-radius:8px;font-family:inherit;font-size:14px;"></select>
    <div style="display:flex;gap:8px;margin-top:2px;">
      <button id="ysf-cl-random" style="flex:1;background:rgba(201,163,106,0.08);border:1px solid rgba(201,163,106,0.3);color:rgba(201,163,106,0.8);padding:9px;border-radius:8px;font-size:13px;font-family:inherit;letter-spacing:1px;">🎲 随机配对</button>
      <button id="ysf-cl-gen" style="flex:2;background:rgba(201,163,106,0.15);border:1px solid var(--primary-color);color:var(--primary-color);padding:9px;border-radius:8px;font-size:14px;font-weight:bold;font-family:'STZhongsong','STSong',serif;letter-spacing:2px;">✦ 截获往来函件</button>
    </div>
  `;
  container.appendChild(topSection);

  // 更新收信人列表（排除发信人）
  function updateToOptions() {
    const fromId = document.getElementById('ysf-cl-from')?.value;
    const toSel = document.getElementById('ysf-cl-to');
    if (!toSel) return;
    toSel.innerHTML = allChars.filter(c => c.id !== fromId).map(c => `<option value="${c.id}">${c.name}（${c.ancientRole||c.assignedRank||'故人'}）</option>`).join('');
  }
  updateToOptions();
  document.getElementById('ysf-cl-from').addEventListener('change', updateToOptions);

  // 随机配对
  document.getElementById('ysf-cl-random').addEventListener('click', () => {
    const shuffled = [...allChars].sort(() => Math.random() - 0.5);
    const fromSel = document.getElementById('ysf-cl-from');
    if (fromSel) fromSel.value = shuffled[0].id;
    updateToOptions();
    const toSel = document.getElementById('ysf-cl-to');
    if (toSel && shuffled.length > 1) toSel.value = shuffled[1].id;
  });

  // 列表区
  const listWrap = document.createElement('div');
  listWrap.id = 'ysf-cl-list';
  listWrap.style.cssText = 'display:flex;flex-direction:column;gap:8px;';
  container.appendChild(listWrap);

  // 渲染列表
  function renderClList() {
    const listEl = document.getElementById('ysf-cl-list');
    if (!listEl) return;
    listEl.innerHTML = '';
    if (ysfCharLettersData.length === 0) {
      listEl.innerHTML = '<div style="color:#555;text-align:center;padding:20px;font-size:13px;letter-spacing:2px;">尚无故人往来函件</div>';
      return;
    }
    [...ysfCharLettersData].reverse().forEach(group => {
      const row = document.createElement('div');
      row.style.cssText = 'display:flex;align-items:center;gap:10px;padding:11px 14px;background:rgba(20,14,10,0.7);border:1px solid rgba(201,163,106,0.2);border-radius:10px;cursor:pointer;transition:opacity 0.15s;';
      const preview = group.letters[0]?.content.replace(/\n/g,' ').slice(0,28)+(group.letters[0]?.content.length>28?'…':'') || '';
      row.innerHTML = `
        <span style="background:rgba(60,40,20,0.8);color:rgba(201,163,106,0.8);border-radius:4px;padding:1px 7px;font-size:11px;flex-shrink:0;letter-spacing:1px;">故人往来</span>
        <div style="flex:1;min-width:0;">
          <div style="color:rgba(201,163,106,0.9);font-size:12px;letter-spacing:1px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;">${group.fromName} → ${group.toName}</div>
          <div style="color:#888;font-size:12px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;margin-top:2px;">${preview}</div>
        </div>
        <div style="display:flex;align-items:center;gap:6px;flex-shrink:0;">
          <span style="color:#555;font-size:10px;">${group.letters[0]?.time||''}</span>
          <button class="ysf-cl-del" data-gid="${group.id}" style="background:transparent;border:1px solid rgba(139,32,32,0.4);color:#c96a6a;font-size:10px;padding:1px 6px;border-radius:4px;font-family:inherit;">删</button>
          <span style="color:#666;font-size:12px;">›</span>
        </div>
      `;
      row.addEventListener('click', (e) => { if (e.target.classList.contains('ysf-cl-del')) return; openClDetail(group); });
      row.querySelector('.ysf-cl-del').addEventListener('click', async (e) => {
        e.stopPropagation();
        const gid = e.currentTarget.dataset.gid;
        const gIdx = ysfCharLettersData.findIndex(g => g.id === gid);
        if (gIdx < 0) return;
        const group = ysfCharLettersData[gIdx];
        ysfCharLettersData.splice(gIdx, 1);
        // 清理双方 memorySeen
        [allChars.find(c=>c.id===group.fromId), allChars.find(c=>c.id===group.toId)].forEach(c => {
          if (!c?.memorySeen) return;
          const mi = c.memorySeen.findIndex(m => m._clGroupId === gid);
          if (mi >= 0) c.memorySeen.splice(mi, 1);
          if (c._isScenarioChar) { window._xlyMemorySeen = c.memorySeen; saveProgress({ xlyMemorySeen: c.memorySeen }); }
          else { saveProgress({ characters: selectedCharsData }); }
        });
        renderClList();
      });
      listWrap.appendChild(row);
    });
  }

  // 打开详情弹层
  function openClDetail(group) {
    const old = document.getElementById('ysf-cl-detail');
    if (old) old.remove();
    const panel = document.createElement('div');
    panel.id = 'ysf-cl-detail';
    panel.style.cssText = 'position:fixed;inset:0;z-index:199999;background:url(\'https://www.imgfox.cn/apis/uploads/20260818/cd2a4b22f1ec4748/IMG_9643.jpeg\') center/cover no-repeat;display:flex;flex-direction:column;';

    // 顶栏
    const clHeader = document.createElement('div');
    clHeader.style.cssText = `
      padding:max(var(--safe-top,44px),44px) 16px 0;
      flex-shrink:0;
      background:transparent;
    `;
    clHeader.innerHTML = `
      <div style="display:flex;justify-content:space-between;align-items:center;padding-bottom:12px;border-bottom:1px solid rgba(201,163,106,0.25);">
        <button id="ysf-cl-detail-back" style="background:transparent;border:none;color:rgba(201,163,106,0.7);font-size:16px;font-family:inherit;padding:8px 4px;">‹ 返回</button>
        <div style="color:var(--primary-color);font-size:14px;font-weight:bold;letter-spacing:2px;font-family:'STZhongsong','STSong',serif;
          background:linear-gradient(to bottom,#ffe9b8,#c9a36a);-webkit-background-clip:text;-webkit-text-fill-color:transparent;">${group.fromName} ↔ ${group.toName}</div>
        <div style="width:48px;"></div>
      </div>
    `;
    panel.appendChild(clHeader);

    // 外层滚动容器
    const clOuter = document.createElement('div');
    clOuter.style.cssText = `
      flex:1; overflow-y:auto;
      background:transparent;
      display:flex; flex-direction:column; align-items:center;
      gap:20px;
      padding:28px 20px calc(var(--safe-bottom,24px)+28px);
    `;

    const clPaperH = Math.round(window.innerHeight * 0.72);
    const clSidePad = 44;

    group.letters.forEach((ltr, lIdx) => {
      const isFrom = ltr.dir === 'from';
      const senderName = isFrom ? group.fromName : group.toName;
      const receiverName = isFrom ? group.toName : group.fromName;

      // 每封信：高度固定，宽度由文字撑开
      const card = document.createElement('div');
      card.style.cssText = `
        position:relative;
        height:${clPaperH}px;
        min-width:${clSidePad * 2 + 60}px;
        display:inline-flex;
        flex-direction:column;
        box-shadow:0 6px 32px rgba(0,0,0,0.75), 0 0 0 1px rgba(160,110,50,0.35);
        border-radius:2px;
        overflow:visible;
      `;

      // 第1层：底图（absolute 铺满容器）
      const bgImg = document.createElement('img');
      bgImg.src = 'https://www.imgfox.cn/apis/uploads/20260822/e5272a025d334c40/IMG_9820.png';
      bgImg.style.cssText = `position:absolute;inset:0;width:100%;height:100%;object-fit:fill;z-index:1;pointer-events:none;border-radius:2px;`;
      card.appendChild(bgImg);

      // 发件人标注
      const meta = document.createElement('div');
      meta.style.cssText = `
        position:relative; z-index:3;
        margin:18px ${clSidePad}px 0;
        display:flex; justify-content:space-between; align-items:center;
        padding-bottom:6px;
        border-bottom:1px solid rgba(140,90,30,0.3);
        flex-shrink:0;
      `;
      meta.innerHTML = `
        <span style="color:#6b3e12;font-size:11px;font-weight:bold;letter-spacing:2px;font-family:'STZhongsong','STSong',serif;">${senderName} 致 ${receiverName}</span>
        <span style="color:#9a6e2a;font-size:10px;">${ltr.time}</span>
      `;
      card.appendChild(meta);

      // 第2层：正文（正常流撑宽）
      const textEl = document.createElement('div');
      textEl.className = 'ysf-letter-text';
      textEl.style.cssText = `
        position:relative; z-index:2;
        flex:1;
        padding:12px ${clSidePad}px 56px;
        writing-mode:vertical-rl;
        text-orientation:upright;
        color:#2c1a0e;
        font-size:14px;
        line-height:1.8;
        letter-spacing:2px;
        font-family:${window._ysfLetterFont || "'Ma Shan Zheng','STKaiti','KaiTi','楷体',cursive,serif"};
        white-space:pre-wrap;
        height:100%;
        box-sizing:border-box;
      `;
      textEl.textContent = ltr.content;
      card.appendChild(textEl);

      clOuter.appendChild(card);
    });

    // ── 底部操作栏：令TA再回一封 ──
    const clBottom = document.createElement('div');
    clBottom.style.cssText = 'padding:10px 16px calc(var(--safe-bottom,24px)+10px);border-top:1px solid rgba(201,163,106,0.25);display:flex;gap:10px;flex-shrink:0;background:rgba(0,0,0,0.15);backdrop-filter:blur(12px);-webkit-backdrop-filter:blur(12px);';
    const clReplyBtn = document.createElement('button');
    clReplyBtn.style.cssText = 'flex:1;background:rgba(201,163,106,0.15);border:1px solid var(--primary-color);color:var(--primary-color);padding:11px;border-radius:10px;font-size:14px;font-weight:bold;letter-spacing:2px;font-family:"STZhongsong","STSong",serif;';
    clReplyBtn.textContent = '✦ 截获下一封往来';
    clBottom.appendChild(clReplyBtn);
    panel.appendChild(clBottom);

    // 截获下一封
    clReplyBtn.addEventListener('click', async () => {
      clReplyBtn.textContent = '截获中…'; clReplyBtn.disabled = true;
      // 确定下一封的发信方向（最后一封是谁发的，下一封就换另一人）
      const lastLtr = group.letters[group.letters.length - 1];
      const nextSenderChar = lastLtr.dir === 'from'
        ? allChars.find(c => c.id === group.toId)
        : allChars.find(c => c.id === group.fromId);
      const nextReceiverChar = lastLtr.dir === 'from'
        ? allChars.find(c => c.id === group.fromId)
        : allChars.find(c => c.id === group.toId);
      if (!nextSenderChar || !nextReceiverChar) { api.ui.toast('找不到角色信息'); clReplyBtn.textContent = '✦ 截获下一封往来'; clReplyBtn.disabled = false; return; }

      const ctxSender = buildLetterCharContext(nextSenderChar);
      const ctxReceiver = buildLetterCharContext(nextReceiverChar);
      const timeStr = ctxSender.timeStr;
      const relKey = `${nextSenderChar.name}->${nextReceiverChar.name}`;
      const relText = window._relationData?.[relKey]?.text || '无特别记录';
      // 上一封信（对方来信）
      const prevContent = lastLtr.content;

      const prompt = `你是古代宫廷角色「${nextSenderChar.name}」（${nextSenderChar.ancientRole||nextSenderChar.assignedRank||'故人'}）。当前时间：${timeStr}。
【全局世界书】：${ctxSender.wbText}
【你的完整人设】：${ctxSender.desc}${ctxSender.charWb}
【TA了解的】：${ctxSender.knownText}
【TA看到的】：${ctxSender.seenText}
【起居注】：${ctxSender.recText}
【你对「${nextReceiverChar.name}」的看法】：${relText}

你收到了「${nextReceiverChar.name}」写给你的信：
「${prevContent}」

请以「${nextSenderChar.name}」的口吻，写一封回信给「${nextReceiverChar.name}」。
要求：古风文言，约100~150字，符合人设，结合来信内容作出回应，体现二人关系。只输出正文。`;

      try {
        const res = await api.ai.chat({ messages:[{role:'user',content:prompt}] });
        const newContent = (typeof res==='string'?res:(res?.content??res?.text??'')).trim();
        const newLtr = { dir: lastLtr.dir === 'from' ? 'to' : 'from', content: newContent, time: timeStr };
        group.letters.push(newLtr);

        // 存档 & memorySeen
        await saveProgress({ ysfCharLettersData });
        const senderMemText = `【故人往来·${nextSenderChar.name}致${nextReceiverChar.name}（续函）】${newContent}`;
        if (!nextSenderChar.memorySeen) nextSenderChar.memorySeen = [];
        nextSenderChar.memorySeen.unshift({ time: timeStr, text: senderMemText, _clGroupId: group.id });
        if (nextSenderChar._isScenarioChar) { window._xlyMemorySeen = nextSenderChar.memorySeen; await saveProgress({ xlyMemorySeen: nextSenderChar.memorySeen }); }
        else { await saveProgress({ characters: selectedCharsData }); }
        checkAndTriggerReflect(nextSenderChar);

        // 刷新弹层：关闭旧的，重新打开（group.letters 已更新）
        panel.remove();
        openClDetail(group);
        api.ui.toast(`已截获 ${nextSenderChar.name} 的续函`);
      } catch(e) { api.ui.toast('截获失败：'+(e?.message||'')); }
      finally { clReplyBtn.textContent = '✦ 截获下一封往来'; clReplyBtn.disabled = false; }
    });

    panel.appendChild(clOuter);
    document.body.appendChild(panel);
    panel.querySelector('#ysf-cl-detail-back').onclick = () => panel.remove();
  }

  renderClList();

  // 生成故人往来函件
  document.getElementById('ysf-cl-gen').addEventListener('click', async () => {
    const fromId = document.getElementById('ysf-cl-from')?.value;
    const toId = document.getElementById('ysf-cl-to')?.value;
    const fromChar = allChars.find(c => c.id === fromId);
    const toChar = allChars.find(c => c.id === toId);
    if (!fromChar || !toChar || fromChar.id === toChar.id) { api.ui.toast('请选择不同的两位故人'); return; }

    const btn = document.getElementById('ysf-cl-gen');
    btn.innerText = '截获中…'; btn.disabled = true;

    const ctxFrom = buildLetterCharContext(fromChar);
    const ctxTo = buildLetterCharContext(toChar);
    const timeStr = ctxFrom.timeStr;

    // 双方关系
    const relFromTo = window._relationData?.[`${fromChar.name}->${toChar.name}`]?.text || '无特别记录';
    const relToFrom = window._relationData?.[`${toChar.name}->${fromChar.name}`]?.text || '无特别记录';

    // Prompt：生成发信
    const promptFrom = `你是古代宫廷角色「${fromChar.name}」（${fromChar.ancientRole||fromChar.assignedRank||'故人'}）。当前时间：${timeStr}。
【全局世界书】：${ctxFrom.wbText}
【你的完整人设】：${ctxFrom.desc}${ctxFrom.charWb}
【TA了解的】：${ctxFrom.knownText}
【TA看到的】：${ctxFrom.seenText}
【起居注】：${ctxFrom.recText}
【你对「${toChar.name}」的看法】：${relFromTo}

【收信人「${toChar.name}」的基本情况】：
身份：${toChar.ancientRole||toChar.assignedRank||'故人'}
人设摘要：${ctxTo.desc.slice(0,300)}

请以「${fromChar.name}」的口吻，写一封寄给「${toChar.name}」的私信。
要求：古风文言，约100~150字，符合人设与当前处境，结合近期经历，体现二人之间的真实关系与情感。只输出正文。`;

    try {
      const res1 = await api.ai.chat({ messages:[{role:'user',content:promptFrom}] });
      const contentFrom = (typeof res1==='string'?res1:(res1?.content??res1?.text??'')).trim();

      // Prompt：生成回信
      const promptTo = `你是古代宫廷角色「${toChar.name}」（${toChar.ancientRole||toChar.assignedRank||'故人'}）。当前时间：${timeStr}。
【全局世界书】：${ctxTo.wbText}
【你的完整人设】：${ctxTo.desc}${ctxTo.charWb}
【TA了解的】：${ctxTo.knownText}
【TA看到的】：${ctxTo.seenText}
【起居注】：${ctxTo.recText}
【你对「${fromChar.name}」的看法】：${relToFrom}

你收到了「${fromChar.name}」写给你的信：
「${contentFrom}」

请以「${toChar.name}」的口吻，写一封回信给「${fromChar.name}」。
要求：古风文言，约100~150字，符合人设，结合来信内容作出回应，体现二人关系。只输出正文。`;

      const res2 = await api.ai.chat({ messages:[{role:'user',content:promptTo}] });
      const contentTo = (typeof res2==='string'?res2:(res2?.content??res2?.text??'')).trim();

      // 存入记录
      const groupId = 'clg_' + Date.now();
      const group = {
        id: groupId,
        fromId: fromChar.id, fromName: fromChar.name,
        toId: toChar.id, toName: toChar.name,
        letters: [
          { dir: 'from', content: contentFrom, time: timeStr },
          { dir: 'to', content: contentTo, time: timeStr }
        ]
      };
      ysfCharLettersData.unshift(group);
      await saveProgress({ ysfCharLettersData });

      // 写入双方 memorySeen
      const memTextFrom = `【故人往来·${fromChar.name}致${toChar.name}】${contentFrom}`;
      const memTextTo = `【故人往来·${toChar.name}致${fromChar.name}】${contentTo}`;

      if (!fromChar.memorySeen) fromChar.memorySeen = [];
      fromChar.memorySeen.unshift({ time: timeStr, text: memTextFrom, _clGroupId: groupId });
      if (fromChar._isScenarioChar) { window._xlyMemorySeen = fromChar.memorySeen; await saveProgress({ xlyMemorySeen: fromChar.memorySeen }); }
      else { await saveProgress({ characters: selectedCharsData }); }
      checkAndTriggerReflect(fromChar);

      if (!toChar.memorySeen) toChar.memorySeen = [];
      toChar.memorySeen.unshift({ time: timeStr, text: memTextTo, _clGroupId: groupId });
      if (toChar._isScenarioChar) { window._xlyMemorySeen = toChar.memorySeen; await saveProgress({ xlyMemorySeen: toChar.memorySeen }); }
      else { await saveProgress({ characters: selectedCharsData }); }
      checkAndTriggerReflect(toChar);

      renderClList();
      api.ui.toast(`已截获 ${fromChar.name} 与 ${toChar.name} 的往来函件`);
    } catch(e) { api.ui.toast('生成失败：'+(e?.message||'')); }
    finally { btn.innerText = '✦ 截获往来函件'; btn.disabled = false; }
  });
}

// ── Tab2 密探截获 ──
let ysfSpyData = []; // [{ id, charId, charName, toName, content, time }]（已持久化）
// char间往来数据声明提前（已持久化）
// ysfCharLettersData 在上方已声明

function renderSpyLetters(container) {
  const now = Date.now();
  const hasCheat = cheatExpireTime > now;

  if (!hasCheat) {
    container.innerHTML = `
      <div style="display:flex; flex-direction:column; align-items:center; gap:20px; padding:40px 20px; text-align:center;">
        <div style="font-size:48px;">🔒</div>
        <div style="color:var(--primary-color); font-size:18px; font-weight:bold; letter-spacing:4px; font-family:'STZhongsong','STSong',serif;">帝王特权</div>
        <div style="color:#aaa; font-size:13px; line-height:1.8; letter-spacing:1px;">密探截获功能需要开通<br>「金手指」才可使用。<br><br>开通后可偷看各位故人<br>写给旁人的未寄出私信。</div>
        <button id="ysf-btn-open-cheat" style="background:linear-gradient(135deg,#c9a36a,#8a6d3b); border:2px solid rgba(255,233,184,0.4); color:#1a1208; padding:13px 32px; border-radius:12px; font-size:15px; font-weight:bold; letter-spacing:4px; font-family:'STZhongsong','STSong',serif; box-shadow:0 4px 16px rgba(201,163,106,0.3);">
          ✦ 开通金手指
        </button>
      </div>
    `;
    document.getElementById('ysf-btn-open-cheat')?.addEventListener('click', () => openCheatMenu());
    return;
  }

  const allChars = [...selectedCharsData, XLY_CHAR].filter(c => c.name && !(typeof isCharacterUnavailableForActivity === 'function' && isCharacterUnavailableForActivity(c)));
  const charOptHtml = allChars.map(c => `<option value="${c.id}">${c.name}</option>`).join('');
  // 收信人选项：你（User）+ 所有char + 固定选项
  const toOptHtml = `
    <option value="">随机（东厂自行判断）</option>
    <option value="__user__">你（皇帝）</option>
    ${allChars.map(c => `<option value="${c.name}">${c.name}</option>`).join('')}
    <option value="家人">家中亲眷</option>
    <option value="旧友">宫外旧友</option>
  `;

  // 操作区（静态HTML）
  const topDiv = document.createElement('div');
  topDiv.innerHTML = `
    <div style="color:#aaa; font-size:12px; line-height:1.7; background:rgba(201,163,106,0.06); border:1px solid rgba(201,163,106,0.2); border-radius:8px; padding:10px 12px; margin-bottom:10px;">
      密探截获：令东厂探子截获某位故人因某种原因未能寄出的私信，一窥其心事。
    </div>
    <div style="display:flex; flex-direction:column; gap:6px; margin-bottom:8px;">
      <div style="color:var(--primary-color); font-size:12px; letter-spacing:2px;">截获对象</div>
      <select id="ysf-spy-char-sel" style="width:100%; background:rgba(0,0,0,0.5); border:1px solid rgba(201,163,106,0.4); color:#eaeaea; padding:10px; border-radius:8px; font-family:inherit; font-size:14px;">
        ${charOptHtml}
      </select>
    </div>
    <div style="display:flex; flex-direction:column; gap:6px; margin-bottom:10px;">
      <div style="color:var(--primary-color); font-size:12px; letter-spacing:2px;">写给何人（可留空随机）</div>
      <select id="ysf-spy-to-sel" style="width:100%; background:rgba(0,0,0,0.5); border:1px solid rgba(201,163,106,0.4); color:#eaeaea; padding:10px; border-radius:8px; font-family:inherit; font-size:14px;">
        ${toOptHtml}
      </select>
    </div>
    <button id="ysf-btn-spy" style="width:100%; background:rgba(201,163,106,0.15); border:1px solid var(--primary-color); color:var(--primary-color); padding:12px; border-radius:10px; font-size:14px; font-weight:bold; letter-spacing:3px; font-family:'STZhongsong','STSong',serif; margin-bottom:12px;">
      🕵️ 令东厂截获密信
    </button>
  `;
  container.appendChild(topDiv);

  // 历史记录列表容器
  const resultEl = document.createElement('div');
  resultEl.id = 'ysf-spy-result';
  resultEl.style.cssText = 'display:flex; flex-direction:column; gap:10px;';
  container.appendChild(resultEl);

  // 渲染历史记录
  function renderSpyList() {
    resultEl.innerHTML = '';
    if (ysfSpyData.length === 0) {
      resultEl.innerHTML = '<div style="color:#555; text-align:center; padding:16px; font-size:13px; letter-spacing:2px;">尚无截获记录</div>';
      return;
    }
    ysfSpyData.forEach(rec => {
      const toLabel = rec.toName === '__user__' ? '（致：你）' : rec.toName ? `（致：${rec.toName}）` : '（收信人不明）';
      const card = document.createElement('div');
      card.style.cssText = 'background:rgba(30,20,10,0.7); border:1px solid rgba(201,163,106,0.5); border-radius:10px; padding:16px; display:flex; flex-direction:column; gap:10px; position:relative; cursor:pointer;';
      const previewSnippet = rec.content.replace(/\n/g,' ').slice(0,30)+(rec.content.length>30?'…':'');
      card.innerHTML = `
        <div style="display:flex; justify-content:space-between; align-items:center;">
          <span style="color:var(--primary-color); font-size:13px; font-weight:bold; font-family:'STZhongsong','STSong',serif;">🕵️ 截获 · ${rec.charName} ${toLabel}</span>
          <div style="display:flex; align-items:center; gap:8px;">
            <span style="color:#555; font-size:11px;">${rec.time}</span>
            <button class="spy-del-btn" data-id="${rec.id}" style="background:transparent;border:1px solid rgba(139,32,32,0.5);color:#c96a6a;font-size:11px;padding:2px 7px;border-radius:4px;font-family:inherit;cursor:pointer;">删</button>
          </div>
        </div>
        <div style="color:#ddd; font-size:13px; line-height:1.8; letter-spacing:1px; font-family:'STSong','Noto Serif CJK SC',serif; white-space:nowrap; overflow:hidden; text-overflow:ellipsis;">${previewSnippet}</div>
        <div style="color:#888; font-size:11px; border-top:1px solid rgba(201,163,106,0.1); padding-top:6px;">点击阅览全文 › — 此信由东厂密探截获，${rec.charName}并不知情 —</div>
      `;
      // 点击弹出信纸详情
      card.addEventListener('click', (e) => {
        if (e.target.classList.contains('spy-del-btn')) return;
        // 打开信纸弹层
        const spyPanel = document.createElement('div');
        spyPanel.style.cssText = 'position:fixed;inset:0;z-index:199999;background:url(\'https://www.imgfox.cn/apis/uploads/20260818/cd2a4b22f1ec4748/IMG_9643.jpeg\') center/cover no-repeat;display:flex;flex-direction:column;';
        const spyHeader = document.createElement('div');
        spyHeader.style.cssText = 'padding:max(var(--safe-top,44px),44px) 16px 0;flex-shrink:0;background:transparent;';
        spyHeader.innerHTML = `<div style="display:flex;justify-content:space-between;align-items:center;padding-bottom:12px;border-bottom:1px solid rgba(201,163,106,0.25);">
          <button id="spy-detail-back" style="background:transparent;border:none;color:rgba(201,163,106,0.7);font-size:16px;font-family:inherit;padding:8px 4px;">‹ 返回</button>
          <div style="color:var(--primary-color);font-size:14px;font-weight:bold;letter-spacing:2px;font-family:'STZhongsong','STSong',serif;background:linear-gradient(to bottom,#ffe9b8,#c9a36a);-webkit-background-clip:text;-webkit-text-fill-color:transparent;">🕵️ 截获 · ${rec.charName} ${toLabel}</div>
          <div style="width:48px;"></div>
        </div>`;
        spyPanel.appendChild(spyHeader);
        const spyOuter = document.createElement('div');
        spyOuter.style.cssText = `flex:1;overflow-y:auto;background:transparent;display:flex;justify-content:center;align-items:flex-start;padding:28px 20px calc(var(--safe-bottom,24px)+28px);`;
        const spyPaperH = Math.round(window.innerHeight * 0.72);
        const spySidePad = 44;
        const spyWrap = document.createElement('div');
        spyWrap.style.cssText = `position:relative;height:${spyPaperH}px;min-width:${spySidePad*2+60}px;display:inline-flex;box-shadow:0 6px 32px rgba(0,0,0,0.75),0 0 0 1px rgba(160,110,50,0.35);border-radius:2px;overflow:visible;`;
        const spyBgImg = document.createElement('img');
        spyBgImg.src = 'https://www.imgfox.cn/apis/uploads/20260822/e5272a025d334c40/IMG_9820.png';
        spyBgImg.style.cssText = `position:absolute;inset:0;width:100%;height:100%;object-fit:fill;z-index:1;pointer-events:none;border-radius:2px;`;
        spyWrap.appendChild(spyBgImg);
        const spyText = document.createElement('div');
        spyText.className = 'ysf-letter-text';
        spyText.style.cssText = `position:relative;z-index:2;padding:64px ${spySidePad}px 60px;writing-mode:vertical-rl;text-orientation:upright;color:#2c1a0e;font-size:15px;line-height:1.8;letter-spacing:2px;font-family:${window._ysfLetterFont||"'Ma Shan Zheng','STKaiti','KaiTi','楷体',cursive,serif"};white-space:pre-wrap;height:100%;box-sizing:border-box;`;
        spyText.textContent = rec.content;
        spyWrap.appendChild(spyText);
        spyOuter.appendChild(spyWrap);
        spyPanel.appendChild(spyOuter);
        document.body.appendChild(spyPanel);
        spyPanel.querySelector('#spy-detail-back').onclick = () => spyPanel.remove();
      });
      // 删除按钮：同步清理 memorySeen
      card.querySelector('.spy-del-btn').addEventListener('click', async (e) => {
        e.stopPropagation();
        const sid = e.currentTarget.dataset.id;
        const idx = ysfSpyData.findIndex(r => r.id === sid);
        if (idx < 0) return;
        const spyRec = ysfSpyData[idx];
        ysfSpyData.splice(idx, 1);

        // 从 截获者 (char) 的 memorySeen 中删
        const fromChar = allChars.find(c => c.id === spyRec.charId);
        if (fromChar?.memorySeen) {
          const mi = fromChar.memorySeen.findIndex(m => m._spyId === sid);
          if (mi >= 0) fromChar.memorySeen.splice(mi, 1);
          if (fromChar._isScenarioChar) { window._xlyMemorySeen = fromChar.memorySeen; await saveProgress({ xlyMemorySeen: fromChar.memorySeen }); }
          else { await saveProgress({ characters: selectedCharsData }); }
        }
        // 密探截获是未寄出的信，收信人不知情，memorySeen 里没有对应记录，无需清理
        renderSpyList();
      });
      resultEl.appendChild(card);
    });
  }

  renderSpyList();

  // 截获按钮
  document.getElementById('ysf-btn-spy')?.addEventListener('click', async () => {
    const charId = document.getElementById('ysf-spy-char-sel')?.value;
    const char = allChars.find(c => c.id === charId);
    if (!char) return;
    const toValue = document.getElementById('ysf-spy-to-sel')?.value || '';
    const btn = document.getElementById('ysf-btn-spy');
    btn.innerText = '密探探查中…'; btn.disabled = true;

    const ctxSpy = buildLetterCharContext(char);

    // 收信人描述（用于 prompt）
    let toDisplayName = '';
    let toPromptDesc = '';
    if (toValue === '__user__') {
      toDisplayName = '__user__';
      toPromptDesc = '写给皇帝（你的主君）';
    } else if (toValue) {
      toDisplayName = toValue;
      toPromptDesc = `写给「${toValue}」`;
    } else {
      toDisplayName = '';
      toPromptDesc = '写给某位心中挂念之人（东厂未能确认收信人）';
    }

    // 若收信人是另一个char，获取其人设补充进prompt
    let toCharDesc = '';
    if (toValue && toValue !== '__user__') {
      const toChar = allChars.find(c => c.name === toValue);
      if (toChar) {
        const toCtx = buildLetterCharContext(toChar);
        toCharDesc = `\n【收信人「${toValue}」的基本情况】：\n身份：${toChar.ancientRole || toChar.assignedRank || '故人'}\n人设摘要：${toCtx.desc.slice(0, 300)}\n与写信人的关系：${ctxSpy.relText.split('\n').find(l => l.startsWith(`对${toValue}`)) || '无特别记录'}`;
      }
    }

    const prompt = `你是古代宫廷角色「${char.name}」（${char.ancientRole || char.assignedRank || '故人'}）。当前时间：${ctxSpy.timeStr}。

【全局世界书】：
${ctxSpy.wbText}
【你的完整人设】：
${ctxSpy.desc}${ctxSpy.charWb}

【位份与居所】：
位份：${char.assignedRank || '无'} | 居所：${char.assignedPalace || '无'}

【TA了解的（位份体系、关系图谱等你所知晓的事）】：
${ctxSpy.knownText}

【TA看到的（你经历过的事）】：
${ctxSpy.seenText}

【起居注（你近期的行迹）】：
${ctxSpy.recText}

【你对他人的看法（关系图谱）】：
${ctxSpy.relText || '无特别记录'}
${toCharDesc}

【背景设定】：
你独处时，提笔写下了一封${toPromptDesc}的私信。
这封信因某种原因最终没有寄出——可能是写好后又犹豫了，可能是被什么事打断，可能是觉得有些话终究不能说出口，也可能是话说了一半又压了回去。
信就这样搁在案头，被东厂探子悄悄截获。

【铁律要求】：
1. 古风文言，情感真实，字数约120~180字；
2. 内容必须结合你的完整人设、近期经历与记忆，有具体所指，而非泛泛而谈；
3. 可以是倾诉秘密、表达真实情感、吐露心中怨恨或渴望、诉说对某事或某人的真实看法、说出平时不敢当面说的话等；
4. 口吻比平时更真实、更脆弱或更大胆，因为这是不打算寄出的私信；
5. 【仅输出信件正文】，不要任何标题、解释或前言。`;

    try {
      const res = await api.ai.chat({ messages: [{ role: 'user', content: prompt }] });
      const content = (typeof res === 'string' ? res : (res?.content ?? res?.text ?? '')).trim();
      if (!content) return;

      const spyId = 'spy_' + Date.now();
      const timeStr = ctxSpy.timeStr;

      // 存入截获记录
      ysfSpyData.unshift({ id: spyId, charId: char.id, charName: char.name, toName: toValue, content, time: timeStr });
      await saveProgress({ ysfSpyData });

      // 写入写信者（char）的 memorySeen
      const fromMemText = toValue === '__user__'
        ? `【截获密信·${char.name}致皇帝（未寄出）】${content}`
        : toValue
          ? `【截获密信·${char.name}致${toValue}（未寄出）】${content}`
          : `【截获密信·${char.name}（收信人不明，未寄出）】${content}`;
      if (!char.memorySeen) char.memorySeen = [];
      char.memorySeen.unshift({ time: timeStr, text: fromMemText, _spyId: spyId });
      if (char._isScenarioChar) { window._xlyMemorySeen = char.memorySeen; await saveProgress({ xlyMemorySeen: char.memorySeen }); }
      else { await saveProgress({ characters: selectedCharsData }); }
      checkAndTriggerReflect(char);

      // 密探截获 = 未寄出的信，收信人不知情，不写入对方的 memorySeen
      renderSpyList();
    } catch(e) { api.ui.toast('截获失败：' + (e?.message || '')); }
    finally { btn.innerText = '🕵️ 令东厂截获密信'; btn.disabled = false; }
  });
}

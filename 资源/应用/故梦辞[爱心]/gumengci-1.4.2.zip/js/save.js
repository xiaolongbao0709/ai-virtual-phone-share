
const api = window.AiPhone;

// ===== State =====
let currentMapDataUrl = null;
let currentSaveId = null;
window._gameProgressFinalized = false;
const TREASURY_INITIAL_SILVER = 50000000;
let treasurySilver = TREASURY_INITIAL_SILVER;
let treasureInventory = {};
let customTreasureItems = [];

// ===== 人物惩戒状态（禁足 / 冷宫） =====
const disciplineExpirySaves = new WeakSet();
function refreshCharacterDiscipline(char) {
  if (!char?.disciplineState) return null;
  const state = char.disciplineState;
  if (state.type === 'confinement' && Number(state.endAt) > 0 && Date.now() >= Number(state.endAt)) {
    char.disciplineState = null;
    if (!disciplineExpirySaves.has(char)) {
      disciplineExpirySaves.add(char);
      Promise.resolve(saveProgress({ characters: typeof selectedCharsData !== 'undefined' ? selectedCharsData : [] }))
        .finally(() => disciplineExpirySaves.delete(char));
    }
    return null;
  }
  return state;
}

function isCharacterConfined(char) {
  return refreshCharacterDiscipline(char)?.type === 'confinement';
}

function isCharacterInColdPalace(char) {
  return refreshCharacterDiscipline(char)?.type === 'cold_palace' || String(char?.assignedPalace || '').startsWith('冷宫');
}

function isCharacterUnavailableForActivity(char) {
  return Boolean(isCharacterConfined(char) || isCharacterInColdPalace(char));
}

function formatDisciplineRemaining(endAt) {
  const ms = Math.max(0, Number(endAt) - Date.now());
  const days = Math.floor(ms / 86400000);
  const hours = Math.floor((ms % 86400000) / 3600000);
  const minutes = Math.max(1, Math.ceil((ms % 3600000) / 60000));
  if (days) return `${days}天${hours}时`;
  if (hours) return `${hours}时${minutes}分`;
  return `${minutes}分`;
}

function getCharacterDisciplineBadge(char) {
  const state = refreshCharacterDiscipline(char);
  if (state?.type === 'confinement') return `禁足中·余${formatDisciplineRemaining(state.endAt)}`;
  if (state?.type === 'cold_palace' || String(char?.assignedPalace || '').startsWith('冷宫')) return '冷宫中';
  return '';
}

async function notifyCharacterUnavailable(char) {
  const state = refreshCharacterDiscipline(char);
  if (state?.type === 'confinement') {
    await api.ui.confirm({ title: `${char.name}正在禁足`, message: `尚余${formatDisciplineRemaining(state.endAt)}。请先前往“养心殿—操作—管理后宫—解除禁足”，或亲自到其住所探望。` });
    return true;
  }
  if (state?.type === 'cold_palace' || String(char?.assignedPalace || '').startsWith('冷宫')) {
    await api.ui.confirm({ title: `${char.name}身在冷宫`, message: '冷宫人物不能被召见、翻牌、随机偶遇或参加宫廷活动。请前往冷宫探望，或在“管理后宫—恢复位份”中将其接回。' });
    return true;
  }
  return false;
}

let disciplineExpiryTimer = null;
function startDisciplineExpiryTimer() {
  if (disciplineExpiryTimer) clearInterval(disciplineExpiryTimer);
  disciplineExpiryTimer = setInterval(async () => {
    if (typeof selectedCharsData === 'undefined') return;
    const restored = selectedCharsData.filter(char => char?.disciplineState?.type === 'confinement' && Number(char.disciplineState.endAt) > 0 && Date.now() >= Number(char.disciplineState.endAt));
    if (!restored.length) return;
    restored.forEach(char => { char.disciplineState = null; });
    await saveProgress({ characters:selectedCharsData });
    api.ui.toast(`${restored.map(char => char.name).join('、')}禁足期满，已恢复正常行动`);
    if (typeof currentDetailPalaceName !== 'undefined' && currentDetailPalaceName && document.getElementById('view-palace-detail')?.classList.contains('active')) enterPalaceDetailView(currentDetailPalaceName);
  }, 30000);
}

// 角色与 NPC 共用的立绘判定。NPC 默认没有立绘；只有实际上传/保存了图片才显示。
function getCharacterPortraitUrl(char) {
  if (!char) return '';
  let value = char.customAvatar || char.avatar || '';
  // 部分剧情会从奏折/朝臣资料生成NPC临时引用；若临时对象未携带图片，
  // 按id或姓名回查NPC存档原对象，避免“明明设置过立绘，剧情却显示不出来”。
  if (!value && (char._isGameNpc || char.npcType || String(char.id || '').includes('npc'))) {
    const storedNpc = (window._courtNpcData || []).find(item =>
      (char.id && item.id === char.id) || (char.name && item.name === char.name)
    );
    value = storedNpc?.customAvatar || storedNpc?.avatar || '';
  }
  return typeof value === 'string' ? value.trim() : '';
}

function hasCharacterPortrait(char) {
  return Boolean(getCharacterPortraitUrl(char));
}

function formatSilver(amount) {
  return Math.max(0, Math.floor(Number(amount) || 0)).toLocaleString('zh-CN');
}

function getAllTreasuryKnowledgeCharacters() {
  const all = [...(typeof selectedCharsData !== 'undefined' ? selectedCharsData : [])];
  if (typeof XLY_CHAR !== 'undefined' && XLY_CHAR) all.push(XLY_CHAR);
  all.push(...(window._courtNpcData || []));
  const seen = new Set();
  return all.filter(char => {
    const key = char?.id || char?.name;
    if (!key || seen.has(key)) return false;
    seen.add(key);
    return true;
  });
}

// 将“众闻”同时写入所有人物的「TA了解的」与其下方「起居注（TA的记事）」。
// 只做补录和去重，不删除任何既有的「TA看到的」或旧记事，兼容历史存档。
function inferPublicNewsOwner(text) {
  const people = getAllTreasuryKnowledgeCharacters()
    .filter(char => char?.name)
    .sort((a, b) => String(b.name).length - String(a.name).length);
  return people.find(char => String(text || '').includes(char.name))?.name || '';
}

function syncPublicNewsToCharacterRecords(text, time, tags = [], eventOwner = '') {
  const newsText = String(text || '').trim();
  if (!newsText) return false;
  let changed = false;
  const ownerName = eventOwner || inferPublicNewsOwner(newsText) || '宫中众闻';
  const sharedId = getAllTreasuryKnowledgeCharacters()
    .flatMap(char => Array.isArray(char.records) ? char.records : [])
    .find(item => String(item?.text || '') === newsText)?.id || generateId();
  getAllTreasuryKnowledgeCharacters().forEach(char => {
    if (!Array.isArray(char.memoryKnown)) char.memoryKnown = [];
    if (!char.memoryKnown.some(item => String(item?.text || item || '') === newsText)) {
      char.memoryKnown.push(newsText);
      changed = true;
    }
    if (!Array.isArray(char.records)) char.records = [];
    const existingRecord = char.records.find(item => String(item?.text || item || '') === newsText);
    if (!existingRecord) {
      char.records.unshift({
        id: sharedId,
        time: time || '众闻',
        text: newsText,
        owner: ownerName,
        eventOwner: ownerName,
        type: 'system',
        tags: [...tags]
      });
      changed = true;
    } else if (ownerName && (existingRecord.eventOwner !== ownerName || existingRecord.owner === char.name)) {
      existingRecord.eventOwner = ownerName;
      existingRecord.owner = ownerName;
      changed = true;
    }
  });
  if (typeof XLY_CHAR !== 'undefined') {
    window._xlyMemoryKnown = XLY_CHAR.memoryKnown;
    window._xlyRecords = XLY_CHAR.records;
  }
  return changed;
}

function applyTreasuryKnowledge() {
  const entry = `【国库银两】当前国库共有${formatSilver(treasurySilver)}两。涉及朝政、奏折、赏赐与开支时，必须以此实际余额为准。`;
  getAllTreasuryKnowledgeCharacters().forEach(char => {
    if (!Array.isArray(char.memoryKnown)) char.memoryKnown = [];
    char.memoryKnown = char.memoryKnown.filter(item => !String(typeof item === 'string' ? item : item?.text || '').startsWith('【国库银两】'));
    char.memoryKnown.push(entry);
  });
  if (typeof XLY_CHAR !== 'undefined') window._xlyMemoryKnown = XLY_CHAR.memoryKnown;
  if (typeof updateTreasuryHud === 'function') updateTreasuryHud();
}

async function saveTreasuryState(extra = {}) {
  applyTreasuryKnowledge();
  await saveProgress({
    treasurySilver,
    treasuryBaseVersion: 2,
    treasureInventory,
    customTreasureItems,
    characters: typeof selectedCharsData !== 'undefined' ? selectedCharsData : [],
    xlyMemoryKnown: typeof XLY_CHAR !== 'undefined' ? XLY_CHAR.memoryKnown : undefined,
    xlyTreasures: typeof XLY_CHAR !== 'undefined' ? XLY_CHAR.treasures : undefined,
    xlyPersonalSilver: typeof XLY_CHAR !== 'undefined' ? XLY_CHAR.personalSilver : undefined,
    courtNpcData: window._courtNpcData || [],
    ...extra
  });
}

// ===== 存档工具 =====
// 图片单独存一张 imgcache 表：{ key, data }
// 主存档只存 key（img_xxx），读档前先把 imgcache 全部加载到内存
const _imgCache = {}; // key → dataUrl（运行时内存）
let _imgCacheLoaded = false;

// 启动时预加载所有图片到内存
async function loadImgCache() {
  if (_imgCacheLoaded) return;
  try {
    const rows = await api.db.list('imgcache');
    rows.forEach(r => { if (r.key && r.data) _imgCache[r.key] = r.data; });
  } catch(e) {}
  _imgCacheLoaded = true;
}

// 把一张图存入 imgcache 表，返回 key
async function persistImage(dataUrl) {
  if (!dataUrl || !dataUrl.startsWith('data:')) return dataUrl;
  // 已缓存则直接返回已有 key
  for (const [k, v] of Object.entries(_imgCache)) {
    if (v === dataUrl) return k;
  }
  const key = 'img_' + Date.now() + '_' + Math.random().toString(36).slice(2, 7);
  _imgCache[key] = dataUrl;
  try {
    await api.db.create('imgcache', { key, data: dataUrl });
  } catch(e) {}
  return key;
}

// 递归把对象里所有 data: 大图替换为持久化 key（异步）
async function stripImages(obj, seen = new WeakSet()) {
  if (!obj || typeof obj !== 'object') return obj;
  if (seen.has(obj)) return undefined;
  seen.add(obj);
  if (Array.isArray(obj)) {
    const arr = [];
    for (const item of obj) {
      const next = await stripImages(item, seen);
      if (next !== undefined) arr.push(next);
    }
    seen.delete(obj);
    return arr;
  }
  const result = {};
  for (const [k, v] of Object.entries(obj)) {
    if (typeof v === 'string' && v.startsWith('data:') && v.length > 500) {
      result[k] = await persistImage(v);
    } else if (v && typeof v === 'object') {
      const next = await stripImages(v, seen);
      if (next !== undefined) result[k] = next;
    } else {
      result[k] = v;
    }
  }
  seen.delete(obj);
  return result;
}

// 递归把 key 还原为 dataUrl（同步，依赖内存缓存）
function restoreImages(obj) {
  if (!obj || typeof obj !== 'object') return obj;
  if (Array.isArray(obj)) return obj.map(restoreImages);
  const result = {};
  for (const [k, v] of Object.entries(obj)) {
    if (typeof v === 'string' && v.startsWith('img_')) {
      result[k] = _imgCache[v] || v; // 找不到就原样保留 key，不会崩溃
    } else if (v && typeof v === 'object') {
      result[k] = restoreImages(v);
    } else {
      result[k] = v;
    }
  }
  return result;
}

function makeCloudSavePayload(source) {
  const seen = new WeakMap();
  const largeStringKeys = /(?:dataurl|data_url|fontdata|font_data|fonturl|font_url|avatar|portrait|background|bg|image|img|icon|mapurl|url)$/i;
  function cleanValue(value, key = '') {
    if (typeof value === 'string') {
      if (value.startsWith('data:')) return '';
      if (value.startsWith('img_')) return '';
      if (value.length > 120000 && largeStringKeys.test(key)) return '';
      return value;
    }
    if (!value || typeof value !== 'object') return value;
    if (seen.has(value)) return seen.get(value);
    if (Array.isArray(value)) {
      const arr = [];
      seen.set(value, arr);
      value.forEach(item => arr.push(cleanValue(item, key)));
      return arr;
    }
    const result = {};
    seen.set(value, result);
    Object.entries(value).forEach(([childKey, childValue]) => {
      result[childKey] = cleanValue(childValue, childKey);
    });
    return result;
  }
  const payload = cleanValue(source || {});
  payload.cloudUploadLite = true;
  payload.cloudUploadLiteAt = new Date().toISOString();
  return payload;
}

async function saveProgress(patch) {
  try {
    await loadImgCache(); // 确保缓存已加载
    // 若玩家在游戏内删除了当前槽，下一次自动保存必须重新建立“完整进度”，
    // 不能只拿本次局部 patch 建一个缺字段的残档。
    let source = patch;
    if (!currentSaveId && window._gameProgressFinalized && typeof captureCurrentGameSnapshot === 'function') {
      const fullSnapshot = captureCurrentGameSnapshot({ palacesPlaced:true, isFinalized:true });
      source = { ...fullSnapshot, ...patch };
      if (Array.isArray(patch.characters) && Array.isArray(fullSnapshot.characters)) {
        source.characters = patch.characters.map(nextChar => ({
          ...(fullSnapshot.characters.find(oldChar => oldChar.id === nextChar.id) || {}),
          ...nextChar
        }));
      }
    }
    const stripped = await stripImages(source);
    if (currentSaveId) {
      const saves = await api.db.list("saves");
      const cur = saves.find(s => s.id === currentSaveId);
      if (cur) {
        if (Array.isArray(stripped.characters) && Array.isArray(cur.characters)) {
          stripped.characters = stripped.characters.map(nextChar => ({
            ...(cur.characters.find(oldChar => oldChar.id === nextChar.id) || {}),
            ...nextChar
          }));
        }
        await api.db.update("saves", currentSaveId, { ...cur, ...stripped, updatedAt: new Date().toISOString() });
        return;
      }
    }
    const newId = await api.db.create("saves", { ...stripped, saveName: patch.saveName || '新存档', updatedAt: new Date().toISOString() });
    currentSaveId = newId;
  } catch(e) { console.error("存档失败", e); }
}

// ===== 游戏内检查点 / 完整进度快照 =====
function captureCurrentGameSnapshot(baseSave = {}) {
  const xly = typeof XLY_CHAR !== 'undefined' ? XLY_CHAR : null;
  const allForReflect = [
    ...(typeof selectedCharsData !== 'undefined' ? selectedCharsData : []),
    xly,
    ...(window._courtNpcData || [])
  ].filter(Boolean);
  const reflectSeenCounts = {};
  allForReflect.forEach(char => {
    if (char.id && char._lastReflectSeenCount !== undefined) reflectSeenCounts[char.id] = char._lastReflectSeenCount;
  });

  return {
    mapUrl: typeof currentMapDataUrl !== 'undefined' ? currentMapDataUrl : null,
    palacesPlaced: baseSave.palacesPlaced !== undefined ? baseSave.palacesPlaced : true,
    isFinalized: baseSave.isFinalized !== undefined ? baseSave.isFinalized : true,
    palacesData: typeof placedPalacesData !== 'undefined' ? placedPalacesData : [],
    rankData: typeof rankData !== 'undefined' ? rankData : [],
    palaceDetails: typeof palaceDetails !== 'undefined' ? palaceDetails : {},
    userAncientDesc: typeof userAncientDesc !== 'undefined' ? userAncientDesc : '',
    characters: typeof selectedCharsData !== 'undefined' ? selectedCharsData : [],

    timeMode: typeof timeMode !== 'undefined' ? timeMode : 'sync',
    customTimeStr: typeof currentCustomTimeStr !== 'undefined' ? currentCustomTimeStr : '',
    globalWorldDesc: window.globalWorldDesc || '',
    globalRulesDesc: window.globalRulesDesc || '',
    globalPortalCfg: typeof globalPortalCfg !== 'undefined' ? globalPortalCfg : undefined,
    globalExtraBooks: Array.isArray(window._globalExtraBooks) ? window._globalExtraBooks : [],
    customPrompts: typeof customPrompts !== 'undefined' ? customPrompts : {},
    relationData: window._relationData || {},
    rgNodesPos: window._rgNodesPos || {},
    scenarioAvatarCfg: window._scenarioAvatarCfgCache || {},

    xlyMemorySeen: xly?.memorySeen || window._xlyMemorySeen || [],
    xlyMemoryKnown: xly?.memoryKnown || window._xlyMemoryKnown || [],
    xlyRecords: xly?.records || window._xlyRecords || [],
    xlyCustomAvatar: xly?.customAvatar || '',
    xlyStoryAvatarCfg: xly?.storyAvatarCfg,
    xlyCharExtraBooks: xly?.charExtraBooks || [],
    xlyRosterData: xly ? {
      name: xly.name,
      ancientRole: xly.ancientRole,
      _rosterCategory: xly._rosterCategory || '',
      assignedRank: xly.assignedRank || '',
      assignedPalace: xly.assignedPalace || '',
      honorificTitle: xly.honorificTitle || '',
      rosterPersonality: xly.rosterPersonality || '',
      rosterMood: xly.rosterMood || '',
      voicePref: xly.voicePref
    } : undefined,
    xlyTreasures: xly?.treasures || [],
    xlyPersonalSilver: xly?.personalSilver || 0,

    fanPaiIconUrl: window._fanPaiIconUrl ?? null,
    autoReflectEnabled: typeof autoReflectEnabled !== 'undefined' ? autoReflectEnabled : true,
    reflectSeenCounts,
    autoRecordSettings: typeof autoRecordSettings !== 'undefined' ? autoRecordSettings : { chat:true, intimate:true },
    ysfLettersData: typeof ysfLettersData !== 'undefined' ? ysfLettersData : [],
    ysfCharLettersData: typeof ysfCharLettersData !== 'undefined' ? ysfCharLettersData : [],
    ysfSpyData: typeof ysfSpyData !== 'undefined' ? ysfSpyData : [],
    qianchaoRecords: window._qianchaoRecords || [],
    qitaRecords: window._qitaRecords || [],
    courtNpcData: window._courtNpcData || [],
    courtUserMemorySeen: window._courtUserMemorySeen || [],
    zouZheData: typeof zouZheData !== 'undefined' ? zouZheData : { pending:[], done:[] },

    treasurySilver: typeof treasurySilver !== 'undefined' ? treasurySilver : TREASURY_INITIAL_SILVER,
    treasuryBaseVersion: 2,
    treasureInventory: typeof treasureInventory !== 'undefined' ? treasureInventory : {},
    customTreasureItems: typeof customTreasureItems !== 'undefined' ? customTreasureItems : [],
    buildTasks: typeof buildTasks !== 'undefined' ? buildTasks : [],
    cheatExpireTime: typeof cheatExpireTime !== 'undefined' ? cheatExpireTime : 0,

    globalFontFamily: typeof _globalFontFamily !== 'undefined' ? _globalFontFamily : '',
    globalFontUrl: typeof _globalFontUrl !== 'undefined' ? _globalFontUrl : '',
    globalFontDataUrl: typeof _globalFontDataUrl !== 'undefined' ? _globalFontDataUrl : '',
    globalFontSize: typeof _globalFontSize !== 'undefined' ? _globalFontSize : 15,
    zzScrollCfg: typeof _zzScrollCfg !== 'undefined' ? _zzScrollCfg : undefined,
    zzListCfgPending: typeof _zzListCfgPending !== 'undefined' ? _zzListCfgPending : undefined,
    zzListCfgDone: typeof _zzListCfgDone !== 'undefined' ? _zzListCfgDone : undefined,
    zzListFontSizePending: typeof _zzListFontSizePending !== 'undefined' ? _zzListFontSizePending : undefined,
    zzListFontSizeDone: typeof _zzListFontSizeDone !== 'undefined' ? _zzListFontSizeDone : undefined,
    zzDetailFontSizePx: typeof _zzDetailFontSizePx !== 'undefined' ? _zzDetailFontSizePx : undefined,
    zzDetailFont: window._zzDetailFont || '',
    zzDetailFontUrl: window._zzDetailFontUrl || '',
    zzDetailFontDataUrl: window._zzDetailFontDataUrl || '',
    ysfLetterFont: window._ysfLetterFont || '',
    ysfLetterFontUrl: window._ysfLetterFontDataUrl || window._ysfLetterFontUrl || ''
  };
}

function makeCheckpointDefaultName() {
  const now = new Date();
  const pad = value => String(value).padStart(2, '0');
  return `检查点 ${pad(now.getMonth() + 1)}-${pad(now.getDate())} ${pad(now.getHours())}:${pad(now.getMinutes())}`;
}

async function listGameSavesSafely() {
  try {
    const rows = await api.db.list('saves');
    return Array.isArray(rows) ? rows : [];
  } catch (error) {
    console.error('读取存档列表失败', error);
    return [];
  }
}

async function writeCurrentGameToSaveSlot(targetId, saveName, options = {}) {
  await loadImgCache();
  const saves = await listGameSavesSafely();
  const target = targetId ? saves.find(item => item.id === targetId) : null;
  if (targetId && !target) throw new Error('目标存档不存在');
  const now = new Date().toISOString();
  const snapshot = captureCurrentGameSnapshot({ ...(target || {}), palacesPlaced:true, isFinalized:true });
  const stripped = await stripImages(snapshot);
  if (target) {
    const finalName = String(saveName || target.saveName || '未命名存档').trim();
    await api.db.update('saves', target.id, { ...target, ...stripped, saveName:finalName, updatedAt:now });
    if (options.switchActive !== false || target.id === currentSaveId || !currentSaveId) currentSaveId = target.id;
    window._gameProgressFinalized = true;
    return target.id;
  }
  const finalName = String(saveName || makeCheckpointDefaultName()).trim();
  const newId = await api.db.create('saves', { ...stripped, saveName:finalName, createdAt:now, updatedAt:now });
  if (options.switchActive !== false || !currentSaveId) currentSaveId = newId;
  window._gameProgressFinalized = true;
  return newId;
}

async function saveCurrentProgressToActiveSlot() {
  const snapshot = captureCurrentGameSnapshot({ palacesPlaced:true, isFinalized:true });
  snapshot.saveName = '自动进度';
  await saveProgress(snapshot);
  window._gameProgressFinalized = true;
  return currentSaveId;
}

function pickActiveSaveRecord(saves) {
  if (!Array.isArray(saves) || !saves.length) return null;
  if (currentSaveId) {
    const current = saves.find(item => item.id === currentSaveId);
    if (current) return current;
  }
  return [...saves].sort((a, b) => String(b.updatedAt || '').localeCompare(String(a.updatedAt || '')))[0] || null;
}

async function markActiveSaveWritten() {
  const saves = await listGameSavesSafely();
  const active = pickActiveSaveRecord(saves);
  if (!active?.id) throw new Error('没有找到当前忆尘录槽');
  const now = new Date().toISOString();
  await api.db.update('saves', active.id, { ...active, manualSavedAt:now, updatedAt:now, isFinalized:true });
  currentSaveId = active.id;
  window._gameProgressFinalized = true;
  return active.id;
}

async function createCheckpointFromActiveSave(saveName) {
  const saves = await listGameSavesSafely();
  const active = pickActiveSaveRecord(saves);
  if (!active?.id) throw new Error('没有找到可复制的忆尘录槽');
  const now = new Date().toISOString();
  const copy = { ...active, saveName:String(saveName || makeCheckpointDefaultName()).trim(), createdAt:now, updatedAt:now, manualSavedAt:now, isFinalized:true };
  delete copy.id;
  return await api.db.create('saves', copy);
}

async function overwriteSaveFromActiveSave(targetId, targetName) {
  const saves = await listGameSavesSafely();
  const active = pickActiveSaveRecord(saves);
  const target = saves.find(item => item.id === targetId);
  if (!active?.id) throw new Error('没有找到当前忆尘录槽');
  if (!target?.id) throw new Error('目标存档不存在');
  const now = new Date().toISOString();
  const payload = { ...active, id:target.id, saveName:targetName || target.saveName || active.saveName || '未命名存档', createdAt:target.createdAt || active.createdAt || now, updatedAt:now, manualSavedAt:now, isFinalized:true };
  await api.db.update('saves', target.id, payload);
  if (target.id === currentSaveId) currentSaveId = target.id;
  window._gameProgressFinalized = true;
  return target.id;
}

let latestProgressSavePromise = null;
async function saveLatestGameProgress() {
  if (!window._gameProgressFinalized || typeof selectedCharsData === 'undefined' || !selectedCharsData.length) return;
  if (latestProgressSavePromise) return latestProgressSavePromise;
  latestProgressSavePromise = (async () => {
    try {
      if (currentSaveId) {
        const saves = await listGameSavesSafely();
        const current = saves.find(item => item.id === currentSaveId);
        if (current) return await writeCurrentGameToSaveSlot(current.id, current.saveName);
      }
      return await writeCurrentGameToSaveSlot(null, `自动进度 ${makeCheckpointDefaultName().replace('检查点 ', '')}`);
    } catch (error) {
      console.error('保存最新进度失败', error);
    } finally {
      latestProgressSavePromise = null;
    }
  })();
  return latestProgressSavePromise;
}

function openCheckpointNameDialog(onConfirm) {
  document.getElementById('checkpoint-name-modal')?.remove();
  const modal = document.createElement('div');
  modal.id = 'checkpoint-name-modal';
  modal.style.cssText = 'position:fixed;inset:0;z-index:100200;background:rgba(0,0,0,.82);display:flex;align-items:center;justify-content:center;padding:24px;';
  const panel = document.createElement('div');
  panel.style.cssText = 'width:min(340px,100%);background:linear-gradient(145deg,#211b15,#12100e);border:1px solid rgba(201,163,106,.65);border-radius:16px;padding:20px;box-shadow:0 18px 50px rgba(0,0,0,.7);';
  const title = document.createElement('div');
  title.textContent = '新建检查点';
  title.style.cssText = 'color:#d8b77b;text-align:center;font-size:18px;letter-spacing:4px;margin-bottom:14px;';
  const input = document.createElement('input');
  input.value = makeCheckpointDefaultName();
  input.maxLength = 40;
  input.style.cssText = 'box-sizing:border-box;width:100%;padding:11px 12px;background:rgba(0,0,0,.45);border:1px solid #66543a;border-radius:8px;color:#f1e5cf;font:14px inherit;outline:none;';
  const row = document.createElement('div');
  row.style.cssText = 'display:flex;gap:10px;margin-top:16px;';
  const cancel = document.createElement('button');
  cancel.textContent = '取消';
  cancel.style.cssText = 'flex:1;padding:10px;border:1px solid #66543a;border-radius:8px;background:transparent;color:#aaa;font:14px inherit;';
  const confirm = document.createElement('button');
  confirm.textContent = '保存';
  confirm.style.cssText = 'flex:1;padding:10px;border:0;border-radius:8px;background:#b58a4c;color:#17110b;font:bold 14px inherit;';
  cancel.onclick = () => modal.remove();
  cancel.type = 'button';
  confirm.type = 'button';
  confirm.onclick = async event => {
    event?.preventDefault?.();
    event?.stopPropagation?.();
    const name = input.value.trim();
    if (!name) { api.ui.toast('请先填写存档名称'); return; }
    confirm.disabled = true;
    confirm.textContent = '保存中…';
    try { await onConfirm(name); modal.remove(); }
    catch (error) { api.ui.toast(`保存失败：${error?.message || '请稍后重试'}`); confirm.disabled=false; confirm.textContent='保存'; }
  };
  row.append(cancel, confirm);
  panel.append(title, input, row);
  modal.appendChild(panel);
  document.body.appendChild(modal);
  setTimeout(() => { input.focus(); input.select(); }, 80);
}

async function openInGameSaveArchive(mode = 'save') {
  try {
    document.getElementById('in-game-save-modal')?.remove();
    let saves = await listGameSavesSafely();
    saves.sort((a, b) => String(b.updatedAt || '').localeCompare(String(a.updatedAt || '')));
    const isLoad = mode === 'load';
    const modal = document.createElement('div');
    modal.id = 'in-game-save-modal';
    modal.style.cssText = 'position:fixed;inset:0;z-index:100100;background:rgba(4,3,2,.9);display:flex;align-items:flex-end;justify-content:center;';
    const panel = document.createElement('div');
    panel.style.cssText = 'box-sizing:border-box;width:min(430px,100%);max-height:88vh;padding:18px 16px calc(var(--safe-bottom,0px) + 18px);overflow-y:auto;background:linear-gradient(160deg,#211b15,#100e0c 72%);border:1px solid rgba(201,163,106,.6);border-bottom:0;border-radius:22px 22px 0 0;box-shadow:0 -16px 48px rgba(0,0,0,.65);color:#e7d8bd;';
    const heading = document.createElement('div');
    heading.textContent = isLoad ? '读 档' : '存 档';
    heading.style.cssText = 'text-align:center;color:#d8b77b;font-size:20px;letter-spacing:8px;margin:2px 0 6px;';
    const hint = document.createElement('div');
    hint.textContent = isLoad ? '读取“忆尘录”中的任意进度；槽位数量不限。' : '当前全部进度将存入“忆尘录”；可另建检查点，也可覆盖旧槽。';
    hint.style.cssText = 'text-align:center;color:#8f826e;font-size:12px;line-height:1.7;margin-bottom:14px;';
    panel.append(heading, hint);

    if (!isLoad) {
      const currentBtn = document.createElement('button');
      currentBtn.style.cssText = 'box-sizing:border-box;width:100%;padding:11px;margin-bottom:8px;border:1px solid #b58a4c;border-radius:10px;background:rgba(181,138,76,.15);color:#e5c892;font:14px inherit;letter-spacing:2px;';
      currentBtn.textContent = currentSaveId ? '保存到当前槽' : '保存为自动进度';
      currentBtn.type = 'button';
      currentBtn.onclick = async event => {
        event?.preventDefault?.();
        event?.stopPropagation?.();
        currentBtn.disabled = true;
        currentBtn.textContent = '保存中…';
        try {
          await markActiveSaveWritten();
          api.ui.toast('最新进度已保存');
          currentBtn.disabled = false;
          currentBtn.textContent = currentSaveId ? '保存到当前槽' : '保存为自动进度';
        } catch (error) {
          console.error('游戏内保存失败', error);
          api.ui.toast(`保存失败：${error?.message || '请稍后重试'}`);
          currentBtn.disabled = false;
          currentBtn.textContent = currentSaveId ? '保存到当前槽' : '保存为自动进度';
        }
      };
      const addBtn = document.createElement('button');
      addBtn.type = 'button';
      addBtn.style.cssText = 'box-sizing:border-box;width:100%;padding:11px;margin-bottom:14px;border:1px solid #66543a;border-radius:10px;background:transparent;color:#c9a36a;font:14px inherit;letter-spacing:2px;';
      addBtn.textContent = '＋ 另存为新检查点';
      addBtn.onclick = () => openCheckpointNameDialog(async name => {
        await createCheckpointFromActiveSave(name);
        api.ui.toast(`检查点“${name}”已存入忆尘录`);
        modal.remove();
      });
      panel.append(currentBtn, addBtn);
      const cloudBtn = document.createElement('button');
      cloudBtn.type = 'button'; cloudBtn.textContent = '☁ 上传到共享存档';
      cloudBtn.style.cssText = 'box-sizing:border-box;width:100%;padding:11px;margin-bottom:14px;border:1px solid #8b744c;border-radius:10px;background:rgba(139,116,76,.12);color:#e5c892;font:14px inherit;letter-spacing:2px;';
      cloudBtn.onclick = () => openCheckpointNameDialog(async name => { await uploadCurrentSaveToCloud(name); api.ui.toast('云存档已上传'); });
      panel.appendChild(cloudBtn);
      const cloudManageBtn = document.createElement('button');
      cloudManageBtn.type = 'button'; cloudManageBtn.textContent = '管理共享存档 / 分享给好友';
      cloudManageBtn.style.cssText = 'box-sizing:border-box;width:100%;padding:11px;margin:-6px 0 14px;border:1px solid #66543a;border-radius:10px;background:transparent;color:#c9a36a;font:13px inherit;letter-spacing:1px;';
      cloudManageBtn.onclick = () => openCloudSaveManager();
      panel.appendChild(cloudManageBtn);
    }

    const list = document.createElement('div');
    list.style.cssText = 'display:flex;flex-direction:column;gap:9px;';
    if (!saves.length) {
      const empty = document.createElement('div');
      empty.textContent = '忆尘录中暂无存档';
      empty.style.cssText = 'padding:26px;text-align:center;color:#665e52;border:1px dashed #4a4034;border-radius:10px;';
      list.appendChild(empty);
    }
    saves.forEach(save => {
      const card = document.createElement('div');
      card.style.cssText = `padding:12px;border:1px solid ${save.id === currentSaveId ? '#b58a4c' : '#40372e'};border-radius:11px;background:${save.id === currentSaveId ? 'rgba(181,138,76,.1)' : 'rgba(0,0,0,.25)'};`;
      const top = document.createElement('div');
      top.style.cssText = 'display:flex;align-items:center;gap:8px;margin-bottom:5px;';
      const name = document.createElement('div');
      name.textContent = save.saveName || '未命名存档';
      name.style.cssText = 'flex:1;color:#e3cfaa;font-size:15px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;';
      top.appendChild(name);
      if (save.id === currentSaveId) {
        const badge = document.createElement('span');
        badge.textContent = '当前';
        badge.style.cssText = 'padding:2px 7px;border:1px solid #9b7540;border-radius:9px;color:#c9a36a;font-size:10px;';
        top.appendChild(badge);
      }
      const detail = document.createElement('div');
      const date = save.updatedAt ? new Date(save.updatedAt).toLocaleString('zh-CN', { month:'2-digit', day:'2-digit', hour:'2-digit', minute:'2-digit' }) : '时间不详';
      detail.textContent = `${(save.characters || []).length}位人物 · ${date}`;
      detail.style.cssText = 'color:#786f63;font-size:11px;margin-bottom:9px;';
      const actions = document.createElement('div');
      actions.style.cssText = 'display:flex;gap:8px;';
      const main = document.createElement('button');
      main.type = 'button';
      main.textContent = isLoad ? '读取' : '覆盖';
      main.style.cssText = 'flex:1;padding:8px;border:1px solid #8d6b3d;border-radius:7px;background:rgba(181,138,76,.13);color:#d8b77b;font:13px inherit;';
      main.onclick = async event => {
        event?.preventDefault?.();
        event?.stopPropagation?.();
        if (isLoad) {
          const ok = await api.ui.confirm({ title:'读取存档', message:`确定读取“${save.saveName || '未命名存档'}”吗？当前画面将切换到该进度。` });
          if (!ok) return;
          modal.remove();
          window._gameProgressFinalized = Boolean(save.isFinalized);
          loadSaveAndEnter(save);
        } else {
          const ok = await api.ui.confirm({ title:'覆盖存档', message:`确定用当前完整进度覆盖“${save.saveName || '未命名存档'}”吗？` });
          if (!ok) return;
          main.disabled = true;
          try {
            await overwriteSaveFromActiveSave(save.id, save.saveName);
            api.ui.toast('存档已覆盖');
            modal.remove();
          } catch (error) {
            console.error('覆盖存档失败', error);
            api.ui.toast(`覆盖失败：${error?.message || '请稍后重试'}`);
            main.disabled=false;
          }
        }
      };
      const del = document.createElement('button');
      del.type = 'button';
      del.textContent = '删除';
      del.style.cssText = 'padding:8px 13px;border:1px solid #6b3832;border-radius:7px;background:transparent;color:#b97870;font:13px inherit;';
      del.onclick = async event => {
        event?.preventDefault?.();
        event?.stopPropagation?.();
        const ok = await api.ui.confirm({ title:'删除存档', message:`确定删除“${save.saveName || '未命名存档'}”吗？此操作无法恢复。` });
        if (!ok) return;
        try {
          await api.db.delete('saves', save.id);
          if (currentSaveId === save.id) currentSaveId = null;
          card.remove();
          api.ui.toast('存档已删除');
        } catch (error) { api.ui.toast('删除失败'); }
      };
      actions.append(main, del);
      card.append(top, detail, actions);
      list.appendChild(card);
    });
    panel.appendChild(list);
    const close = document.createElement('button');
    close.type = 'button';
    close.textContent = '关闭';
    close.style.cssText = 'display:block;margin:14px auto 0;padding:7px 24px;border:0;background:transparent;color:#746b60;font:13px inherit;';
    close.onclick = () => modal.remove();
    panel.appendChild(close);
    modal.appendChild(panel);
    modal.onclick = event => { if (event.target === modal) modal.remove(); };
    document.body.appendChild(modal);
  } catch (error) {
    console.error('打开游戏内存档失败', error);
    api.ui.toast('存档面板打开失败，请稍后重试');
  }
}

function openInGameSaveMenu() {
  try {
    const task = openInGameSaveArchive('save');
    if (task && typeof task.catch === 'function') task.catch(error => {
      console.error('打开存档入口失败', error);
      api.ui.toast('存档面板打开失败，请稍后重试');
    });
  } catch (error) {
    console.error('打开存档入口失败', error);
    api.ui.toast('存档面板打开失败，请稍后重试');
  }
}

async function uploadCurrentSaveToCloud(name) {
  if (typeof gmcCloudFetch !== 'function') throw new Error('云端模块尚未加载');
  const snap = captureCurrentGameSnapshot({ saveName:name });
  const account = window._gmcAccountSession || null;
  if (!account?.token) throw new Error('请先在云笺阁账号中心注册或登录');
  const payload = makeCloudSavePayload(snap);
  const raw=JSON.stringify(payload);
  if(raw.length>7800000)throw new Error('共享存档仍然过大，请先删除部分超长记忆/记事后再上传');
  if(raw.length<90000)return await gmcCloudFetch('/cloud/saves',{token:account.token,name,payload},'POST',false);
  const start=await gmcCloudFetch('/cloud/uploads/start',{token:account.token},'POST',false);
  const size=40000;
  for(let i=0,index=0;i<raw.length;i+=size,index++)await gmcCloudFetch('/cloud/uploads/chunk',{token:account.token,uploadId:start.uploadId,index,content:raw.slice(i,i+size)},'POST',false);
  return await gmcCloudFetch('/cloud/uploads/finish',{token:account.token,uploadId:start.uploadId,name},'POST',false);
}

async function openCloudSaveManager() {
  if(typeof gmcCloudFetch!=='function'||typeof restoreGmcAccountSession!=='function')return api.ui.toast('云笺阁尚未加载');
  const a=await restoreGmcAccountSession();if(!a?.token)return api.ui.toast('请先在云笺阁账号中心登录');
  document.getElementById('gmc-cloud-save-manager')?.remove();const m=document.createElement('div');m.id='gmc-cloud-save-manager';m.style.cssText='position:fixed;inset:0;z-index:100300;background:rgba(5,3,2,.94);color:#eee;padding:calc(var(--safe-top,44px) + 12px) 16px 20px;overflow:auto;font-family:inherit;';m.innerHTML='<div style="max-width:500px;margin:auto"><div style="display:flex;justify-content:space-between;align-items:center"><b style="color:#edcf94;font-size:20px;letter-spacing:4px">共享存档</b><button id="gmc-csm-close" style="border:1px solid #8c7047;border-radius:999px;background:transparent;color:#d8b77b;padding:7px 14px;font:13px inherit">关闭</button></div><p style="color:#9b8b73;font-size:12px;line-height:1.8">在此查看已上传的云档，并分享给已添加的好友。查看权限不能复制，复制权限可收入对方忆尘录。</p><div id="gmc-csm-body"></div></div>';document.body.appendChild(m);m.querySelector('#gmc-csm-close').onclick=()=>m.remove();const body=m.querySelector('#gmc-csm-body');const call=(p,d={},method='GET')=>gmcCloudFetch(p,{...d,token:a.token},method,false);
  async function render(){try{const [saves,friends,sent]=await Promise.all([call('/cloud/saves'),call('/friends'),call('/friends/share/sent')]);body.innerHTML=(saves||[]).map(s=>`<div style="margin:12px 0;padding:14px;border:1px solid rgba(201,163,106,.25);border-radius:15px;background:rgba(255,255,255,.04)"><b style="color:#ead2a2">${gmcEscapeHtml(s.name)}</b><div style="color:#8e806a;font-size:11px;margin:5px 0">更新：${gmcEscapeHtml(s.updated_at||'')}</div><select data-save="${s.id}" style="width:100%;padding:8px;background:#1d160f;color:#e7d8bd;border:1px solid #715936;border-radius:9px;font:12px inherit"><option value="">选择好友分享…</option>${(friends||[]).map(f=>`<option value="${f.id}">${gmcEscapeHtml(f.nickname)} · ${f.id}</option>`).join('')}</select><div style="display:flex;gap:8px;margin-top:8px"><button data-share-view="${s.id}" style="flex:1;border:1px solid #8b7049;border-radius:9px;background:rgba(181,138,76,.14);color:#e5c892;padding:8px;font:12px inherit">仅查看分享</button><button data-share-copy="${s.id}" style="flex:1;border:1px solid #8b7049;border-radius:9px;background:rgba(181,138,76,.24);color:#e5c892;padding:8px;font:12px inherit">允许复制</button></div></div>`).join('')||'<div style="padding:35px;text-align:center;color:#8e806a">暂无已上传云存档</div>';const sentHtml=(sent||[]).map(x=>`<div style="padding:9px 0;border-top:1px solid rgba(201,163,106,.12);font-size:12px;color:#cdbb98">${gmcEscapeHtml(x.name)} → ${gmcEscapeHtml(x.nickname)}（${x.permission==='copy'?'允许复制':'仅查看'}）<button data-revoke="${x.save_id}|${x.user_id}" style="float:right;border:0;background:transparent;color:#d98178;font:12px inherit">取消</button></div>`).join('')||'<div style="color:#756955;font-size:12px">尚未分享给任何好友</div>';body.insertAdjacentHTML('beforeend',`<div style="margin-top:16px;padding:14px;border:1px solid rgba(201,163,106,.18);border-radius:15px;background:rgba(255,255,255,.025)"><b style="color:#d8b77b">已分享权限</b>${sentHtml}</div>`);body.querySelectorAll('[data-share-view],[data-share-copy]').forEach(b=>b.onclick=async()=>{const sid=b.dataset.shareView||b.dataset.shareCopy;const uid=body.querySelector(`select[data-save="${sid}"]`).value;if(!uid)return api.ui.toast('请先选择好友');await call('/friends/share',{saveId:sid,userId:uid,permission:b.dataset.shareCopy?'copy':'view'},'POST');api.ui.toast('分享权限已保存');render()});body.querySelectorAll('[data-revoke]').forEach(b=>b.onclick=async()=>{const [saveId,userId]=b.dataset.revoke.split('|');await call('/friends/share/revoke',{saveId,userId},'POST');render()})}catch(e){body.innerHTML=`<div style="padding:25px;text-align:center;color:#d99">${gmcEscapeHtml(e.message)}</div>`}}render();
}

async function copySharedCloudSaveToArchive(saveId, ownerName) {
  const a=typeof restoreGmcAccountSession==='function'?await restoreGmcAccountSession():null;if(!a?.token)throw new Error('请先登录正式账号');
  const remote=await gmcCloudFetch('/cloud/saves/'+encodeURIComponent(saveId),{token:a.token},'GET',false);
  if(!remote?.canCopy)throw new Error('该存档仅允许查看，不能复制');
  const data=remote.payload&&typeof remote.payload==='object'?JSON.parse(JSON.stringify(remote.payload)):{};
  delete data.gmcAccountSession;delete data.accountToken;delete data.token;delete data.apiKey;delete data.apiConfig;delete data.cloudIdentity;delete data.gmcCloudIdentity;
  data.saveName=`${remote.name||'好友存档'}（来自${ownerName||'好友'}）`;data.sharedFrom={ownerName:ownerName||'',saveId,importedAt:new Date().toISOString()};data.updatedAt=new Date().toISOString();
  const id=await api.db.create('saves',data);return id;
}

function getSharedCloudSavePreview(payload, cloudInfo = {}) {
  const save = payload && typeof payload === 'object' ? payload : {};
  const chars = Array.isArray(save.characters) ? save.characters : [];
  const npcs = Array.isArray(save.courtNpcData) ? save.courtNpcData : [];
  const notes = new Set();
  const addNotes = rows => (Array.isArray(rows) ? rows : []).forEach(item => {
    const text = typeof item === 'string' ? item : (item?.text || '');
    if (text) notes.add(item?.id || `${item?.time || ''}|${text}`);
  });
  chars.forEach(char => addNotes(char?.records));
  npcs.forEach(npc => addNotes(npc?.records));
  addNotes(save.xlyRecords); addNotes(save.qianchaoRecords); addNotes(save.qitaRecords);
  const createdAt = save.createdAt || cloudInfo.created_at || '';
  const elapsed = createdAt ? Math.max(0, Date.now() - new Date(createdAt).getTime()) : NaN;
  const duration = Number.isFinite(elapsed) ? (() => {
    const totalMinutes = Math.floor(elapsed / 60000), days = Math.floor(totalMinutes / 1440), hours = Math.floor((totalMinutes % 1440) / 60), mins = totalMinutes % 60;
    return `${days ? `${days}天` : ''}${hours ? `${hours}小时` : ''}${mins}分钟`;
  })() : '旧存档未记录建立时间';
  const silver = Number(save.treasurySilver);
  return {
    duration, characters: chars.length, npcs: npcs.length, records: notes.size,
    palaces: Array.isArray(save.palacesData) ? save.palacesData.length : 0,
    building: Array.isArray(save.buildTasks) ? save.buildTasks.length : 0,
    silver: Number.isFinite(silver) ? `${silver.toLocaleString('zh-CN')} 两` : '未记录'
  };
}
function openInGameLoadMenu() {
  try {
    const task = openInGameSaveArchive('load');
    if (task && typeof task.catch === 'function') task.catch(error => {
      console.error('打开读档入口失败', error);
      api.ui.toast('读档面板打开失败，请稍后重试');
    });
  } catch (error) {
    console.error('打开读档入口失败', error);
    api.ui.toast('读档面板打开失败，请稍后重试');
  }
}

let exitSaveTriggeredAt = 0;
function triggerExitLatestSave() {
  const now = Date.now();
  if (now - exitSaveTriggeredAt < 800) return;
  exitSaveTriggeredAt = now;
  void saveLatestGameProgress();
}
document.addEventListener('visibilitychange', () => { if (document.visibilityState === 'hidden') triggerExitLatestSave(); });
window.addEventListener('pagehide', triggerExitLatestSave);
window.addEventListener('beforeunload', triggerExitLatestSave);

// ===== AI 剧情每轮上下文（所有剧情续写共用） =====
function getCharacterMemoryParts(char) {
  const memories = Array.isArray(char?.memorySeen) ? char.memorySeen : [];
  const seen = memories.filter(item => !item?._isReflect && !String(item?.text || item || '').startsWith('【思绪】'));
  const thoughts = memories.filter(item => item?._isReflect || String(item?.text || item || '').startsWith('【思绪】'));
  const formatMemory = item => {
    if (typeof item === 'string') return item;
    return `${item?.time ? `[${item.time}] ` : ''}${item?.text || ''}`.trim();
  };
  return {
    seenText: seen.map(formatMemory).filter(Boolean).join('\n') || '无',
    knownText: (Array.isArray(char?.memoryKnown) ? char.memoryKnown : []).map(item => typeof item === 'string' ? item : (item?.text || JSON.stringify(item))).filter(Boolean).join('\n') || '无',
    thoughtsText: thoughts.map(formatMemory).filter(Boolean).join('\n') || '无'
  };
}

function getCharacterOriginalPersona(char) {
  if (!char) return '无';
  if (char._isScenarioChar && typeof XLY_PROFILE !== 'undefined') return XLY_PROFILE;
  return String(char.ancientDescOriginal || char.ancientDesc || '无')
    .replace(/^【当前游戏时间】：[^\n]*\n?/, '')
    .replace(/【当前后宫位份体系（由高到低）】[\s\S]*/, '')
    .trim() || '无';
}

function buildCharacterAiContext(char) {
  if (!char) return '【人物档案】\n无';
  const memory = getCharacterMemoryParts(char);
  const records = (Array.isArray(char.records) ? char.records : []).slice(0, 10)
    .map(item => `[${item.time || '时间不详'}] ${item.text || ''}`).join('\n') || '无';
  let charBooks = char.charWorldDesc ? `【人物传】\n${char.charWorldDesc}` : '';
  if (typeof window._buildCharExtraWbText === 'function') {
    const extra = window._buildCharExtraWbText(char);
    if (extra) charBooks += `${charBooks ? '\n\n' : ''}【人物附加世界书】\n${extra}`;
  }
  return `【${char.name || '无名人物'}完整档案（每轮必须重新遵守）】
身份：${char.ancientRole || '未知'}
位份/官职：${char.assignedRank || '无'}
居所：${char.assignedPalace || '无'}
当前惩戒状态：${typeof getCharacterDisciplineBadge === 'function' ? (getCharacterDisciplineBadge(char) || '无') : '无'}
古代人设：${getCharacterOriginalPersona(char)}
${charBooks || '人物世界书：无'}
【TA看到的】
${memory.seenText}
【TA了解的】
${memory.knownText}
【TA的思绪】
${memory.thoughtsText}
【近期记事】
${records}`;
}

function buildCharactersAiContext(chars) {
  const unique = [];
  const seenIds = new Set();
  (chars || []).filter(Boolean).forEach(char => {
    const key = char.id || char.name;
    if (!key || seenIds.has(key)) return;
    seenIds.add(key);
    unique.push(char);
  });
  return unique.map(buildCharacterAiContext).join('\n\n') || '无人物资料';
}

function buildGlobalAiContext() {
  let text = '';
  text += `【国库实存】\n当前国库银两：${formatSilver(treasurySilver)}两。所有涉及财政、拨款、赏赐、工程与朝政的判断，都必须严格以此余额为准，不得凭空假设国库空虚或另有未记录的钱款。\n\n`;
  if (typeof userAncientDesc !== 'undefined' && userAncientDesc) text += `【皇帝（User）人设】\n${userAncientDesc}\n\n`;
  if (window.globalWorldDesc) text += `【天下志】\n${window.globalWorldDesc}\n\n`;
  if (window.globalRulesDesc) text += `【长信规】\n${window.globalRulesDesc}\n\n`;
  if (typeof rankData !== 'undefined' && Array.isArray(rankData)) text += `【位份册】\n${rankData.map(item => `${item.rank}：自称${item.selfClaim}${item.note ? `，${item.note}` : ''}`).join('\n')}\n\n`;
  if (typeof window._buildExtraWbText === 'function') {
    const extra = window._buildExtraWbText();
    if (extra) text += `【全局附加世界书】\n${extra}\n\n`;
  }
  return text.trim() || '无全局设定';
}

function getAiParagraphFormatGuard() {
  return `【输出格式最高约束】
1. 叙事只能写成<p>实际叙事内容</p>，叙事段不得设置data-speaker。
2. “旁白”“叙述”“Narrator”只是系统分类名，绝对不得作为正文、段首、说话者或标签内容输出；禁止输出“旁白：”“【旁白】”“<p>旁白</p>”。
3. 人物台词只能写成<p data-speaker="准确人物姓名">“实际台词”</p>。
4. 只输出闭合的<p>段落，不得输出Markdown、标题、代码块、标签外文字或思考过程。`;
}

function getLongPlotContinuationGuard() {
  return `【后续剧情篇幅最高约束】
本轮是User输入后的正式续写，正文目标约1500字，不得再以500字左右草草结束。至少安排15个有实质推进的小段；为兼顾篇幅，一个内容小段可由连续两至三个短<p>构成。每个叙事<p>尽量约50至100字，人物台词仍单独成段。必须承接User最新言行，推进动作、关系、环境与新的互动钩子，禁止用总结、复述履历或空泛抒情凑字。`;
}

async function saveStoryAvatarConfig(char, cfg) {
  if (!char) return;
  char.storyAvatarCfg = { scale: Number(cfg.scale), x: Number(cfg.x), y: Number(cfg.y) };
  const selected = selectedCharsData.find(item => item.id === char.id || (!char.id && item.name === char.name));
  if (selected) selected.storyAvatarCfg = { ...char.storyAvatarCfg };
  const npc = (window._courtNpcData || []).find(item => item.id === char.id);
  if (npc) npc.storyAvatarCfg = { ...char.storyAvatarCfg };
  if (typeof XLY_CHAR !== 'undefined' && (char === XLY_CHAR || char.id === XLY_CHAR.id)) {
    XLY_CHAR.storyAvatarCfg = { ...char.storyAvatarCfg };
  }
  await saveProgress({
    characters: selectedCharsData,
    xlyStoryAvatarCfg: typeof XLY_CHAR !== 'undefined' ? XLY_CHAR.storyAvatarCfg : undefined,
    courtNpcData: window._courtNpcData || []
  });
}

// ===== 忆尘录弹窗 =====
document.getElementById('btn-save-list').addEventListener('click', () => showSaveModal());

async function showSaveModal() {
  const existing = document.getElementById('save-modal');
  if (existing) existing.remove();

  let saves = [];
  try { saves = await api.db.list("saves"); } catch(e) {}

  const modal = document.createElement('div');
  modal.id = 'save-modal';
  modal.style.cssText = 'position:fixed;inset:0;z-index:9999;background:rgba(0,0,0,0.82);display:flex;align-items:flex-end;justify-content:center;';

  const inner = document.createElement('div');
  inner.style.cssText = 'width:100%;max-width:420px;background:#1a1816;border:1px solid var(--primary-color);border-radius:20px 20px 0 0;padding:20px 16px calc(var(--safe-bottom)+16px);display:flex;flex-direction:column;gap:12px;max-height:80vh;overflow-y:auto;';

  const title = document.createElement('div');
  title.style.cssText = 'color:var(--primary-color);font-size:20px;text-align:center;letter-spacing:6px;margin-bottom:4px;';
  title.textContent = '忆尘录';
  inner.appendChild(title);

  // 渲染存档槽
  function renderSlots() {
    inner.querySelectorAll('.save-slot,.save-add-btn,.modal-close-btn').forEach(el => el.remove());

    saves.forEach(save => {
      const slot = document.createElement('div');
      slot.className = 'save-slot';
      const charNames = (save.characters||[]).map(c=>c.name).join('、') || '无故人';
      const dateStr = save.updatedAt ? new Date(save.updatedAt).toLocaleString('zh-CN',{month:'2-digit',day:'2-digit',hour:'2-digit',minute:'2-digit'}) : '';

      // 主体信息区
      const info = document.createElement('div');
      info.className = 'save-slot-info';
      info.innerHTML = `<div class="save-slot-name">${save.saveName || '未命名存档'}</div>
        <div class="save-slot-detail">${charNames} · ${save.palacesPlaced?'皇城已定':'皇城未定'} · ${dateStr}</div>`;
      slot.appendChild(info);

      // 右滑操作区（重命名 + 删除）
      const actions = document.createElement('div');
      actions.className = 'save-slot-actions';

      const renameBtn = document.createElement('button');
      renameBtn.className = 'save-slot-rename';
      renameBtn.textContent = '命名';
      renameBtn.addEventListener('click', async (e) => {
        e.stopPropagation();
        slot.classList.remove('swipe-open');
        
        // 使用原生 prompt 时，部分环境下可能被拦截或样式不佳，我们自己造个小弹窗
        const div = document.createElement('div');
        div.style.cssText = 'position:fixed; inset:0; background:rgba(0,0,0,0.8); z-index:99999; display:flex; align-items:center; justify-content:center;';
        div.innerHTML = `
          <div style="background:#1a1816; padding:20px; border:1px solid var(--primary-color); border-radius:12px; width:80%; max-width:300px;">
            <div style="color:var(--primary-color); margin-bottom:12px; font-size:16px;">重命名存档</div>
            <input type="text" id="rename-input" value="${save.saveName || ''}" placeholder="请输入存档名称" style="width:100%; padding:10px; background:#000; color:#fff; border:1px solid #555; border-radius:6px; margin-bottom:16px; font-size:14px; font-family:inherit;">
            <div style="display:flex; gap:12px;">
              <button id="rename-cancel" style="flex:1; padding:10px; background:transparent; border:1px solid #666; color:#aaa; border-radius:6px; font-size:14px;">取消</button>
              <button id="rename-confirm" style="flex:1; padding:10px; background:var(--primary-color); border:none; color:#000; border-radius:6px; font-size:14px; font-weight:bold;">确认</button>
            </div>
          </div>
        `;
        document.body.appendChild(div);
        
        // 自动聚焦
        setTimeout(() => document.getElementById('rename-input').focus(), 100);
        
        document.getElementById('rename-cancel').onclick = () => div.remove();
        document.getElementById('rename-confirm').onclick = async () => {
          const newName = document.getElementById('rename-input').value;
          if (newName && newName.trim()) {
            save.saveName = newName.trim();
            try { await api.db.update("saves", save.id, { ...save }); } catch(err) {}
            renderSlots();
          }
          div.remove();
        };
      });

      const delBtn = document.createElement('button');
      delBtn.className = 'save-slot-del';
      delBtn.textContent = '删除';
      delBtn.addEventListener('click', async (e) => {
        e.stopPropagation();
        try {
          await api.db.delete("saves", save.id);
          saves = saves.filter(s => s.id !== save.id);
          if (currentSaveId === save.id) currentSaveId = null;
          renderSlots();
          api.ui.toast("存档已删除");
        } catch(err) { api.ui.toast("删除失败"); }
      });

      actions.appendChild(renameBtn);
      actions.appendChild(delBtn);
      slot.appendChild(actions);

      // 点击槽体 → 续前缘
      slot.addEventListener('click', (e) => {
        if (e.target === renameBtn || e.target === delBtn) return;
        if (slot.classList.contains('swipe-open')) { slot.classList.remove('swipe-open'); return; }
        modal.remove();
        loadSaveAndEnter(save);
      });

      // 右滑手势
      let touchStartX = 0;
      slot.addEventListener('touchstart', e => { touchStartX = e.touches[0].clientX; }, {passive:true});
      slot.addEventListener('touchmove', e => {
        const dx = e.touches[0].clientX - touchStartX;
        if (dx < -40) slot.classList.add('swipe-open');
        else if (dx > 10) slot.classList.remove('swipe-open');
      }, {passive:true});

      inner.appendChild(slot);
    });

    // 新建存档按钮
    const addBtn = document.createElement('button');
    addBtn.className = 'save-add-btn';
    addBtn.textContent = '＋ 新开一段前尘';
    addBtn.addEventListener('click', () => {
      modal.remove();
      // 重置状态，开新档
      currentSaveId = null;
      window._gameProgressFinalized = false;
      currentMapDataUrl = null;
      placedPalacesData = [];
      selectedCharsData = [];
      selectedCharIds = new Set();
      switchView(vMapSetup);
    });
    inner.appendChild(addBtn);

    // 关闭按钮
    let closeBtn = inner.querySelector('.modal-close-btn');
    if (!closeBtn) {
      closeBtn = document.createElement('button');
      closeBtn.className = 'modal-close-btn';
      closeBtn.style.cssText = 'background:transparent;border:none;color:#555;font-family:inherit;font-size:13px;padding:4px;';
      closeBtn.textContent = '关闭';
      closeBtn.addEventListener('click', () => modal.remove());
      inner.appendChild(closeBtn);
    }
  }

  modal.addEventListener('click', e => { if (e.target === modal) modal.remove(); });
  modal.appendChild(inner);
  document.body.appendChild(modal);
  renderSlots();
}

function loadSaveAndEnter(save) {
  (async () => {
    // 确保图片缓存已从 DB 加载，再把 key 还原为 dataUrl
    await loadImgCache();
    save = restoreImages(save);

    currentSaveId = save.id;
    window._gameProgressFinalized = Boolean(save.isFinalized);
    currentMapDataUrl = save.mapUrl || null;
    selectedCharsData = save.characters || [];
    selectedCharIds = new Set(selectedCharsData.map(c => c.id));
    placedPalacesData = save.palacesData || [];
    if (typeof palaces !== 'undefined') {
      const basePalaces = ['乾清宫','坤宁宫','东六宫','西六宫','养心殿','内务府','御花园','冷宫'];
      palaces.splice(0, palaces.length, ...basePalaces);
    }
    placedPalacesData.forEach(item => { if (item?.name && typeof palaces !== 'undefined' && !palaces.includes(item.name)) palaces.push(item.name); });

    // 确保 allCharacters 已加载（人物定制界面需要原始角色卡数据）
    if (allCharacters.length === 0) {
      try { allCharacters = await api.characters.list(); } catch(e) { allCharacters = []; }
    }

    if (save.palacesPlaced && selectedCharsData.length > 0) {
      if (save.rankData) rankData = save.rankData;
      userAncientDesc = save.userAncientDesc || '';
      if (save.palaceDetails) palaceDetails = save.palaceDetails;
      if (!palaceDetails['乾清宫']) palaceDetails['乾清宫'] = { note: '', bgUrl: QIANQING_DEFAULT_BG };
      if (!palaceDetails['乾清宫'].bgUrl) palaceDetails['乾清宫'].bgUrl = QIANQING_DEFAULT_BG;
      if (!palaceDetails['华清宫']) palaceDetails['华清宫'] = { note: '', bgUrl: HUAQING_DEFAULT_BG, description: HUAQING_DEFAULT_DESCRIPTION, rules: HUAQING_DEFAULT_RULES };
      if (!palaceDetails['华清宫'].bgUrl) palaceDetails['华清宫'].bgUrl = HUAQING_DEFAULT_BG;
      if (!palaceDetails['华清宫'].description) palaceDetails['华清宫'].description = HUAQING_DEFAULT_DESCRIPTION;
      if (!palaceDetails['华清宫'].rules) palaceDetails['华清宫'].rules = HUAQING_DEFAULT_RULES;
      if (!palaceDetails['冷宫']) palaceDetails['冷宫'] = { note: '幽禁失宠之人', bgUrl: COLD_PALACE_DEFAULT_BG };
      if (!palaceDetails['冷宫'].bgUrl) palaceDetails['冷宫'].bgUrl = COLD_PALACE_DEFAULT_BG;
      timeMode = save.timeMode || 'sync';
      currentCustomTimeStr = save.customTimeStr || '';
      // 读档后修复 iconConfig.url 占位符（存档时为节省体积用 __use_icon__ 代替图片数据）
      if (placedPalacesData) {
        placedPalacesData.forEach(p => {
          if (p.iconConfig && p.iconConfig.url === '__use_icon__') {
            p.iconConfig.url = p.icon || null;
          }
        });
      }
      window.globalWorldDesc = save.globalWorldDesc !== undefined ? save.globalWorldDesc : defaultGlobalWorldDesc;
      window.globalRulesDesc = save.globalRulesDesc !== undefined ? save.globalRulesDesc : defaultRulesDesc;
      globalPortalCfg = save.globalPortalCfg || { url:null, scale:100, x:0, y:0, fsize:24, textMode:'vertical' };
      customPrompts = save.customPrompts || {};
      window._relationData = save.relationData || {};
      // 确保载入最新的坐标
      window._rgNodesPos = save.rgNodesPos || {};
      // 读档时也清空之前的图片缓存
      window._rgImgCache = {};
      window._scenarioAvatarCfgCache = save.scenarioAvatarCfg || {};
      window._xlyMemorySeen = save.xlyMemorySeen || [];
      XLY_CHAR.memorySeen = window._xlyMemorySeen;
      window._xlyRecords = save.xlyRecords || [];
      XLY_CHAR.records = window._xlyRecords;
      XLY_CHAR.customAvatar = save.xlyCustomAvatar || '';
      XLY_CHAR.storyAvatarCfg = save.xlyStoryAvatarCfg || { scale:100, x:0, y:0 };
      XLY_CHAR.memoryKnown = save.xlyMemoryKnown || [];
      if (!window._xlyBaseRosterData) {
        window._xlyBaseRosterData = {
          name:XLY_CHAR.name, ancientRole:XLY_CHAR.ancientRole, _rosterCategory:XLY_CHAR._rosterCategory || '',
          assignedRank:XLY_CHAR.assignedRank || '', assignedPalace:XLY_CHAR.assignedPalace || '',
          honorificTitle:XLY_CHAR.honorificTitle || '', rosterPersonality:XLY_CHAR.rosterPersonality || '', rosterMood:XLY_CHAR.rosterMood || ''
        };
      }
      Object.assign(XLY_CHAR, window._xlyBaseRosterData, save.xlyRosterData || {});
      window._fanPaiIconUrl = save.fanPaiIconUrl !== undefined ? save.fanPaiIconUrl : null;
      autoReflectEnabled = save.autoReflectEnabled !== undefined ? save.autoReflectEnabled : true;
      // 恢复信笺三数组
      ysfLettersData = save.ysfLettersData || [];
      ysfCharLettersData = save.ysfCharLettersData || [];
      ysfSpyData = save.ysfSpyData || [];
      // 恢复各角色的沉思计数基准
      {
        const allC = [...(save.characters || []), XLY_CHAR, ...(save.courtNpcData || [])];
        const savedReflectCounts = save.reflectSeenCounts || {};
        allC.forEach(c => {
          delete c._lastReflectSeenCount;
          if (savedReflectCounts[c.id] !== undefined) {
            c._lastReflectSeenCount = savedReflectCounts[c.id];
          }
        });
      }
      autoRecordSettings = save.autoRecordSettings || { chat:true, intimate:true };
      document.getElementById('chk-auto-record-chat').checked = autoRecordSettings.chat;
      document.getElementById('chk-auto-record-intimate').checked = autoRecordSettings.intimate;
      window._qianchaoRecords = save.qianchaoRecords || [];
      window._courtNpcData = save.courtNpcData || [];
      if (typeof normalizeGameNpc === 'function') window._courtNpcData.forEach(normalizeGameNpc);
      // 旧存档无损迁移：收集过去写在「TA看到的」「TA了解的」或个人记事里的
      // 赏赐/册封众闻，再补录到所有人物「TA了解的 → 起居注」。原位置一律保留。
      const publicNewsMap = new Map();
      const collectPublicNews = items => (Array.isArray(items) ? items : []).forEach(item => {
        const text = String(item?.text || item || '').trim();
        if (!text.startsWith('【赏赐众闻】') && !text.startsWith('【后宫册封众闻】')) return;
        if (!publicNewsMap.has(text)) publicNewsMap.set(text, { text, time: item?.time || '众闻' });
      });
      getAllTreasuryKnowledgeCharacters().forEach(char => {
        collectPublicNews(char.memorySeen);
        collectPublicNews(char.memoryKnown);
        collectPublicNews(char.records);
      });
      collectPublicNews(window._qianchaoRecords);
      let migratedPublicNews = false;
      publicNewsMap.forEach(news => {
        const tags = news.text.startsWith('【赏赐众闻】') ? ['赏赐', '众闻'] : ['后宫', '赐封', '众闻'];
        if (syncPublicNewsToCharacterRecords(news.text, news.time, tags)) migratedPublicNews = true;
      });
      if (migratedPublicNews) {
        await saveProgress({
          characters: selectedCharsData,
          courtNpcData: window._courtNpcData || [],
          xlyMemoryKnown: XLY_CHAR.memoryKnown,
          xlyRecords: XLY_CHAR.records
        });
      }
      window._courtUserMemorySeen = save.courtUserMemorySeen || [];
      window._qitaRecords = save.qitaRecords || [];
      zouZheData = save.zouZheData || { pending:[], done:[] };
      if (save.zzScrollCfg && typeof _zzScrollCfg !== 'undefined') _zzScrollCfg = save.zzScrollCfg;
      if (save.zzListCfgPending && typeof _zzListCfgPending !== 'undefined') _zzListCfgPending = save.zzListCfgPending;
      if (save.zzListCfgDone && typeof _zzListCfgDone !== 'undefined') _zzListCfgDone = save.zzListCfgDone;
      if (save.zzDetailFont !== undefined) window._zzDetailFont = save.zzDetailFont;
      if (save.zzDetailFontUrl !== undefined) window._zzDetailFontUrl = save.zzDetailFontUrl;
      if (save.zzDetailFontDataUrl !== undefined) window._zzDetailFontDataUrl = save.zzDetailFontDataUrl;
      const savedTreasury = Number(save.treasurySilver);
      treasurySilver = Number.isFinite(savedTreasury) ? Math.max(0, Math.floor(savedTreasury)) : TREASURY_INITIAL_SILVER;
      // 迁移19—21版错误的5000两初始值；发生过收支的其他余额保持原样。
      if (!save.treasuryBaseVersion && treasurySilver === 5000) treasurySilver = TREASURY_INITIAL_SILVER;
      treasureInventory = save.treasureInventory && typeof save.treasureInventory === 'object' ? save.treasureInventory : {};
      customTreasureItems = Array.isArray(save.customTreasureItems) ? save.customTreasureItems : [];
      XLY_CHAR.treasures = save.xlyTreasures || [];
      XLY_CHAR.personalSilver = save.xlyPersonalSilver !== undefined ? save.xlyPersonalSilver : 0;
      applyTreasuryKnowledge();
      // 旧存档迁移：把全部待处理/已批阅奏折及后续往来同步进上奏者“TA看到的”。
      if (typeof syncAllZouZheAuthorMemories === 'function') {
        await syncAllZouZheAuthorMemories();
      }
      // 旧存档迁移：确保默认“预设”世界书存在并恢复自定义书。
      window._globalExtraBooks = Array.isArray(save.globalExtraBooks) ? save.globalExtraBooks : [];
      if (!window._globalExtraBooks.some(book => book.id === 'geb_default_preset')) {
        window._globalExtraBooks.unshift({ id: 'geb_default_preset', name: '预设', content: defaultPresetDesc });
      }
      const presetBook = window._globalExtraBooks.find(book => book.id === 'geb_default_preset');
      if (presetBook && presetBook.content === defaultRulesDesc) presetBook.content = defaultPresetDesc;
      if (typeof XLY_CHAR !== 'undefined') XLY_CHAR.charExtraBooks = save.xlyCharExtraBooks || [];
      // 名册知识在读档完成时立即进入各人物“TA了解的”。
      if (typeof syncRosterKnowledgeToCharacters === 'function') syncRosterKnowledgeToCharacters();
      restoreCheatState(save);
      if (save.isFinalized) {
        initMemoryView();
        switchView(vMemory);
      } else {
        initRankSetupView(); switchView(vRankSetup);
      }
    } else if (currentMapDataUrl) {
      initPlacementView(); switchView(vPlacement);
    } else {
      switchView(vMapSetup);
    }
  })();
}

// ===== 拾前尘：总是新开（不覆盖旧存档）=====
document.getElementById('btn-start').addEventListener('click', () => {
  currentSaveId = null;
  window._gameProgressFinalized = false;
  currentMapDataUrl = null;
  placedPalacesData = [];
  selectedCharsData = [];
  selectedCharIds = new Set();
  userAncientDesc = "";
  treasurySilver = TREASURY_INITIAL_SILVER;
  treasureInventory = {};
  customTreasureItems = [];
  if (typeof updateTreasuryHud === 'function') updateTreasuryHud();
  switchView(vMapSetup);
});

// --- 记事系统核心逻辑 ---
// 记事数据结构：{ id, time, text, type, tags }
// type: 'system' | 'ai'
// tags: ['众谈'] | ['彤录'] 等
function generateId() { return 'rec_' + Date.now() + '_' + Math.random().toString(36).slice(2, 6); }

// 在读档时恢复金手指状态
function restoreCheatState(save) {
  cheatExpireTime = Number(save.cheatExpireTime) || 0;
  buildTasks = Array.isArray(save.buildTasks) ? save.buildTasks : [];
  // 恢复全局字体设置
  _globalFontFamily  = save.globalFontFamily || '';
  _globalFontUrl     = save.globalFontUrl || '';
  _globalFontDataUrl = save.globalFontDataUrl || '';
  _globalFontSize = typeof save.globalFontSize === 'number' ? save.globalFontSize : GLOBAL_FONT_DEFAULT_SIZE;
  // 应用已保存的全局字体
  applyGlobalFont(_globalFontFamily, _globalFontUrl, _globalFontDataUrl, _globalFontSize);
  // 恢复列表页字体大小
  _zzListFontSizePending = typeof save.zzListFontSizePending === 'number' ? save.zzListFontSizePending : 14;
  _zzListFontSizeDone = typeof save.zzListFontSizeDone === 'number' ? save.zzListFontSizeDone : 14;
  // 恢复详情页字体大小
  _zzDetailFontSizePx = typeof save.zzDetailFontSizePx === 'number' ? save.zzDetailFontSizePx : 14;
  // 恢复信笺字体设置
  window._ysfLetterFont = save.ysfLetterFont || '';
  window._ysfLetterFontUrl = '';
  window._ysfLetterFontDataUrl = '';
  if (window._ysfLetterFont) {
    const fontUrl = save.ysfLetterFontUrl || '';
    if (fontUrl && fontUrl.startsWith('data:')) {
      // 上传的字体文件
      window._ysfLetterFontDataUrl = fontUrl;
      const fontName = window._ysfLetterFont.replace(/['"]/g,'').split(',')[0];
      if (!document.querySelector(`style[data-ysf-font="${fontName}"]`)) {
        const s = document.createElement('style');
        s.dataset.ysfFont = fontName;
        s.textContent = `@font-face { font-family:'${fontName}'; src:url('${fontUrl}'); }`;
        document.head.appendChild(s);
      }
    } else if (fontUrl) {
      // 网络字体链接
      window._ysfLetterFontUrl = fontUrl;
      loadFontLink(fontUrl);
    }
  }
}

// 加载字体链接（CSS @import 或直链 TTF）
function loadFontLink(url) {
  if (!url) return;
  const id = 'ysf-font-link-' + btoa(url).slice(0, 16).replace(/[^a-z0-9]/gi,'');
  if (document.getElementById(id)) return; // 已加载
  if (url.includes('fonts.googleapis.com') || url.includes('fonts.gstatic.com') || url.endsWith('.css')) {
    const link = document.createElement('link');
    link.id = id; link.rel = 'stylesheet'; link.href = url;
    document.head.appendChild(link);
  } else if (url.match(/\.(ttf|otf|woff|woff2)(\?.*)?$/i)) {
    // 直链字体文件，生成 @font-face
    const fontName = 'YsfNetFont_' + id;
    const s = document.createElement('style');
    s.id = id;
    s.textContent = `@font-face { font-family:'${fontName}'; src:url('${url}'); }`;
    document.head.appendChild(s);
    // 把 family 名回写，方便后续 apply
    window._ysfLetterFontFromUrl = `'${fontName}',serif`;
  }
}

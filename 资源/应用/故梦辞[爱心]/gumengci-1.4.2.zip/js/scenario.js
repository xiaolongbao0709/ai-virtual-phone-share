

// ===== Typewriter Effect =====
let twTimer = null;
let isTwTyping = false;
let twFullText = "";
let twBox = null;
let twResolve = null;

function playTypewriter(box, text, timeMs=1500) {
  return new Promise(resolve => {
    isTwTyping = true;
    twFullText = text;
    twBox = box;
    twResolve = resolve;
    box.innerHTML = '';
    
    const chars = [];
    let inTag = false, tagBuf = '';
    for(let i=0; i<text.length; i++){
      if(text[i]==='<'){ inTag=true; tagBuf='<'; }
      else if(text[i]==='>'){ inTag=false; tagBuf+='>'; chars.push(tagBuf); tagBuf=''; }
      else if(inTag){ tagBuf+=text[i]; }
      else { chars.push(text[i]); }
    }
    
    // 调整速度：每字最慢 60ms，最快 30ms。适中不沉闷
    const speed = Math.max(30, Math.min(60, timeMs / chars.length));
    let i = 0;
    
    function step() {
      if(!isTwTyping || twBox !== box) return;
      if(i < chars.length) {
        box.innerHTML += chars[i];
        i++;
        // 自动滚动到底部
        box.scrollTop = box.scrollHeight;
        twTimer = setTimeout(step, speed);
      } else {
        isTwTyping = false;
        resolve();
      }
    }
    clearTimeout(twTimer);
    step();
  });
}

function skipTypewriter() {
  if (isTwTyping && twBox) {
    isTwTyping = false;
    clearTimeout(twTimer);
    twBox.innerHTML = twFullText;
    if(twResolve) twResolve();
    return true;
  }
  return false;
}

// ===== 气泡模式：'fixed'=固定高度滚动 | 'expand'=自动伸展(默认) =====
let bubbleMode = 'expand';

function applyBubbleMode() {
  const indoorWrap = document.getElementById('indoor-chat-wrap');
  const storyWrap  = document.getElementById('story-text-wrap');
  const indoorBtn  = document.getElementById('btn-indoor-bubble-mode');
  const storyBtn   = document.getElementById('btn-story-bubble-mode');

  if (bubbleMode === 'expand') {
    indoorWrap?.classList.add('bubble-expand');
    storyWrap?.classList.add('bubble-expand');
    if (indoorBtn) { indoorBtn.textContent = '展'; indoorBtn.style.background = 'rgba(201,163,106,0.25)'; }
    if (storyBtn)  { storyBtn.textContent  = '展'; storyBtn.style.background  = 'rgba(201,163,106,0.25)'; }
  } else {
    indoorWrap?.classList.remove('bubble-expand');
    storyWrap?.classList.remove('bubble-expand');
    if (indoorBtn) { indoorBtn.textContent = '卷'; indoorBtn.style.background = 'rgba(0,0,0,0.5)'; }
    if (storyBtn)  { storyBtn.textContent  = '卷'; storyBtn.style.background  = 'rgba(0,0,0,0.5)'; }
  }
}

function toggleBubbleMode() {
  bubbleMode = (bubbleMode === 'fixed') ? 'expand' : 'fixed';
  applyBubbleMode();
}

// ===== 退出室内模式 =====
window.handleExitIndoor = function() {
  const indoorBar = document.getElementById('indoor-bottom-bar');
  const chatControls = document.getElementById('indoor-chat-controls');
  
  if (chatControls.style.display === 'flex') {
    // 正在聊天中，需要确认是否保存对话
    document.getElementById('btn-inchat-exit').click();
  } else {
    // 没在聊天，直接退出
    switchView(vPalaceDetail);
  }
};

// ===== 履历弹窗事件（顶层绑定）=====
const historyModal = document.getElementById('story-history-modal');
const historyList = document.getElementById('story-history-list');
function escHtml(s) { return String(s||'').replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;'); }

document.getElementById('btn-story-history').addEventListener('click', () => {
  historyList.innerHTML = storyContext.history.map((h, i) => `
    <div style="border-bottom:1px solid #333; padding-bottom:12px;">
      <div style="color:${h.speaker==='皇帝'?'var(--primary-color)':(h.speaker?'#fff':'#888')}; font-size:12px; margin-bottom:4px;">${escHtml(h.speaker) || '旁白'}</div>
      <textarea class="hist-edit" data-idx="${i}" style="width:100%; min-height:40px; background:transparent; border:none; color:#ccc; resize:vertical; font-family:inherit; font-size:14px;">${escHtml(h.text)}</textarea>
      <div style="display:flex; justify-content:flex-end; gap:6px; margin-top:4px; flex-wrap:wrap;">
        <button class="hist-del" data-idx="${i}" style="background:transparent; border:1px solid #555; color:#777; padding:2px 8px; border-radius:4px; font-size:12px;">删除</button>
        <button class="hist-goto" data-idx="${i}" style="background:transparent; border:1px solid #888; color:#aaa; padding:2px 8px; border-radius:4px; font-size:12px;">定位到此</button>
        <button class="hist-reroll" data-idx="${i}" style="background:rgba(201,163,106,0.15); border:1px solid var(--primary-color); color:var(--primary-color); padding:2px 8px; border-radius:4px; font-size:12px;">从此重推</button>
      </div>
    </div>
  `).join('');
  historyList.querySelectorAll('.hist-edit').forEach(ta => {
    ta.addEventListener('change', e => { storyContext.history[e.target.dataset.idx].text = e.target.value; });
  });
  historyList.querySelectorAll('.hist-del').forEach(btn => {
    btn.addEventListener('click', e => {
      storyContext.history.splice(e.target.dataset.idx, 1);
      document.getElementById('btn-story-history').click();
    });
  });
  historyList.querySelectorAll('.hist-goto').forEach(btn => {
    btn.addEventListener('click', e => {
      const idx = parseInt(e.target.dataset.idx);
      historyModal.style.display = 'none';
      
      const savedHistory = storyContext.history.slice(0, idx);
      const remainingSegs = storyContext.history.slice(idx).map(s => Object.assign({}, s)); // 克隆剩余所有记录
      
      storyContext.history = savedHistory;
      storySegments = remainingSegs;
      currentSegmentIdx = 0;
      
      ttsAbortFlag = true;
      try { api.voice.stop && api.voice.stop(); } catch(e) {}
      setStoryTapHandler(null);
      storyControls.style.display = 'none';
      document.getElementById('story-blocker').style.display = 'block';
      showNextSegment();
    });
  });
  historyList.querySelectorAll('.hist-reroll').forEach(btn => {
    btn.addEventListener('click', e => {
      const idx = parseInt(e.target.dataset.idx);
      storyContext.history = storyContext.history.slice(0, idx);
      historyModal.style.display = 'none';
      
      // 自动找到上一句 user 说的话来触发
      let lastUserIdx = -1;
      for (let i = storyContext.history.length - 1; i >= 0; i--) {
        if (storyContext.history[i].type === 'user') {
          lastUserIdx = i;
          break;
        }
      }
      
      if (lastUserIdx !== -1) {
        const userText = storyContext.history[lastUserIdx].text;
        storyContext.history = storyContext.history.slice(0, lastUserIdx);
        document.getElementById('story-user-input').value = userText;
        
        // 隐藏控制区，下推文字框
        const textWrap = document.getElementById('story-text-wrap');
        storyControls.style.display = 'none';
        textWrap.style.bottom = 'calc(var(--safe-bottom) + 20px)';
        
        document.getElementById('btn-story-send').click();
      } else {
        // 如果前面没有 user 的话，意味着重推开头
        storyContext.history = [];
        
        // 恢复 UI 状态，显示推演中
        storyTextBox.innerHTML = "准备重新推演，请在弹窗中选择条件...";
        const textWrap = document.getElementById('story-text-wrap');
        textWrap.style.opacity = '1';
        textWrap.style.bottom = 'calc(var(--safe-bottom) + 20px)';
        storyTextBox.style.opacity = '1';
        storyControls.style.display = 'none';
        
        // 重新调用生成
        if (storyContext.mode === 'morningCourt') {
          startMorningCourt();
        } else {
          document.getElementById('btn-story-reroll-modal').click();
        }
      }
    });
  });
  historyModal.style.display = 'flex';
});
document.getElementById('btn-close-history').addEventListener('click', () => { historyModal.style.display = 'none'; });

// 室内聊天状态
let indoorChatContext = { history: [], segments: [], currentIdx: 0, tapHandler: null, abortVoice: false };
const indoorAvatarImg = document.getElementById('indoor-avatar-img');

async function openIndoorView(pName, rName, char) {
  if (pName !== '冷宫') window._indoorSceneBgOverride = '';
  window.currentIndoorChar = char;
  currentDetailPalaceName = pName;
  window._indoorSceneContext = {
    type: pName === '养心殿' ? 'yangxin_visit' : 'palace_visit',
    pName,
    rName,
    premise: pName === '冷宫'
      ? `皇帝亲自来到冷宫幽院探望${char.name}。${char.name}正在冷宫幽禁、没有位份；环境、礼序、心境和言行必须符合失宠幽居处境。绝对不得写成养心殿传召，也不得忘记其冷宫身份。`
      : pName === '养心殿'
      ? `皇帝正在养心殿内与${char.name}相见。除非入口另有说明，不得擅自改写成从其他宫殿传召。`
      : `皇帝已亲自摆驾前往${pName}${rName || ''}探望${char.name}，当前剧情地点就是${pName}${rName || ''}。绝对不是皇帝传召${char.name}前往养心殿。`
  };
  
  // 谢临渊特殊处理：不要求设置室内背景，直接借用养心殿背景
  if (char.id === '__xly__') {
    char.indoorBgUrl = palaceDetails['养心殿'].bgUrl;
  }

  if (pName === '冷宫') {
    window._indoorSceneBgOverride = palaceDetails['冷宫']?.bgUrl || (typeof COLD_PALACE_DEFAULT_BG !== 'undefined' ? COLD_PALACE_DEFAULT_BG : '');
    enterIndoorView();
    return;
  }
  
  if (!char.indoorBgUrl) {
    // 尚未设置背景，呼出绘景弹窗
    currentDetailPalaceName = '__INDOOR__';
    pbTitle.innerText = `${char.name} · 室内绘景`;
    pbPrompt.value = `真实画风，中国古代皇宫室内，${pName}${rName}内景，符合${char.assignedRank||'后妃'}身份的陈设，华丽，唯美，无人物`;
    pbImg.style.display = 'none';
    pbPlaceholder.style.display = 'block';
    pbLoader.style.display = 'none';
    btnPbConfirm.style.display = 'none';
    tempPbDataUrl = null;
    isCourtyardMode = false;
    pbModal.style.display = 'flex';
  } else {
    enterIndoorView();
  }
}

function startPalaceStaffInteraction(pName, npcType, npc, mode) {
  const roommates = typeof getPalaceStaffResidents === 'function' ? getPalaceStaffResidents(pName, npcType) : [npc];
  const roomLabel = npcType === 'maid' ? '宫女房' : '侍从房';
  const bgUrl = palaceDetails[pName]?.earRoomBgUrls?.[npcType];
  if (!bgUrl) {
    api.ui.toast('请先设定这间耳房的背景图');
    openEarRoomBackgroundEditor(pName, npcType);
    return;
  }
  npc.indoorBgUrl = bgUrl;
  currentDetailPalaceName = pName;
  window.currentIndoorChar = npc;
  window._staffInteractionContext = { pName, npcType, roomLabel, roommates, mainNpcId: npc.id };
  window._indoorPortraitParticipants = roommates;
  window._fanPaiChosenChars = null;
  window._indoorSceneContext = { type: 'ear_room', pName, rName: roomLabel, premise: `皇帝亲自来到${pName}${roomLabel}，正在此处与${npc.name}及同屋人互动；不得写成养心殿传召。` };
  enterIndoorView();
  setTimeout(() => document.getElementById(mode === 'intimate' ? 'btn-indoor-intimate' : 'btn-xly-chat').click(), 180);
}

async function openPalaceEavesdrop(pName, targetChar) {
  const staff = typeof getPalaceStaffResidents === 'function' ? getPalaceStaffResidents(pName) : [];
  if (!staff.length) {
    api.ui.toast('这座宫殿的耳房尚无人居住，无从探听');
    return;
  }
  document.getElementById('palace-eavesdrop-modal')?.remove();
  const modal = document.createElement('div');
  modal.id = 'palace-eavesdrop-modal';
  modal.style.cssText = 'position:fixed;inset:0;z-index:100500;background:rgba(8,5,3,0.9);backdrop-filter:blur(10px);display:flex;flex-direction:column;padding-top:var(--safe-top);font-family:"STZhongsong","STSong",serif;';
  modal.innerHTML = `<div style="height:54px;display:flex;align-items:center;justify-content:space-between;padding:0 16px;border-bottom:1px solid rgba(201,163,106,0.28);"><button id="eavesdrop-close" style="background:transparent;border:none;color:#999;font-family:inherit;font-size:15px;">‹ 返回</button><div style="color:#e7c990;font-size:17px;letter-spacing:4px;">暗中探听</div><div style="width:48px;"></div></div><div id="eavesdrop-body" style="flex:1;overflow-y:auto;padding:22px 20px calc(var(--safe-bottom) + 24px);color:#ddd;line-height:1.9;font-size:14px;"><div style="color:#a88d63;text-align:center;padding-top:30vh;">宫墙风细，正在听取耳房私语……</div></div>`;
  document.body.appendChild(modal);
  modal.querySelector('#eavesdrop-close').onclick = () => modal.remove();
  const prompt = `你是古代后宫群像剧情导演。皇帝正在${pName}墙外暗中探听，耳房里的侍从与宫女正在议论后妃「${targetChar.name}」。

【本轮重新读取的后妃与本宫耳房全员完整档案】
${buildCharactersAiContext([targetChar, ...staff])}

写一段300至600字的古风八卦现场。内容须从已给资料与记忆延伸，可有误解、偏见、试探与不同立场，但不要把未经证实之事写成绝对事实。至少3人参与；只能使用名单中的准确姓名。人物发言写成<p data-speaker="准确姓名">“台词”</p>，叙事写成<p>动作或环境</p>，不要Markdown、标题、代码块，不得替皇帝说话。

${getAiParagraphFormatGuard()}`;
  try {
    const result = await api.ai.chat({ messages: [{ role: 'user', content: prompt }] });
    const text = typeof result === 'string' ? result : (result?.content ?? result?.text ?? '');
    const safeBlocks = [...text.matchAll(/<p(?:\s+data-speaker="([^"]+)")?[^>]*>([\s\S]*?)<\/p>/g)].map(match => `<div style="margin-bottom:14px;${match[1] ? 'color:#f0d7a4;' : 'color:#aaa;font-style:italic;'}">${match[1] ? `<b style="color:#b69562;">${escHtml(match[1])}：</b>` : ''}${escHtml(match[2].replace(/<[^>]+>/g, ''))}</div>`).join('');
    modal.querySelector('#eavesdrop-body').innerHTML = safeBlocks || `<div style="white-space:pre-wrap;">${escHtml(text.replace(/<[^>]+>/g, ''))}</div>`;
    const timeStr = hudTime?.innerText || '时间不详';
    staff.forEach(person => {
      if (!Array.isArray(person.memorySeen)) person.memorySeen = [];
      person.memorySeen.unshift({ time: timeStr, text: `【耳房私语】众人在${pName}耳房议论${targetChar.name}，各自流露了不同态度。` });
    });
    await saveProgress({ courtNpcData: window._courtNpcData || [] });
  } catch (error) {
    modal.querySelector('#eavesdrop-body').innerHTML = '<div style="color:#888;text-align:center;padding-top:30vh;">风声掩语，未能听清，请稍后再试。</div>';
  }
}

function enterIndoorView() {
  const char = window.currentIndoorChar;
  const scene = window._indoorSceneContext || {};
  const residenceRoot = typeof getPalaceRootName === 'function' ? getPalaceRootName(char?.assignedPalace) : String(char?.assignedPalace || '').replace(/(正殿|东偏殿|西偏殿|耳房|庭院).*$/, '');
  const isAllowedResidenceVisit = scene.pName === '冷宫' || (scene.type === 'palace_visit' && scene.pName && scene.pName === residenceRoot);
  if (typeof isCharacterUnavailableForActivity === 'function' && isCharacterUnavailableForActivity(char) && !isAllowedResidenceVisit) {
    notifyCharacterUnavailable(char);
    return;
  }
  document.getElementById('indoor-bg-layer').style.backgroundImage = `url('${window._indoorSceneBgOverride || char.indoorBgUrl || ''}')`;
  const avatarAdjustButton = document.getElementById('btn-indoor-avatar-adj');
  const staffCtx = window._staffInteractionContext?.mainNpcId === char.id ? window._staffInteractionContext : null;
  if (!staffCtx) window._indoorPortraitParticipants = [char];

  // NPC 没有配置立绘时只显示背景；一旦在置度所配置，立即与普通角色同样显示。
  if (!hasCharacterPortrait(char)) {
    indoorAvatarImg.removeAttribute('src');
    indoorAvatarImg.style.display = 'none';
    avatarAdjustButton.style.display = 'none';
    window.currentIndoorDisplayChar = null;
    switchView(vIndoor);
    return;
  }

  indoorAvatarImg.style.display = '';
  avatarAdjustButton.style.display = 'flex';
  
  const displayAvatar = getCharacterPortraitUrl(char);
  indoorAvatarImg.src = displayAvatar;
  window.currentIndoorDisplayChar = char;
  
  if (char.storyAvatarCfg) {
    const cfg = char.storyAvatarCfg;
    indoorAvatarImg.style.transform = `translate(${cfg.x}px, ${cfg.y}px) scale(${cfg.scale / 100})`;
  } else {
    indoorAvatarImg.style.transform = 'translate(0px, 0px) scale(1)';
  }
  
  switchView(vIndoor);
}

document.getElementById('btn-exit-indoor').addEventListener('click', () => {
  switchView(vPalaceDetail);
});

document.getElementById('btn-indoor-bg').addEventListener('click', () => {
  const char = window.currentIndoorChar;
  if (window._indoorSceneContext?.type === 'palace_visit' && window._indoorSceneContext?.pName === '冷宫') {
    openColdPalaceBackgroundEditor();
    return;
  }
  currentDetailPalaceName = '__INDOOR__';
  pbTitle.innerText = `${char.name} · 重新绘景`;
  pbPrompt.value = `真实画风，中国古代皇宫室内，符合${char.assignedRank||'后妃'}身份的陈设，华丽，唯美，无人物`;
  pbImg.style.display = 'none';
  pbPlaceholder.style.display = 'block';
  pbLoader.style.display = 'none';
  btnPbConfirm.style.display = 'none';
  tempPbDataUrl = null;
  isCourtyardMode = false;
  pbModal.style.display = 'flex';
});

document.getElementById('btn-indoor-bgm').addEventListener('click', (e) => {
  e.stopPropagation();
  musicPanel.classList.toggle('open');
});

let indoorVoiceEnabled = true;
document.getElementById('btn-indoor-voice').addEventListener('click', (e) => {
  e.stopPropagation();
  indoorVoiceEnabled = !indoorVoiceEnabled;
  const btn = document.getElementById('btn-indoor-voice');
  document.getElementById('indoor-voice-on').style.display  = indoorVoiceEnabled ? 'block' : 'none';
  document.getElementById('indoor-voice-off').style.display = indoorVoiceEnabled ? 'none'  : 'block';
  btn.style.borderColor = indoorVoiceEnabled ? 'var(--primary-color)' : '#555';
  btn.style.color       = indoorVoiceEnabled ? 'var(--primary-color)' : '#555';
});

document.getElementById('btn-indoor-bubble-mode').addEventListener('click', toggleBubbleMode);
document.getElementById('btn-story-bubble-mode').addEventListener('click', toggleBubbleMode);
applyBubbleMode();

document.getElementById('btn-indoor-avatar-adj').addEventListener('click', () => {
  const char = window.currentIndoorDisplayChar || window.currentIndoorChar;
  if (!hasCharacterPortrait(char)) { api.ui.toast('当前说话者尚未设置立绘'); return; }
  if (!char.storyAvatarCfg) {
    char.storyAvatarCfg = { scale: 100, x: 0, y: 0 };
  }
  
  window.currentAdjChar = char;
  const storyAvatarAdjModal = document.getElementById('story-avatar-adj-modal');
  const rangeAdjScale = document.getElementById('adj-scale');
  const rangeAdjX = document.getElementById('adj-x');
  const rangeAdjY = document.getElementById('adj-y');
  
  rangeAdjScale.value = char.storyAvatarCfg.scale;
  rangeAdjX.value = char.storyAvatarCfg.x;
  rangeAdjY.value = char.storyAvatarCfg.y;
  
  storyAvatarAdjModal.dataset.fromIndoor = 'true';
  storyAvatarAdjModal.style.display = 'flex';
});

// --- 室内聊天逻辑 ---
function getIndoorChatContext(char) {
  const timeStr = hudTime.innerText;
  let wbText = "";
  if (userAncientDesc) wbText += `【皇帝（User）人设】：\n${userAncientDesc}\n\n`;
  if (window.globalWorldDesc) wbText += `【大世界设定】：\n${window.globalWorldDesc}\n\n`;
  if (window.globalRulesDesc) wbText += `【后宫规矩与皇权设定】：\n${window.globalRulesDesc}\n\n`;
  if (rankData && rankData.length > 0) {
    wbText += `【后宫位份体系】：\n` + rankData.map(r => `- ${r.rank} (自称:${r.selfClaim})`).join('\n') + `\n\n`;
  }

  // 完整人设（原始版，不被时间/位份追加污染）
  let desc = char.ancientDescOriginal || char.ancientDesc.replace(/^【当前游戏时间】：[^\n]*\n?/, '').replace(/【当前后宫位份体系（由高到低）】[\s\S]*/, '');

  // 专属世界书
  let charWb = char.charWorldDesc ? `\n【专属人物世界书】：\n${char.charWorldDesc}` : '';

  // TA看到的（memorySeen）
  let memoryText = (char.memorySeen || []).map(m => `[${m.time}] ${m.text}`).join('\n') || '无';

  // TA了解的（memoryKnown：位份、关系图谱、性别等）
  let knownText = (char.memoryKnown || []).join('\n') || '无';

  // TA的思绪（与亲历记忆分开发送，续写时也会重新读取）
  let thoughtsText = (char.memorySeen || []).filter(m => m?._isReflect || String(m?.text || '').startsWith('【思绪】')).map(m => `[${m.time || '时间不详'}] ${m.text || m}`).join('\n') || '无';

  // 起居注（records，最近10条）
  let recText = (char.records || []).slice(0, 10).map(r => `[${r.time}] ${r.text}`).join('\n') || '无';

  // 关系图谱（该角色对他人的看法）
  const allC = [...selectedCharsData, XLY_CHAR];
  const relLines = [];
  allC.filter(c => c.name !== char.name).forEach(other => {
    const key = `${char.name}->${other.name}`;
    const rel = window._relationData?.[key];
    if (rel?.text) relLines.push(`对${other.name}：${rel.text}`);
  });
  let relText = relLines.length > 0 ? relLines.join('\n') : '无';

  const staffCtx = window._staffInteractionContext?.mainNpcId === char.id ? window._staffInteractionContext : null;
  let roommateText = '';
  if (staffCtx) {
    roommateText = staffCtx.roommates.map(person => `- ${person.name}（${person.ancientRole}）：${person.ancientDesc || '无介绍'}；性格${person.rosterPersonality || '未定'}；状态${person.rosterMood || '未定'}；忠诚度${person.loyalty ?? 0}`).join('\n');
    wbText += `【当前多人耳房】\n地点：${staffCtx.pName}${staffCtx.roomLabel}\n同屋全员：\n${roommateText}\n\n`;
  }

  return { timeStr, wbText, desc, charWb, memoryText, knownText, thoughtsText, recText, relText, staffCtx, roommateText };
}

document.getElementById('btn-xly-chat').addEventListener('click', async () => {
  const char = window.currentIndoorChar;
  document.getElementById('indoor-bottom-bar').style.opacity = '0';
  setTimeout(() => document.getElementById('indoor-bottom-bar').style.display = 'none', 300);
  
  document.getElementById('indoor-chat-wrap').style.display = 'flex';
  document.getElementById('indoor-chat-box').innerText = "正在酝酿思绪...";
  document.getElementById('indoor-chat-box').style.opacity = '1';
  document.getElementById('indoor-blocker').style.display = 'block';
  
  indoorChatContext.history = [];
  indoorChatContext.mode = 'chat';
  
  const ctx = getIndoorChatContext(char);
  const charGender = char.gender || (char.memoryKnown||[]).find(k=>k.startsWith('【性别】'))?.replace('【性别】：','') || '未知';
  let sysPrompt = customPrompts.indoorChatOpen || defaultPrompts.indoorChatOpen;
  sysPrompt = sysPrompt
    .replace('{{timeStr}}', ctx.timeStr)
    .replace('{{pName}}', currentDetailPalaceName)
    .replace(/\{\{charName\}\}/g, char.name)
    .replace('{{charGender}}', charGender)
    .replace('{{wbText}}', ctx.wbText)
    .replace('{{assignedRank}}', char.assignedRank || '无')
    .replace('{{desc}}', ctx.desc)
    .replace('{{charWb}}', ctx.charWb)
    .replace('{{knownText}}', ctx.knownText)
    .replace('{{memoryText}}', ctx.memoryText)
    .replace('{{recText}}', ctx.recText)
    .replace('{{relText}}', ctx.relText);
  const sceneCtx = window._indoorSceneContext || {};
  const openingParticipants = ctx.staffCtx?.roommates?.length ? ctx.staffCtx.roommates : [char];
  sysPrompt += `\n\n【本轮真实场景前提】\n${sceneCtx.premise || `皇帝与${char.name}正在${currentDetailPalaceName || '当前宫殿'}相见。`}\n${buildCharactersAiContext(openingParticipants)}\n\n${getAiParagraphFormatGuard()}`;
  if (ctx.staffCtx) sysPrompt += `\n\n【多人耳房强制规则】这是与${char.name}在${ctx.staffCtx.pName}${ctx.staffCtx.roomLabel}发生的对话。每一轮都必须自然描写至少一名同屋人的动作、神态、插话或暗中反应；同屋人只能使用上方名单中的准确姓名。人物发言继续使用<p data-speaker="准确姓名">台词</p>，叙事用<p>描写</p>，不得替皇帝说话。`;

  try {
    const res = await api.ai.chat({ messages:[{role:"user", content:sysPrompt}] });
    const text = typeof res === 'string' ? res : (res?.content ?? res?.text ?? '');
    playIndoorChat(text);
  } catch(e) {
    document.getElementById('indoor-chat-box').innerText = "对话开启失败，请重试。";
    document.getElementById('indoor-bottom-bar').style.display = 'flex';
    document.getElementById('indoor-bottom-bar').style.opacity = '1';
    document.getElementById('indoor-chat-wrap').style.display = 'none';
    document.getElementById('indoor-blocker').style.display = 'none';
  }
});

document.getElementById('btn-indoor-records').addEventListener('click', () => {
  if (window.currentIndoorChar) {
    openCharRecords(window.currentIndoorChar);
  }
});

document.getElementById('btn-indoor-manage').addEventListener('click', () => {
  const char = window.currentIndoorChar;
  if (!char) return;
  if (typeof openPalaceDisciplineManagement === 'function') openPalaceDisciplineManagement(char);
  else api.ui.toast('人物管理功能尚未载入');
});

document.getElementById('btn-indoor-intimate').addEventListener('click', async () => {
  const char = window.currentIndoorChar;
  document.getElementById('indoor-bottom-bar').style.opacity = '0';
  setTimeout(() => document.getElementById('indoor-bottom-bar').style.display = 'none', 300);
  
  document.getElementById('indoor-chat-wrap').style.display = 'flex';
  document.getElementById('indoor-chat-box').innerText = "红帐暖香，正在推演...";
  document.getElementById('indoor-chat-box').style.opacity = '1';
  document.getElementById('indoor-blocker').style.display = 'block';
  
  indoorChatContext.history = [];
  indoorChatContext.mode = 'intimate';
  
  const ctx = getIndoorChatContext(char);
  const charGender2 = char.gender || (char.memoryKnown||[]).find(k=>k.startsWith('【性别】'))?.replace('【性别】：','') || '未知';
  let sysPrompt = customPrompts.indoorIntimateOpen || defaultPrompts.indoorIntimateOpen;
  sysPrompt = sysPrompt
    .replace('{{timeStr}}', ctx.timeStr)
    .replace('{{pName}}', currentDetailPalaceName)
    .replace(/\{\{charName\}\}/g, char.name)
    .replace('{{charGender}}', charGender2)
    .replace('{{wbText}}', ctx.wbText)
    .replace('{{assignedRank}}', char.assignedRank || '无')
    .replace('{{desc}}', ctx.desc)
    .replace('{{charWb}}', ctx.charWb)
    .replace('{{knownText}}', ctx.knownText)
    .replace('{{memoryText}}', ctx.memoryText)
    .replace('{{recText}}', ctx.recText)
    .replace('{{relText}}', ctx.relText);
  const sceneCtx = window._indoorSceneContext || {};
  const openingParticipants = ctx.staffCtx?.roommates?.length ? ctx.staffCtx.roommates : [char];
  sysPrompt += `\n\n【本轮真实场景前提】\n${sceneCtx.premise || `皇帝与${char.name}正在${currentDetailPalaceName || '当前宫殿'}相见。`}\n${buildCharactersAiContext(openingParticipants)}\n\n${getAiParagraphFormatGuard()}`;
  if (ctx.staffCtx) sysPrompt += `\n\n【多人耳房强制规则】地点是${ctx.staffCtx.pName}${ctx.staffCtx.roomLabel}，${char.name}与同屋人共同居住，所有登场人物均为成年人。剧情必须符合平台允许的含蓄古风表达，并在每一轮交代同屋人的回避、惊讶、窃语、掩门或其他在场反应；同屋人只能使用上方名单中的准确姓名。人物发言使用<p data-speaker="准确姓名">台词</p>，叙事使用<p>描写</p>，不得替皇帝说话。`;

  try {
    const res = await api.ai.chat({ messages:[{role:"user", content:sysPrompt}] });
    const text = typeof res === 'string' ? res : (res?.content ?? res?.text ?? '');
    playIndoorChat(text);
  } catch(e) {
    document.getElementById('indoor-chat-box').innerText = "推演失败，请重试。";
    document.getElementById('indoor-bottom-bar').style.display = 'flex';
    document.getElementById('indoor-bottom-bar').style.opacity = '1';
    document.getElementById('indoor-chat-wrap').style.display = 'none';
    document.getElementById('indoor-blocker').style.display = 'none';
  }
});

function playIndoorChat(fullText) {
  const pRegex = /<p(?:[^>]*)>(.*?)<\/p>/g;
  indoorChatContext.segments = [];
  let match;
  while ((match = pRegex.exec(fullText)) !== null) {
    const content = String(match[1] || '').replace(/^\s*[【\[]?(?:旁白|叙述|Narrator)[】\]]?\s*[:：]?\s*/i, '').trim();
    let speaker = null;
    speaker = extractStorySpeakerFromTag(match[0]);
    if (/^(?:旁白|叙述|Narrator)$/i.test(String(speaker || '').trim())) speaker = null;
    if (content && !/^[【\[]?(?:旁白|叙述|Narrator)[】\]]?$/i.test(content)) indoorChatContext.segments.push({ type: speaker ? 'dialogue' : 'desc', speaker, text: content });
  }
  if (indoorChatContext.segments.length === 0) {
    indoorChatContext.segments = fullText.replace(/<[^>]+>/g, '').split('\n')
      .map(line => line.replace(/^\s*[【\[]?(?:旁白|叙述|Narrator)[】\]]?\s*[:：]?\s*/i, '').trim())
      .filter(Boolean).map(text => ({ type:'desc', speaker:null, text }));
  }
  indoorChatContext.currentIdx = 0;
  showNextIndoorSegment();
}

function setIndoorTapHandler(fn) {
  const blocker = document.getElementById('indoor-blocker');
  const textBox = document.getElementById('indoor-chat-box').parentElement;
  if (indoorChatContext.tapHandler) {
    blocker.removeEventListener('click', indoorChatContext.tapHandler);
    textBox.removeEventListener('click', indoorChatContext.tapHandler);
  }
  indoorChatContext.tapHandler = fn;
  if (fn) {
    blocker.addEventListener('click', fn);
    textBox.addEventListener('click', fn);
  }
}

function showNextIndoorSegment() {
  const textWrap = document.getElementById('indoor-chat-wrap');
  const controls = document.getElementById('indoor-chat-controls');
  
  if (indoorChatContext.currentIdx >= indoorChatContext.segments.length) {
    document.getElementById('indoor-chat-box').innerHTML = '<span style="color:#888;font-size:13px;">— 等待您的言行 —</span>';
    controls.style.display = 'flex';
    // 根据上面按钮的实际高度动态上推文字框，避免重叠
    const controlsHeight = controls.offsetHeight;
    textWrap.style.bottom = `calc(var(--safe-bottom) + ${controlsHeight + 20}px)`;
    setIndoorTapHandler(null);
    document.getElementById('indoor-blocker').style.display = 'none';
    return;
  }
  
  // 播放时确保气泡贴底
  textWrap.style.bottom = 'calc(var(--safe-bottom) + 8px)';
  setIndoorTapHandler(null);
  
  const seg = indoorChatContext.segments[indoorChatContext.currentIdx];
  indoorChatContext.history.push(seg);

  const chatBox = document.getElementById('indoor-chat-box');
  textWrap.style.opacity = '0'; // 连框一起淡出
  chatBox.style.opacity = '0';

  // 处理多人模式下的立绘动态跳出
  const multiContainer = document.getElementById('fanpai-multi-container');
  if (multiContainer && window._fanPaiChosenChars) {
    const avatarImg = document.getElementById('fanpai-multi-avatar-img');
    const avatarName = document.getElementById('fanpai-multi-avatar-name');
    let targetChar = null;
    if (seg.speaker && seg.speaker !== '皇帝') {
      targetChar = window._fanPaiChosenChars.find(c => c.name === seg.speaker);
    }
    
    if (targetChar) {
      window.currentStoryDisplayChar = targetChar;
      const displayAvatar = targetChar.customAvatar || targetChar.avatar;
      const applyTargetCharTransform = () => {
        if (targetChar.storyAvatarCfg) {
          const cfg = targetChar.storyAvatarCfg;
          avatarImg.style.transform = `translate(${cfg.x}px, ${cfg.y}px) scale(${cfg.scale / 100})`;
        } else {
          avatarImg.style.transform = 'translate(0px, 0px) scale(1)';
        }
      };
      
      if (avatarImg.src !== displayAvatar || avatarName.innerText !== targetChar.name) {
        multiContainer.style.opacity = '0';
        setTimeout(() => {
          avatarImg.src = displayAvatar;
          avatarName.innerText = targetChar.name;
          applyTargetCharTransform();
          multiContainer.style.display = 'flex';
          multiContainer.offsetHeight; // 强制重绘
          multiContainer.style.opacity = '1';
        }, 300);
      } else {
        applyTargetCharTransform();
        multiContainer.style.display = 'flex';
        multiContainer.offsetHeight;
        multiContainer.style.opacity = '1';
      }
    } else {
      window.currentStoryDisplayChar = null;
      multiContainer.style.opacity = '0';
      setTimeout(() => { multiContainer.style.display = 'none'; }, 400);
    }
  }
  if ((!multiContainer || !window._fanPaiChosenChars) && Array.isArray(window._indoorPortraitParticipants)) {
    const speakerChar = window._indoorPortraitParticipants.find(char => char.name === seg.speaker);
    if (speakerChar && hasCharacterPortrait(speakerChar)) {
      const cfg = speakerChar.storyAvatarCfg || { scale: 100, x: 0, y: 0 };
      indoorAvatarImg.src = getCharacterPortraitUrl(speakerChar);
      indoorAvatarImg.style.transform = `translate(${cfg.x}px, ${cfg.y}px) scale(${cfg.scale / 100})`;
      indoorAvatarImg.style.display = '';
      document.getElementById('btn-indoor-avatar-adj').style.display = 'flex';
      window.currentIndoorDisplayChar = speakerChar;
    } else if (seg.speaker) {
      indoorAvatarImg.style.display = 'none';
      document.getElementById('btn-indoor-avatar-adj').style.display = 'none';
      window.currentIndoorDisplayChar = null;
    }
  }
  
  setTimeout(async () => {
    chatBox.innerHTML = '';
    textWrap.style.opacity = '1'; // 框淡入
    chatBox.style.opacity = '1';
    
    setIndoorTapHandler(() => { skipTypewriter(); });
    await playTypewriter(chatBox, seg.text, 2500);
    
    if (indoorVoiceEnabled && seg.speaker) {
      const char = (window._indoorPortraitParticipants || []).find(person => person.name === seg.speaker) || window.currentIndoorChar;
      const pref = char.voicePref || {};
      // 根据朗读范围决定是否朗读
      if (pref.readMode === 'none') {
        indoorChatContext.currentIdx++;
        setIndoorTapHandler(() => { showNextIndoorSegment(); });
        return;
      }
      const speechMatch = seg.text.match(/"([^"]+)"/);
      let textToRead;
      if (pref.readMode === 'all_text') {
        textToRead = seg.text.replace(/<[^>]+>/g, '');
      } else {
        textToRead = speechMatch ? speechMatch[1] : seg.text.replace(/<[^>]+>/g, '');
      }
      if (pref.customPrefix) textToRead = pref.customPrefix + textToRead;
      if (pref.customSuffix) textToRead = textToRead + pref.customSuffix;
      indoorChatContext.abortVoice = false;
      indoorChatContext.currentIdx++;
      
      setIndoorTapHandler(() => {
        indoorChatContext.abortVoice = true;
        try { api.voice.stop && api.voice.stop(); } catch(e) {}
        showNextIndoorSegment();
      });
      
      try {
        const ttsArgs = { characterId: char.id, text: textToRead };
        if (pref.emotion && pref.emotion !== 'neutral') ttsArgs.emotion = pref.emotion;
        const s = await api.voice.tts(ttsArgs);
        if (!indoorChatContext.abortVoice) {
          await api.voice.play({ dataUrl: s.dataUrl });
        }
      } catch(e) {}
      
      if (!indoorChatContext.abortVoice) {
        setIndoorTapHandler(() => { showNextIndoorSegment(); });
      }
      return;
    }
    
    indoorChatContext.currentIdx++;
    setIndoorTapHandler(() => { showNextIndoorSegment(); });
  }, 400);
}

document.getElementById('btn-inchat-replay').addEventListener('click', () => {
  // 重听：回到本次生成的最初一句
  if (indoorChatContext.segments.length > 0) {
    // 因为 history 里已经 push 进去了，所以要把本次生成的片段从 history 里扒出来
    const segCount = indoorChatContext.segments.length;
    if (indoorChatContext.history.length >= segCount) {
      indoorChatContext.history.splice(indoorChatContext.history.length - segCount, segCount);
    } else {
      indoorChatContext.history = [];
    }
    indoorChatContext.currentIdx = 0;
    document.getElementById('indoor-chat-controls').style.display = 'none';
    document.getElementById('indoor-blocker').style.display = 'block';
    showNextIndoorSegment();
  }
});

document.getElementById('btn-inchat-reroll').addEventListener('click', () => {
  // 重新生成：删掉 user 最后发的一句话（如果有的话），然后重新触发发送
  // 找到上一句 user 说话的位置
  let lastUserIdx = -1;
  for (let i = indoorChatContext.history.length - 1; i >= 0; i--) {
    if (indoorChatContext.history[i].type === 'user') {
      lastUserIdx = i;
      break;
    }
  }
  
  if (lastUserIdx !== -1) {
    // 截断到 user 发话之前，并重新发送这句话
    const userText = indoorChatContext.history[lastUserIdx].text;
    indoorChatContext.history = indoorChatContext.history.slice(0, lastUserIdx);
    document.getElementById('indoor-chat-input').value = userText;
    document.getElementById('btn-inchat-send').click();
  } else {
    // 第一句话的重新生成（无 user 历史）
    indoorChatContext.history = [];
    document.getElementById('btn-xly-chat').click();
  }
});

// 原来的 btn-inchat-send 监听器改为直接赋值，避免与拦截逻辑冲突
document.getElementById('btn-inchat-send').onclick = async (e) => {
  if (indoorChatContext.mode === 'dishi_zouzhe') return; // 如果是帝师模式，交给拦截器处理
  const input = document.getElementById('indoor-chat-input');
  if(!input.value.trim()) return;
  const userText = input.value.trim();
  indoorChatContext.history.push({ type:'user', speaker:'皇帝', text: userText });
  input.value = '';
  
  document.getElementById('indoor-chat-box').innerText = "TA正在思索...";
  document.getElementById('indoor-chat-controls').style.display = 'none';
  document.getElementById('indoor-chat-wrap').style.bottom = 'calc(var(--safe-bottom) + 8px)';
  document.getElementById('indoor-blocker').style.display = 'block';
  
  const historyText = indoorChatContext.history.map(x => `${x.speaker?x.speaker:'叙事段'}：${x.text}`).join('\n');
  let sysPrompt = customPrompts.indoorChatReply || defaultPrompts.indoorChatReply;
  sysPrompt = sysPrompt
    .replace('{{charName}}', window.currentIndoorChar.name)
    .replace('{{historyText}}', historyText);
  let replyParticipants = Array.isArray(window._fanPaiChosenChars) && window._fanPaiChosenChars.length
    ? window._fanPaiChosenChars
    : [window.currentIndoorChar];
  const activeStaffCtx = window._staffInteractionContext?.mainNpcId === window.currentIndoorChar.id ? window._staffInteractionContext : null;
  if (activeStaffCtx?.roommates?.length) replyParticipants = activeStaffCtx.roommates;
  const sceneCtx = window._indoorSceneContext || {};
  sysPrompt += `\n\n【本轮必须重新读取的全局设定】\n${buildGlobalAiContext()}\n\n【本轮必须重新读取的全部在场人物档案】\n${buildCharactersAiContext(replyParticipants)}\n\n【不可改变的场景前提】\n${sceneCtx.premise || `皇帝与${replyParticipants.map(char => char.name).join('、')}仍在${currentDetailPalaceName || '当前宫殿'}继续上一轮互动。`}\n\n${getAiParagraphFormatGuard()}`;
  const staffCtx = window._staffInteractionContext?.mainNpcId === window.currentIndoorChar.id ? window._staffInteractionContext : null;
  if (staffCtx) {
    const roommates = staffCtx.roommates.map(person => `${person.name}（${person.ancientRole}，${person.rosterPersonality || '性格未定'}，${person.rosterMood || '状态未定'}）`).join('、');
    sysPrompt += `\n\n当前是${staffCtx.pName}${staffCtx.roomLabel}的多人剧情。同屋人：${roommates}。继续回应皇帝最新言行，并且本轮必须描写至少一名同屋人的真实反应。发言严格使用<p data-speaker="准确姓名">台词</p>，叙事用<p>描写</p>；不得杜撰名单外同屋人，不得替皇帝发言。`;
  }
  sysPrompt += `\n\n${getLongPlotContinuationGuard()}`;

  try {
    const res = await api.ai.chat({ messages:[{role:"user", content:sysPrompt}] });
    const text = typeof res === 'string' ? res : (res?.content ?? res?.text ?? '');
    playIndoorChat(text);
  } catch(e) {
    document.getElementById('indoor-chat-box').innerText = "回复失败。";
    document.getElementById('indoor-chat-controls').style.display = 'flex';
    document.getElementById('indoor-blocker').style.display = 'none';
  }
};

// 室内对话 - 履历功能（复用剧情履历的UI）
document.getElementById('btn-inchat-history').addEventListener('click', () => {
  historyList.innerHTML = indoorChatContext.history.map((h, i) => `
    <div style="border-bottom:1px solid #333; padding-bottom:12px;">
      <div style="color:${h.speaker==='皇帝'?'var(--primary-color)':(h.speaker?'#fff':'#888')}; font-size:12px; margin-bottom:4px;">${escHtml(h.speaker) || '旁白'}</div>
      <textarea class="hist-edit" data-idx="${i}" style="width:100%; min-height:40px; background:transparent; border:none; color:#ccc; resize:vertical; font-family:inherit; font-size:14px;">${escHtml(h.text)}</textarea>
      <div style="display:flex; justify-content:flex-end; gap:6px; margin-top:4px; flex-wrap:wrap;">
        <button class="hist-del" data-idx="${i}" style="background:transparent; border:1px solid #555; color:#777; padding:2px 8px; border-radius:4px; font-size:12px;">删除</button>
        <button class="hist-goto" data-idx="${i}" style="background:transparent; border:1px solid #888; color:#aaa; padding:2px 8px; border-radius:4px; font-size:12px;">定位到此</button>
        <button class="hist-reroll" data-idx="${i}" style="background:rgba(201,163,106,0.15); border:1px solid var(--primary-color); color:var(--primary-color); padding:2px 8px; border-radius:4px; font-size:12px;">从此重推</button>
      </div>
    </div>
  `).join('');
  
  historyList.querySelectorAll('.hist-edit').forEach(ta => {
    ta.addEventListener('change', e => { indoorChatContext.history[e.target.dataset.idx].text = e.target.value; });
  });
  historyList.querySelectorAll('.hist-del').forEach(btn => {
    btn.addEventListener('click', e => {
      indoorChatContext.history.splice(e.target.dataset.idx, 1);
      document.getElementById('btn-inchat-history').click();
    });
  });
  
  // 室内模式也开放“定位到此”功能
  historyList.querySelectorAll('.hist-goto').forEach(btn => {
    btn.style.display = 'inline-block';
    btn.addEventListener('click', e => {
      const idx = parseInt(e.target.dataset.idx);
      historyModal.style.display = 'none';
      
      const savedHistory = indoorChatContext.history.slice(0, idx);
      const remainingSegs = indoorChatContext.history.slice(idx).map(s => Object.assign({}, s));
      
      indoorChatContext.history = savedHistory;
      indoorChatContext.segments = remainingSegs;
      indoorChatContext.currentIdx = 0;
      
      indoorChatContext.abortVoice = true;
      try { api.voice.stop && api.voice.stop(); } catch(e) {}
      setIndoorTapHandler(null);
      document.getElementById('indoor-chat-controls').style.display = 'none';
      document.getElementById('indoor-blocker').style.display = 'block';
      showNextIndoorSegment();
    });
  });

  historyList.querySelectorAll('.hist-reroll').forEach(btn => {
    btn.addEventListener('click', e => {
      const idx = parseInt(e.target.dataset.idx);
      indoorChatContext.history = indoorChatContext.history.slice(0, idx);
      historyModal.style.display = 'none';
      
      let lastUserIdx = -1;
      for (let i = indoorChatContext.history.length - 1; i >= 0; i--) {
        if (indoorChatContext.history[i].type === 'user') {
          lastUserIdx = i;
          break;
        }
      }
      
      if (lastUserIdx !== -1) {
        const userText = indoorChatContext.history[lastUserIdx].text;
        indoorChatContext.history = indoorChatContext.history.slice(0, lastUserIdx);
        document.getElementById('indoor-chat-input').value = userText;
        
        // 隐藏控制区，下推文字框
        const textWrap = document.getElementById('indoor-chat-wrap');
        document.getElementById('indoor-chat-controls').style.display = 'none';
        textWrap.style.bottom = 'calc(var(--safe-bottom) + 20px)';
        
        document.getElementById('btn-inchat-send').click();
      } else {
        indoorChatContext.history = [];
        document.getElementById('btn-xly-chat').click();
      }
    });
  });
  
  historyModal.style.display = 'flex';
});

// 通用添加记事函数：
// 如果包含“众谈”标签，只同步给后宫角色和侍从、宫女；否则只给指定 char 发。
// 由于所有妃嫔的记事在“养心殿”都能看到，养心殿不需要单独存，渲染时聚合即可。
function getHaremPublicRecordRecipients() {
  const people = [
    ...selectedCharsData.filter(person => person.ancientRole === '后妃'),
    ...(typeof getAllGameNpcs === 'function' ? getAllGameNpcs() : (window._courtNpcData || []))
      .filter(person => person.npcType === 'attendant' || person.npcType === 'maid' || person.ancientRole === '侍从' || person.ancientRole === '宫女')
  ];
  const seen = new Set();
  return people.filter(person => {
    const key = person?.id || person?.name;
    if (!key || seen.has(key)) return false;
    seen.add(key);
    return true;
  });
}

async function addRecord(char, text, type = 'system', tags = []) {
  const rec = { id: generateId(), time: hudTime.innerText, text, owner: char?.name || '', type, tags };
  
  if (tags.includes('众谈')) {
    getHaremPublicRecordRecipients().forEach(person => {
      if (!Array.isArray(person.records)) person.records = [];
      person.records.unshift({ ...rec });
      if (!Array.isArray(person.memorySeen)) person.memorySeen = [];
      if (!person.memorySeen.some(item => item?._publicChatRecordId === rec.id)) {
        person.memorySeen.unshift({ time: rec.time, text: `【众谈】${text}`, _publicChatRecordId: rec.id });
      }
    });
  } else {
    if (char) {
      if (!char.records) char.records = [];
      char.records.unshift(rec);
    }
  }
  
  if (tags.includes('众谈')) {
    await saveProgress({ characters: selectedCharsData, courtNpcData: window._courtNpcData || [] });
  } else if (char?._isGameNpc) {
    await saveProgress({ courtNpcData: window._courtNpcData || [] });
  } else if (char._isScenarioChar) {
    window._xlyRecords = XLY_CHAR.records;
    await saveProgress({ xlyRecords: XLY_CHAR.records });
  } else {
    await saveProgress({ characters: selectedCharsData });
  }
}

// 自动记事：闲聊（众谈）
function getRecordCharacterDisplayName(char) {
  if (!char) return '无名之人';
  if (char.ancientRole === '后妃') {
    const rank = char.assignedRank || '后妃';
    const title = char.honorificTitle ? `·${char.honorificTitle}` : '';
    return `${rank}${title}${char.name}`;
  }
  return `${char.ancientRole || char.assignedRank || '故人'}${char.name}`;
}

async function autoRecordChat(char) {
  if (!autoRecordSettings.chat) return;
  const tStr = hudTime.innerText;
  const text = `皇帝履及${char.assignedPalace || '此地'}，与${getRecordCharacterDisplayName(char)}闲话片刻，言笑晏晏，不知所谈何事。`;
  const isHaremCircle = char?.ancientRole === '后妃' || char?.npcType === 'attendant' || char?.npcType === 'maid' || char?.ancientRole === '侍从' || char?.ancientRole === '宫女';
  await addRecord(char, text, 'system', isHaremCircle ? ['众谈'] : ['前朝']);
}

// 自动记事：临幸（彤录）
async function autoRecordIntimate(char) {
  if (!autoRecordSettings.intimate) return;
  const tStr = hudTime.innerText;
  const text = `皇帝留宿${char.assignedPalace || '此地'}，红罗帐暖，春宵一刻，赐${getRecordCharacterDisplayName(char)}雨露之恩。`;
  await addRecord(char, text, 'system', ['彤录']);
}

// 室内对话 - 结束保存逻辑
document.getElementById('btn-inchat-exit').addEventListener('click', () => {
  // 翻牌子有独立的多人侍寝结算弹窗，避免两个退出弹窗同时出现。
  if (Array.isArray(window._fanPaiChosenChars) && window._fanPaiChosenChars.length) return;
  document.getElementById('indoor-save-modal').style.display = 'flex';
});
document.getElementById('btn-insave-cancel').addEventListener('click', () => {
  document.getElementById('indoor-save-modal').style.display = 'none';
});
document.getElementById('btn-insave-forget').addEventListener('click', () => {
  document.getElementById('indoor-save-modal').style.display = 'none';
  closeIndoorChat();
});

function getIndoorCompleteMemoryText() {
  const modeName = indoorChatContext.mode === 'intimate' ? '临幸' : '闲聊';
  const lines = indoorChatContext.history
    .map(item => `${item.speaker || '叙事'}：${String(item.text || '').trim()}`)
    .filter(Boolean);
  return `【${modeName}完整剧情】\n${lines.join('\n')}`;
}

function openIndoorMemoryConfirmation(content, memoryMode) {
  const indoorChar = window.currentIndoorChar;
  pendingMemorySummary = content;
  memorySummaryInput.value = content;
  window._pendingMemoryFlow = {
    type: 'indoor',
    char: indoorChar,
    staffCtx: window._staffInteractionContext?.mainNpcId === indoorChar?.id ? window._staffInteractionContext : null,
    indoorMode: indoorChatContext.mode,
    memoryMode
  };
  const title = document.getElementById('memory-confirm-title');
  if (title) title.innerText = memoryMode === 'full' ? '确认完整剧情记录' : '确认记忆小结';
  document.getElementById('memory-confirm-hint').innerText = memoryMode === 'full'
    ? '确认后将本次全部剧情原文录入当前人物的「TA看到的」'
    : '确认后将AI小结录入当前人物的「TA看到的」';
  memoryConfirmModal.style.display = 'flex';
}

function restoreIndoorMemoryMoment(message = '记忆处理失败，请重新选择录入方式') {
  document.getElementById('indoor-save-modal').style.display = 'none';
  memoryConfirmModal.style.display = 'none';
  window._pendingMemoryFlow = null;
  const chatWrap = document.getElementById('indoor-chat-wrap');
  const chatBox = document.getElementById('indoor-chat-box');
  const controls = document.getElementById('indoor-chat-controls');
  const last = indoorChatContext.history[indoorChatContext.history.length - 1];
  chatWrap.style.display = 'flex';
  chatWrap.style.opacity = '1';
  chatBox.style.opacity = '1';
  chatBox.innerHTML = last
    ? `${last.speaker ? `<span style="color:#d9bd83;font-size:12px;letter-spacing:2px;">【${escHtml(last.speaker)}】</span><br>` : ''}${escHtml(last.text)}`
    : '<span style="color:#888;">— 本轮剧情仍在，可重新选择记忆方式 —</span>';
  controls.style.display = 'flex';
  chatWrap.style.bottom = `calc(var(--safe-bottom) + ${controls.offsetHeight + 20}px)`;
  document.getElementById('indoor-blocker').style.display = 'none';
  setIndoorTapHandler(null);
  api.ui.toast(message);
}

document.getElementById('btn-insave-full').addEventListener('click', () => {
  document.getElementById('indoor-save-modal').style.display = 'none';
  const completeMemory = getIndoorCompleteMemoryText();
  if (!indoorChatContext.history.length || !completeMemory.trim()) {
    restoreIndoorMemoryMoment('当前没有可录入的完整剧情');
    return;
  }
  openIndoorMemoryConfirmation(completeMemory, 'full');
});
document.getElementById('btn-insave-remember').addEventListener('click', async () => {
  document.getElementById('indoor-save-modal').style.display = 'none';
  
  const chatBox = document.getElementById('indoor-chat-box');
  const controls = document.getElementById('indoor-chat-controls');
  
  chatBox.innerHTML = '<span style="color:var(--primary-color);">正在提炼记忆小结...</span>';
  controls.style.display = 'none';
  document.getElementById('indoor-blocker').style.display = 'block';
  
  const historyText = indoorChatContext.history.map(x => `${x.speaker?x.speaker:'叙事段'}：${x.text}`).join('\n');
  const sysPrompt = `请把以下刚发生的私下剧情（闲聊或临幸），总结为一段不超过200字的客观陈述，作为角色的核心记忆。
剧情记录：
${historyText}`;

  try {
    const res = await api.ai.chat({ messages:[{role:"user", content:sysPrompt}] });
    const summary = String(typeof res === 'string' ? res : (res?.content ?? res?.text ?? '')).trim();
    if (!summary) throw new Error('empty memory summary');
    openIndoorMemoryConfirmation(summary, 'summary');
  } catch(e) {
    restoreIndoorMemoryMoment('小结生成失败，剧情已保留，可重新生成');
  }
});

function closeIndoorChat() {
  document.getElementById('indoor-chat-controls').style.display = 'none';
  document.getElementById('indoor-chat-wrap').style.display = 'none';
  document.getElementById('indoor-chat-box').innerHTML = ''; // 清空内容
  const bar = document.getElementById('indoor-bottom-bar');
  bar.style.display = 'flex';
  setTimeout(() => bar.style.opacity = '1', 50);
  if (window._staffInteractionContext?.mainNpcId === window.currentIndoorChar?.id) window._staffInteractionContext = null;
  window._indoorPortraitParticipants = null;
  window.currentIndoorDisplayChar = null;
  window._indoorSceneContext = null;
}

// === 10. Story Player ===
let storyContext = { pName:"", rName:"", mainChar:null, history:[] };
const storyActiveCard = document.getElementById('story-active-card');
const storyCardImg = document.getElementById('story-card-img');
const storyCardName = document.getElementById('story-card-name');
const storyTextBox = document.getElementById('story-text-box');
const storyControls = document.getElementById('story-controls');
let storyVoiceEnabled = true; // 声音开关，默认开

// ===== 御花园 · 喝茶 / 四处走走 =====
function getImperialGardenCharacterPool(includeUnavailable = false) {
  const pool = [...selectedCharsData];
  if (typeof XLY_CHAR !== 'undefined' && XLY_CHAR) pool.push(XLY_CHAR);
  const seen = new Set();
  return pool.filter(char => {
    const key = char?.id || char?.name;
    if (!key || seen.has(key) || (!includeUnavailable && typeof isCharacterUnavailableForActivity === 'function' && isCharacterUnavailableForActivity(char))) return false;
    seen.add(key);
    return true;
  });
}

function getEntourageForCharacters(chars) {
  const ids = new Set((chars || []).filter(char => char?.ancientRole === '后妃').map(char => char.id));
  const names = new Set((chars || []).filter(char => char?.ancientRole === '后妃').map(char => char.name));
  const npcs = typeof getAllGameNpcs === 'function' ? getAllGameNpcs() : (window._courtNpcData || []);
  return npcs.filter(npc => npc?.npcType && (ids.has(npc.masterId) || names.has(npc.masterName)));
}

function openGardenCharacterPicker(kind) {
  document.getElementById('garden-character-picker')?.remove();
  const pool = getImperialGardenCharacterPool(true);
  if (!pool.length) {
    api.ui.toast('当前没有可同行的角色');
    return;
  }
  const isWalk = kind === 'walk';
  const modal = document.createElement('div');
  modal.id = 'garden-character-picker';
  modal.style.cssText = 'position:fixed;inset:0;z-index:100500;background:rgba(4,9,5,0.9);backdrop-filter:blur(12px);display:flex;align-items:flex-end;justify-content:center;font-family:"STZhongsong","STSong",serif;';
  modal.innerHTML = `<div style="width:100%;max-width:440px;max-height:86vh;background:linear-gradient(180deg,#172018,#0d120e);border:1px solid rgba(201,163,106,0.55);border-radius:22px 22px 0 0;padding:20px 16px calc(var(--safe-bottom) + 18px);display:flex;flex-direction:column;gap:14px;box-shadow:0 -12px 40px rgba(0,0,0,0.5);">
    <div style="text-align:center;color:#eed9a8;font-size:19px;letter-spacing:5px;">${isWalk ? '四处走走' : '临水煮茶'}</div>
    <div style="color:#91876d;font-size:12px;line-height:1.7;text-align:center;">${isWalk ? '可独自游园随机偶遇，也可多选角色陪同' : '选择一位或多位角色同席喝茶，剧情会读取每个人的完整记忆'}</div>
    ${isWalk ? '<label style="display:flex;align-items:center;gap:10px;padding:12px;border:1px solid rgba(201,163,106,0.35);border-radius:12px;color:#e5cf9f;"><input id="garden-walk-solo" type="checkbox" style="accent-color:#c9a36a;">独自走走 · 由AI按时辰判断可能偶遇之人</label>' : ''}
    <div id="garden-char-list" style="overflow-y:auto;display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:9px;padding:2px;">${pool.map(char => { const badge=typeof getCharacterDisciplineBadge==='function'?getCharacterDisciplineBadge(char):''; return `<label data-garden-label="${escHtml(char.id || char.name)}" style="display:flex;align-items:center;gap:8px;padding:10px;background:rgba(255,255,255,0.035);border:1px solid rgba(201,163,106,0.2);border-radius:10px;color:#d7c7a6;font-size:13px;${badge?'filter:grayscale(.6);opacity:.62;':''}"><input type="checkbox" data-garden-char="${escHtml(char.id || char.name)}" data-restricted="${badge?'1':'0'}" ${badge?'disabled':''} style="accent-color:#c9a36a;"><span><b style="color:#f0ddb5;">${escHtml(char.name)}</b><br><small style="color:${badge?'#d3937e':'#87785e'};">${escHtml(badge || char.assignedRank || char.ancientRole || '角色')}</small></span></label>`; }).join('')}</div>
    <div style="display:flex;gap:10px;"><button id="garden-picker-cancel" style="flex:1;padding:11px;border-radius:20px;background:transparent;border:1px solid #596159;color:#899087;font-family:inherit;">取消</button><button id="garden-picker-confirm" style="flex:1;padding:11px;border-radius:20px;background:#c9a36a;border:none;color:#17120c;font-weight:bold;font-family:inherit;">进入剧情</button></div>
  </div>`;
  document.body.appendChild(modal);
  const solo = modal.querySelector('#garden-walk-solo');
  const boxes = [...modal.querySelectorAll('[data-garden-char]')];
  modal.querySelectorAll('[data-garden-label]').forEach(label => label.onclick = async event => {
    const char = pool.find(item => String(item.id || item.name) === label.dataset.gardenLabel);
    if (char && typeof isCharacterUnavailableForActivity === 'function' && isCharacterUnavailableForActivity(char)) { event.preventDefault(); await notifyCharacterUnavailable(char); }
  });
  if (solo) solo.onchange = () => boxes.forEach(box => { box.disabled = solo.checked || box.dataset.restricted === '1'; box.closest('label').style.opacity = solo.checked ? '0.38' : (box.dataset.restricted === '1' ? '0.62' : '1'); });
  modal.querySelector('#garden-picker-cancel').onclick = () => modal.remove();
  modal.querySelector('#garden-picker-confirm').onclick = () => {
    const isSolo = Boolean(solo?.checked);
    const selected = boxes.filter(box => box.checked).map(box => pool.find(char => String(char.id || char.name) === box.dataset.gardenChar)).filter(Boolean);
    if (!isSolo && !selected.length) {
      api.ui.toast(isWalk ? '请选择陪同角色，或勾选“独自走走”' : '请至少选择一位同席角色');
      return;
    }
    modal.remove();
    startImperialGardenStory(kind, selected, isSolo);
  };
}

function openImperialGardenTeaPicker() { openGardenCharacterPicker('tea'); }
function openImperialGardenWalkPicker() { openGardenCharacterPicker('walk'); }

async function startImperialGardenStory(kind, chosenChars, isSolo = false) {
  const allChars = getImperialGardenCharacterPool();
  chosenChars = (chosenChars || []).filter(char => !(typeof isCharacterUnavailableForActivity === 'function' && isCharacterUnavailableForActivity(char)));
  if (!isSolo && !chosenChars.length) {
    api.ui.toast('所选人物当前均无法参加游园');
    return;
  }
  const possibleChars = isSolo ? allChars : chosenChars;
  const entourage = getEntourageForCharacters(possibleChars);
  const contextPeople = [...possibleChars, ...entourage];
  storyContext = {
    mode: 'imperialGarden', pName: '御花园', rName: kind === 'tea' ? '茶席' : '花径',
    mainChar: chosenChars[0] || possibleChars[0] || null, history: [], participants: contextPeople,
    gardenKind: kind, gardenSolo: isSolo, gardenChosen: [...chosenChars],
    scenePremise: kind === 'tea'
      ? `皇帝正在御花园与${chosenChars.map(char => char.name).join('、')}同席喝茶，当前时辰为${hudTime.innerText}。`
      : isSolo
        ? `皇帝正在${hudTime.innerText}独自游览御花园，可能按人物行迹自然偶遇一人或多人。`
        : `皇帝正在${hudTime.innerText}与${chosenChars.map(char => char.name).join('、')}一同游览御花园。`
  };
  setMorningCourtStoryUi(false);
  setMorningAudienceStoryUi(false);
  document.getElementById('story-bg-layer').style.backgroundImage = `url('${palaceDetails['御花园']?.bgUrl || ''}')`;
  storyTextBox.innerText = kind === 'tea' ? '茶烟初起，正在铺陈御苑茶叙……' : '花径风动，正在推演游园际遇……';
  storyTextBox.style.opacity = '1';
  storyControls.style.display = 'none';
  document.getElementById('story-text-wrap').style.display = 'flex';
  switchView(vStory);
  const allowedNames = possibleChars.map(char => char.name).join('、') || '无';
  const staffRule = entourage.length
    ? `身份为后妃的人物须按名册携带其侍从或宫女。随行名册：${entourage.map(npc => `${npc.name}（主人：${npc.masterName || '未分配'}）`).join('、')}。下人的反应可写进叙事；除非必要，不要让下人成为主要发言者。`
    : '本次相关后妃名下没有已分配的侍从或宫女，不得凭空捏造贴身下人姓名。';
  const eventRule = kind === 'tea'
    ? `皇帝已经选定${chosenChars.map(char => char.name).join('、')}同席喝茶。结合${hudTime.innerText}判断茶品、光线、温度、众人来路与当下心境；让每位被选角色都自然参与，并给皇帝留下可回复的互动钩子。`
    : isSolo
      ? `皇帝选择独自走走。请先根据当前时辰、身份、居所、近期记忆与起居注，从允许名单中判断谁最可能出现在御花园；随机选择一人或多人形成自然偶遇，也允许先无人再于花径转角遇见。不得让全部角色无理由齐聚。`
      : `皇帝已经选定${chosenChars.map(char => char.name).join('、')}陪同游园。结合时辰安排路线、景物与话题，让每位同行者都有符合关系与记忆的反应。`;
  const prompt = `你是古代皇帝宫廷群像剧情导演，正在演绎御花园${kind === 'tea' ? '喝茶' : '游园'}剧情。

【当前时间】${hudTime.innerText}
【全局设定】
${buildGlobalAiContext()}

【本轮可用人物及全部人设、TA看到的、TA了解的、TA的思绪、起居注】
${buildCharactersAiContext(contextPeople)}

【允许出现的主要角色准确姓名】${allowedNames}
【场景要求】${eventRule}
【随行规则】${staffRule}

正文约1500字，层层推进环境、动作、关系与对话，并在结尾停在等待皇帝回应的位置。绝对不要替皇帝说话、决定或描写皇帝未输入的反应。人物台词必须使用准确姓名；独自游园时只能从允许名单中选择偶遇者。

${getAiParagraphFormatGuard()}`;
  try {
    const result = await api.ai.chat({ messages: [{ role: 'user', content: prompt }] });
    playStory(typeof result === 'string' ? result : (result?.content ?? result?.text ?? ''));
  } catch (error) {
    storyTextBox.innerText = '御园剧情生成失败，请稍后重试。';
    storyControls.style.display = 'flex';
  }
}

// ===== 华清宫：多人召见、沐浴与赐封 =====
function getHuaQingSummonGroups() {
  const consorts = selectedCharsData.filter(char => char.ancientRole === '后妃');
  const ministers = selectedCharsData.filter(char => typeof isMinisterRosterCharacter === 'function' ? isMinisterRosterCharacter(char) : ['帝师', '左相', '右相', '大臣', '臣子'].includes(char.ancientRole));
  const others = selectedCharsData.filter(char => char.ancientRole !== '后妃' && !ministers.some(item => item.id === char.id));
  if (typeof XLY_CHAR !== 'undefined' && XLY_CHAR && !others.some(char => char.id === XLY_CHAR.id)) others.unshift(XLY_CHAR);
  const npcs = typeof getAllGameNpcs === 'function' ? getAllGameNpcs() : (window._courtNpcData || []);
  return { consorts, ministers, others, npcs };
}

function openHuaQingSummonPicker() {
  document.getElementById('huaqing-summon-modal')?.remove();
  const groups = getHuaQingSummonGroups();
  const selectedIds = new Set();
  let activeTab = 'consorts';
  const modal = document.createElement('div');
  modal.id = 'huaqing-summon-modal';
  modal.style.cssText = `
    position:fixed; inset:0; z-index:100700; display:flex; flex-direction:column;
    background-image:url('https://www.imgfox.cn/apis/uploads/20260818/cd2a4b22f1ec4748/IMG_9643.jpeg');
    background-size:cover; background-position:center;
    font-family:"STZhongsong","STSong",serif;
  `;
  modal.innerHTML = `
    <div style="position:absolute;inset:0;background:rgba(6,4,2,.72);backdrop-filter:blur(2px);-webkit-backdrop-filter:blur(2px);z-index:0;"></div>
    <div style="position:relative;z-index:2;padding:calc(var(--safe-top) + 12px) 16px 12px;display:flex;justify-content:space-between;align-items:center;border-bottom:1px solid rgba(201,163,106,.2);flex-shrink:0;">
      <button id="huaqing-summon-close" style="background:transparent;border:none;color:#888;font-size:16px;font-family:inherit;">关闭</button>
      <div style="color:var(--primary-color);font-size:16px;font-weight:bold;letter-spacing:4px;background:linear-gradient(to bottom,#ffe9b8,#c9a36a);-webkit-background-clip:text;-webkit-text-fill-color:transparent;filter:drop-shadow(0 1px 4px rgba(0,0,0,.8));">华清召见</div>
      <div style="width:40px;"></div>
    </div>
    <div id="huaqing-summon-tabs" style="position:relative;z-index:2;display:flex;gap:9px;padding:11px 16px 9px;flex-shrink:0;"></div>
    <div id="huaqing-summon-list" style="position:relative;z-index:1;flex:1;display:grid;grid-template-columns:repeat(2,1fr);grid-auto-rows:260px;gap:16px;overflow-y:auto;overflow-x:hidden;padding:10px 18px calc(var(--safe-bottom) + 166px);scrollbar-width:none;-webkit-overflow-scrolling:touch;align-content:start;"></div>
    <div style="position:absolute;z-index:4;left:14px;right:14px;bottom:calc(var(--safe-bottom) + 12px);padding:11px 12px 12px;background:rgba(12,10,8,.64);backdrop-filter:blur(20px);-webkit-backdrop-filter:blur(20px);border:1px solid rgba(201,163,106,.38);border-radius:19px;box-shadow:0 8px 30px rgba(0,0,0,.58);">
      <div id="huaqing-selected-bar" style="min-height:34px;color:#cbb083;font-size:11px;line-height:1.65;padding:0 3px 8px;">已选：暂无（最多6人）</div>
      <button id="huaqing-summon-confirm" style="width:100%;padding:11px;border-radius:20px;background:linear-gradient(180deg,#dfbd7d,#b98d4d);border:1px solid rgba(255,232,184,.55);color:#160f08;font-family:inherit;font-weight:bold;letter-spacing:4px;box-shadow:0 4px 14px rgba(0,0,0,.35);">确认召见</button>
    </div>`;
  document.body.appendChild(modal);
  const tabLabels = { consorts: '召见妃嫔', ministers: '召见臣子', others: '召见其它', npcs: '召见NPC' };
  const getAll = () => [...groups.consorts, ...groups.ministers, ...groups.others, ...groups.npcs];
  const updateSelectedBar = () => {
    const names = getAll().filter(char => selectedIds.has(char.id)).map(char => char.name);
    modal.querySelector('#huaqing-selected-bar').innerHTML = `<b style="color:#efd39b;">已选 ${names.length}/6：</b>${names.length ? escHtml(names.join('、')) : '暂无'}`;
  };
  const renderTabs = () => {
    const bar = modal.querySelector('#huaqing-summon-tabs');
    bar.innerHTML = Object.keys(tabLabels).map(key => `<button data-hq-tab="${key}" style="flex:1;padding:9px 3px;border-radius:18px;font-family:inherit;font-size:12px;letter-spacing:1px;backdrop-filter:blur(14px);-webkit-backdrop-filter:blur(14px);transition:all .22s;${activeTab === key ? 'background:rgba(201,163,106,.22);border:1px solid rgba(229,194,126,.9);color:#f5ddb0;box-shadow:0 0 15px rgba(201,163,106,.13);' : 'background:rgba(10,8,6,.42);border:1px solid rgba(201,163,106,.22);color:#817462;'}">${tabLabels[key]}</button>`).join('');
    bar.querySelectorAll('[data-hq-tab]').forEach(button => button.onclick = () => { activeTab = button.dataset.hqTab; renderTabs(); renderList(); });
  };
  const renderList = () => {
    const list = modal.querySelector('#huaqing-summon-list');
    const people = groups[activeTab];
    list.innerHTML = '';
    if (!people.length) {
      list.style.display = 'flex';
      list.style.alignItems = 'center';
      list.style.justifyContent = 'center';
      list.innerHTML = '<div style="color:#6f665b;text-align:center;letter-spacing:3px;">当前页面无人可召</div>';
      return;
    }
    list.style.display = 'grid';
    people.forEach((char, index) => {
      const selected = selectedIds.has(char.id);
      const disciplineBadge = typeof getCharacterDisciplineBadge === 'function' ? getCharacterDisciplineBadge(char) : '';
      const scenarioCfg = typeof getScenarioAvatarCfg === 'function' ? getScenarioAvatarCfg(char.id) : null;
      // NPC立绘只认NPC存档中的customAvatar/avatar，避免被同ID的旧召见头像配置覆盖。
      const isNpc = Boolean(char._isGameNpc || char.npcType);
      const portrait = isNpc ? getCharacterPortraitUrl(char) : (scenarioCfg?.url || getCharacterPortraitUrl(char));
      const cardCfg = char.cardAvatarCfg || { scale: 100, x: 0, y: 0 };
      const scale = scenarioCfg?.scale || cardCfg.scale || 100;
      const card = document.createElement('button');
      card.dataset.hqPerson = char.id;
      card.style.cssText = `
        width:100%;height:100%;padding:0;position:relative;overflow:hidden;cursor:pointer;
        margin-top:${index % 2 === 1 ? '30px' : '0'};border-radius:18px;
        background:rgba(26,22,20,.68);backdrop-filter:blur(15px);-webkit-backdrop-filter:blur(15px);
        border:${selected ? '2px solid #f2cc82' : '1px solid rgba(201,163,106,.5)'};
        box-shadow:${selected ? '0 0 24px rgba(224,181,102,.42),inset 0 0 0 1px rgba(255,229,174,.25)' : '0 8px 24px rgba(0,0,0,.6),inset 0 0 0 1px rgba(201,163,106,.08)'};
        transition:transform .18s,box-shadow .18s,border-color .18s;
      `;
      card.innerHTML = `
        <div style="position:absolute;inset:0;overflow:hidden;border-radius:18px;display:flex;align-items:center;justify-content:center;">
          ${portrait ? `<img src="${portrait}" draggable="false" style="width:100%;height:100%;object-fit:cover;object-position:top center;transform:translate(${cardCfg.x || 0}px,${cardCfg.y || 0}px) scale(${scale / 100});transform-origin:top center;display:block;pointer-events:none;">` : '<div style="color:rgba(201,163,106,.42);font-size:13px;letter-spacing:4px;text-shadow:0 1px 4px #000;">暂无立绘</div>'}
        </div>
        <div style="position:absolute;inset:0;background:${selected ? 'linear-gradient(to top,rgba(34,20,6,.98) 0%,rgba(91,57,20,.32) 58%,rgba(238,196,112,.1) 100%)' : 'linear-gradient(to top,rgba(6,4,2,.97) 0%,rgba(6,4,2,.6) 38%,transparent 72%)'};pointer-events:none;"></div>
        <div style="position:absolute;top:0;left:0;right:0;height:1px;background:linear-gradient(to right,transparent,rgba(201,163,106,.7),transparent);pointer-events:none;"></div>
        <div style="position:absolute;top:10px;right:10px;min-width:42px;padding:4px 7px;border-radius:10px;background:${disciplineBadge ? 'rgba(105,24,23,.92)' : selected ? 'rgba(210,167,88,.92)' : 'rgba(0,0,0,.66)'};border:.5px solid rgba(238,202,133,.65);color:${disciplineBadge ? '#ffd4bd' : selected ? '#211307' : 'rgba(225,193,132,.88)'};font-size:9px;letter-spacing:1px;pointer-events:none;">${escHtml(disciplineBadge || (selected ? '已选中' : '轻触选择'))}</div>
        <div style="position:absolute;bottom:0;left:0;right:0;padding:12px 14px;text-align:left;display:flex;flex-direction:column;gap:3px;pointer-events:none;">
          <div style="font-size:18px;font-weight:bold;letter-spacing:4px;background:linear-gradient(to bottom,#ffe9b8,#c9a36a);-webkit-background-clip:text;-webkit-text-fill-color:transparent;filter:drop-shadow(0 1px 4px rgba(0,0,0,.9));">${escHtml(char.name)}</div>
          <div style="font-size:11px;color:rgba(201,163,106,.72);letter-spacing:2px;">${escHtml(char.assignedRank || char.ancientRole || 'NPC')}</div>
        </div>`;
      card.addEventListener('touchstart', () => { card.style.transform = 'scale(.97)'; }, { passive: true });
      card.addEventListener('touchend', () => { card.style.transform = 'scale(1)'; }, { passive: true });
      if (disciplineBadge) card.style.filter = 'grayscale(.55) brightness(.67)';
      card.onclick = async () => {
      if (typeof isCharacterUnavailableForActivity === 'function' && isCharacterUnavailableForActivity(char)) { await notifyCharacterUnavailable(char); return; }
      const id = card.dataset.hqPerson;
      if (selectedIds.has(id)) selectedIds.delete(id);
      else if (selectedIds.size >= 6) { api.ui.toast('华清宫一次最多召见6人'); return; }
      else selectedIds.add(id);
      updateSelectedBar();
      renderList();
      };
      list.appendChild(card);
    });
  };
  modal.querySelector('#huaqing-summon-close').onclick = () => modal.remove();
  modal.querySelector('#huaqing-summon-confirm').onclick = () => {
    const chosen = getAll().filter(char => selectedIds.has(char.id));
    if (!chosen.length) { api.ui.toast('请至少选择一位受召者'); return; }
    modal.remove();
    startHuaQingSummonStory(chosen);
  };
  renderTabs(); renderList(); updateSelectedBar();
}

async function startHuaQingSummonStory(chosen) {
  chosen = chosen.filter(char => !(typeof isCharacterUnavailableForActivity === 'function' && isCharacterUnavailableForActivity(char)));
  if (!chosen.length) { api.ui.toast('所选人物当前均不可召见'); return; }
  const details = palaceDetails['华清宫'];
  storyContext = { mode: 'huaqingSummon', pName: '华清宫', rName: '汤殿', mainChar: chosen[0], participants: chosen, history: [], memoryRecipientsAll: true, huaqingChosen: chosen, scenePremise: `皇帝正在华清宫召见${chosen.map(char => char.name).join('、')}；众人已经奉召来到温泉行宫，后续剧情不得改写到养心殿或其他宫殿。\n华清宫描述：${details.description || HUAQING_DEFAULT_DESCRIPTION}\n华清宫规则：${details.rules || HUAQING_DEFAULT_RULES}` };
  setMorningCourtStoryUi(false);
  document.getElementById('story-bg-layer').style.backgroundImage = `url('${details.bgUrl || HUAQING_DEFAULT_BG}')`;
  document.getElementById('btn-story-avatar-adj').style.display = 'none';
  window.currentStoryDisplayChar = null;
  storyActiveCard.style.display = 'none';
  storyTextBox.innerText = '内侍分赴各处传召，华清宫暖雾渐起……';
  storyTextBox.style.opacity = '1'; storyControls.style.display = 'none';
  document.getElementById('story-text-wrap').style.display = 'flex'; switchView(vStory);
  let prompt = customPrompts.huaqingSummon || defaultPrompts.huaqingSummon;
  prompt = prompt.replace(/\{\{timeStr\}\}/g, hudTime.innerText).replace(/\{\{participantNames\}\}/g, chosen.map(char => char.name).join('、')).replace(/\{\{huaqingDescription\}\}/g, details.description || HUAQING_DEFAULT_DESCRIPTION).replace(/\{\{huaqingRules\}\}/g, details.rules || HUAQING_DEFAULT_RULES);
  prompt += `\n\n【本轮全部受召人物的完整人设与三类记忆】\n${buildCharactersAiContext(chosen)}\n\n【全局设定】\n${buildGlobalAiContext()}\n\n【立绘调用强制格式】\n每一位受召者都必须在本轮至少说一句话。data-speaker只能填写以下准确姓名，不得附加身份、官职、位份、括号或空格：${chosen.map(char => char.name).join('、')}。\n\n${getAiParagraphFormatGuard()}`;
  try {
    const result = await api.ai.chat({ messages: [{ role: 'user', content: prompt }] });
    playStory(typeof result === 'string' ? result : (result?.content ?? result?.text ?? ''));
  } catch (error) { storyTextBox.innerText = '华清宫召见推演失败，请稍后重试。'; storyControls.style.display = 'flex'; }
}

async function startHuaQingBath(existingCandidates = null) {
  const staff = (typeof getAllGameNpcs === 'function' ? getAllGameNpcs() : (window._courtNpcData || [])).filter(npc => (npc.npcType === 'attendant' || npc.npcType === 'maid' || npc.ancientRole === '侍从' || npc.ancientRole === '宫女') && Number(npc.loyalty) < 50);
  if (staff.length < 2 && !existingCandidates?.length) { api.ui.toast(`忠诚度低于50的侍从与宫女仅有${staff.length}人，至少需要2人才可推演`); return; }
  const candidates = existingCandidates?.length
    ? existingCandidates.slice(0, 3)
    : [...staff].sort(() => Math.random() - .5).slice(0, Math.min(3, staff.length));
  if (candidates.length < 2) { api.ui.toast(`当前可用候选仅有${candidates.length}人，至少需要2人才可推演`); return; }
  const details = palaceDetails['华清宫'];
  storyContext = { mode: 'huaqingBathLoading', pName: '华清宫', rName: '汤殿', history: [], bathCandidates: candidates };
  setMorningCourtStoryUi(false);
  document.getElementById('story-bg-layer').style.backgroundImage = `url('${details.bgUrl || HUAQING_DEFAULT_BG}')`;
  document.getElementById('btn-story-avatar-adj').style.display = 'none';
  window.currentStoryDisplayChar = null;
  storyActiveCard.style.display = 'none'; storyTextBox.innerText = '汤泉水声轻响，正在从低忠诚宫人中推演人心……'; storyControls.style.display = 'none';
  document.getElementById('story-text-wrap').style.display = 'flex'; switchView(vStory);
  let prompt = customPrompts.huaqingBath || defaultPrompts.huaqingBath;
  prompt = prompt.replace(/\{\{timeStr\}\}/g, hudTime.innerText).replace(/\{\{candidateCount\}\}/g, String(candidates.length)).replace(/\{\{candidateNames\}\}/g, candidates.map(npc => npc.name).join('、')).replace(/\{\{huaqingDescription\}\}/g, details.description || HUAQING_DEFAULT_DESCRIPTION).replace(/\{\{huaqingRules\}\}/g, details.rules || HUAQING_DEFAULT_RULES);
  const candidateDetails = candidates.map(npc => `${npc.name}：身份${npc.ancientRole || '宫人'}；性别${npc.gender || '未知'}；性格${npc.rosterPersonality || '未定'}；状态${npc.rosterMood || '未定'}；忠诚度${npc.loyalty ?? 0}；主人${npc.masterName || '未分配'}；介绍${npc.ancientDesc || '无'}`).join('\n');
  prompt += `\n\n【本轮候选人数强制校正】\n本轮实际只有${candidates.length}名候选：${candidates.map(npc => npc.name).join('、')}。只能从这些人中选择，不得因为旧提示词写了“三人”而虚构第三人。\n\n【候选基础信息】\n${candidateDetails}\n\n【候选人的完整人设与三类记忆】\n${buildCharactersAiContext(candidates)}\n\n【全局设定】\n${buildGlobalAiContext()}\n\n必须保留<chosen-name>与<story>外层标签；<story>内部叙事只用<p>，台词只用带准确data-speaker的<p>，不得输出“旁白”或思考过程。`;
  try {
    const result = await api.ai.chat({ messages: [{ role: 'user', content: prompt }] });
    const raw = String(typeof result === 'string' ? result : (result?.content ?? result?.text ?? '')).replace(/```(?:html|xml)?|```/gi, '').trim();
    const chosenName = raw.match(/<chosen-name>([\s\S]*?)(?:<\/chosen-name>|<story>)/i)?.[1]?.replace(/<[^>]+>/g, '').trim();
    const chosen = candidates.find(npc => npc.name === chosenName) || [...candidates].sort((a, b) => Number(a.loyalty || 0) - Number(b.loyalty || 0))[0];
    const story = raw.match(/<story>([\s\S]*?)(?:<\/story>|$)/i)?.[1] || (raw.match(/<p(?:[^>]*)>[\s\S]*?(?:<\/p>|$)/gi) || []).join('');
    storyContext = { mode: 'huaqingBath', pName: '华清宫', rName: '汤殿', mainChar: chosen, participants: [chosen], contextParticipants: candidates, history: [], memoryRecipientsAll: true, bathCandidates: candidates, afterMemorySave: 'huaqingConferral', scenePremise: `皇帝仍在华清宫汤殿沐浴，${chosen.name}是从候选宫人中主动争取近前侍奉的人；不得改写为养心殿传召。\n华清宫描述：${details.description || HUAQING_DEFAULT_DESCRIPTION}\n华清宫规则：${details.rules || HUAQING_DEFAULT_RULES}` };
    playStory(story || `<p>${chosen.name}绕过帘外值守，低声请命侍奉汤泉。</p><p data-speaker="${chosen.name}">“奴愿近前侍奉，请主君示下。”</p>`);
  } catch (error) { storyTextBox.innerText = '华清宫沐浴推演失败，请稍后重试。'; storyControls.style.display = 'flex'; }
}

function setHuaQingConferralStoryUi(enabled) {
  const exit = document.getElementById('btn-exit-story'), reroll = document.getElementById('btn-story-reroll-modal'), next = document.getElementById('btn-story-next'), inputRow = document.getElementById('story-user-input').parentElement;
  if (enabled) { exit.innerText = '结束册封'; exit.style.width = '88px'; exit.style.borderRadius = '18px'; exit.style.fontSize = '12px'; reroll.style.display = 'none'; next.innerText = '完成册封'; inputRow.style.display = 'none'; }
  else { exit.innerText = '‹'; exit.style.width = ''; exit.style.borderRadius = ''; exit.style.fontSize = ''; reroll.style.display = 'flex'; next.innerText = '继续 ›'; inputRow.style.display = 'flex'; }
}

async function openHuaQingConferralPrompt(npc, bathSummary) {
  if (!npc || !(window._courtNpcData || []).some(item => item.id === npc.id)) return;
  const yes = await api.ui.confirm({ title: `是否赐封${npc.name}`, message: '是否将这名宫人正式册封为后妃？选择“否”将保留其NPC身份，不改变人物资料。' });
  if (!yes) return;
  const ranks = rankData.map(item => item.rank).filter(Boolean);
  const residences = (typeof getYangXinRosterPalaceOptions === 'function' ? getYangXinRosterPalaceOptions('') : []).filter(name => !name.endsWith('耳房'));
  if (!ranks.length || !residences.length) { api.ui.toast('请先在位份册与宫殿中完成可选项设置'); return; }
  document.getElementById('huaqing-conferral-modal')?.remove();
  const modal = document.createElement('div'); modal.id = 'huaqing-conferral-modal';
  modal.style.cssText = 'position:fixed;inset:0;z-index:100800;background:rgba(4,3,2,.88);display:flex;align-items:flex-end;justify-content:center;font-family:"STZhongsong","STSong",serif;';
  modal.innerHTML = `<div style="width:100%;max-width:430px;background:linear-gradient(180deg,#291b11,#100b08);border:1px solid rgba(201,163,106,.58);border-radius:24px 24px 0 0;padding:20px 17px calc(var(--safe-bottom) + 18px);"><div style="color:#efd6a3;text-align:center;font-size:19px;letter-spacing:5px;">拟定册封</div><div style="color:#8d785b;text-align:center;font-size:12px;margin:8px 0 18px;">${escHtml(npc.name)} · 由NPC转入正式角色</div><label style="display:block;color:#bda173;font-size:12px;margin-bottom:6px;">册封位份</label><select id="huaqing-conferral-rank" style="width:100%;padding:10px;margin-bottom:14px;background:#17110c;border:1px solid #665037;border-radius:8px;color:#e8d5b2;font-family:inherit;">${ranks.map(rank => `<option value="${escHtml(rank)}">${escHtml(rank)}</option>`).join('')}</select><label style="display:block;color:#bda173;font-size:12px;margin-bottom:6px;">赐居宫室</label><select id="huaqing-conferral-palace" style="width:100%;padding:10px;margin-bottom:18px;background:#17110c;border:1px solid #665037;border-radius:8px;color:#e8d5b2;font-family:inherit;">${residences.map(name => `<option value="${escHtml(name)}">${escHtml(name)}</option>`).join('')}</select><div style="display:flex;gap:10px;"><button id="huaqing-conferral-cancel" style="flex:1;padding:11px;border-radius:20px;background:transparent;border:1px solid #51483d;color:#83796b;font-family:inherit;">取消</button><button id="huaqing-conferral-confirm" style="flex:2;padding:11px;border-radius:20px;background:#c9a36a;border:none;color:#160f09;font-family:inherit;font-weight:bold;">颁旨册封</button></div></div>`;
  document.body.appendChild(modal);
  const rankSelect = modal.querySelector('#huaqing-conferral-rank'), palaceSelect = modal.querySelector('#huaqing-conferral-palace');
  const syncTopRank = () => { if (rankSelect.value === rankData[0]?.rank) { palaceSelect.innerHTML = '<option value="坤宁宫正殿">坤宁宫正殿（主位）</option>'; palaceSelect.disabled = true; } else if (palaceSelect.disabled) { palaceSelect.disabled = false; palaceSelect.innerHTML = residences.map(name => `<option value="${escHtml(name)}">${escHtml(name)}</option>`).join(''); } };
  rankSelect.onchange = syncTopRank; syncTopRank();
  modal.querySelector('#huaqing-conferral-cancel').onclick = () => modal.remove();
  modal.onclick = event => { if (event.target === modal) modal.remove(); };
  modal.querySelector('#huaqing-conferral-confirm').onclick = () => { const rankName = rankSelect.value, palaceName = palaceSelect.value; modal.remove(); startHuaQingConferralStory(npc, bathSummary, rankName, palaceName); };
}

async function promptHuaQingPortrait(char) {
  if (hasCharacterPortrait(char)) return;
  const pickNow = await api.ui.confirm({ title: '尚未设置立绘', message: `${char.name}已成为正式角色，但目前没有立绘。是否现在选择图片？更完整的人设、头像与立绘设置可稍后前往“内务府 → 自设台 / 置度所 → 立绘”修改。` });
  if (!pickNow) { api.ui.toast('已暂用纯背景剧情，可稍后在内务府补充立绘'); return; }
  try { const picked = await api.media.pick({ accept: 'image/*' }); if (picked?.file?.dataUrl) { char.customAvatar = picked.file.dataUrl; await saveProgress({ characters: selectedCharsData }); api.ui.toast(`${char.name}的立绘已保存`); } } catch (error) {}
}

async function startHuaQingConferralStory(npc, bathSummary, rankName, palaceName) {
  const npcContext = buildCharacterAiContext(npc), timeStr = hudTime.innerText;
  const formerMaster = selectedCharsData.find(char => (npc.masterId && char.id === npc.masterId) || (npc.masterName && char.name === npc.masterName))
    || (typeof XLY_CHAR !== 'undefined' && ((npc.masterId && XLY_CHAR.id === npc.masterId) || (npc.masterName && XLY_CHAR.name === npc.masterName)) ? XLY_CHAR : null)
    || (window._courtNpcData || []).find(char => char.id !== npc.id && ((npc.masterId && char.id === npc.masterId) || (npc.masterName && char.name === npc.masterName)));
  const formerMasterName = formerMaster?.name || '无主人';
  const formerMasterContext = formerMaster ? buildCharacterAiContext(formerMaster) : '此NPC册封前没有主人。不得凭空增设旧主或主从关系。';
  const formerHouseholdStaff = (window._courtNpcData || []).filter(person => {
    if (!person || person.id === npc.id || !['侍从', '宫女'].includes(person.ancientRole)) return false;
    const sameMaster = (npc.masterId && person.masterId === npc.masterId) || (npc.masterName && person.masterName === npc.masterName);
    const masterPalace = formerMaster?.assignedPalace || npc.assignedPalace;
    const samePalace = masterPalace && person.assignedPalace === masterPalace;
    return sameMaster || samePalace;
  }).slice(0, 6);
  const householdContext = formerHouseholdStaff.length
    ? buildCharactersAiContext(formerHouseholdStaff)
    : '没有可读取的同宫具名侍从或宫女。可以描写华清宫当值宫人的低声议论，但不得凭空冒用现有角色姓名。';
  storyContext = { mode: 'huaqingConferralLoading', pName: '华清宫', rName: '册封', mainChar: npc, participants: [npc, formerMaster, ...formerHouseholdStaff].filter(Boolean), formerMaster, history: [] };
  setMorningCourtStoryUi(false); setHuaQingConferralStoryUi(true);
  document.getElementById('story-bg-layer').style.backgroundImage = `url('${palaceDetails['华清宫'].bgUrl || HUAQING_DEFAULT_BG}')`;
  document.getElementById('btn-story-avatar-adj').style.display = 'none';
  window.currentStoryDisplayChar = null;
  storyActiveCard.style.display = 'none'; storyTextBox.innerText = '册封旨意已拟，正在推演谢恩与宫中议论……'; storyControls.style.display = 'none'; switchView(vStory);
  let prompt = customPrompts.huaqingConferral || defaultPrompts.huaqingConferral;
  prompt = prompt.replace(/\{\{npcName\}\}/g, npc.name).replace(/\{\{rankName\}\}/g, rankName).replace(/\{\{palaceName\}\}/g, palaceName).replace(/\{\{formerMasterName\}\}/g, formerMasterName);
  prompt += `\n\n【此人册封前的全部NPC资料与三类记忆】\n${npcContext}\n\n【册封前的主人判定】\n原主人：${formerMasterName}\n${formerMasterContext}\n\n【原主人宫中可参与议论的侍从、宫女完整资料与记忆】\n${householdContext}\n\n【上一轮华清宫记忆摘要】\n${bathSummary}\n\n【后宫位份表及备注】\n${rankData.map(item => `${item.rank}：${item.note || '无备注'}；自称${item.selfClaim || '未定'}`).join('\n')}\n\n【全局设定】\n${buildGlobalAiContext()}\n\n【正文必须完整呈现的三段内容】\n1. ${npc.name}听旨、理解所赐位份轻重并正式谢恩，写清动作、言语与离开汤殿后的反应。\n2. ${formerMaster ? `${formerMaster.name}必须在正文中真实出场：得知原属宫人${npc.name}被册封后的动作、言语、内心变化，以及两人册封后第一次直接互动。不能只把主人反应塞进小结。` : `${npc.name}原本没有主人，不得虚构旧主，篇幅用于册封后的身份变化与宫中余波。`}\n3. ${formerHouseholdStaff.length ? `让${formerHouseholdStaff.map(person => person.name).join('、')}中的至少两人依各自人设参与议论或作出反应；不能只写“宫人议论”四字带过。` : '必须写出至少三段华清宫当值侍从、宫女之间有具体内容的低声议论和各异反应。'}\n所有具名人物发言必须使用准确姓名作为data-speaker。正文目标约2500字、至少25个有实质推进的短段。必须保留<memory-summary>与<story>外层标签；<story>内部叙事只用<p>，台词只用带准确data-speaker的<p>，不得输出“旁白”或思考过程。`;
  let story = '', summary = '';
  try { const result = await api.ai.chat({ messages: [{ role: 'user', content: prompt }] }); const raw = String(typeof result === 'string' ? result : (result?.content ?? result?.text ?? '')).replace(/```(?:html|xml)?|```/gi, '').trim(); summary = raw.match(/<memory-summary>([\s\S]*?)(?:<\/memory-summary>|<story>)/i)?.[1]?.replace(/<[^>]+>/g, '').trim().slice(0, 150) || ''; story = raw.match(/<story>([\s\S]*?)(?:<\/story>|$)/i)?.[1] || (raw.match(/<p(?:[^>]*)>[\s\S]*?(?:<\/p>|$)/gi) || []).join(''); } catch (error) {}
  if (!summary) summary = `${npc.name}在华清宫侍奉后蒙皇帝册为${rankName}、赐居${palaceName}，接旨谢恩${formerMaster ? `；原主人${formerMaster.name}得知后与其重新确认彼此身份` : ''}。`.slice(0, 150);
  const storyPlainLength = () => String(story || '').replace(/<[^>]+>/g, '').trim().length;
  const missingMasterScene = formerMaster && !String(story).includes(formerMaster.name);
  const householdMentionCount = formerHouseholdStaff.filter(person => String(story).includes(person.name)).length;
  const missingHouseholdScene = formerHouseholdStaff.length && householdMentionCount < Math.min(2, formerHouseholdStaff.length);
  if (storyPlainLength() < 1200 || missingMasterScene || missingHouseholdScene) {
    try {
      const retryPrompt = `${prompt}\n\n【已有正文，必须从它的结尾继续补写，禁止重写或复述】\n<story>${story}</story>\n\n【正文续写】上一次正文过短，或遗漏了原主人/宫人反应。小结已经合格，这次不要输出小结，只输出新增的<story>...</story>段落，把整篇补足到约2500字、至少25段；${formerMaster ? `必须让${formerMaster.name}在新增正文中出场、说话，并与${npc.name}直接互动；` : ''}${formerHouseholdStaff.length ? `必须让${formerHouseholdStaff.map(person => person.name).join('、')}中的至少两人参与有具体内容的议论；` : '必须安排多段侍从与宫女的具体议论；'}不得用一句概括代替这些场景。`;
      const retryResult = await api.ai.chat({ messages: [{ role: 'user', content: retryPrompt }] });
      const retryRaw = String(typeof retryResult === 'string' ? retryResult : (retryResult?.content ?? retryResult?.text ?? '')).replace(/```(?:html|xml)?|```/gi, '').trim();
      const retryStory = retryRaw.match(/<story>([\s\S]*?)(?:<\/story>|$)/i)?.[1] || (retryRaw.match(/<p(?:[^>]*)>[\s\S]*?(?:<\/p>|$)/gi) || []).join('');
      if (String(retryStory).replace(/<[^>]+>/g, '').trim()) story = `${story}${retryStory}`;
    } catch (error) {}
  }
  if (!story) story = `<p>册封旨意传至华清宫，宫人屏息听宣。</p><p data-speaker="${npc.name}">“臣侍叩谢主君恩典。”</p><p>${npc.name}领旨后退出汤殿，沿途宫人低声议论这场突如其来的荣宠。</p>${formerMaster ? `<p>消息随后传到${formerMaster.name}处，旧日主从即将在新的位份礼序下重新相见。</p><p data-speaker="${formerMaster.name}">“既已承恩入册，往后便该依新礼相见了。”</p><p data-speaker="${npc.name}">“旧日照拂不敢忘，今日再见，心中亦有许多话未曾说尽。”</p>` : ''}`;
  const promoted = { ...npc, ancientRole: '后妃', assignedRank: rankName, assignedPalace: palaceName, ancientDesc: npc.ancientDesc || '尚待补充人物设定。', ancientDescOriginal: npc.ancientDesc || '尚待补充人物设定。', memorySeen: [{ time: timeStr, text: `【华清宫册封】${summary}` }, { time: timeStr, text: `【华清宫侍奉】${bathSummary}` }], memoryKnown: [], records: [], charWorldDesc: npc.charWorldDesc || '', _isCustom: true };
  delete promoted._isGameNpc; delete promoted.npcType; delete promoted.masterId; delete promoted.masterName;
  const npcIndex = (window._courtNpcData || []).findIndex(item => item.id === npc.id); if (npcIndex >= 0) window._courtNpcData.splice(npcIndex, 1);
  selectedCharsData.push(promoted); selectedCharIds?.add?.(promoted.id);
  const publicText = `【后宫册封众闻】${timeStr}，皇帝于华清宫册封${promoted.name}为${rankName}，赐居${palaceName}。`;
  syncPublicNewsToCharacterRecords(publicText, timeStr, ['后宫', '赐封', '众闻'], promoted.name);
  if (typeof syncRosterKnowledgeToCharacters === 'function') syncRosterKnowledgeToCharacters();
  await saveProgress({ characters: selectedCharsData, courtNpcData: window._courtNpcData || [], xlyMemoryKnown: XLY_CHAR.memoryKnown, xlyRecords: XLY_CHAR.records });
  await promptHuaQingPortrait(promoted);
  storyContext = { mode: 'huaqingConferral', pName: '华清宫', rName: '册封', mainChar: promoted, participants: [promoted, formerMaster, ...formerHouseholdStaff].filter(Boolean), formerMaster, history: [] };
  api.ui.toast(`${promoted.name}已转为正式后妃，册封众闻已写入全员“TA了解的 → 起居注”`);
  playStory(story);
}

// ===== 坤宁宫 · 晨昏定省 =====
function isMorningAudienceTime() {
  if (timeMode === 'sync') {
    const hour = new Date().getHours();
    return hour >= 7 && hour <= 10;
  }
  return pickerData.h === 4 || pickerData.h === 5;
}

function getHighestRankConsort() {
  const consorts = selectedCharsData.filter(char => char.ancientRole === '后妃' && !(typeof isCharacterUnavailableForActivity === 'function' && isCharacterUnavailableForActivity(char)));
  const rankOrder = new Map((rankData || []).map((item, index) => [item.rank, index]));
  return consorts.sort((a, b) => (rankOrder.get(a.assignedRank) ?? 999) - (rankOrder.get(b.assignedRank) ?? 999))[0] || null;
}

async function promptMorningAudience() {
  const host = getHighestRankConsort();
  if (!host || host.assignedPalace !== '坤宁宫正殿') {
    api.ui.toast('坤宁宫正殿尚无位份最高的后妃主位');
    return;
  }
  const inTime = isMorningAudienceTime();
  const cheatActive = isMorningCourtCheatActive();
  if (!inTime && !cheatActive) {
    api.ui.toast('晨昏定省仅在早上7点至10点开放；开启金手指后可补看今早小会');
    return;
  }
  const ok = await api.ui.confirm({
    title: '坤宁宫 · 晨昏定省',
    message: inTime ? `各宫后妃将向${host.assignedRank || '主位'}${host.name}请安，是否入内旁观？` : '当前已过请安时辰。金手指已开启，是否补看今早的晨昏定省？'
  });
  if (!ok) return;
  await startMorningAudience(host, !inTime);
}

function setMorningAudienceStoryUi(enabled) {
  const exitButton = document.getElementById('btn-exit-story');
  const rerollButton = document.getElementById('btn-story-reroll-modal');
  const nextButton = document.getElementById('btn-story-next');
  const inputRow = document.getElementById('story-user-input').parentElement;
  if (enabled) {
    exitButton.innerText = '退出小会';
    exitButton.style.width = '86px';
    exitButton.style.borderRadius = '18px';
    exitButton.style.fontSize = '13px';
    rerollButton.style.display = 'none';
    nextButton.innerText = '继续旁观 ›';
    inputRow.style.display = 'none';
  } else if (storyContext.mode !== 'morningCourt') {
    inputRow.style.display = 'flex';
  }
}

async function startMorningAudience(host, isCatchUp = false) {
  const consorts = selectedCharsData.filter(char => char.ancientRole === '后妃' && !(typeof isCharacterUnavailableForActivity === 'function' && isCharacterUnavailableForActivity(char)));
  const entourage = getEntourageForCharacters(consorts);
  storyContext = {
    mode: 'morningAudience', pName: '坤宁宫', rName: '正殿', mainChar: host,
    history: [], participants: consorts, contextParticipants: [...consorts, ...entourage],
    memoryRecipientsAll: true, isCatchUp,
    scenePremise: `这是${hudTime.innerText}发生在坤宁宫正殿的晨昏定省小会，皇帝不在场也不参与。`
  };
  setMorningCourtStoryUi(false);
  setMorningAudienceStoryUi(true);
  document.getElementById('story-bg-layer').style.backgroundImage = `url('${palaceDetails['坤宁宫']?.bgUrl || host.indoorBgUrl || ''}')`;
  storyTextBox.innerText = '各宫仪仗渐次停在坤宁门外，正在铺陈请安小会……';
  storyControls.style.display = 'none';
  document.getElementById('story-text-wrap').style.display = 'flex';
  switchView(vStory);
  const prompt = buildMorningAudiencePrompt(false);
  try {
    const result = await api.ai.chat({ messages: [{ role: 'user', content: prompt }] });
    playStory(typeof result === 'string' ? result : (result?.content ?? result?.text ?? ''));
  } catch (error) {
    storyTextBox.innerText = '请安小会推演失败，请稍后重试。';
    storyControls.style.display = 'flex';
  }
}

function buildMorningAudiencePrompt(isContinuation) {
  const host = storyContext.mainChar;
  const historyText = (storyContext.history || []).map(item => `${item.speaker || '叙事段'}：${item.text}`).join('\n') || '尚未开始';
  return `你是古代皇帝后宫群像剧情导演，演绎坤宁宫正殿的“晨昏定省”。

【绝对前提】这是一场由位份最高的${host.assignedRank || '主位'}${host.name}主持、各位后妃前来请安的小会。User/皇帝不在场、不发言、不参与，也不需要为皇帝留下回复位置。${storyContext.isCatchUp ? '这是用金手指补看的今早情景，剧情发生时仍按早上7点至10点的晨间状态描写。' : ''}
【当前记录时间】${hudTime.innerText}
【全局设定】
${buildGlobalAiContext()}

【所有后妃及随行侍从宫女的完整档案与全部记忆】
${buildCharactersAiContext(storyContext.contextParticipants || storyContext.participants)}

【此前小会履历】
${historyText}

${isContinuation ? '继续推进尚未结束的请安小会，引出新的请安次序、宫务话题、礼数交锋或人物暗线，禁止复述前文。' : '从各宫后妃依位份抵达、向主位行礼问安开始。每位已有后妃都应在合理篇幅内出现；后妃若名下已有侍从或宫女，需交代其随行与反应。'}
严格按位份顺序、人物关系、人设与记忆安排言行，不得凭空创造名单外后妃。正文约1500字，至少15个有推进的小段。只描写在场人物，不得生成User的台词、动作、反应或心理。

${getAiParagraphFormatGuard()}`;
}

async function continueMorningAudience() {
  storyTextBox.innerText = '请安小会仍在继续……';
  storyControls.style.display = 'none';
  document.getElementById('story-text-wrap').style.bottom = 'calc(var(--safe-bottom) + 8px)';
  try {
    const result = await api.ai.chat({ messages: [{ role: 'user', content: buildMorningAudiencePrompt(true) }] });
    const text = typeof result === 'string' ? result : (result?.content ?? result?.text ?? '');
    const cleanText = text.replace(/<think>[\s\S]*?<\/think>/g, '');
    const matches = [...cleanText.matchAll(/<p(?:[^>]*)>(.*?)<\/p>/g)];
    storySegments = matches.map(match => {
      const speaker = extractStorySpeakerFromTag(match[0]);
      return { type: speaker ? 'dialogue' : 'desc', speaker, text: normalizeStorySegmentText(match[1], speaker) };
    }).filter(item => item.text);
    if (!storySegments.length) storySegments = cleanText.replace(/<[^>]+>/g, '').split('\n').map(text => text.trim()).filter(Boolean).map(text => ({ type:'desc', speaker:null, text }));
    currentSegmentIdx = 0;
    showNextSegment();
  } catch (error) {
    storyTextBox.innerText = '后续小会推演失败，请稍后重试。';
    storyControls.style.display = 'flex';
  }
}

// ===== 乾清宫 · 早朝 =====
const MORNING_COURT_ROLES = ['帝师', '左相', '右相', '大臣', '臣子'];

function isMorningCourtTime() {
  if (timeMode === 'sync') {
    const hour = new Date().getHours();
    return hour >= 5 && hour <= 12;
  }
  // 手动时间以时辰为粒度：卯、辰、巳、午对应上午五点至十二点。
  return pickerData.h >= 3 && pickerData.h <= 6;
}

function isMorningCourtCheatActive() {
  return typeof cheatExpireTime !== 'undefined' && cheatExpireTime > Date.now();
}

function getMorningCourtOfficials() {
  const all = [...selectedCharsData];
  if (typeof XLY_CHAR !== 'undefined' && XLY_CHAR) all.push(XLY_CHAR);
  const seen = new Set();
  return all.filter(char => {
    if (!char || (!MORNING_COURT_ROLES.includes(char.ancientRole) && char._rosterCategory !== 'minister')) return false;
    const key = char.id || char.name;
    if (seen.has(key)) return false;
    seen.add(key);
    return true;
  });
}

function normalizeCourtNpcName(rawName) {
  return String(rawName || '')
    .replace(/^(臣|奏臣)\s*[:：]?\s*/, '')
    .replace(/[\r\n]+/g, ' ')
    .trim();
}

function getStoredCourtNpcs() {
  if (!Array.isArray(window._courtNpcData)) window._courtNpcData = [];
  return window._courtNpcData;
}

function getMorningCourtRecords() {
  const officialRecords = getMorningCourtOfficials().flatMap(char =>
    (char.records || [])
      .filter(record => (record.tags || []).includes('前朝'))
      .map(record => ({ ...record, owner: record.owner || char.name }))
  );
  const publicRecords = (window._qianchaoRecords || []).map(record => ({ ...record }));
  const unique = new Map();
  [...publicRecords, ...officialRecords].forEach(record => {
    const key = record.id || `${record.time}|${record.owner}|${record.text}`;
    if (!unique.has(key)) unique.set(key, record);
  });
  return [...unique.values()]
    .sort((a, b) => String(b.id || b.time || '').localeCompare(String(a.id || a.time || '')))
    .slice(0, 30);
}

function discoverMorningCourtNpcs(officials, courtRecords) {
  const officialNames = new Set(officials.map(char => char.name));
  const storedNpcs = getStoredCourtNpcs();
  const courtEligibleNpcs = storedNpcs.filter(npc => !npc.npcType);
  if (storedNpcs.length >= 60) return courtEligibleNpcs.filter(npc => !officialNames.has(npc.name));
  const candidates = [];
  [...(zouZheData.pending || []), ...(zouZheData.done || [])].forEach(item => {
    if (item.authorName) candidates.push(item.authorName);
    else if (item.author) candidates.push(item.author);
  });
  courtRecords.forEach(record => {
    if (record.owner) candidates.push(record.owner);
  });
  courtEligibleNpcs.forEach(npc => candidates.push(npc.name));

  const storedByName = new Map(storedNpcs.map(npc => [npc.name, npc]));
  const seen = new Set();
  return candidates.map(normalizeCourtNpcName).filter(name => {
    if (!name || officialNames.has(name) || seen.has(name)) return false;
    seen.add(name);
    return true;
  }).map(name => storedByName.get(name) || {
    id: `court_npc_${generateId()}`,
    name,
    ancientRole: '前朝NPC',
    ancientDesc: '由奏折署名或前朝记事识别出的朝臣。',
    memoryKnown: [],
    memorySeen: [],
    records: [],
    _isGameNpc: true
  }).slice(0, 60);
}

function formatCourtMemorial(item, status, index) {
  const dialogue = Array.isArray(item._dialog) && item._dialog.length
    ? item._dialog.map((entry, dialogIndex) => `${dialogIndex + 1}. ${entry.role === 'emperor' ? '皇帝朱批' : '大臣回执'}：${entry.text || ''}`).join('\n')
    : '暂无后续往来';
  const funding = Array.isArray(item.funding) && item.funding.length
    ? item.funding.map(entry => `[${entry.time || '时间不详'}] 拨款${formatSilver(entry.amount)}两，承办：${entry.recipient || item.author || '佚名'}`).join('\n') : '尚未拨款';
  return `【${status}${index + 1}】\n标题：${item.title || '无题'}\n上奏者：${item.author || '佚名'}\n奏折原文：${item.content || item.text || item.body || '无'}\n御批/处理：${item.reply || item.response || item.result || (status === '待批阅' ? '尚未御批' : '已批阅')}\n拨款记录：\n${funding}\n后续全部往来：\n${dialogue}`;
}

function formatCourtPerson(char) {
  return buildCharacterAiContext(char);
}

function buildMorningCourtContext() {
  const officials = getMorningCourtOfficials();
  const courtRecords = getMorningCourtRecords();
  const npcs = discoverMorningCourtNpcs(officials, courtRecords);
  const pendingText = (zouZheData.pending || []).map((item, index) => formatCourtMemorial(item, '待批阅', index)).join('\n\n') || '无待批奏折';
  const doneText = (zouZheData.done || []).map((item, index) => formatCourtMemorial(item, '已批阅', index)).join('\n\n') || '无已批奏折';
  const officialText = officials.map(formatCourtPerson).join('\n\n') || '暂无已创建的前朝角色';
  const npcText = npcs.map(formatCourtPerson).join('\n\n') || '暂无从奏折或前朝记事识别的NPC';
  const recordText = courtRecords.map((record, index) => `【前朝记事${index + 1}】[${record.time || '时间不详'}] ${record.owner || '佚名'}：${record.text || ''}`).join('\n') || '无';
  return {
    officials,
    npcs,
    courtRecords,
    promptText: `【当前时间】\n${hudTime.innerText}\n\n【国库实存】\n${formatSilver(treasurySilver)}两。朝议涉及财政时必须严格以此余额为准，不得无故声称国库空虚。\n\n【全部全局设定与世界书】\n${buildGlobalAiContext()}\n\n【全部待批阅奏折】\n${pendingText}\n\n【全部已批阅奏折】\n${doneText}\n\n【在册前朝角色完整资料与记忆】\n${officialText}\n\n【由奏折与记事识别的前朝NPC资料与记忆】\n${npcText}\n\n【最新30条“前朝”记事】\n${recordText}`
  };
}

function getStoryCharacterByName(name) {
  if (!name) return null;
  const speakerText = String(name).trim();
  const participantPool = [...(storyContext.participants || []), ...(storyContext.contextParticipants || [])].filter(Boolean);
  const participant = participantPool.find(char => char?.name === speakerText);
  if (participant) return participant;
  if (storyContext.mode === 'morningCourt') {
    const courtChar = (storyContext.courtOfficials || []).find(char => char.name === speakerText);
    if (courtChar) return courtChar;
    const courtNpc = (storyContext.courtNpcs || []).find(char => char.name === speakerText);
    if (courtNpc) return courtNpc;
  }
  const globalPool = [
    ...participantPool,
    ...(storyContext.courtOfficials || []),
    ...(storyContext.courtNpcs || []),
    ...selectedCharsData,
    ...(typeof XLY_CHAR !== 'undefined' ? [XLY_CHAR] : []),
    ...(window._courtNpcData || [])
  ].filter(Boolean);
  const exact = globalPool.find(char => char.name === speakerText);
  if (exact) return exact;
  // AI偶尔会把speaker写成“宫女·姓名”“姓名（侍从）”或“身份 姓名”。
  // 优先匹配更长的姓名，仍返回NPC存档原对象，保证已配置立绘可以被调用。
  return [...new Map(globalPool.map(char => [char.id || char.name, char])).values()]
    .filter(char => char.name && speakerText.includes(String(char.name)))
    .sort((a, b) => String(b.name).length - String(a.name).length)[0] || null;
}

function renderMorningCourtBadge() {
  const badge = document.getElementById('court-status-badge');
  const chipStyle = 'background:rgba(0,0,0,0.62);border:1px solid rgba(201,163,106,0.58);color:#ead6aa;border-radius:15px;padding:6px 10px;font-size:11px;letter-spacing:1px;font-family:inherit;box-shadow:0 2px 8px rgba(0,0,0,0.35);';
  badge.innerHTML = `
    <button type="button" style="${chipStyle}">国库 ${formatSilver(treasurySilver)}两</button>
    <button data-court-overview="pending" style="${chipStyle}">待批 ${zouZheData.pending?.length || 0}</button>
    <button data-court-overview="done" style="${chipStyle}">已批 ${zouZheData.done?.length || 0}</button>
    <button data-court-overview="officials" style="${chipStyle}">朝臣 ${(storyContext.courtOfficials || []).length + (storyContext.courtNpcs || []).length}</button>
  `;
  badge.onclick = event => {
    const button = event.target.closest('[data-court-overview]');
    if (button) openMorningCourtOverview(button.dataset.courtOverview);
  };
}

function openMorningCourtOverview(initialTab = 'pending') {
  document.getElementById('court-overview-modal')?.remove();
  const modal = document.createElement('div');
  modal.id = 'court-overview-modal';
  modal.style.cssText = 'position:fixed;inset:0;z-index:100500;background:rgba(5,4,3,0.88);backdrop-filter:blur(12px);display:flex;flex-direction:column;padding-top:var(--safe-top);font-family:"STZhongsong","STSong",serif;';
  modal.innerHTML = `
    <div style="height:56px;display:flex;align-items:center;justify-content:space-between;padding:0 16px;border-bottom:1px solid rgba(201,163,106,0.25);background:rgba(20,16,12,0.75);">
      <button id="court-overview-close" style="background:transparent;border:none;color:#aaa;font-size:15px;font-family:inherit;">‹ 返回朝堂</button>
      <div style="color:#ecd7a7;font-size:17px;letter-spacing:4px;">朝议总览</div><div style="width:72px;"></div>
    </div>
    <div id="court-overview-tabs" style="display:flex;gap:8px;padding:12px 14px;border-bottom:1px solid rgba(201,163,106,0.14);">
      <button data-tab="pending">待批奏折</button><button data-tab="done">已批奏折</button><button data-tab="officials">朝臣名单</button>
    </div>
    <div id="court-overview-body" style="flex:1;overflow-y:auto;padding:14px 14px calc(var(--safe-bottom) + 20px);"></div>`;
  document.body.appendChild(modal);
  modal.querySelector('#court-overview-close').onclick = () => modal.remove();

  const render = tab => {
    modal.querySelectorAll('[data-tab]').forEach(button => {
      const active = button.dataset.tab === tab;
      button.style.cssText = `flex:1;padding:8px 4px;border-radius:18px;font-family:inherit;font-size:12px;letter-spacing:1px;${active ? 'background:rgba(201,163,106,0.2);border:1px solid #c9a36a;color:#ffe9b8;' : 'background:transparent;border:1px solid #555;color:#888;'}`;
    });
    const body = modal.querySelector('#court-overview-body');
    if (tab === 'officials') {
      const people = [...(storyContext.courtOfficials || []), ...(storyContext.courtNpcs || [])];
      body.innerHTML = people.length ? `<div style="display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:10px;">${people.map(person => `
        <div style="background:linear-gradient(145deg,rgba(43,32,22,0.9),rgba(17,14,11,0.9));border:1px solid rgba(201,163,106,0.28);border-radius:12px;padding:12px;">
          <div style="color:#f1ddb1;font-size:15px;letter-spacing:2px;">${escHtml(person.name)}</div>
          <div style="color:#a88e64;font-size:11px;margin-top:4px;">${escHtml(person.ancientRole || person.assignedRank || '朝臣')}</div>
          <div style="color:#999;font-size:12px;line-height:1.6;margin-top:8px;display:-webkit-box;-webkit-line-clamp:4;-webkit-box-orient:vertical;overflow:hidden;">${escHtml(person.ancientDescOriginal || person.ancientDesc || '暂无人物资料')}</div>
        </div>`).join('')}</div>` : '<div style="color:#777;text-align:center;padding:50px 0;">当前没有可列出的朝臣</div>';
      return;
    }
    const list = tab === 'pending' ? (zouZheData.pending || []) : (zouZheData.done || []);
    body.innerHTML = list.length ? list.map((item, index) => `
      <button class="court-memorial-row" data-index="${index}" style="width:100%;text-align:left;background:linear-gradient(135deg,rgba(54,39,24,0.88),rgba(22,17,12,0.92));border:1px solid rgba(201,163,106,0.3);border-radius:12px;padding:13px;margin-bottom:10px;color:#ddd;font-family:inherit;">
        <div style="display:flex;justify-content:space-between;gap:8px;"><span style="color:#f0dab0;font-size:14px;letter-spacing:1px;">${escHtml(item.title || '无题奏折')}</span><span style="color:#846f50;font-size:10px;white-space:nowrap;">${escHtml(item.time || '')}</span></div>
        <div style="color:#aa916a;font-size:11px;margin-top:6px;">${escHtml(item.author || '佚名')} · 点击查看全文</div>
      </button>`).join('') : `<div style="color:#777;text-align:center;padding:50px 0;">暂无${tab === 'pending' ? '待批' : '已批'}奏折</div>`;
    body.querySelectorAll('.court-memorial-row').forEach(button => {
      button.onclick = () => {
        const item = list[Number(button.dataset.index)];
        body.innerHTML = `
          <button id="court-detail-back" style="background:transparent;border:none;color:#a9926e;font-family:inherit;font-size:13px;padding:4px 0 14px;">‹ 返回奏折列表</button>
          <div style="background:#d8c59f;color:#3c2a18;border-radius:12px;padding:22px 18px;box-shadow:0 8px 28px rgba(0,0,0,0.45);line-height:1.9;">
            <div style="font-size:19px;text-align:center;font-weight:bold;letter-spacing:3px;margin-bottom:12px;">${escHtml(item.title || '无题奏折')}</div>
            <div style="font-size:12px;text-align:center;color:#765c39;margin-bottom:18px;">${escHtml(item.author || '佚名')} · ${escHtml(item.time || '时间不详')}</div>
            <div style="font-size:14px;white-space:pre-wrap;">${escHtml(item.content || item.text || item.body || '无正文')}</div>
            ${tab === 'done' ? `<div style="margin-top:18px;padding-top:14px;border-top:1px solid rgba(80,50,20,0.25);"><b>御批：</b><div style="white-space:pre-wrap;">${escHtml(item.reply || item.response || item.result || '已批阅')}</div></div>
            <div style="margin-top:18px;padding-top:14px;border-top:1px solid rgba(80,50,20,0.25);"><b>后续往来：</b>${Array.isArray(item._dialog) && item._dialog.length ? item._dialog.map((entry, dialogIndex) => `<div style="margin-top:10px;padding:10px;border-radius:8px;background:${entry.role === 'emperor' ? 'rgba(139,16,16,0.08)' : 'rgba(70,48,23,0.08)'};"><div style="font-size:11px;color:#775530;">${dialogIndex + 1}. ${entry.role === 'emperor' ? '皇帝朱批' : '大臣回执'}</div><div style="white-space:pre-wrap;margin-top:4px;">${escHtml(entry.text || '')}</div></div>`).join('') : '<div style="color:#826c4b;margin-top:8px;">暂无后续往来</div>'}</div>` : ''}
          </div>`;
        body.querySelector('#court-detail-back').onclick = () => render(tab);
      };
    });
  };
  modal.querySelectorAll('[data-tab]').forEach(button => button.onclick = () => render(button.dataset.tab));
  render(initialTab);
}

function setMorningCourtStoryUi(enabled) {
  const exitButton = document.getElementById('btn-exit-story');
  const rerollButton = document.getElementById('btn-story-reroll-modal');
  const nextButton = document.getElementById('btn-story-next');
  const input = document.getElementById('story-user-input');
  const badge = document.getElementById('court-status-badge');
  const inputRow = input.parentElement;
  if (enabled) {
    exitButton.innerText = '退朝';
    exitButton.style.width = '72px';
    exitButton.style.borderRadius = '18px';
    exitButton.style.fontSize = '14px';
    rerollButton.style.display = 'none';
    nextButton.innerText = '下一议题 ›';
    input.placeholder = '输入旨意、追问或决断...';
    inputRow.style.display = 'flex';
    badge.style.display = 'flex';
    renderMorningCourtBadge();
  } else {
    exitButton.innerText = '‹';
    exitButton.style.width = '';
    exitButton.style.borderRadius = '';
    exitButton.style.fontSize = '';
    rerollButton.style.display = 'flex';
    nextButton.innerText = '继续 ›';
    input.placeholder = '输入您的言行...';
    if (storyContext.mode !== 'morningAudience') inputRow.style.display = 'flex';
    badge.style.display = 'none';
  }
}

async function promptMorningCourt() {
  const cheatActive = isMorningCourtCheatActive();
  const inCourtTime = isMorningCourtTime();
  if (!inCourtTime && !cheatActive) {
    api.ui.toast('已过早朝时间。开通「养心殿 → 操作 → 金手指」后，可无视时辰强制上朝');
    return;
  }
  const message = !inCourtTime && cheatActive
    ? '当前已过早朝时辰，但金手指已开启。是否无视时辰，强制召集百官升殿？'
    : '百官已候于丹墀，是否即刻升殿上朝？';
  const ok = await api.ui.confirm({ title: '乾清宫 · 早朝', message });
  if (!ok) return;
  if (!inCourtTime && cheatActive) {
    api.ui.toast('金手指生效：无视时辰，百官即刻入朝');
  }
  await startMorningCourt();
}

async function startMorningCourt() {
  if (typeof switchTrackByName === 'function') switchTrackByName('泱泱', true);
  const courtData = buildMorningCourtContext();
  storyContext = {
    mode: 'morningCourt',
    pName: '乾清宫',
    rName: '朝堂',
    mainChar: courtData.officials[0] || null,
    history: [],
    courtOfficials: courtData.officials,
    courtNpcs: courtData.npcs,
    courtRecords: courtData.courtRecords,
    courtPromptText: courtData.promptText,
    pendingCourtRecord: ''
  };
  setMorningCourtStoryUi(true);
  document.getElementById('story-bg-layer').style.backgroundImage = `url('${palaceDetails['乾清宫'].bgUrl}')`;
  storyTextBox.innerText = '鸣鞭三响，百官入班，正在铺陈朝议...';
  storyTextBox.style.opacity = '1';
  storyControls.style.display = 'none';
  document.getElementById('story-text-wrap').style.display = 'flex';
  switchView(vStory);

  const speakerNames = [...courtData.officials, ...courtData.npcs].map(char => char.name).join('、') || '无固定名单，可仅用叙事段推进';
  const sysPrompt = `你是古代皇帝宫廷模拟游戏的“早朝剧情导演”。请依据下列完整资料演绎乾清宫早朝。\n\n${courtData.promptText}\n\n【可用发言者精确姓名】\n${speakerNames}\n\n【创作要求】\n1. 朝议必须围绕奏折展开，优先挑选2至4件最紧要或相互牵连的奏折；既可追问待批奏折，也要让已批奏折产生后续、反对意见或执行反馈。\n2. 大臣依身份、人设、记忆与利害上奏、争辩、请旨，真实char必须有参与感；可用名单中的NPC参与，但不得捏造或替换已存在角色的姓名。\n3. 皇帝就是User。绝对不要替User说话、下旨或作决定；最后停在需要User回复、追问或决断的位置。\n4. 可加入党争、证据矛盾、预算取舍、地方急报、官员互相拆台等有趣变化，但必须与给定资料相容。\n5. 拆成短段，每段都必须使用<p>标签。人物发言严格写成<p data-speaker="精确姓名">“实际台词”</p>。叙事段必须写成<p>实际发生的环境、动作或神态描写</p>。严禁把“旁白”两个字当作段落内容、前缀或说话者，严禁输出<p>旁白</p>、旁白：、【旁白】。\n6. 只输出格式完整且闭合的<p>段落，不得输出标签外文字、Markdown、标题、代码块或思考过程。\n7. 本轮约800至1200字，从鸣鞭、百官入班开始，先让数位朝臣陈奏与交锋，再等待User。`;
  try {
    const res = await api.ai.chat({ messages: [{ role: 'user', content: sysPrompt }] });
    const text = typeof res === 'string' ? res : (res?.content ?? res?.text ?? '');
    playStory(text);
  } catch (error) {
    storyTextBox.innerText = '早朝推演失败，请稍后重试。';
    storyControls.style.display = 'flex';
  }
}

function setRewardStoryUi(enabled) {
  const exit=document.getElementById('btn-exit-story'), reroll=document.getElementById('btn-story-reroll-modal'), next=document.getElementById('btn-story-next'), input=document.getElementById('story-user-input');
  if(enabled){exit.innerText='结束赏赐';exit.style.width='88px';exit.style.borderRadius='18px';exit.style.fontSize='12px';reroll.style.display='none';next.innerText='结束赏赐';input.parentElement.style.display='none';document.getElementById('court-status-badge').style.display='none';}
  else {exit.innerText='‹';exit.style.width='';exit.style.borderRadius='';exit.style.fontSize='';reroll.style.display='flex';next.innerText='继续 ›';input.parentElement.style.display='flex';}
}

async function startRewardCeremonyStory(target, reward, initialSavePromise = null) {
  const isConsort = target.ancientRole === '后妃';
  const assignedPalace = typeof getPalaceRootName === 'function' ? getPalaceRootName(target.assignedPalace) : String(target.assignedPalace || '').replace(/(正殿|东偏殿|西偏殿|耳房|庭院).*$/, '');
  const consortIndoorBg = isConsort && typeof target.indoorBgUrl === 'string' ? target.indoorBgUrl.trim() : '';
  const yangXinBg = palaceDetails['养心殿']?.bgUrl || '';
  const rewardBg = consortIndoorBg || yangXinBg || palaceDetails['御书房']?.bgUrl || '';
  const rewardPlace = consortIndoorBg ? (target.assignedPalace || assignedPalace || '寝宫内殿') : '养心殿';
  storyContext={mode:'rewardCeremony',pName:rewardPlace,rName:'赏赐',mainChar:target,participants:[XLY_CHAR,target],history:[],rewardTarget:target,rewardData:reward,rewardBackground:rewardBg};
  setMorningCourtStoryUi(false); setRewardStoryUi(true);
  document.getElementById('story-bg-layer').style.backgroundImage=`url('${rewardBg}')`;
  const targetAvatar = getCharacterPortraitUrl(target);
  if (targetAvatar) {
    storyCardImg.src = targetAvatar;
    storyCardName.innerText = target.name;
    const cfg = target.storyAvatarCfg || { scale:100, x:0, y:0 };
    storyCardImg.style.transform = `translate(${cfg.x}px, ${cfg.y}px) scale(${cfg.scale / 100})`;
    storyActiveCard.style.display = 'flex'; storyActiveCard.style.opacity = '1';
    window.currentStoryDisplayChar = target;
  } else {
    storyActiveCard.style.display = 'none'; storyActiveCard.style.opacity = '0';
    window.currentStoryDisplayChar = null;
  }
  storyTextBox.innerText='谢临渊正奉旨准备赏赐……';storyTextBox.style.opacity='1';storyControls.style.display='none';document.getElementById('story-text-wrap').style.display='flex';switchView(vStory);
  if (initialSavePromise) await initialSavePromise;
  const prompt=`你是古代皇帝宫廷模拟游戏的剧情导演。皇帝刚刚颁下赏赐：${reward.detail}，受赏者是${getRewardIdentity(target)}${target.name}。请演绎谢临渊领旨、准备仪仗与赏物、前往传谕，以及${target.name}接旨受赏的全过程。
【本次剧情地点】${rewardPlace}。${isConsort ? (consortIndoorBg ? `谢临渊已前往${target.name}所居的${rewardPlace}传旨，不得写成将其传召到养心殿。` : `${target.name}尚未设定寝宫内殿场景，本次在养心殿接旨。`) : `受赏者不是后妃，本次在养心殿接旨。`}
当前时间：${reward.time}

【全局设定】
${buildGlobalAiContext()}

【谢临渊与受赏者完整人设、TA看到的、TA了解的、TA的思绪】
${buildCharactersAiContext([XLY_CHAR,target])}

不要输出JSON、Markdown、代码块或解释。严格按下列分隔标签输出：
<reaction-summary>不超过200字，客观总结${target.name}收到${reward.detail}后的具体反应、言行与情绪，不虚构User的额外行为</reaction-summary>
<story>
在这里输出约2000字剧情，拆为至少20个短段。叙事用<p>内容</p>；台词只允许谢临渊和${target.name}，分别用<p data-speaker="谢临渊">台词</p>与<p data-speaker="${target.name}">台词</p>。不得让User参与、说话或做决定，不得输出“旁白”二字。
</story>`;
  let html='',summary='',raw='';
  try {
    const res=await api.ai.chat({messages:[{role:'user',content:prompt}]});
    raw=String(typeof res==='string'?res:(res?.content??res?.text??'')).replace(/```(?:html|xml)?|```/gi,'').trim();
    const summaryMatch=raw.match(/<reaction-summary>([\s\S]*?)(?:<\/reaction-summary>|<story>)/i);
    const storyMatch=raw.match(/<story>([\s\S]*?)(?:<\/story>|$)/i);
    summary=String(summaryMatch?.[1]||'').replace(/<[^>]+>/g,'').trim();
    html=String(storyMatch?.[1]||'').trim();
    if (!html) html=(raw.match(/<p(?:[^>]*)>[\s\S]*?(?:<\/p>|$)/gi)||[]).join('');
    if (!html) html=raw;
  } catch(e) {
    api.ui.toast('赏赐剧情生成失败，已使用保底剧情');
    html=`<p>谢临渊奉旨将${reward.detail}送至${target.name}处，依礼宣谕。</p><p data-speaker="${target.name}">“臣领赏，叩谢圣恩。”</p>`;
  }
  // 如果服务返回被截断或只有数句，自动补试一次，不再因格式问题直接播放两句保底文。
  if (String(html).replace(/<[^>]+>/g,'').trim().length < 600) {
    try {
      const retryPrompt=`请重新完整生成这次赏赐剧情：皇帝命谢临渊向${getRewardIdentity(target)}${target.name}${reward.detail}。地点为${rewardPlace}，当前时间为${reward.time}。
必须严格依据以下人物资料：
${buildCharactersAiContext([XLY_CHAR,target])}
只输出<story>...</story>；标签内写约2000字、至少20个短段。叙事用<p>内容</p>，台词用<p data-speaker="准确姓名">台词</p>。不得使用JSON，不得替User说话，不得输出“旁白”字样。`;
      const retryRes=await api.ai.chat({messages:[{role:'user',content:retryPrompt}]});
      const retryRaw=String(typeof retryRes==='string'?retryRes:(retryRes?.content??retryRes?.text??'')).replace(/```(?:html|xml)?|```/gi,'').trim();
      const retryStory=String(retryRaw.match(/<story>([\s\S]*?)(?:<\/story>|$)/i)?.[1] || (retryRaw.match(/<p(?:[^>]*)>[\s\S]*?(?:<\/p>|$)/gi)||[]).join('')).trim();
      if (retryStory.replace(/<[^>]+>/g,'').trim().length > String(html).replace(/<[^>]+>/g,'').trim().length) html=retryStory;
    } catch(e) {}
  }
  if(!summary)summary=`${target.name}收到皇帝${reward.detail}，由谢临渊奉旨传谕并依礼领受，对此次恩赏郑重谢恩。`;
  const reactionText=`【赏赐反应】${summary}`;if(!Array.isArray(target.memorySeen))target.memorySeen=[];target.memorySeen.unshift({time:reward.time,text:reactionText});
  syncPublicNewsToCharacterRecords(reward.publicText, reward.time, ['赏赐', '众闻'], target.name);
  await saveTreasuryState({characters:selectedCharsData,xlyMemoryKnown:XLY_CHAR.memoryKnown,xlyRecords:XLY_CHAR.records,courtNpcData:window._courtNpcData||[]});
  api.ui.toast('赏赐众闻已写入全员“TA了解的 → 起居注”，当事人反应已录入“TA看到的”');playStory(html);
}

// 声音按钮
document.getElementById('btn-story-voice').addEventListener('click', (e) => {
  e.stopPropagation();
  storyVoiceEnabled = !storyVoiceEnabled;
  const btn = document.getElementById('btn-story-voice');
  document.getElementById('voice-icon-on').style.display  = storyVoiceEnabled ? 'block' : 'none';
  document.getElementById('voice-icon-off').style.display = storyVoiceEnabled ? 'none'  : 'block';
  btn.style.borderColor = storyVoiceEnabled ? 'var(--primary-color)' : '#555';
  btn.style.color       = storyVoiceEnabled ? 'var(--primary-color)' : '#555';
});

document.getElementById('btn-story-bgm').addEventListener('click', event => {
  event.stopPropagation();
  musicPanel.classList.toggle('open');
  syncBgmBtns();
});

async function startAiStory(pName, rName, char, customOptions = null) {
  if (typeof isCharacterUnavailableForActivity === 'function' && isCharacterUnavailableForActivity(char)) {
    await notifyCharacterUnavailable(char);
    return;
  }
  storyContext = { pName, rName, mainChar:char, history:[], participants:[] };
  setMorningCourtStoryUi(false);
  document.getElementById('story-bg-layer').style.backgroundImage = `url('${palaceDetails[pName].bgUrl}')`;
  storyTextBox.innerText = "正在推演宫中动向...";
  storyTextBox.style.opacity = '1';
  storyControls.style.display = 'none';
  document.getElementById('story-text-wrap').style.display = 'flex';
  switchView(vStory);
  
  // 构造发给AI的信息
  const timeStr = hudTime.innerText;
  // 获取全部妃子（不管在不在本宫，确保发给AI全量数据）
  const allConcubines = selectedCharsData.filter(c => c.ancientRole==='后妃' && !(typeof isCharacterUnavailableForActivity === 'function' && isCharacterUnavailableForActivity(c)));
  
  // 获取同宫妃子名单
  const coResidents = allConcubines.filter(c => c.assignedPalace && c.assignedPalace.startsWith(pName) && c.name !== char.name);
  storyContext.participants = allConcubines;
  const coResidentNames = coResidents.length > 0 ? coResidents.map(c => c.name).join('、') : '无';
  
  // 从全局世界书组装附加信息
  let wbText = "";
  if (userAncientDesc) wbText += `【皇帝（User）人设】：\n${userAncientDesc}\n\n`;
  if (window.globalWorldDesc) wbText += `【大世界设定】：\n${window.globalWorldDesc}\n\n`;
  if (window.globalRulesDesc) wbText += `【后宫规矩与皇权设定】：\n${window.globalRulesDesc}\n\n`;
  if (rankData && rankData.length > 0) {
    wbText += `【后宫位份体系】：\n` + rankData.map(r => `- ${r.rank} (自称:${r.selfClaim})`).join('\n') + `\n\n`;
  }
  
  let concubinesInfo = allConcubines.map(c => {
    // 优先使用原始人设，避免带有重复被追加的全局位份表
    let desc = c.ancientDescOriginal || c.ancientDesc.replace(/^【当前游戏时间】：[^\n]*\n?/, '').replace(/【当前后宫位份体系（由高到低）】[\s\S]*/, '');
    let charWb = c.charWorldDesc ? `\n【专属世界书】：\n${c.charWorldDesc}` : '';
    // TA了解的
    let knownText = (c.memoryKnown || []).join('\n') || '无';
    // TA看到的
    let seenText = (c.memorySeen || []).map(m => `[${m.time}] ${m.text}`).join('\n') || '无';
    // 起居注
    let recText = (c.records || []).slice(0, 5).map(r => `[${r.time}] ${r.text}`).join('\n') || '无';
    // 关系图谱
    const relLines = [];
    allConcubines.filter(o => o.name !== c.name).forEach(other => {
      const key = `${c.name}->${other.name}`;
      const rel = window._relationData?.[key];
      if (rel?.text) relLines.push(`对${other.name}：${rel.text}`);
    });
    let relText = relLines.length > 0 ? relLines.join('\n') : '无';
    return `【${c.name}】
位份：${c.assignedRank || '无'} | 居所：${c.assignedPalace || '无'}
人物设定：${desc}${charWb}
TA了解的：${knownText}
TA看到的：${seenText}
起居注：${recText}
关系图谱：${relText}`;
  }).join('\n\n');

  // 构建自定义重roll要求
  let customRule = "";
  if (customOptions) {
    let parts = [];
    if (customOptions.mainPresence === "在场") parts.push(`主位妃子（${char.name}）当前必须在场！`);
    if (customOptions.mainPresence === "不在场") parts.push(`主位妃子（${char.name}）当前不在场，可能只有宫女太监在！`);
    if (customOptions.visitor) parts.push(`妃子【${customOptions.visitor}】正好来此地串门，必须让她出场！`);
    if (customOptions.prompt) parts.push(`剧情走向提示：${customOptions.prompt}`);
    if (parts.length > 0) {
      customRule = `\n\n【本次推演强制设定（User指定）】：\n` + parts.map((p,i) => `${i+1}. ${p}`).join('\n');
    }
  }
  
  let sysPrompt = customPrompts.storyReroll || defaultPrompts.storyReroll;
  sysPrompt = sysPrompt
    .replace('{{timeStr}}', timeStr)
    .replace(/\{\{pName\}\}/g, pName)
    .replace('{{rName}}', rName)
    .replace(/\{\{charName\}\}/g, char.name)
    .replace(/\{\{coResidentNames\}\}/g, coResidentNames)
    .replace('{{wbText}}', wbText)
    .replace('{{concubinesInfo}}', concubinesInfo)
    .replace('{{customRule}}', customRule);
  sysPrompt += `\n\n${getAiParagraphFormatGuard()}`;

  try {
    const res = await api.ai.chat({ messages:[{role:"user", content:sysPrompt}] });
    const text = typeof res === 'string' ? res : (res?.content ?? res?.text ?? '');
    playStory(text);
  } catch(e) {
    storyTextBox.innerText = "推演失败，请重试。";
  }
}

let storySegments = [];
let currentSegmentIdx = 0;

function normalizeStorySegmentText(text, speaker) {
  let normalized = String(text || '').trim();
  if (!speaker || /^(?:旁白|叙述|Narrator)$/i.test(String(speaker).trim())) {
    normalized = normalized
      .replace(/^\s*[【\[]?旁白[】\]]?\s*[:：]\s*/i, '')
      .replace(/^\s*[【\[]?叙述[】\]]?\s*[:：]\s*/i, '');
    if (/^\s*[【\[]?旁白[】\]]?\s*$/i.test(normalized)) return '';
  }
  return normalized;
}

function extractStorySpeakerFromTag(tagText) {
  const match = String(tagText || '').match(/\b(?:data-)?speaker\s*=\s*(?:"([^"]+)"|'([^']+)'|“([^”]+)”|‘([^’]+)’|([^\s>]+))/i);
  return (match?.[1] || match?.[2] || match?.[3] || match?.[4] || match?.[5] || '').trim() || null;
}

function playStory(fullText) {
  // 过滤掉 AI 的 <think> 思考过程
  const cleanText = fullText.replace(/<think>[\s\S]*?<\/think>/g, '');

  // 解析段落
  const pRegex = /<p(?:[^>]*)>(.*?)<\/p>/g;
  storySegments = [];
  let match;
  while ((match = pRegex.exec(cleanText)) !== null) {
    const pTag = match[0];
    const rawContent = match[1];
    let speaker = null;
    speaker = extractStorySpeakerFromTag(pTag);
    if (/^(?:旁白|叙述|Narrator)$/i.test(String(speaker || '').trim())) speaker = null;
    const content = normalizeStorySegmentText(rawContent, speaker);
    if (content) storySegments.push({ type: speaker ? 'dialogue' : 'desc', speaker, text: content });
  }
  
  if (storySegments.length === 0) {
    // 兜底降级处理
    storySegments = fullText.replace(/<[^>]+>/g, '').split('\n').map(x => normalizeStorySegmentText(x, null)).filter(Boolean).map(x => ({ type:'desc', speaker:null, text:x }));
  }
  
  currentSegmentIdx = 0;
  storyContext.history = []; // 重置履历
  showNextSegment();
}

// 打断当前 TTS 播放的标志
let ttsAbortFlag = false;

// 点击屏幕/文字框推进剧情
let storyTapHandler = null;
function setStoryTapHandler(fn) {
  const blocker = document.getElementById('story-blocker');
  const textBox = document.getElementById('story-text-box').parentElement; // 磨砂框
  if (storyTapHandler) {
    blocker.removeEventListener('click', storyTapHandler);
    textBox.removeEventListener('click', storyTapHandler);
  }
  storyTapHandler = fn;
  if (fn) {
    blocker.addEventListener('click', fn);
    textBox.addEventListener('click', fn);
  }
}

function showNextSegment() {
  const textWrap = document.getElementById('story-text-wrap');
  if (currentSegmentIdx >= storySegments.length) {
    // 全部播完，显示输入控制区，等待 user 输入
    storyTextBox.innerHTML = storyContext.mode === 'rewardCeremony'
      ? '<span style="color:#b99b69;font-size:13px;">— 赏赐已毕，反应小结已录入 —</span>'
      : storyContext.mode === 'huaqingConferral'
        ? '<span style="color:#b99b69;font-size:13px;">— 册封礼毕，人物与众闻均已入册 —</span>'
      : '<span style="color:#888;font-size:13px;">— 此幕已终 / 等待您的言行 —</span>';
    storyControls.style.display = 'flex';
    // 动态计算控制区高度，把文字框往上推
    const controlsHeight = storyControls.offsetHeight;
    textWrap.style.bottom = `calc(var(--safe-bottom) + ${controlsHeight + 20}px)`;
    setStoryTapHandler(null);
    return;
  }
  // 播放剧情时，文字框贴底
  textWrap.style.bottom = 'calc(var(--safe-bottom) + 8px)';

  // 禁止点击（渲染中）
  setStoryTapHandler(null);

  const seg = storySegments[currentSegmentIdx];
  storyContext.history.push(seg);

  // 优化丝滑过渡：先淡出旧文字
  storyTextBox.style.opacity = '0';
  
  // 卡片判断
  let targetChar = null;
  if (seg.speaker && seg.speaker !== '路人' && seg.speaker !== '皇帝') {
    targetChar = getStoryCharacterByName(seg.speaker);
  }
  const targetAvatar = getCharacterPortraitUrl(targetChar);
  const speakerHasPortrait = Boolean(targetChar && targetAvatar);
  if (!speakerHasPortrait) targetChar = null;
  window.currentStoryDisplayChar = targetChar;
  document.getElementById('btn-story-avatar-adj').style.display = targetChar ? 'flex' : 'none';

  // 隐藏容器框
  textWrap.style.opacity = '0';
  
  setTimeout(async () => {
    // 立绘显示平滑过渡
    if (targetChar) {
      const displayAvatar = getCharacterPortraitUrl(targetChar);
      const applyTargetCharTransform = () => {
        if (targetChar.storyAvatarCfg) {
          const cfg = targetChar.storyAvatarCfg;
          storyCardImg.style.transform = `translate(${cfg.x}px, ${cfg.y}px) scale(${cfg.scale / 100})`;
        } else {
          storyCardImg.style.transform = 'translate(0px, 0px) scale(1)';
        }
      };
      
      if (storyCardImg.src !== displayAvatar || storyCardName.innerText !== targetChar.name) {
        // 先淡出旧立绘
        storyActiveCard.style.opacity = '0';
        setTimeout(() => {
          storyCardImg.src = displayAvatar;
          storyCardName.innerText = targetChar.name;
          applyTargetCharTransform();
          storyActiveCard.style.display = 'flex';
          storyActiveCard.offsetHeight; // 强制重绘
          storyActiveCard.style.opacity = '1';
        }, 300);
      } else {
        // 同一个人，直接确保显示
        applyTargetCharTransform();
        storyActiveCard.style.display = 'flex';
        storyActiveCard.offsetHeight;
        storyActiveCard.style.opacity = '1';
      }
    } else {
      storyActiveCard.style.opacity = '0';
      setTimeout(() => { storyActiveCard.style.display = 'none'; }, 400);
    }

    // 框淡入，文字打字机
    storyTextBox.innerHTML = '';
    textWrap.style.opacity = '1';
    storyTextBox.style.opacity = '1';
    
    // 渲染打字机
    setStoryTapHandler(() => { skipTypewriter(); }); // 渲染中点击可跳过打字
    const displayedText = seg.speaker && !speakerHasPortrait
      ? `<span style="color:#d9bd83;font-size:12px;letter-spacing:2px;">【${String(seg.speaker).replace(/[<>&]/g, '')}】</span><br>${seg.text}`
      : seg.text;
    await playTypewriter(storyTextBox, displayedText, 2500); // 适中速度打完

    // TTS（受声音开关控制，可被点击打断）
    if (storyVoiceEnabled && seg.speaker && seg.speaker !== '路人') {
      const c = getStoryCharacterByName(seg.speaker);
      if (c) {
        const pref = c.voicePref || {};
        // 朗读范围
        if (pref.readMode === 'none') {
          currentSegmentIdx++;
          setStoryTapHandler(() => { showNextSegment(); });
          return;
        }
        const speechMatch = seg.text.match(/"([^"]+)"/);
        let textToRead;
        if (pref.readMode === 'all_text') {
          textToRead = seg.text.replace(/<[^>]+>/g, '');
        } else {
          textToRead = speechMatch ? speechMatch[1] : seg.text.replace(/<[^>]+>/g, '');
        }
        if (pref.customPrefix) textToRead = pref.customPrefix + textToRead;
        if (pref.customSuffix) textToRead = textToRead + pref.customSuffix;
        ttsAbortFlag = false;
        // 打完字后，点击打断语音进入下一段
        currentSegmentIdx++;
        setStoryTapHandler(() => {
          ttsAbortFlag = true;
          try { api.voice.stop && api.voice.stop(); } catch(e) {}
          showNextSegment();
        });
        try {
          const ttsArgs = { characterId: c.id, text: textToRead };
          if (pref.emotion && pref.emotion !== 'neutral') ttsArgs.emotion = pref.emotion;
          const s = await api.voice.tts(ttsArgs);
          if (!ttsAbortFlag) {
            await api.voice.play({ dataUrl: s.dataUrl });
          }
        } catch(e) {}
        // 语音自然播完后，推进到下一段
        if (!ttsAbortFlag) {
          setStoryTapHandler(() => { showNextSegment(); });
        }
        return; 
      }
    }

    // 无语音段：打字机播完后，等待点击推进
    currentSegmentIdx++;
    setStoryTapHandler(() => { showNextSegment(); });

  }, 400);
}

document.getElementById('btn-story-replay').addEventListener('click', () => {
  if (storySegments.length > 0) {
    const segCount = storySegments.length;
    if (storyContext.history.length >= segCount) {
      storyContext.history.splice(storyContext.history.length - segCount, segCount);
    } else {
      storyContext.history = [];
    }
    currentSegmentIdx = 0;
    document.getElementById('story-controls').style.display = 'none';
    document.getElementById('story-blocker').style.display = 'block';
    showNextSegment();
  }
});

document.getElementById('btn-story-send').addEventListener('click', async () => {
  const input = document.getElementById('story-user-input');
  if(!input.value.trim()) return;
  const userText = input.value.trim();
  storyContext.history.push({ type:'user', speaker:'皇帝', text: userText });
  input.value = '';
  
  storyTextBox.innerText = "推演中...";
  storyControls.style.display = 'none';
  document.getElementById('story-text-wrap').style.bottom = 'calc(var(--safe-bottom) + 8px)';
  
  // 拼接历史
  const historyText = storyContext.history.map(x => `${x.speaker ? x.speaker : '叙事段'}：${x.text}`).join('\n');
  let sysPrompt;
  if (storyContext.mode === 'morningCourt') {
    const speakerNames = [...(storyContext.courtOfficials || []), ...(storyContext.courtNpcs || [])].map(char => char.name).join('、');
    sysPrompt = `你是古代皇帝宫廷模拟游戏的“早朝剧情导演”。请继续乾清宫朝议。

${storyContext.courtPromptText}

【可用发言者精确姓名】
${speakerNames || '无固定名单'}

【截至现在的完整朝议履历】
${historyText}

【续写要求】
1. 直接承接皇帝（User）最新的回复、追问或决断，让相关大臣作出符合身份、人设、记忆和利害的反应。
2. 继续围绕尚未解决的奏折推进；可补充证据、引出关联奏折、形成派系争辩或呈报执行后果，避免重复上一轮。
3. 绝对不要替User说话、下旨或决定。结尾再次停在需要User回应的位置，除非User主动点击“退朝”，否则不得自行结束早朝。
4. 人物发言严格写成<p data-speaker="精确姓名">“实际台词”</p>；叙事段写成<p>实际环境、动作或神态描写</p>。严禁输出“旁白”二字，严禁<p>旁白</p>、旁白：、【旁白】。
5. 只输出格式完整、正确闭合的<p>段落，不得输出标签外文字、Markdown、标题、代码块或思考过程。
6. 本轮正文约1500字，至少安排15个有实质推进的小段；一个内容小段可以拆成连续两至三个短<p>。`;
  } else {
    sysPrompt = customPrompts.storyReply || defaultPrompts.storyReply;
    sysPrompt = sysPrompt.replace('{{historyText}}', historyText);
    const participants = storyContext.participants?.length ? storyContext.participants : [storyContext.mainChar];
    sysPrompt += `\n\n【本轮必须重新读取的全局设定】\n${buildGlobalAiContext()}\n\n【本轮必须重新读取的在场人物完整档案】\n${buildCharactersAiContext(participants)}\n\n【地点与事件前提】\n${storyContext.scenePremise || `皇帝仍在${storyContext.pName || '当前宫殿'}${storyContext.rName || ''}，继续刚才亲自到访后发生的剧情；不得改写为养心殿传召。`}\n\n${getAiParagraphFormatGuard()}`;
  }
  // 运行时再追加统一长续写约束，覆盖旧存档中的500/800字自定义提示词。
  sysPrompt += `\n\n${getLongPlotContinuationGuard()}`;

  try {
    const res = await api.ai.chat({ messages:[{role:"user", content:sysPrompt}] });
    const text = typeof res === 'string' ? res : (res?.content ?? res?.text ?? '');
    // 这里偷懒复用 playStory 逻辑，但不重新解析 meta
    const pRegex = /<p(?:[^>]*)>(.*?)<\/p>/g;
    storySegments = [];
    let match;
    while ((match = pRegex.exec(text)) !== null) {
      const pTag = match[0];
      const rawContent = match[1];
      let speaker = null;
      speaker = extractStorySpeakerFromTag(pTag);
      if (/^(?:旁白|叙述|Narrator)$/i.test(String(speaker || '').trim())) speaker = null;
      const content = normalizeStorySegmentText(rawContent, speaker);
      if (content) storySegments.push({ type: speaker ? 'dialogue' : 'desc', speaker, text: content });
    }
    if (storySegments.length === 0) storySegments = text.replace(/<[^>]+>/g, '').split('\n').map(x => normalizeStorySegmentText(x, null)).filter(Boolean).map(x => ({ type:'desc', speaker:null, text:x }));
    currentSegmentIdx = 0;
    showNextSegment();
  } catch(e) {
    storyTextBox.innerText = "推演失败。";
    storyControls.style.display = 'flex';
  }
});

document.getElementById('btn-story-next').addEventListener('click', () => {
  if (storyContext.mode === 'rewardCeremony') {
    setRewardStoryUi(false);
    switchView(vPalaceDetail);
    return;
  }
  if (storyContext.mode === 'morningAudience') {
    continueMorningAudience();
    return;
  }
  if (storyContext.mode === 'huaqingConferral') {
    setHuaQingConferralStoryUi(false);
    enterPalaceDetailView('华清宫');
    return;
  }
  const input = document.getElementById('story-user-input');
  if (!input.value.trim()) {
    input.value = storyContext.mode === 'morningCourt'
      ? '请继续朝议，转入下一件最紧要的奏折，并让其他朝臣陈明意见。'
      : '请继续推进此幕。';
  }
  document.getElementById('btn-story-send').click();
});


// 重推弹窗
const storyRerollModal = document.getElementById('story-reroll-modal');
const rerollVisitorSelect = document.getElementById('reroll-visitor');

document.getElementById('btn-story-reroll-modal').addEventListener('click', () => {
  if (storyContext.mode === 'morningCourt') {
    startMorningCourt();
    return;
  }
  if (storyContext.mode === 'imperialGarden') {
    startImperialGardenStory(storyContext.gardenKind, storyContext.gardenChosen || [], storyContext.gardenSolo);
    return;
  }
  if (storyContext.mode === 'morningAudience') {
    startMorningAudience(storyContext.mainChar, storyContext.isCatchUp);
    return;
  }
  if (storyContext.mode === 'huaqingSummon') {
    startHuaQingSummonStory(storyContext.huaqingChosen || storyContext.participants || []);
    return;
  }
  if (storyContext.mode === 'huaqingBath') {
    startHuaQingBath(storyContext.bathCandidates || []);
    return;
  }
  const allConcubines = selectedCharsData.filter(c => c.ancientRole==='后妃' && !(typeof isCharacterUnavailableForActivity === 'function' && isCharacterUnavailableForActivity(c)));
  rerollVisitorSelect.innerHTML = '<option value="">随机/无人串门</option>' + 
    allConcubines.filter(c => c.name !== storyContext.mainChar.name).map(c => `<option value="${c.name}">${c.name}</option>`).join('');
  document.getElementById('reroll-main-presence').value = "";
  document.getElementById('reroll-prompt').value = "";
  
  // 恢复背景文字框的提示
  document.getElementById('story-text-box').innerHTML = "准备重新推演，请在弹窗中选择条件...";
  document.getElementById('story-text-wrap').style.opacity = '1';
  document.getElementById('story-text-box').style.opacity = '1';
  document.getElementById('story-controls').style.display = 'none';
  
  storyRerollModal.style.display = 'flex';
});

document.getElementById('btn-reroll-cancel').addEventListener('click', () => {
  storyRerollModal.style.display = 'none';
});

document.getElementById('btn-reroll-confirm').addEventListener('click', () => {
  storyRerollModal.style.display = 'none';
  const customOptions = {
    mainPresence: document.getElementById('reroll-main-presence').value,
    visitor: document.getElementById('reroll-visitor').value,
    prompt: document.getElementById('reroll-prompt').value.trim()
  };
  
  // 停止当前语音与推进
  ttsAbortFlag = true;
  try { api.voice.stop && api.voice.stop(); } catch(e) {}
  setStoryTapHandler(null);
  
  startAiStory(storyContext.pName, storyContext.rName, storyContext.mainChar, customOptions);
});

// 退出与记忆结算
const storyExitModal = document.getElementById('story-exit-modal');
const memoryConfirmModal = document.getElementById('memory-confirm-modal');
const memorySummaryInput = document.getElementById('memory-summary-input');
let pendingMemorySummary = "";

function renderLastStoryMoment(context) {
  const activeContext = context || storyContext;
  const last = activeContext?.history?.[activeContext.history.length - 1];
  switchView(vStory);
  memoryConfirmModal.style.display = 'none';
  storyExitModal.style.display = 'none';
  const textWrap = document.getElementById('story-text-wrap');
  textWrap.style.display = 'flex';
  textWrap.style.opacity = '1';
  storyTextBox.style.opacity = '1';
  storyTextBox.innerHTML = last
    ? `${last.speaker ? `<span style="color:#d9bd83;font-size:12px;letter-spacing:2px;">【${escHtml(last.speaker)}】</span><br>` : ''}${escHtml(last.text)}`
    : '<span style="color:#888;">— 本轮剧情仍在，可重新选择记忆方式 —</span>';
  storyControls.style.display = 'flex';
  textWrap.style.bottom = `calc(var(--safe-bottom) + ${storyControls.offsetHeight + 20}px)`;
  document.getElementById('story-blocker').style.display = 'none';
  setStoryTapHandler(null);
}

function captureMemorySettlementState() {
  const all = [...selectedCharsData, (typeof XLY_CHAR !== 'undefined' ? XLY_CHAR : null), ...(window._courtNpcData || [])].filter(Boolean);
  const seen = new Set();
  return {
    characters: all.filter(char => {
      const key = char.id || char.name;
      if (!key || seen.has(key)) return false;
      seen.add(key);
      return true;
    }).map(char => ({
      char,
      memorySeen: Array.isArray(char.memorySeen) ? char.memorySeen.slice() : [],
      records: Array.isArray(char.records) ? char.records.slice() : []
    })),
    courtUserMemorySeen: Array.isArray(window._courtUserMemorySeen) ? window._courtUserMemorySeen.slice() : [],
    qianchaoRecords: Array.isArray(window._qianchaoRecords) ? window._qianchaoRecords.slice() : []
  };
}

function restoreMemorySettlementState(snapshot) {
  if (!snapshot) return;
  snapshot.characters.forEach(item => {
    item.char.memorySeen = item.memorySeen;
    item.char.records = item.records;
  });
  window._courtUserMemorySeen = snapshot.courtUserMemorySeen;
  window._qianchaoRecords = snapshot.qianchaoRecords;
  if (typeof XLY_CHAR !== 'undefined') {
    window._xlyMemorySeen = XLY_CHAR.memorySeen;
    window._xlyRecords = XLY_CHAR.records;
  }
}

function handleMemorySettlementFailure(pendingFlow, snapshot, message = '记忆保存失败，剧情已保留，可重新尝试') {
  restoreMemorySettlementState(snapshot);
  window._pendingMemoryFlow = null;
  if (pendingFlow?.type === 'indoor') restoreIndoorMemoryMoment(message);
  else {
    renderLastStoryMoment(pendingFlow?.context || storyContext);
    api.ui.toast(message);
  }
}

document.getElementById('btn-exit-story').addEventListener('click', () => {
  if (storyContext.mode === 'rewardCeremony') {
    setRewardStoryUi(false);
    switchView(vPalaceDetail);
    return;
  }
  if (storyContext.mode === 'huaqingConferral') {
    setHuaQingConferralStoryUi(false);
    enterPalaceDetailView('华清宫');
    return;
  }
  const isCourt = storyContext.mode === 'morningCourt';
  const isAudience = storyContext.mode === 'morningAudience';
  const isHuaQingBath = storyContext.mode === 'huaqingBath';
  document.getElementById('story-exit-title').innerText = isCourt ? '退朝' : isAudience ? '退出小会' : '离去';
  document.getElementById('story-exit-message').innerHTML = isCourt
    ? '是否将本次朝议化作在场众人的记忆？<br><span style="font-size:12px; color:#888;">若选择“是”，将先由AI提炼小结，确认后同时写入“TA看到的”与前朝记事。</span>'
    : isAudience
      ? '是否把今早的晨昏定省小会录入所有在场后妃的记忆？<br><span style="font-size:12px; color:#888;">选择“是”后可先确认AI小结。</span>'
      : isHuaQingBath
        ? '是否将本次华清宫沐浴录入这名NPC的记忆？<br><span style="font-size:12px; color:#c9a36a;">确认小结并写入“TA看到的”后，将继续询问是否赐封，并进入位份、宫殿与册封剧情流程。</span>'
        : '是否将这段见闻化作在场众人的记忆？<br><span style="font-size:12px; color:#888;">(若选是，AI将自动提炼这段经历存入TA们的内心)</span>';
  document.getElementById('btn-exit-forget').innerText = isCourt ? '否，不留记录' : '当做无事发生';
  document.getElementById('btn-exit-remember').innerText = isCourt ? '是，提炼小结' : '铭记于心';
  storyExitModal.style.display = 'flex';
});
document.getElementById('btn-exit-cancel').addEventListener('click', () => {
  storyExitModal.style.display = 'none';
});
document.getElementById('btn-exit-forget').addEventListener('click', () => {
  storyExitModal.style.display = 'none';
  window._pendingMemoryFlow = null;
  switchView(vPalaceDetail);
  if (storyContext.mode === 'morningCourt') setMorningCourtStoryUi(false);
  if (storyContext.mode === 'morningAudience') { setMorningAudienceStoryUi(false); setMorningCourtStoryUi(false); }
});
document.getElementById('btn-exit-remember').addEventListener('click', async () => {
  storyExitModal.style.display = 'none';
  storyTextBox.innerText = "正在提炼剧情小结...";
  storyControls.style.display = 'none';

  // 保存退出瞬间的剧情对象，防止AI总结期间页面或其他弹窗改写全局storyContext。
  const settlementContext = storyContext;
  window._pendingMemoryFlow = { type: 'story', context: settlementContext };
  const historyText = settlementContext.history.map(x => `${x.speaker?x.speaker:'叙事段'}：${x.text}`).join('\n');
  const sysPrompt = settlementContext.mode === 'morningCourt'
    ? `请总结以下刚刚结束的皇帝早朝。只输出一个JSON对象，不要Markdown，不要任何解释：\n{\n  "memorySummary": "给所有在场者写入TA看到的客观朝议小结，不超过200字",\n  "recordSummary": "用于养心殿记事总录前朝标签的独立小结，不超过100字，点明核心奏折、争议与皇帝决断；如皇帝尚未决断则如实写明"\n}\n\n朝议记录：\n${historyText}`
    : `请把以下刚发生的剧情，总结为一段不超过200字的客观陈述。\n剧情记录：\n${historyText}`;
  try {
    const res = await api.ai.chat({ messages:[{role:"user", content:sysPrompt}] });
    const rawSummary = String(typeof res === 'string' ? res : (res?.content ?? res?.text ?? '')).trim();
    if (!rawSummary) throw new Error('empty memory summary');
    const memoryTitle = document.getElementById('memory-confirm-title');
    if (memoryTitle) memoryTitle.innerText = '确认记忆小结';
    if (settlementContext.mode === 'morningCourt') {
      const jsonMatch = rawSummary.match(/\{[\s\S]*\}/);
      let parsed = null;
      try { parsed = jsonMatch ? JSON.parse(jsonMatch[0]) : null; } catch (error) {}
      pendingMemorySummary = parsed?.memorySummary || rawSummary.replace(/```(?:json)?|```/g, '').trim().slice(0, 200);
      settlementContext.pendingCourtRecord = (parsed?.recordSummary || pendingMemorySummary).trim().slice(0, 100);
      document.getElementById('memory-confirm-hint').innerText = '确认后将录入在场所有角色与NPC的「TA看到的」，并生成一条“前朝”记事';
    } else {
      pendingMemorySummary = rawSummary;
      document.getElementById('memory-confirm-hint').innerText = settlementContext.mode === 'huaqingBath'
        ? '确认后写入该NPC的「TA看到的」，随后继续赐封流程'
        : '此记忆将被录入在场所有人的「TA看到的」';
    }
    memorySummaryInput.value = pendingMemorySummary;
    memoryConfirmModal.style.display = 'flex';
  } catch(e) {
    window._pendingMemoryFlow = null;
    renderLastStoryMoment(settlementContext);
    api.ui.toast('小结生成失败，剧情已保留，可重新生成');
  }
});

document.getElementById('btn-memory-discard').addEventListener('click', () => {
  const pendingFlow = window._pendingMemoryFlow;
  memoryConfirmModal.style.display = 'none';
  window._pendingMemoryFlow = null;
  if (pendingFlow?.type === 'indoor') {
    closeIndoorChat();
    return;
  }
  const settlementContext = pendingFlow?.type === 'story' ? pendingFlow.context : storyContext;
  switchView(vPalaceDetail);
  if (settlementContext.mode === 'morningCourt') setMorningCourtStoryUi(false);
  if (settlementContext.mode === 'morningAudience') { setMorningAudienceStoryUi(false); setMorningCourtStoryUi(false); }
});

document.getElementById('btn-memory-save').addEventListener('click', async () => {
  const finalSummary = memorySummaryInput.value.trim();
  if (!finalSummary) { api.ui.toast("小结不可为空"); return; }
  const pendingFlow = window._pendingMemoryFlow;
  const settlementSnapshot = captureMemorySettlementState();

  try {

  if (pendingFlow?.type === 'indoor') {
    const char = pendingFlow.char;
    if (!char) { api.ui.toast('未找到需要录入记忆的人物'); return; }
    if (!Array.isArray(char.memorySeen)) char.memorySeen = [];
    const timeStr = hudTime.innerText;
    char.memorySeen.unshift({ time: timeStr, text: finalSummary });
    if (pendingFlow.staffCtx) {
      pendingFlow.staffCtx.roommates.filter(person => person.id !== char.id).forEach(person => {
        if (!Array.isArray(person.memorySeen)) person.memorySeen = [];
        person.memorySeen.unshift({ time: timeStr, text: `【同屋见闻】${finalSummary}` });
      });
      await saveProgress({ courtNpcData: window._courtNpcData || [] });
    } else if (char._isGameNpc) {
      await saveProgress({ courtNpcData: window._courtNpcData || [] });
    } else if (char._isScenarioChar) {
      window._xlyMemorySeen = char.memorySeen;
      await saveProgress({ xlyMemorySeen: char.memorySeen });
    } else {
      await saveProgress({ characters: selectedCharsData });
    }
    try {
      if (pendingFlow.indoorMode === 'intimate') await autoRecordIntimate(char);
      else await autoRecordChat(char);
    } catch (error) {}
    window._pendingMemoryFlow = null;
    memoryConfirmModal.style.display = 'none';
    api.ui.toast(pendingFlow.memoryMode === 'full' ? '完整剧情已录入「TA看到的」' : '小结已录入「TA看到的」');
    closeIndoorChat();
    return;
  }

  const settlementContext = pendingFlow?.type === 'story' ? pendingFlow.context : storyContext;
  const huaqingConferralTarget = settlementContext.mode === 'huaqingBath' && settlementContext.afterMemorySave === 'huaqingConferral' ? settlementContext.mainChar : null;

  if (settlementContext.mode === 'morningCourt') {
    const timeStr = hudTime.innerText;
    const memoryItem = { time: timeStr, text: finalSummary };
    const officials = settlementContext.courtOfficials || [];
    officials.forEach(char => {
      if (!char.memorySeen) char.memorySeen = [];
      char.memorySeen.unshift({ ...memoryItem });
    });

    const storedNpcs = getStoredCourtNpcs();
    (settlementContext.courtNpcs || []).forEach(npc => {
      const stored = storedNpcs.find(item => item.name === npc.name);
      const target = stored || npc;
      if (!target.memorySeen) target.memorySeen = [];
      target.memorySeen.unshift({ ...memoryItem });
      if (!stored && storedNpcs.length < 60) storedNpcs.push(typeof normalizeGameNpc === 'function' ? normalizeGameNpc(target) : target);
    });

    if (!Array.isArray(window._courtUserMemorySeen)) window._courtUserMemorySeen = [];
    window._courtUserMemorySeen.unshift({ ...memoryItem });
    if (!Array.isArray(window._qianchaoRecords)) window._qianchaoRecords = [];
    const courtRecordText = (settlementContext.pendingCourtRecord || finalSummary).trim().slice(0, 100);
    window._qianchaoRecords.unshift({
      id: generateId(),
      time: timeStr,
      text: courtRecordText,
      owner: '朝议',
      type: 'ai',
      tags: ['前朝', '早朝']
    });

    if (typeof XLY_CHAR !== 'undefined' && officials.includes(XLY_CHAR)) {
      window._xlyMemorySeen = XLY_CHAR.memorySeen;
    }
    await saveProgress({
      characters: selectedCharsData,
      xlyMemorySeen: typeof XLY_CHAR !== 'undefined' ? XLY_CHAR.memorySeen : undefined,
      courtNpcData: storedNpcs,
      courtUserMemorySeen: window._courtUserMemorySeen,
      qianchaoRecords: window._qianchaoRecords
    });
    officials.forEach(char => checkAndTriggerReflect(char));
    api.ui.toast('朝议小结已录入众人记忆与“前朝”记事');
    window._pendingMemoryFlow = null;
    memoryConfirmModal.style.display = 'none';
    switchView(vPalaceDetail);
    setMorningCourtStoryUi(false);
    return;
  }
  
  const timeStr = hudTime.innerText;
  // 提取刚刚在场的所有角色名
  const allNames = settlementContext.memoryRecipientsAll
    ? (settlementContext.participants || []).map(char => char.name)
    : settlementContext.history.filter(x => x.speaker && x.speaker !== '皇帝' && x.speaker !== '路人').map(x => x.speaker);
  // 如果没有任何人说话，保底记录给主位的人
  if (allNames.length === 0 && settlementContext.mainChar) {
    allNames.push(settlementContext.mainChar.name);
  }
  const uniqueNames = [...new Set(allNames)];
  
  uniqueNames.forEach(n => {
    const char = selectedCharsData.find(c => c.name === n)
      || (typeof XLY_CHAR !== 'undefined' && XLY_CHAR.name === n ? XLY_CHAR : null)
      || (window._courtNpcData || []).find(c => c.name === n);
    if (char) {
      if (!char.memorySeen) char.memorySeen = [];
      char.memorySeen.unshift({ time: timeStr, text: finalSummary });
    }
  });

  // 华清宫沐浴必须直接按NPC id再次落入原对象，避免同名或speaker格式造成漏记。
  if (huaqingConferralTarget) {
    const storedNpc = (window._courtNpcData || []).find(npc => npc.id === huaqingConferralTarget.id) || huaqingConferralTarget;
    if (!Array.isArray(storedNpc.memorySeen)) storedNpc.memorySeen = [];
    const alreadySaved = storedNpc.memorySeen.some(item => String(item?.text || item) === finalSummary);
    if (!alreadySaved) storedNpc.memorySeen.unshift({ time: timeStr, text: finalSummary });
  }
  
  if (typeof XLY_CHAR !== 'undefined') window._xlyMemorySeen = XLY_CHAR.memorySeen;
  await saveProgress({ characters: selectedCharsData, xlyMemorySeen: typeof XLY_CHAR !== 'undefined' ? XLY_CHAR.memorySeen : undefined, courtNpcData: window._courtNpcData || [] });
  // 自动沉思检查（异步，不阻塞主流程）
  uniqueNames.forEach(n => {
    const char = selectedCharsData.find(c => c.name === n);
    if (char) checkAndTriggerReflect(char);
  });
  api.ui.toast("小结已录入「TA看到的」");
  window._pendingMemoryFlow = null;
  memoryConfirmModal.style.display = 'none';
  switchView(vPalaceDetail);
  if (settlementContext.mode === 'morningAudience') { setMorningAudienceStoryUi(false); setMorningCourtStoryUi(false); }
  if (huaqingConferralTarget) setTimeout(() => openHuaQingConferralPrompt(huaqingConferralTarget, finalSummary), 180);
  } catch (error) {
    handleMemorySettlementFailure(pendingFlow, settlementSnapshot);
  }
});
const SCENARIO_EMPTY_SLOTS = 7;

function getScenarioAvatarCfg(id) {
  return (window._scenarioAvatarCfgCache || {})[id] || null;
}
function setScenarioAvatarCfg(id, cfg) {
  if (!window._scenarioAvatarCfgCache) window._scenarioAvatarCfgCache = {};
  window._scenarioAvatarCfgCache[id] = cfg;
}

// 召见菜单
function openZhaoJianMenu() {
  const old = document.getElementById('zhaojian-menu-modal');
  if (old) old.remove();

  const modal = document.createElement('div');
  modal.id = 'zhaojian-menu-modal';
  modal.style.cssText = 'position:absolute; inset:0; z-index:9999; display:flex; align-items:flex-end; justify-content:center; padding-bottom:calc(var(--safe-bottom) + 80px);';

  const panel = document.createElement('div');
  panel.style.cssText = 'width:200px; background:rgba(20,18,16,0.85); backdrop-filter:blur(16px); -webkit-backdrop-filter:blur(16px); border:1px solid rgba(201,163,106,0.4); border-radius:16px; padding:12px 0; display:flex; flex-direction:column; box-shadow:0 8px 24px rgba(0,0,0,0.6); animation:fadeInDown 0.2s ease reverse;';
  panel.style.transformOrigin = 'bottom center';
  
  const ops = [
    { name: '召见妃嫔', action: () => { modal.remove(); openScenarioPanel('houfei'); } },
    { name: '召见其它', action: () => { modal.remove(); openScenarioPanel('qita'); } },
    { name: '翻牌子', action: () => { modal.remove(); openFanPaiModal(); } }
  ];

  ops.forEach((op, idx) => {
    const btn = document.createElement('button');
    btn.style.cssText = `background:transparent; border:none; padding:12px; color:#ccc; font-size:14px; letter-spacing:2px; font-family:inherit; transition:background 0.2s;`;
    btn.innerText = op.name;
    if (idx < ops.length - 1) {
      btn.style.borderBottom = '1px solid rgba(255,255,255,0.08)';
    }
    btn.onclick = op.action;
    panel.appendChild(btn);
  });

  modal.appendChild(panel);
  modal.addEventListener('click', (e) => { if(e.target === modal) modal.remove(); });
  document.getElementById('view-palace-detail').appendChild(modal);
}

// 动态构建展示列表
let currentScenarioMode = 'houfei';

function getScenarioList() {
  if (currentScenarioMode === 'houfei') {
    return selectedCharsData.filter(c => c.ancientRole === '后妃').map(c => ({
      id: c.id,
      name: c.name,
      subtitle: c.assignedRank || '未册封',
      defaultAvatar: c.customAvatar || c.avatar || SCENARIO_DEFAULT_AVATAR,
      profile: c.ancientDescOriginal || c.ancientDesc,
      _charRef: c
    }));
  } else {
    // 其他（包含谢临渊、前朝大臣等）
    const others = selectedCharsData.filter(c => c.ancientRole !== '后妃').map(c => ({
      id: c.id,
      name: c.name,
      subtitle: c.ancientRole,
      defaultAvatar: c.customAvatar || c.avatar || SCENARIO_DEFAULT_AVATAR,
      profile: c.ancientDescOriginal || c.ancientDesc,
      _charRef: c
    }));
    // 加入谢临渊
    others.unshift({
      id: XLY_CHAR.id,
      name: XLY_CHAR.name,
      subtitle: XLY_CHAR.ancientRole,
      defaultAvatar: XLY_CHAR.customAvatar || XLY_CHAR.avatar,
      profile: XLY_PROFILE,
      _charRef: XLY_CHAR
    });
    return others;
  }
}

function renderScenarioPane() {
  const carousel = document.getElementById('scenario-carousel');
  if (!carousel) return;
  carousel.innerHTML = '';

  const list = getScenarioList();
  
  if (list.length === 0) {
    carousel.style.display = 'flex';
    carousel.style.alignItems = 'center';
    carousel.style.justifyContent = 'center';
    carousel.innerHTML = '<div style="color:#666; font-size:14px; letter-spacing:2px;">暂无此身份的故人</div>';
    return;
  }
  
  // 恢复网格布局
  carousel.style.display = 'grid';
  carousel.style.alignItems = '';
  carousel.style.justifyContent = '';

  list.forEach((sc, scIdx) => {
    const cfg = getScenarioAvatarCfg(sc.id);
    const avatarUrl = (cfg && cfg.url) ? cfg.url : sc.defaultAvatar;
    const scale = (cfg && cfg.scale) ? cfg.scale : 100;

    // 右列（奇数列，从0开始）向下错落 30px
    const isRightCol = (scIdx % 2 === 1);
    const marginTop = isRightCol ? '30px' : '0px';

    const card = document.createElement('div');
    card.style.cssText = `
      width:100%; height:100%;
      background:#1a1614;
      border:1px solid rgba(201,163,106,0.5);
      border-radius:18px;
      display:flex; flex-direction:column;
      overflow:hidden;
      position:relative;
      cursor:pointer;
      margin-top:${marginTop};
      box-shadow:0 8px 24px rgba(0,0,0,0.6), inset 0 0 0 1px rgba(201,163,106,0.08);
      transition:transform 0.18s, box-shadow 0.18s;
    `;

    // 全图背景头像
    const avatarBg = document.createElement('div');
    avatarBg.style.cssText = 'position:absolute; inset:0; overflow:hidden; border-radius:18px;';
    const avatarImg = document.createElement('img');
    avatarImg.src = avatarUrl;
    avatarImg.style.cssText = `width:100%; height:100%; object-fit:cover; object-position:top center; transform:scale(${scale/100}); transform-origin:top center; display:block; pointer-events:none;`;
    avatarImg.draggable = false;
    avatarImg.onerror = () => { avatarBg.style.background = 'rgba(40,30,20,0.9)'; avatarImg.style.display='none'; };
    avatarBg.appendChild(avatarImg);
    card.appendChild(avatarBg);

    // 底部渐变遮罩（更深，确保文字清晰）
    const gradOverlay = document.createElement('div');
    gradOverlay.style.cssText = 'position:absolute; bottom:0; left:0; right:0; height:90px; background:linear-gradient(to top, rgba(6,4,2,0.97) 0%, rgba(6,4,2,0.6) 55%, transparent 100%); border-radius:0 0 18px 18px; pointer-events:none;';
    card.appendChild(gradOverlay);

    // 顶部微光边框装饰
    const topGlow = document.createElement('div');
    topGlow.style.cssText = 'position:absolute; top:0; left:0; right:0; height:1px; background:linear-gradient(to right, transparent, rgba(201,163,106,0.6), transparent); pointer-events:none;';
    card.appendChild(topGlow);

    // 双击换像角标
    const dblHint = document.createElement('div');
    dblHint.style.cssText = 'position:absolute; top:10px; right:10px; background:rgba(0,0,0,0.7); border:0.5px solid rgba(201,163,106,0.5); color:rgba(201,163,106,0.85); font-size:9px; padding:3px 6px; border-radius:10px; pointer-events:none; letter-spacing:1px;';
    dblHint.textContent = '双击换像';
    card.appendChild(dblHint);

    // 底部名字与位份
    const nameBar = document.createElement('div');
    nameBar.style.cssText = 'position:absolute; bottom:0; left:0; right:0; padding:12px 14px; display:flex; flex-direction:column; gap:3px;';
    const nameEl = document.createElement('div');
    nameEl.style.cssText = 'font-size:18px; font-weight:bold; letter-spacing:4px; font-family:"STZhongsong","STSong",serif; background:linear-gradient(to bottom,#ffe9b8,#c9a36a); -webkit-background-clip:text; -webkit-text-fill-color:transparent; filter:drop-shadow(0 1px 4px rgba(0,0,0,0.9));';
    nameEl.textContent = sc.name;
    const subtitleEl = document.createElement('div');
    subtitleEl.style.cssText = 'font-size:11px; color:rgba(201,163,106,0.7); letter-spacing:2px;';
    subtitleEl.textContent = sc.subtitle;
    nameBar.appendChild(nameEl);
    nameBar.appendChild(subtitleEl);
    card.appendChild(nameBar);
    const disciplineBadge = typeof getCharacterDisciplineBadge === 'function' ? getCharacterDisciplineBadge(sc._charRef) : '';
    if (disciplineBadge) {
      const badge = document.createElement('div');
      badge.style.cssText = 'position:absolute;top:10px;left:10px;z-index:5;background:rgba(105,24,23,.9);border:1px solid #d08b72;color:#ffe0c5;border-radius:12px;padding:4px 7px;font-size:10px;letter-spacing:1px;';
      badge.innerText = disciplineBadge;
      card.appendChild(badge);
      card.style.filter = 'grayscale(.45) brightness(.72)';
    }

    // 触摸按压效果
    card.addEventListener('touchstart', () => { card.style.transform = 'scale(0.97)'; card.style.boxShadow = '0 4px 12px rgba(0,0,0,0.8)'; }, {passive:true});
    card.addEventListener('touchend', () => { card.style.transform = 'scale(1)'; card.style.boxShadow = '0 8px 24px rgba(0,0,0,0.6)'; }, {passive:true});

    // 双击换像
    let lastTapTime = 0;
    card.addEventListener('touchend', (e) => {
      const now = Date.now();
      if (now - lastTapTime < 350) { e.stopPropagation(); openScenarioAvatarModal(sc, avatarImg); }
      lastTapTime = now;
    });
    card.addEventListener('dblclick', (e) => { e.stopPropagation(); openScenarioAvatarModal(sc, avatarImg); });

    // 单击召见
    card.addEventListener('click', async () => {
      const charRef = sc._charRef;
      if (typeof isCharacterUnavailableForActivity === 'function' && isCharacterUnavailableForActivity(charRef)) {
        await notifyCharacterUnavailable(charRef);
        return;
      }
      document.getElementById('scenario-panel').style.display = 'none';
      charRef.indoorBgUrl = palaceDetails['养心殿']?.bgUrl || charRef.indoorBgUrl || null;
      window.currentIndoorChar = charRef;
      window._indoorSceneContext = { type:'yangxin_summon', pName:'养心殿', rName:'内殿', premise:`皇帝身处养心殿，已经传召${charRef.name}前来觐见；${charRef.name}是奉召来到养心殿，不是皇帝去其宫中探望。` };
      enterIndoorView();
    });

    carousel.appendChild(card);
  });

  // 空槽（保持网格填满，最少凑够偶数使布局整齐）
  const minSlots = list.length % 2 === 1 ? 1 : 0; // 奇数个时补一个空槽
  const extraSlots = Math.max(minSlots, Math.max(0, 4 - list.length));
  for (let i = 0; i < extraSlots; i++) {
    const totalIdx = list.length + i;
    const isRightCol = (totalIdx % 2 === 1);
    const marginTop = isRightCol ? '30px' : '0px';
    const emptyCard = document.createElement('div');
    emptyCard.style.cssText = `
      width:100%; height:100%;
      background:rgba(15,12,10,0.5);
      border:1px dashed rgba(201,163,106,0.15);
      border-radius:18px;
      display:flex; flex-direction:column;
      align-items:center; justify-content:center;
      gap:12px;
      margin-top:${marginTop};
    `;
    emptyCard.innerHTML = `
      <div style="width:52px;height:52px;border-radius:50%;border:1px dashed rgba(201,163,106,0.2);display:flex;align-items:center;justify-content:center;">
        <span style="color:rgba(201,163,106,0.2);font-size:20px;">虚</span>
      </div>
      <div style="color:rgba(201,163,106,0.2);font-size:12px;letter-spacing:4px;font-family:'STZhongsong','STSong',serif;">待定</div>
    `;
    carousel.appendChild(emptyCard);
  }
}

function openScenarioAvatarModal(sc, imgRef) {
  _scAvatarTarget = sc;
  _scAvatarImgRef = imgRef;
  const cfg = getScenarioAvatarCfg(sc.id);
  _scTempUrl = (cfg && cfg.url) ? cfg.url : sc.defaultAvatar;
  const modal = document.getElementById('scenario-avatar-modal');
  const preview = document.getElementById('sc-avatar-preview');
  const scaleRange = document.getElementById('sc-avatar-scale');
  document.getElementById('sc-avatar-modal-title').textContent = '为「' + sc.name + '」更换头像';
  preview.src = _scTempUrl;
  scaleRange.value = (cfg && cfg.scale) ? cfg.scale : 100;
  preview.style.transform = 'scale(' + (scaleRange.value / 100) + ')';
  modal.style.display = 'flex';
}

let _scAvatarTarget = null, _scAvatarImgRef = null, _scTempUrl = null;

// 拦截室内聊天发送按钮，如果是帝师商议模式，增加方案确认检测
const btnInchatSend = document.getElementById('btn-inchat-send');
// 保存原始的 onclick，然后重写
const origInchatSend = btnInchatSend ? btnInchatSend.onclick : null;

if (btnInchatSend) {
  btnInchatSend.onclick = async (e) => {
    if (indoorChatContext.mode !== 'dishi_zouzhe') {
      if (origInchatSend) origInchatSend(e);
      return;
    }

  const input = document.getElementById('indoor-chat-input');
  if(!input.value.trim()) return;
  const userText = input.value.trim();
  indoorChatContext.history.push({ type:'user', speaker:'皇帝', text: userText });
  input.value = '';
  
  document.getElementById('indoor-chat-box').innerText = "帝师沉思中...";
  document.getElementById('indoor-chat-controls').style.display = 'none';
  document.getElementById('indoor-chat-wrap').style.bottom = 'calc(var(--safe-bottom) + 8px)';
  document.getElementById('indoor-blocker').style.display = 'block';
  
  const historyText = indoorChatContext.history.map(x => `${x.speaker?x.speaker:'叙事段'}：${x.text}`).join('\n');
  const zz = indoorChatContext.zz;

  const sysPrompt = `继续刚才与帝师「${window.currentIndoorChar.name}」关于奏折【${zz.title}】的商讨。
对话履历：
${historyText}

请根据皇帝的最新言行，生成帝师的回应。
【特殊任务】：智能识别目前的对话进度。如果帝师认为皇帝已经做出了明确的决断，或者两人已经达成了一个具体的处理方案，请在回复的最后一行单独输出一个标签：[方案已定]
其他要求同前（<p>分段，带data-speaker）。

【本轮必须重新读取的帝师完整档案】
${buildCharacterAiContext(window.currentIndoorChar)}

${getAiParagraphFormatGuard()}

${getLongPlotContinuationGuard()}`;

  try {
    const res = await api.ai.chat({ messages:[{role:"user", content:sysPrompt}] });
    let text = typeof res === 'string' ? res : (res?.content ?? res?.text ?? '');
    
    let planConfirmed = false;
    if (text.includes('[方案已定]')) {
      planConfirmed = true;
      text = text.replace('[方案已定]', '').trim();
    }

    // 播放文字
    playIndoorChat(text);

    // 如果方案已定，改变离去按钮为"就这个方案"
    if (planConfirmed) {
      setTimeout(() => {
        const exitBtn = document.getElementById('btn-inchat-exit');
        exitBtn.textContent = '就这个方案';
        exitBtn.style.background = 'var(--primary-color)';
        exitBtn.style.color = '#000';
        exitBtn.style.borderColor = 'var(--primary-color)';
        
        exitBtn.onclick = async () => {
          exitBtn.textContent = '代批中...';
          exitBtn.disabled = true;

          // 生成最终批语
          const finalPrompt = `请根据以下皇帝与帝师的商议过程，由帝师代笔，为奏折写一句最终的朱批（不超过20字）。
奏折内容：${zz.content}
商议过程：${indoorChatContext.history.map(x => `${x.speaker || '叙事段'}：${x.text}`).join('\n')}
只输出批语正文，不带引号。`;
          
          try {
            const fRes = await api.ai.chat({ messages:[{role:"user", content:finalPrompt}] });
            const replyText = typeof fRes === 'string' ? fRes : (fRes?.content ?? fRes?.text ?? '');
            
            zz.reply = `（${window.currentIndoorChar.name} 代批）${replyText.trim()}`;
            zouZheData.pending = zouZheData.pending.filter(z => z.id !== zz.id);
            zouZheData.done.unshift(zz);
            if (typeof saveZouZheWithAuthorMemory === 'function') await saveZouZheWithAuthorMemory(zz, '已批阅');
            else await saveProgress({ zouZheData });
            api.ui.toast("奏折已批阅存档");
            
            // 退出
            document.getElementById('btn-exit-indoor').click();
            
            // 提示 user 先去御书房等候
            setTimeout(() => {
              api.ui.toast(`${zz.author.split('，')[0].replace(/^臣\s*/,'')} 已领旨，稍候将至御书房回禀`);
            }, 800);

            // 批完后再次调取 API 收到大臣回复
            setTimeout(async () => {
              try {
                const zzModal2 = document.getElementById('zouzhe-panel-modal');
                let zzLoader2 = null;
                if (zzModal2) {
                  zzLoader2 = document.createElement('div');
                  zzLoader2.id = 'zz-inner-loader';
                  zzLoader2.style.cssText = 'position:absolute; inset:0; background:rgba(0,0,0,0.6); backdrop-filter:blur(4px); z-index:200; display:flex; flex-direction:column; align-items:center; justify-content:center; gap:16px;';
                  zzLoader2.innerHTML = `<div style="width:40px;height:40px;border:3px solid rgba(201,163,106,0.3);border-top-color:var(--primary-color);border-radius:50%;animation:spin 1s linear infinite;"></div><div style="color:var(--primary-color);font-size:14px;letter-spacing:2px;text-shadow:0 1px 3px #000;">正在等待大臣回禀…</div>`;
                  zzModal2.appendChild(zzLoader2);
                }
                
                const replyToReplyPrompt = `你是古代大臣「${zz.author}」。
你上奏了：${zz.content}
皇帝（或帝师）朱批回复：${zz.reply}

【本轮重新读取的大臣人设与全部记忆】
${typeof buildZouZheAuthorAiContext === 'function' ? buildZouZheAuthorAiContext(zz) : '暂无可关联人物资料'}

请以「${zz.author}」的口吻，写一封简短的谢恩/领旨回执（50字以内），古风文言。只输出正文。`;
                const rrRes = await api.ai.chat({ messages: [{ role: 'user', content: replyToReplyPrompt }] });
                const rrText = (typeof rrRes === 'string' ? rrRes : (rrRes?.content ?? rrRes?.text ?? '')).trim();
                
                if (globalLoader) globalLoader.style.display = 'none';
                
                if (zzLoader2) zzLoader2.remove();
                if (rrText) {
                  showZouZheReplyScroll(zz, rrText, async () => {
                    zz.reply += `\n\n[大臣回执]：${rrText}`;
                    if (typeof saveZouZheWithAuthorMemory === 'function') await saveZouZheWithAuthorMemory(zz, '已批阅');
                    else await saveProgress({ zouZheData });
                  });
                }
              } catch (e) {
                console.error("生成大臣回执失败", e);
                const el2 = document.getElementById('zz-inner-loader');
                if (el2) el2.remove();
              }
            }, 2000);
            
          } catch(err) {
            api.ui.toast("批语生成失败");
            exitBtn.textContent = '就这个方案';
            exitBtn.disabled = false;
          }
        };
      }, 500); // 稍微延迟等 UI 渲染
    }

  } catch(err) {
    document.getElementById('indoor-chat-box').innerText = "回复失败。";
    document.getElementById('indoor-chat-controls').style.display = 'flex';
    document.getElementById('indoor-blocker').style.display = 'none';
  }
};
}

// ===== 内务府·名臣录（独立，只含谢临渊+空槽，横向卡片风格）=====
function openMingChenLu() {
  const old = document.getElementById('mingchen-panel');
  if (old) old.remove();

  const panel = document.createElement('div');
  panel.id = 'mingchen-panel';
  panel.style.cssText = `
    position:fixed; inset:0; z-index:9999; display:flex; flex-direction:column;
    background-image:url('https://www.imgfox.cn/apis/uploads/20260818/cd2a4b22f1ec4748/IMG_9643.jpeg');
    background-size:cover; background-position:center;
  `;

  const bgOverlay = document.createElement('div');
  bgOverlay.style.cssText = 'position:absolute; inset:0; background:rgba(6,4,2,0.72); backdrop-filter:blur(2px); -webkit-backdrop-filter:blur(2px); z-index:0;';
  panel.appendChild(bgOverlay);

  // 顶栏
  const header = document.createElement('div');
  header.style.cssText = 'position:relative; z-index:1; padding:calc(var(--safe-top) + 12px) 16px 12px; display:flex; justify-content:space-between; align-items:center; border-bottom:1px solid rgba(201,163,106,0.2); flex-shrink:0;';
  header.innerHTML = `
    <button id="btn-close-mingchen" style="background:transparent; border:none; color:#888; font-size:16px; font-family:inherit;">关闭</button>
    <div style="color:var(--primary-color); font-size:16px; font-weight:bold; letter-spacing:4px; font-family:'STZhongsong','STSong',serif;
      background:linear-gradient(to bottom,#ffe9b8,#c9a36a); -webkit-background-clip:text; -webkit-text-fill-color:transparent;
      filter:drop-shadow(0 1px 4px rgba(0,0,0,0.8));">名臣录</div>
    <div style="width:40px;"></div>
  `;
  panel.appendChild(header);

  // 横向卡片滚动区
  const carousel = document.createElement('div');
  carousel.style.cssText = 'position:relative; z-index:1; flex:1; display:flex; gap:0; overflow-x:auto; overflow-y:visible; padding:40px 20px; scrollbar-width:none; -webkit-overflow-scrolling:touch; align-items:center;';

  // 谢临渊卡片
  const cfg = getScenarioAvatarCfg(XLY_CHAR.id);
  const avatarUrl = (cfg && cfg.url) ? cfg.url : XLY_CHAR.customAvatar || XLY_CHAR.avatar;
  const scale = (cfg && cfg.scale) ? cfg.scale : 100;

  const card = document.createElement('div');
  card.style.cssText = `flex-shrink:0; width:150px; height:220px; scroll-snap-align:center; margin:0 8px;
    background:#1a1614; border:1px solid rgba(201,163,106,0.6); border-radius:16px;
    display:flex; flex-direction:column; overflow:hidden; position:relative;
    transform:translateY(-28px); cursor:pointer;`;

  const avatarBg = document.createElement('div');
  avatarBg.style.cssText = 'position:absolute; inset:0; overflow:hidden; border-radius:16px;';
  const avatarImg = document.createElement('img');
  avatarImg.src = avatarUrl;
  avatarImg.style.cssText = `width:100%; height:100%; object-fit:cover; object-position:top center; transform:scale(${scale/100}); transform-origin:top center; display:block;`;
  avatarImg.draggable = false;
  avatarImg.onerror = () => { avatarBg.style.background = 'rgba(40,30,20,0.8)'; avatarImg.style.display='none'; };
  avatarBg.appendChild(avatarImg);
  card.appendChild(avatarBg);

  const gradOverlay = document.createElement('div');
  gradOverlay.style.cssText = 'position:absolute; bottom:0; left:0; right:0; height:80px; background:linear-gradient(to top, rgba(10,8,6,0.95) 0%, rgba(10,8,6,0.5) 60%, transparent 100%); border-radius:0 0 16px 16px; pointer-events:none;';
  card.appendChild(gradOverlay);

  const dblHint = document.createElement('div');
  dblHint.style.cssText = 'position:absolute; top:8px; right:8px; background:rgba(0,0,0,0.65); border:0.5px solid rgba(201,163,106,0.5); color:var(--primary-color); font-size:9px; padding:2px 5px; border-radius:8px; pointer-events:none;';
  dblHint.textContent = '双击换像';
  card.appendChild(dblHint);

  const nameBar = document.createElement('div');
  nameBar.style.cssText = 'position:absolute; bottom:0; left:0; right:0; padding:10px 12px; display:flex; flex-direction:column; gap:2px;';
  nameBar.innerHTML = `
    <div style="font-size:17px; font-weight:bold; letter-spacing:3px; font-family:'STZhongsong','STSong',serif;
      background:linear-gradient(to bottom,#ffe9b8,#c9a36a); -webkit-background-clip:text; -webkit-text-fill-color:transparent;
      filter:drop-shadow(0 1px 3px rgba(0,0,0,0.9));">${XLY_CHAR.name}</div>
    <div style="font-size:10px; color:rgba(201,163,106,0.75); letter-spacing:2px;">${XLY_CHAR.ancientRole}</div>
  `;
  card.appendChild(nameBar);

  // 双击换像
  let lastTapTime = 0;
  card.addEventListener('touchend', (e) => {
    const now = Date.now();
    if (now - lastTapTime < 350) {
      e.stopPropagation();
      const sc = { id: XLY_CHAR.id, name: XLY_CHAR.name, defaultAvatar: XLY_CHAR.customAvatar || XLY_CHAR.avatar };
      openScenarioAvatarModal(sc, avatarImg);
    }
    lastTapTime = now;
  });
  card.addEventListener('dblclick', (e) => {
    e.stopPropagation();
    const sc = { id: XLY_CHAR.id, name: XLY_CHAR.name, defaultAvatar: XLY_CHAR.customAvatar || XLY_CHAR.avatar };
    openScenarioAvatarModal(sc, avatarImg);
  });

  // 单击进入对话
  card.addEventListener('click', () => {
    panel.style.display = 'none';
    XLY_CHAR.indoorBgUrl = palaceDetails['养心殿']?.bgUrl || XLY_CHAR.indoorBgUrl || null;
    window.currentIndoorChar = XLY_CHAR;
    window._indoorSceneContext = { type:'yangxin_summon', pName:'养心殿', rName:'内殿', premise:`皇帝身处养心殿，已传召${XLY_CHAR.name}前来觐见；${XLY_CHAR.name}是奉召来到养心殿。` };
    enterIndoorView();
  });

  carousel.appendChild(card);

  // 空槽
  for (let i = 0; i < 7; i++) {
    const yOffset = (i % 2 === 0) ? 28 : -28;
    const emptyCard = document.createElement('div');
    emptyCard.style.cssText = `flex-shrink:0; width:150px; height:220px; scroll-snap-align:center; margin:0 8px;
      background:rgba(20,18,16,0.6); border:1px dashed rgba(201,163,106,0.2); border-radius:16px;
      display:flex; flex-direction:column; align-items:center; justify-content:center; gap:12px;
      transform:translateY(${yOffset}px);`;
    emptyCard.innerHTML = `
      <div style="width:56px;height:56px;border-radius:50%;border:1px dashed rgba(201,163,106,0.25);display:flex;align-items:center;justify-content:center;">
        <span style="color:rgba(201,163,106,0.25);font-size:22px;">虚</span>
      </div>
      <div style="color:rgba(201,163,106,0.25);font-size:13px;letter-spacing:4px;font-family:'STZhongsong','STSong',serif;">待定</div>
    `;
    carousel.appendChild(emptyCard);
  }

  panel.appendChild(carousel);
  document.getElementById('app').appendChild(panel);

  document.getElementById('btn-close-mingchen').addEventListener('click', () => panel.remove());
}

// ===== 召见面板入口 =====
function openScenarioPanel(mode = 'houfei') {
  currentScenarioMode = mode;
  let panel = document.getElementById('scenario-panel');
  if (!panel) {
    panel = document.createElement('div');
    panel.id = 'scenario-panel';
    // 使用主界面背景图，加高斯模糊暗色遮罩
    panel.style.cssText = `
      position:fixed; inset:0; z-index:9999; display:flex; flex-direction:column;
      background-image:url('https://www.imgfox.cn/apis/uploads/20260818/cd2a4b22f1ec4748/IMG_9643.jpeg');
      background-size:cover; background-position:center;
    `;

    // 全局暗色模糊遮罩层
    const bgOverlay = document.createElement('div');
    bgOverlay.style.cssText = 'position:absolute; inset:0; background:rgba(6,4,2,0.72); backdrop-filter:blur(2px); -webkit-backdrop-filter:blur(2px); z-index:0;';
    panel.appendChild(bgOverlay);

    // 顶栏
    const header = document.createElement('div');
    header.id = 'scenario-header';
    header.style.cssText = 'position:relative; z-index:1; padding:calc(var(--safe-top) + 12px) 16px 12px; display:flex; justify-content:space-between; align-items:center; border-bottom:1px solid rgba(201,163,106,0.2); flex-shrink:0;';
    header.innerHTML = `
      <button id="btn-close-scenario" style="background:transparent; border:none; color:#888; font-size:16px; font-family:inherit;">关闭</button>
      <div id="scenario-title" style="color:var(--primary-color); font-size:16px; font-weight:bold; letter-spacing:4px; font-family:'STZhongsong','STSong',serif; background:linear-gradient(to bottom,#ffe9b8,#c9a36a); -webkit-background-clip:text; -webkit-text-fill-color:transparent; filter:drop-shadow(0 1px 4px rgba(0,0,0,0.8));">召见</div>
      <div style="width:40px;"></div>
    `;
    panel.appendChild(header);

    // 卡片多排网格滚动区
    const carousel = document.createElement('div');
    carousel.id = 'scenario-carousel';
    carousel.style.cssText = `
      position:relative; z-index:1; flex:1;
      display:grid;
      grid-template-columns: repeat(2, 1fr);
      grid-auto-rows: 260px;
      gap:16px;
      overflow-y:auto; overflow-x:hidden;
      padding:20px 18px calc(var(--safe-bottom,24px) + 20px);
      scrollbar-width:none;
      -webkit-overflow-scrolling:touch;
      align-content:start;
    `;
    panel.appendChild(carousel);

    document.getElementById('app').appendChild(panel);

    document.getElementById('btn-close-scenario').addEventListener('click', () => {
      panel.style.display = 'none';
    });
  }
  
  document.getElementById('scenario-title').innerText = mode === 'houfei' ? '召见妃嫔' : '召见群臣';
  panel.style.display = 'flex';
  renderScenarioPane();
}

// ===== 名臣录头像弹窗事件绑定（函数定义已在上方）=====
document.getElementById('sc-avatar-scale').addEventListener('input', function() {
  document.getElementById('sc-avatar-preview').style.transform = 'scale(' + (this.value / 100) + ')';
});
document.getElementById('sc-avatar-pick').addEventListener('click', async () => {
  try {
    const picked = await api.media.pick({ accept: 'image/*' });
    if (picked && picked.file) { _scTempUrl = picked.file.dataUrl; document.getElementById('sc-avatar-preview').src = _scTempUrl; }
  } catch(e) {}
});
document.getElementById('sc-avatar-reset').addEventListener('click', () => {
  if (!_scAvatarTarget) return;
  _scTempUrl = _scAvatarTarget.defaultAvatar;
  document.getElementById('sc-avatar-preview').src = _scTempUrl;
  document.getElementById('sc-avatar-scale').value = 100;
  document.getElementById('sc-avatar-preview').style.transform = 'scale(1)';
});
document.getElementById('sc-avatar-cancel').addEventListener('click', () => {
  document.getElementById('scenario-avatar-modal').style.display = 'none';
});
document.getElementById('sc-avatar-save').addEventListener('click', async () => {
  if (!_scAvatarTarget) return;
  const scale = parseInt(document.getElementById('sc-avatar-scale').value);
  const cfg = { url: _scTempUrl, scale };
  setScenarioAvatarCfg(_scAvatarTarget.id, cfg);
  try {
    if (!window._scenarioAvatarCfgCache) window._scenarioAvatarCfgCache = {};
    await saveProgress({ scenarioAvatarCfg: window._scenarioAvatarCfgCache });
  } catch(e) {}
  if (_scAvatarImgRef) { _scAvatarImgRef.src = _scTempUrl; _scAvatarImgRef.style.transform = 'scale(' + (scale / 100) + ')'; }
  document.getElementById('scenario-avatar-modal').style.display = 'none';
  api.ui.toast('头像已保存');
});

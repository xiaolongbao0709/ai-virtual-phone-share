 // 当前操作的存档槽 id（null = 新档）
const QIANQING_DEFAULT_BG = 'https://www.imgfox.cn/apis/uploads/20260824/1b5d57ffab034d5c/IMG_9888.png';
const HUAQING_DEFAULT_BG = 'https://www.imgfox.cn/apis/uploads/20260902/13739178ad734d60/IMG_9969.png';
const COLD_PALACE_DEFAULT_BG = 'https://www.imgfox.cn/apis/uploads/20260910/27bf74d453a24d04/IMG_0279.png';
const HUAQING_DEFAULT_DESCRIPTION = '华清宫是离宫深处的温泉行宫。赤柱金檐环抱汤池，暖雾沿雕花梁木缓缓升起，灯火映着水纹与玉阶，宫人只在帘外听候。这里远离朝堂喧声，适合召见、休憩与私下相谈。';
const HUAQING_DEFAULT_RULES = '入宫者须依身份守礼，不得替皇帝作决定；人物言行必须服从各自人设、记忆与当前时辰。多人相遇时先写传召、赴宫和门前照面，再进入汤殿互动。叙事含蓄古雅，角色台词标明准确姓名，未配置立绘的NPC只显示背景。';
const palaces = ["乾清宫","坤宁宫","东六宫","西六宫","养心殿","内务府","御花园","冷宫"];
let placedPalacesData = []; // [{name, x, y, icon}]
let pendingPalaces = []; // 待放置（拖动中）
let activePalaceToPlace = null;

let palaceDetails = {
  "乾清宫": { note: "", bgUrl: QIANQING_DEFAULT_BG },
  "华清宫": { note: "温泉行宫", bgUrl: HUAQING_DEFAULT_BG, description: HUAQING_DEFAULT_DESCRIPTION, rules: HUAQING_DEFAULT_RULES },
  "冷宫": { note: "幽禁失宠之人", bgUrl: COLD_PALACE_DEFAULT_BG },
  "坤宁宫": { note: "" },
  "景仁宫": { note: "" }, "承乾宫": { note: "" }, "钟粹宫": { note: "" }, "延禧宫": { note: "" }, "永和宫": { note: "" }, "景阳宫": { note: "" },
  "翊坤宫": { note: "" }, "永寿宫": { note: "" }, "咸福宫": { note: "" }, "长春宫": { note: "" }, "储秀宫": { note: "" }, "启祥宫": { note: "" }
};

// ===== Elements =====
const vMain      = document.getElementById('view-main');
const vMapSetup  = document.getElementById('view-map-setup');
const vPlacement = document.getElementById('view-placement');
const vCharSelect= document.getElementById('view-char-select');
const vCharCustomize = document.getElementById('view-char-customize');
const vRankSetup = document.getElementById('view-rank-setup');
const vAssignSetup = document.getElementById('view-assign-setup');
const vMemory    = document.getElementById('view-memory');
const vPalaceDetail = document.getElementById('view-palace-detail');
const vStory = document.getElementById('view-story');
const vMemoryManage = document.getElementById('view-memory-manage');

function switchView(v) {
  document.querySelectorAll('.view').forEach(x => x.classList.remove('active'));
  v.classList.add('active');
  // 进入有自己音乐按钮的页面时，隐藏全局悬浮 bgm-control 防止重叠
  const bgmCtrl = document.getElementById('bgm-control');
  if (bgmCtrl) {
    const hasOwnBar = (v === vMemory || v === vPalaceDetail || v === vIndoor || v === vStory);
    bgmCtrl.style.display = hasOwnBar ? 'none' : 'flex';
  }
}

let isRePlacementMode = false;

// ===== 返回键 =====
document.getElementById('btn-back-map').addEventListener('click', () => switchView(vMain));
document.getElementById('btn-back-placement').addEventListener('click', () => {
  if (isRePlacementMode) {
    isRePlacementMode = false;
    switchView(vMemoryManage);
    if (window.openDevToolsModal) window.openDevToolsModal();
    const pdTab = document.querySelector('.dev-tab[data-target="dev-palace"]');
    if (pdTab) pdTab.click();
  } else {
    switchView(vMapSetup);
  }
});
document.getElementById('btn-back-customize').addEventListener('click', () => {
  initCharSelectView(); switchView(vCharSelect);
});
document.getElementById('btn-back-rank').addEventListener('click', () => {
  switchView(vCharCustomize);
});
document.getElementById('btn-back-assign').addEventListener('click', () => {
  switchView(vRankSetup);
});

// ===== 2. Map Setup =====
const mapImgEl       = document.getElementById('map-img-element');
const mapPlaceholder = document.getElementById('map-placeholder');
const mapLoader      = document.getElementById('map-loader');
const aiPrompt       = document.getElementById('ai-prompt');
const setupBtnsInit  = document.getElementById('setup-btns-init');
const setupBtnsConfirm = document.getElementById('setup-btns-confirm');

document.getElementById('btn-default-map').addEventListener('click', async () => {
  currentMapDataUrl = "https://www.imgfox.cn/apis/uploads/20260820/6d8d61f6983c48d2/IMG_9688.png";
  await saveProgress({ mapUrl: currentMapDataUrl, palacesPlaced: false });
  api.ui.toast("皇城绘卷已存入忆尘录");
  initPlacementView();
  switchView(vPlacement);
});

document.getElementById('btn-import-map').addEventListener('click', async () => {
  try {
    const picked = await api.media.pick({ accept:"image/*" });
    if (picked?.file) {
      currentMapDataUrl = picked.file.dataUrl;
      showMapPreview();
      await saveProgress({ mapUrl: currentMapDataUrl });
    }
  } catch(e) { console.error(e); }
});

document.getElementById('btn-ai-map').addEventListener('click', async () => {
  aiPrompt.style.display = 'block';
  setupBtnsInit.style.display = 'none';
  setupBtnsConfirm.style.display = 'flex';
  await generateAIMap();
});

document.getElementById('btn-reroll').addEventListener('click', () => generateAIMap());

async function generateAIMap() {
  const globalLoader = document.getElementById('global-loader-modal');
  const globalLoaderText = document.getElementById('global-loader-text');
  
  mapImgEl.style.display = 'none';
  mapPlaceholder.style.display = 'none';
  mapLoader.style.display = 'block';
  setupBtnsConfirm.style.pointerEvents = 'none';
  setupBtnsConfirm.style.opacity = '0.5';
  
  globalLoaderText.innerText = "正在绘制皇城卷...";
  globalLoader.style.display = 'flex';
  
  try {
    const img = await api.ai.generateImage({ prompt: aiPrompt.value });
    if (img?.dataUrl) {
      currentMapDataUrl = img.dataUrl;
      showMapPreview();
      await saveProgress({ mapUrl: currentMapDataUrl });
    }
  } catch(e) {
    api.ui.toast("生成失败，请检查API配置");
    mapPlaceholder.style.display = 'block';
    mapPlaceholder.innerText = '生成失败';
  } finally {
    mapLoader.style.display = 'none';
    setupBtnsConfirm.style.pointerEvents = 'auto';
    setupBtnsConfirm.style.opacity = '1';
    globalLoader.style.display = 'none';
  }
}

function showMapPreview() {
  if (!currentMapDataUrl) return;
  mapImgEl.src = currentMapDataUrl;
  mapImgEl.style.display = 'block';
  mapPlaceholder.style.display = 'none';
  setupBtnsInit.style.display = 'none';
  setupBtnsConfirm.style.display = 'flex';
}

document.getElementById('btn-confirm-map').addEventListener('click', async () => {
  if (!currentMapDataUrl) return;
  await saveProgress({ mapUrl: currentMapDataUrl, palacesPlaced: false });
  api.ui.toast("皇城绘卷已存入忆尘录");
  initPlacementView();
  switchView(vPlacement);
});

// ===== 3. Palace Placement（含拖动 + 冷宫 + 确认布局）=====
const palaceBar     = document.getElementById('palace-bar');
const placementArea = document.getElementById('placement-area');
const btnNextPlacement = document.getElementById('btn-next-placement');
const btnConfirmPlacement = document.getElementById('btn-confirm-placement');

// 已放置的宫殿标签集合（可拖动）
let placedLabels = {}; // name -> DOM element

function initPlacementView() {
  document.getElementById('placement-bg').src = currentMapDataUrl || '';
  let guideTip = document.getElementById('placement-guide-tip');
  if (!guideTip) {
    guideTip = document.createElement('div');
    guideTip.id = 'placement-guide-tip';
    guideTip.style.cssText = 'position:absolute;top:calc(var(--safe-top) + 10px);left:50%;transform:translateX(-50%);z-index:30;width:min(88%,360px);padding:10px 13px;border:1px solid rgba(201,163,106,0.7);border-radius:12px;background:rgba(16,11,7,0.86);color:#e7ce99;font-size:12px;line-height:1.7;text-align:center;letter-spacing:1px;pointer-events:none;box-shadow:0 5px 18px rgba(0,0,0,0.45);';
    vPlacement.appendChild(guideTip);
  }
  guideTip.innerHTML = '<b style="color:#f0c96f;">布置方法：</b>先点底部宫殿名，再点地图上的放置位置。<br>全部宫殿放完后才会出现“确认布局”。';
  
  // 关键修复：确保拖拽区域铺满可见区域
  placementArea.innerHTML = '';
  placedLabels = {};
  palaceBar.innerHTML = '';
  activePalaceToPlace = null;
  btnNextPlacement.classList.remove('visible');
  btnConfirmPlacement.style.display = 'none';

  // 恢复已保存的布局
  placedPalacesData.forEach(pd => {
    createPalaceLabel(pd.name, pd.x, pd.y, pd.icon, pd.iconConfig);
  });

  // 底栏按钮
  palaces.forEach(p => {
    const btn = document.createElement('button');
    btn.className = 'palace-btn';
    btn.innerText = p;
    btn.dataset.name = p;
    // 若已在布局数据中则标为 placed
    if (placedPalacesData.find(pd => pd.name === p)) btn.classList.add('placed');
    btn.onclick = () => selectPalaceToPlace(btn, p);
    palaceBar.appendChild(btn);
  });

  updatePlacementProgress();
}

function selectPalaceToPlace(btn, name) {
  if (btn.classList.contains('placed')) return;
  document.querySelectorAll('.palace-btn').forEach(b => b.classList.remove('active'));
  btn.classList.add('active');
  activePalaceToPlace = name;
}

function createPalaceLabel(name, x, y, iconUrl = null, iconConfig = null) {
  const label = document.createElement('div');
  label.className = 'placed-palace';
  label.dataset.name = name;
  label.style.left = x + 'px';
  label.style.top  = y + 'px';
  
  if (iconConfig || iconUrl) {
    const cfg = iconConfig || { url: iconUrl, scale: 100, opacity: 100, offsetX: 0, offsetY: 0, labelY: -20, textMode: 'horizontal' };
    label.classList.add('has-icon');
    const writingMode = cfg.textMode === 'vertical' ? 'writing-mode:vertical-rl; text-orientation:upright; left:50%; bottom:auto; top:50%; transform:translate(-50%, -50%); letter-spacing:2px;' : 'left:50%; transform:translateX(-50%); white-space:nowrap; letter-spacing:1px;';
    const bottomStyle = cfg.textMode === 'vertical' ? '' : `bottom: ${cfg.labelY}px;`;
    
    label.innerHTML = `<img src="${cfg.url}" style="transform: translate(${cfg.offsetX}px, ${cfg.offsetY}px) scale(${cfg.scale/100}); opacity: ${cfg.opacity/100};"><div class="palace-name-label" style="${bottomStyle} ${writingMode}">${name}</div>`;
  } else {
    label.innerText = name;
  }
  
  placementArea.appendChild(label);
  placedLabels[name] = label;
  makeDraggable(label);
}

function makeDraggable(el) {
  let startX, startY, origLeft, origTop, isDragging = false;

  function onStart(cx, cy) {
    isDragging = false;
    startX = cx; startY = cy;
    origLeft = parseFloat(el.style.left);
    origTop  = parseFloat(el.style.top);
    el.classList.add('dragging');
  }
  function onMove(cx, cy) {
    const dx = cx - startX, dy = cy - startY;
    if (!isDragging && (Math.abs(dx) > 4 || Math.abs(dy) > 4)) isDragging = true;
    if (!isDragging) return;
    const rect = placementArea.getBoundingClientRect();
    const newLeft = Math.max(0, Math.min(rect.width,  origLeft + dx));
    const newTop  = Math.max(0, Math.min(rect.height, origTop  + dy));
    el.style.left = newLeft + 'px';
    el.style.top  = newTop  + 'px';
  }
  function onEnd() {
    el.classList.remove('dragging');
    if (isDragging) {
      // 更新内存数据
      const name = el.dataset.name;
      const entry = placedPalacesData.find(p => p.name === name);
      if (entry) { entry.x = parseFloat(el.style.left); entry.y = parseFloat(el.style.top); }
    }
    isDragging = false;
  }

  el.addEventListener('touchstart', e => {
    onStart(e.touches[0].clientX, e.touches[0].clientY);
  }, {passive:true});
  el.addEventListener('touchmove', e => {
    e.stopPropagation();
    onMove(e.touches[0].clientX, e.touches[0].clientY);
  }, {passive:false});
  el.addEventListener('touchend', () => onEnd());

  el.addEventListener('mousedown', e => {
    onStart(e.clientX, e.clientY);
    const mm = ev => onMove(ev.clientX, ev.clientY);
    const mu = () => { onEnd(); window.removeEventListener('mousemove', mm); window.removeEventListener('mouseup', mu); };
    window.addEventListener('mousemove', mm);
    window.addEventListener('mouseup', mu);
  });
}

placementArea.addEventListener('click', (e) => {
  if (!activePalaceToPlace) return;
  // 如果点击的是已放置的标签本身，忽略
  if (e.target.classList.contains('placed-palace')) return;

  const rect = placementArea.getBoundingClientRect();
  const x = e.clientX - rect.left;
  const y = e.clientY - rect.top;

  // 若已放置过同名宫殿则更新位置
  const existing = placedPalacesData.find(p => p.name === activePalaceToPlace);
  if (existing) {
    existing.x = x; existing.y = y;
    if (placedLabels[activePalaceToPlace]) {
      placedLabels[activePalaceToPlace].style.left = x + 'px';
      placedLabels[activePalaceToPlace].style.top  = y + 'px';
    }
  } else {
    placedPalacesData.push({ name: activePalaceToPlace, x, y });
    createPalaceLabel(activePalaceToPlace, x, y);
    const btn = document.querySelector(`.palace-btn[data-name="${activePalaceToPlace}"]`);
    if (btn) { btn.classList.remove('active'); btn.classList.add('placed'); }
  }

  activePalaceToPlace = null;
  document.querySelectorAll('.palace-btn').forEach(b => b.classList.remove('active'));
  updatePlacementProgress();
});

function updatePlacementProgress() {
  const allPlaced = palaces.every(p => placedPalacesData.find(pd => pd.name === p));
  const guideTip = document.getElementById('placement-guide-tip');
  if (allPlaced) {
    btnConfirmPlacement.style.display = 'block';
    if (guideTip) guideTip.innerHTML = '<b style="color:#f0c96f;">宫殿已全部放置。</b>请检查位置，然后点击底部“确认布局”。';
  } else if (guideTip) {
    const left = palaces.filter(name => !placedPalacesData.some(item => item.name === name)).length;
    guideTip.innerHTML = `<b style="color:#f0c96f;">布置方法：</b>先点底部宫殿名，再点地图位置。<br>还需放置 ${left} 座宫殿，全部放完才能继续。`;
  }
}

btnConfirmPlacement.addEventListener('click', async () => {
  await saveProgress({ palacesPlaced: true, palacesData: placedPalacesData });
  api.ui.toast("皇城布局已定，存入忆尘录");
  
  if (isRePlacementMode) {
    isRePlacementMode = false;
    // 重摆模式下，直接回到置度所
    initMemoryView(); // 刷新大地图上的标签
    switchView(vMemoryManage);
    if (window.openDevToolsModal) window.openDevToolsModal();
    const pdTab = document.querySelector('.dev-tab[data-target="dev-palace"]');
    if (pdTab) pdTab.click();
  } else {
    btnNextPlacement.classList.add('visible');
  }
});

btnNextPlacement.addEventListener('click', () => {
  initCharSelectView();
  switchView(vCharSelect);
});

// 宫门样式全局配置
let globalPortalCfg = { url: null, scale: 100, x: 0, y: 0, fsize: 24, textMode: 'vertical' };

// ===== 8. Memory Main =====
const hudTime = document.getElementById('hud-time');
const treasuryHudButton = document.getElementById('btn-treasury-map');
// hudTime 现在是 view-top-bar 内部的元素，不再需要 appendChild 到 body
const memoryMapContainer = document.getElementById('memory-map-container');
const memoryBg = document.getElementById('memory-bg');
const memoryArea = document.getElementById('memory-area');

function initMemoryView() {
  memoryBg.src = currentMapDataUrl || '';
  memoryArea.innerHTML = '';

  // 兼容冷宫入口加入前创建的旧存档：不要求玩家重做整张地图，自动在左下侧补一个可移动的初始入口。
  if (!placedPalacesData.some(item => item.name === '冷宫')) {
    placedPalacesData.push({
      name: '冷宫',
      x: Math.max(34, Math.round((window.innerWidth || 390) * 0.12)),
      y: Math.max(320, Math.round((window.innerHeight || 760) * 0.72))
    });
    saveProgress({ palacesData: placedPalacesData, palaceDetails });
  }
  
  // 恢复宫殿标签（不可拖动）
  placedPalacesData.forEach(pd => {
    const label = document.createElement('div');
    label.className = 'placed-palace';
    label.dataset.name = pd.name;
    label.style.left = pd.x + 'px';
    label.style.top  = pd.y + 'px';
    
    if (pd.iconConfig || pd.icon) {
      const cfg = pd.iconConfig || { url: pd.icon, scale: 100, opacity: 100, offsetX: 0, offsetY: 0, labelY: -20, textMode: 'horizontal' };
      label.classList.add('has-icon');
      const writingMode = cfg.textMode === 'vertical' ? 'writing-mode:vertical-rl; text-orientation:upright; left:50%; bottom:auto; top:50%; transform:translate(-50%,-50%); letter-spacing:2px;' : 'left:50%; transform:translateX(-50%); white-space:nowrap; letter-spacing:1px;';
      const bottomStyle = cfg.textMode === 'vertical' ? '' : `bottom: ${cfg.labelY}px;`;
      
      label.innerHTML = `<img src="${cfg.url}" style="transform: translate(${cfg.offsetX}px, ${cfg.offsetY}px) scale(${cfg.scale/100}); opacity: ${cfg.opacity/100};"><div class="palace-name-label" style="${bottomStyle} ${writingMode}">${pd.name}</div>`;
    } else {
      label.innerText = pd.name;
      if(pd.name === '冷宫') {
        label.style.borderColor = '#7a5c7a';
        label.style.color = '#c9a3c9';
      }
    }
    
    label.style.pointerEvents = 'auto';
    label.style.cursor = 'pointer';
    label.addEventListener('click', () => {
      if (pd.name === '东六宫' || pd.name === '西六宫') {
        openSixPalacesView(pd.name);
      } else {
        openPalaceDetail(pd.name);
      }
    });
    memoryArea.appendChild(label);
  });
  
  hudTime.style.display = 'block';
  // 确保能点击
  hudTime.style.pointerEvents = 'auto';
  hudTime.style.zIndex = '999';
  updateHudTimeFromReal();
  updateTreasuryHud();
}

function updateTreasuryHud() {
  if (treasuryHudButton) treasuryHudButton.innerText = `国库 ${formatSilver(treasurySilver)}两`;
}

function openTreasuryRechargeModal() {
  document.getElementById('treasury-recharge-modal')?.remove();
  const packages = [
    { silver: 100000, price: 20, name: '10万银两包' },
    { silver: 500000, price: 88, name: '50万银两包' },
    { silver: 1000000, price: 150, name: '100万银两包' },
    { silver: 5000000, price: 500, name: '500万银两包' },
    { silver: 10000000, price: 888, name: '1000万银两包' },
    { silver: 50000000, price: 2688, name: '5000万银两包' }
  ];
  const modal = document.createElement('div');
  modal.id = 'treasury-recharge-modal';
  modal.style.cssText = 'position:fixed;inset:0;z-index:100600;background:rgba(4,3,2,0.88);backdrop-filter:blur(12px);display:flex;align-items:flex-end;justify-content:center;font-family:"STZhongsong","STSong",serif;';
  modal.innerHTML = `<div style="width:100%;max-width:440px;max-height:88vh;overflow-y:auto;background:linear-gradient(180deg,#251c12,#100d09);border:1px solid rgba(201,163,106,.55);border-radius:24px 24px 0 0;padding:22px 16px calc(var(--safe-bottom) + 18px);">
    <div style="color:#efdba9;text-align:center;font-size:20px;letter-spacing:5px;">国库银库</div>
    <div style="color:#b99a64;text-align:center;font-size:14px;margin:10px 0 18px;">现有 ${formatSilver(treasurySilver)} 两</div>
    <div style="display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:10px;">${packages.map((item, index) => `<button data-treasury-pack="${index}" style="padding:15px 8px;border-radius:12px;background:rgba(201,163,106,.08);border:1px solid rgba(201,163,106,.35);color:#e6cf9f;font-family:inherit;"><b style="display:block;font-size:14px;">${item.name}</b><span style="display:block;color:#9b8056;font-size:12px;margin-top:7px;">¥${item.price}</span></button>`).join('')}</div>
    <button id="treasury-recharge-close" style="width:100%;margin-top:16px;padding:11px;border-radius:20px;background:transparent;border:1px solid #5e5548;color:#958a78;font-family:inherit;">暂不充值</button>
  </div>`;
  document.body.appendChild(modal);
  modal.querySelector('#treasury-recharge-close').onclick = () => modal.remove();
  modal.querySelectorAll('[data-treasury-pack]').forEach(button => {
    button.onclick = async () => {
      const item = packages[Number(button.dataset.treasuryPack)];
      const ok = await api.ui.confirm({ title: '国库充值', message: `支付¥${item.price}购买${item.name}，充值${formatSilver(item.silver)}两？` });
      if (!ok) return;
      button.disabled = true; button.innerText = '请稍候…';
      try {
        const wallet = await api.wallet.get();
        if (!wallet?.accounts?.length) throw new Error('未找到钱包账户');
        const result = await api.wallet.pay({ amount:item.price, accountId:wallet.accounts[0].id, title:'故梦辞·国库', detail:`购买${item.name}`, category:'游戏内购' });
        if (!result?.ok) throw new Error(result?.error || '支付取消或失败');
        treasurySilver += item.silver;
        await saveTreasuryState();
        api.ui.toast(`${item.name}已入库，现有${formatSilver(treasurySilver)}两`);
        modal.remove();
      } catch (error) {
        api.ui.toast(error?.message || '充值失败，请检查钱包配置');
        button.disabled = false; button.innerHTML = `<b style="display:block;font-size:14px;">${item.name}</b><span style="display:block;color:#9b8056;font-size:12px;margin-top:7px;">¥${item.price}</span>`;
      }
    };
  });
}

treasuryHudButton?.addEventListener('click', event => { event.stopPropagation(); openTreasuryRechargeModal(); });

// 时间换算逻辑
const ancientHours = [
  { name: "子时", note: "23-1点" }, { name: "丑时", note: "1-3点" }, { name: "寅时", note: "3-5点" },
  { name: "卯时", note: "5-7点" }, { name: "辰时", note: "7-9点" }, { name: "巳时", note: "9-11点" },
  { name: "午时", note: "11-13点" }, { name: "未时", note: "13-15点" }, { name: "申时", note: "15-17点" },
  { name: "酉时", note: "17-19点" }, { name: "戌时", note: "19-21点" }, { name: "亥时", note: "21-23点" }
];
const ancientQuarters = [
  { name: "初刻", note: "0-15分" }, { name: "一刻", note: "15-30分" },
  { name: "二刻", note: "30-45分" }, { name: "三刻", note: "45-60分" }
];
const ancientMonths = ["正月","二月","三月","四月","五月","六月","七月","八月","九月","十月","冬月","腊月"];

function getAncientTimeStr(date) {
  // 年份统一用当前年份减去基准，比如 2026 -> 永安六十一年 (假设基准 1965)
  const baseYear = 1965;
  const yearNum = Math.max(1, date.getFullYear() - baseYear + 1);
  // 月份 0-11
  const mStr = ancientMonths[date.getMonth()];
  // 日
  const d = date.getDate();
  const dStr = (d <= 10) ? ("初" + ["一","二","三","四","五","六","七","八","九","十"][d-1]) : 
               (d < 20) ? ("十" + (d===10?"":["一","二","三","四","五","六","七","八","九"][d-11])) :
               (d === 20) ? "二十" :
               (d < 30) ? ("廿" + ["一","二","三","四","五","六","七","八","九"][d-21]) :
               (d === 30) ? "三十" : "三十一";
  
  const h = date.getHours();
  let hIdx = Math.floor((h + 1) / 2) % 12;
  const hStr = ancientHours[hIdx].name;
  
  const min = date.getMinutes();
  let qIdx = Math.floor(min / 15);
  const qStr = ancientQuarters[qIdx].name;
  
  return `永安${yearNum === 1 ? '元' : convertNumberToChinese(yearNum)}年${mStr}${dStr} ${hStr}${qStr}`;
}

function convertNumberToChinese(num) {
  const digits = ["零","一","二","三","四","五","六","七","八","九"];
  const units = ["","十","百"];
  let str = num.toString();
  if (num < 10) return digits[num];
  if (num < 20) return "十" + (num===10 ? "" : digits[num%10]);
  if (num < 100) return digits[Math.floor(num/10)] + "十" + (num%10===0 ? "" : digits[num%10]);
  return num.toString(); // 简化
}

function updateHudTimeFromReal() {
  startSyncTimer();
}

// === 12. Six Palaces View ===
const vSixPalaces = document.getElementById('view-six-palaces');
const spGrid = document.getElementById('six-palaces-grid');
let currentSixPalacesName = null; // '东六宫' 或 '西六宫'

function openSixPalacesView(clusterName) {
  currentSixPalacesName = clusterName;
  document.getElementById('six-palaces-title').innerText = clusterName;
  
  if (!palaceDetails[clusterName]) palaceDetails[clusterName] = { note: "" };
  
  // 背景图
  const bgUrl = palaceDetails[clusterName].bgUrl || '';
  document.getElementById('six-palaces-bg-layer').style.backgroundImage = `url('${bgUrl}')`;
  
  renderSixPalacesGrid();
  switchView(vSixPalaces);
}

function renderSixPalacesGrid() {
  spGrid.innerHTML = '';
  const arr = currentSixPalacesName === '东六宫' ? eastPalaces : westPalaces;
  
  arr.forEach(pName => {
    const portal = document.createElement('div');
    portal.className = 'portal-item';
    
    // 应用自定义样式
    let imgHtml = '';
    if (globalPortalCfg.url) {
      portal.classList.add('no-bg'); // 如果有自定义图片，去掉底板的磨砂和边框
      const { scale, x, y } = globalPortalCfg;
      imgHtml = `<img class="portal-img" src="${globalPortalCfg.url}" style="transform: translate(${x}px, ${y}px) scale(${scale/100});">`;
    }
    
    const isVert = globalPortalCfg.textMode === 'vertical';
    const writingMode = isVert ? 'writing-mode:vertical-rl; text-orientation:upright;' : 'writing-mode:horizontal-tb; text-orientation:mixed;';
    
    portal.innerHTML = `
      ${imgHtml}
      <div class="portal-label" style="${writingMode} font-size:${globalPortalCfg.fsize}px;">${pName}</div>
    `;
    
    portal.addEventListener('click', () => {
      openPalaceDetail(pName);
    });
    
    spGrid.appendChild(portal);
  });
}

document.getElementById('btn-back-six-palaces').addEventListener('click', () => {
  switchView(vMemory);
});

// 换背景复用 pbModal
document.getElementById('btn-change-bg-six-palaces').addEventListener('click', () => {
  currentDetailPalaceName = currentSixPalacesName; // 借用这个变量给确认按钮用
  pbTitle.innerText = `${currentSixPalacesName} · 重新绘景`;
  pbPrompt.value = `真实画风，中国古代皇宫室外，${currentSixPalacesName}外景，大气，华丽，唯美，无人物`;
  pbImg.style.display = 'none';
  pbPlaceholder.style.display = 'block';
  pbLoader.style.display = 'none';
  btnPbConfirm.style.display = 'none';
  tempPbDataUrl = null;
  isCourtyardMode = false;
  pbModal.style.display = 'flex';
});

// 宫门 DIY 弹窗
const ptCfgModal = document.getElementById('portal-cfg-modal');
const ptCfgPreviewImg = document.getElementById('pt-cfg-preview-img');
const ptCfgPreviewLabel = document.getElementById('pt-cfg-preview-label');
const ptRangeScale = document.getElementById('pt-cfg-scale');
const ptRangeX = document.getElementById('pt-cfg-x');
const ptRangeY = document.getElementById('pt-cfg-y');
const ptRangeFsize = document.getElementById('pt-cfg-fsize');
const ptRadiosTextMode = document.getElementsByName('pt-cfg-textmode');
let ptTempUrl = null;

function updatePtPreview() {
  ptCfgPreviewImg.style.transform = `translate(${ptRangeX.value}px, ${ptRangeY.value}px) scale(${ptRangeScale.value / 100})`;
  ptCfgPreviewLabel.style.fontSize = `${ptRangeFsize.value}px`;
  
  const textMode = document.querySelector('input[name="pt-cfg-textmode"]:checked').value;
  if (textMode === 'vertical') {
    ptCfgPreviewLabel.style.writingMode = 'vertical-rl';
    ptCfgPreviewLabel.style.textOrientation = 'upright';
  } else {
    ptCfgPreviewLabel.style.writingMode = 'horizontal-tb';
    ptCfgPreviewLabel.style.textOrientation = 'mixed';
  }
}

[ptRangeScale, ptRangeX, ptRangeY, ptRangeFsize].forEach(el => el.addEventListener('input', updatePtPreview));
ptRadiosTextMode.forEach(el => el.addEventListener('change', updatePtPreview));

document.getElementById('btn-cfg-portals').addEventListener('click', () => {
  ptTempUrl = globalPortalCfg.url;
  ptCfgPreviewImg.src = ptTempUrl || '';
  const previewBox = document.getElementById('pt-cfg-preview-box');
  if (ptTempUrl) {
    previewBox.classList.add('no-bg');
  } else {
    previewBox.classList.remove('no-bg');
  }
  
  ptRangeScale.value = globalPortalCfg.scale;
  ptRangeX.value = globalPortalCfg.x;
  ptRangeY.value = globalPortalCfg.y;
  ptRangeFsize.value = globalPortalCfg.fsize;
  document.querySelector(`input[name="pt-cfg-textmode"][value="${globalPortalCfg.textMode}"]`).checked = true;
  updatePtPreview();
  ptCfgModal.style.display = 'flex';
});

document.getElementById('btn-pt-cfg-reupload').addEventListener('click', async () => {
  try {
    const picked = await api.media.pick({ accept: "image/*" });
    if (picked?.file) {
      ptTempUrl = picked.file.dataUrl;
      ptCfgPreviewImg.src = ptTempUrl;
      document.getElementById('pt-cfg-preview-box').classList.add('no-bg');
    }
  } catch(e) {}
});

document.getElementById('btn-pt-cfg-remove').addEventListener('click', async () => {
  globalPortalCfg = { url: null, scale: 100, x: 0, y: 0, fsize: 24, textMode: 'vertical' };
  document.getElementById('pt-cfg-preview-box').classList.remove('no-bg');
  await saveProgress({ globalPortalCfg });
  renderSixPalacesGrid();
  ptCfgModal.style.display = 'none';
});

document.getElementById('btn-pt-cfg-cancel').addEventListener('click', () => ptCfgModal.style.display = 'none');

document.getElementById('btn-pt-cfg-remove').addEventListener('click', async () => {
  globalPortalCfg = { url: null, scale: 100, x: 0, y: 0, fsize: 24, textMode: 'vertical' };
  await saveProgress({ globalPortalCfg });
  renderSixPalacesGrid();
  ptCfgModal.style.display = 'none';
});

document.getElementById('btn-pt-cfg-reupload').addEventListener('click', async () => {
  try {
    const picked = await api.media.pick({ accept: "image/*" });
    if (picked?.file) {
      ptTempUrl = picked.file.dataUrl;
      ptCfgPreviewImg.src = ptTempUrl;
    }
  } catch(e) {}
});

document.getElementById('btn-pt-cfg-save').addEventListener('click', async () => {
  globalPortalCfg = {
    url: ptTempUrl,
    scale: parseInt(ptRangeScale.value),
    x: parseInt(ptRangeX.value),
    y: parseInt(ptRangeY.value),
    fsize: parseInt(ptRangeFsize.value),
    textMode: document.querySelector('input[name="pt-cfg-textmode"]:checked').value
  };
  await saveProgress({ globalPortalCfg });
  renderSixPalacesGrid();
  ptCfgModal.style.display = 'none';
});

// === 9. Palace Detail & BG Setup ===
const pbModal = document.getElementById('palace-bg-modal');
const pbTitle = document.getElementById('pb-modal-title');
const pbImg = document.getElementById('pb-img');
const pbLoader = document.getElementById('pb-loader');
const pbPlaceholder = document.getElementById('pb-placeholder');
const pbPrompt = document.getElementById('pb-prompt');
const btnPbConfirm = document.getElementById('btn-pb-confirm');
const pbFilterControls = document.getElementById('pb-filter-controls');
const pbBrightness = document.getElementById('pb-brightness');
const pbContrast = document.getElementById('pb-contrast');
const pbR = document.getElementById('pb-r');
const pbG = document.getElementById('pb-g');
const pbB = document.getElementById('pb-b');
const pbColorMatrix = document.getElementById('pb-color-matrix');
let currentDetailPalaceName = null;
let tempPbDataUrl = null;
let currentEarRoomPalaceName = '';
let currentEarRoomType = '';

function applyPbFilter() {
  const b = pbBrightness.value;
  const c = pbContrast.value;
  const rv = pbR.value / 100;
  const gv = pbG.value / 100;
  const bv = pbB.value / 100;
  
  // 使用 SVG 滤镜实现 RGB 独立调色
  pbColorMatrix.setAttribute('values', `${rv} 0 0 0 0  0 ${gv} 0 0 0  0 0 ${bv} 0 0  0 0 0 1 0`);
  
  pbImg.style.filter = `brightness(${b}%) contrast(${c}%) url(#pb-color-filter)`;
}
[pbBrightness, pbContrast, pbR, pbG, pbB].forEach(el => el.addEventListener('input', applyPbFilter));

function resetPbFilter() {
  pbBrightness.value = 100;
  pbContrast.value = 100;
  pbR.value = 100;
  pbG.value = 100;
  pbB.value = 100;
  applyPbFilter();
  pbFilterControls.style.display = 'none';
}

// 同步控制确认+下载+设为图标按钮显隐的辅助函数
function setPbActionBtnsVisible(visible) {
  const d = visible ? 'block' : 'none';
  btnPbConfirm.style.display = d;
  const dlBtn = document.getElementById('btn-pb-download');
  if (dlBtn) dlBtn.style.display = d;
  const iconBtn = document.getElementById('btn-pb-as-icon');
  if (iconBtn) iconBtn.style.display = d;
}

// pbModal 快捷预设按钮绑定（pbModal 是静态HTML，用事件委托）
document.getElementById('palace-bg-modal').addEventListener('click', e => {
  const qBtn = e.target.closest('.pb-quick-btn');
  if (qBtn) {
    const pbPromptEl = document.getElementById('pb-prompt');
    if (pbPromptEl) pbPromptEl.value = qBtn.dataset.txt;
  }
});

// "设为图标"按钮：把当前预览图设为宫殿图标
document.getElementById('btn-pb-as-icon').addEventListener('click', async () => {
  if (!tempPbDataUrl) { api.ui.toast('请先生成或导入图片'); return; }
  // 烤入滤镜
  const finalDataUrl = bakeFilterToDataUrl(pbImg);

  // 弹出选择宫殿
  const iconPicker = document.createElement('div');
  iconPicker.style.cssText = 'position:fixed;inset:0;z-index:200000;background:rgba(0,0,0,0.85);display:flex;align-items:flex-end;justify-content:center;';
  const palaceNames = placedPalacesData.map(p => p.name);
  const optHtml = palaceNames.map(n => `<button class="pb-icon-palace-btn" data-name="${n}" style="background:rgba(201,163,106,0.08);border:1px solid rgba(201,163,106,0.3);color:var(--primary-color);padding:10px 16px;border-radius:8px;font-size:14px;font-family:inherit;letter-spacing:2px;">${n}</button>`).join('');
  iconPicker.innerHTML = `
    <div style="width:100%;max-width:420px;background:#1a1816;border:1px solid var(--primary-color);border-radius:20px 20px 0 0;padding:20px 16px calc(var(--safe-bottom,24px)+16px);display:flex;flex-direction:column;gap:10px;max-height:70vh;overflow-y:auto;">
      <div style="color:var(--primary-color);font-size:16px;text-align:center;letter-spacing:3px;font-family:'STZhongsong','STSong',serif;">设为哪座宫殿的图标？</div>
      <div style="display:flex;flex-direction:column;gap:8px;">${optHtml}</div>
      <button id="pb-icon-cancel" style="background:transparent;border:none;color:#555;font-family:inherit;font-size:13px;padding:4px;">取消</button>
    </div>
  `;
  document.body.appendChild(iconPicker);
  iconPicker.addEventListener('click', e => { if(e.target === iconPicker) iconPicker.remove(); });
  document.getElementById('pb-icon-cancel').onclick = () => iconPicker.remove();

  iconPicker.querySelectorAll('.pb-icon-palace-btn').forEach(btn => {
    btn.onclick = async () => {
      const palaceName = btn.dataset.name;
      iconPicker.remove();
      const pd = placedPalacesData.find(p => p.name === palaceName);
      if (pd) {
        pd.icon = finalDataUrl;
        pd.iconConfig = { url: finalDataUrl, scale: 100, opacity: 100, offsetX: 0, offsetY: 0, labelY: -20, textMode: 'horizontal' };
        await saveProgress({ palacesData: placedPalacesData });
        initMemoryView();
        api.ui.toast(`✓ 已设为「${palaceName}」的图标`);
      }
    };
  });
});

function showPbFilter() {
  pbFilterControls.style.display = 'flex';
  
  // 若是室内绘景，在预览框里把人物立绘加上
  if (currentDetailPalaceName === '__INDOOR__' && window.currentIndoorChar) {
    const char = window.currentIndoorChar;
    const avatarContainer = document.getElementById('pb-preview-avatar');
    const avatarImg = document.getElementById('pb-preview-avatar-img');
    avatarImg.src = char.customAvatar || char.avatar;
    if (char.storyAvatarCfg) {
      const cfg = char.storyAvatarCfg;
      
      // 因为预览框只是实际屏幕的一部分大小，我们要把坐标等比例缩放
      // 假设预览框高度约占全屏高度的 1/3，我们就把偏移量除以 3
      const ratio = 0.35; 
      const scaledX = cfg.x * ratio;
      const scaledY = cfg.y * ratio;
      
      avatarImg.style.transform = `translate(${scaledX}px, ${scaledY}px) scale(${cfg.scale / 100})`;
    } else {
      avatarImg.style.transform = 'translate(0px, 0px) scale(1)';
    }
    avatarContainer.style.display = 'flex';
  } else {
    document.getElementById('pb-preview-avatar').style.display = 'none';
  }
}

// ===== 音乐系统 =====
const bgmControl = document.getElementById('bgm-control');
const bgmAudio   = document.getElementById('bgm-audio');
const bgmIcon    = document.getElementById('bgm-icon');
const musicPanel = document.getElementById('music-panel');
const vinylDisc  = document.getElementById('vinyl-disc');
const musicSongName = document.getElementById('music-song-name');
const musicStatus   = document.getElementById('music-status');
const mcPlay  = document.getElementById('mc-play');
const mcPrev  = document.getElementById('mc-prev');
const mcNext  = document.getElementById('mc-next');
const mcMode  = document.getElementById('mc-mode');
const mcClose = document.getElementById('mc-close');
const musicPlaylist = document.getElementById('music-playlist');

// 曲库
const playlist = [
  { name: '山野煮雨', url: 'http://music.163.com/song/media/outer/url?id=2677687612.mp3' },
  { name: '诀别书',   url: 'http://music.163.com/song/media/outer/url?id=2038191895.mp3' },
  { name: '镜月',     url: 'http://music.163.com/song/media/outer/url?id=3399895934.mp3' },
  { name: '浮光',     url: 'http://music.163.com/song/media/outer/url?id=1394601255.mp3' },
  { name: '托遗响于悲风', url: 'http://music.163.com/song/media/outer/url?id=2725968843.mp3' },
  { name: 'Sang（扶桑）', url: 'http://music.163.com/song/media/outer/url?id=3373909335.mp3' },
  { name: '紫禁城里的端庄猫', url: 'http://music.163.com/song/media/outer/url?id=1822281724.mp3' },
  { name: '泱泱', url: 'http://music.163.com/song/media/outer/url?id=2064652710.mp3' },
];
let currentTrackIdx = 0;  // 默认第0首（山野煮雨）
let isBgmPlaying = false;
let loopMode = 'list';    // 'list' | 'single'

function renderPlaylist() {
  musicPlaylist.innerHTML = '';
  playlist.forEach((track, idx) => {
    const item = document.createElement('div');
    item.className = 'playlist-item' + (idx === currentTrackIdx ? ' current' : '');
    item.innerHTML = `
      <span class="pi-idx">${idx + 1}</span>
      <span class="pi-name">${track.name}</span>
      <span class="pi-eq">♪</span>`;
    item.addEventListener('click', () => { switchTrack(idx); playBgm(); });
    musicPlaylist.appendChild(item);
  });
}

function switchTrack(idx) {
  currentTrackIdx = idx;
  bgmAudio.src = playlist[idx].url;
  bgmAudio.load();
  musicSongName.innerText = playlist[idx].name;
  renderPlaylist();
}

function switchTrackByName(name, shouldPlay = isBgmPlaying) {
  const idx = playlist.findIndex(track => track.name === name);
  if (idx < 0) return false;
  if (currentTrackIdx !== idx) switchTrack(idx);
  else renderPlaylist();
  if (shouldPlay) playBgm();
  return true;
}

function updateLoopUI() {
  if (loopMode === 'single') {
    mcMode.innerText = '单曲';
    mcMode.classList.add('active');
    mcMode.title = '单曲循环（点击切换）';
    bgmAudio.loop = true;
  } else {
    mcMode.innerText = '列表';
    mcMode.classList.remove('active');
    mcMode.title = '列表循环（点击切换）';
    bgmAudio.loop = false;
  }
}

// 统一更新所有音乐按钮的旋转状态
function applySpinState(playing) {
  // 全局悬浮按钮
  if (playing) bgmControl.classList.add('spinning');
  else bgmControl.classList.remove('spinning');
  // 顶栏内嵌按钮（包含所有页面的音乐按钮）
  ['btn-bgm-map','btn-bgm-palace','btn-indoor-bgm','btn-story-bgm','btn-bgm-six-palaces-inner'].forEach(id => {
    const el = document.getElementById(id);
    if (!el) return;
    if (playing) el.classList.add('spinning');
    else el.classList.remove('spinning');
  });
  // 动态生成的页面里也可能有音乐按钮，用 class 统一处理
  document.querySelectorAll('.bgm-spin-target').forEach(el => {
    if (playing) el.classList.add('spinning');
    else el.classList.remove('spinning');
  });
}

function playBgm() {
  bgmAudio.play().then(() => {
    isBgmPlaying = true;
    mcPlay.innerHTML = '&#9646;&#9646;';
    applySpinState(true);
    vinylDisc.classList.add('playing');
    musicStatus.innerText = '正在播放';
  }).catch(() => {});
}

function pauseBgm() {
  bgmAudio.pause();
  isBgmPlaying = false;
  mcPlay.innerHTML = '&#9654;';
  applySpinState(false);
  vinylDisc.classList.remove('playing');
  musicStatus.innerText = '已暂停';
}

function syncBgmBtns() {
  mcPlay.innerHTML = isBgmPlaying ? '&#9646;&#9646;' : '&#9654;';
  applySpinState(isBgmPlaying);
  if (isBgmPlaying) vinylDisc.classList.add('playing');
  else vinylDisc.classList.remove('playing');
  musicStatus.innerText = isBgmPlaying ? '正在播放' : '已暂停';
}

// 列表循环：一首结束自动播下一首
bgmAudio.addEventListener('ended', () => {
  if (loopMode === 'list') {
    currentTrackIdx = (currentTrackIdx + 1) % playlist.length;
    switchTrack(currentTrackIdx);
    playBgm();
  }
});

// 控制按钮
mcPlay.addEventListener('click', (e) => {
  e.stopPropagation();
  if (isBgmPlaying) pauseBgm(); else playBgm();
});
mcPrev.addEventListener('click', (e) => {
  e.stopPropagation();
  currentTrackIdx = (currentTrackIdx - 1 + playlist.length) % playlist.length;
  switchTrack(currentTrackIdx);
  if (isBgmPlaying) playBgm();
});
mcNext.addEventListener('click', (e) => {
  e.stopPropagation();
  currentTrackIdx = (currentTrackIdx + 1) % playlist.length;
  switchTrack(currentTrackIdx);
  if (isBgmPlaying) playBgm();
});
mcMode.addEventListener('click', (e) => {
  e.stopPropagation();
  loopMode = loopMode === 'list' ? 'single' : 'list';
  updateLoopUI();
});
mcClose.addEventListener('click', (e) => {
  e.stopPropagation();
  musicPanel.classList.remove('open');
});

// 点击悬浮按钮：打开/关闭小窗
bgmControl.addEventListener('click', (e) => {
  e.stopPropagation();
  musicPanel.classList.toggle('open');
});

// 点击小窗外关闭
document.addEventListener('click', (e) => {
  if (musicPanel.classList.contains('open') &&
      !musicPanel.contains(e.target) &&
      e.target !== bgmControl &&
      !bgmControl.contains(e.target)) {
    musicPanel.classList.remove('open');
  }
});

// 自动播放与旋转
let bgmInited = false;
const initBGM = (e) => {
  if (bgmInited) return;
  bgmInited = true;
  // 阻止同一次触摸同时触发 touchstart + click 导致二次调用
  if (e && e.type === 'touchstart') {
    document.removeEventListener('click', initBGM);
  }
  document.removeEventListener('touchstart', initBGM);
  playBgm();
};

function openPalaceDetail(pName) {
  currentDetailPalaceName = pName;
  if (!palaceDetails[pName]) palaceDetails[pName] = { note: "" };
  if (pName === '乾清宫' && !palaceDetails[pName].bgUrl) palaceDetails[pName].bgUrl = QIANQING_DEFAULT_BG;

  // 御书房：专属视图
  if (pName === '御书房') {
    if (!palaceDetails[pName].bgUrl) {
      pbTitle.innerText = `御书房 · 内景`;
      pbPrompt.value = `真实画风，中国古代皇宫御书房内景，龙案奏折，书架典籍，烛光摇曳，庄严肃穆，华丽，无人物`;
      pbImg.style.display = 'none';
      pbPlaceholder.style.display = 'block';
      pbLoader.style.display = 'none';
      btnPbConfirm.style.display = 'none';
      tempPbDataUrl = null;
      pbModal.style.display = 'flex';
    } else {
      enterPalaceDetailView(pName);
    }
    return;
  }

  // 内务府：直接进入，不需要绘景
  if (pName === '内务府') {
    if (!palaceDetails[pName].bgUrl) {
      pbTitle.innerText = `内务府 · 内景`;
      pbPrompt.value = `真实画风，中国古代皇宫内务府室内，卷宗档案，烛光，华丽，唯美，无人物`;
      pbImg.style.display = 'none';
      pbPlaceholder.style.display = 'block';
      pbLoader.style.display = 'none';
      btnPbConfirm.style.display = 'none';
      tempPbDataUrl = null;
      pbModal.style.display = 'flex';
    } else {
      enterPalaceDetailView(pName);
    }
    return;
  }

  // 乾清宫：只有一张朝堂背景，不使用正殿/偏殿房间结构
  if (pName === '乾清宫') {
    switchTrackByName('泱泱', true);
    enterPalaceDetailView(pName);
    return;
  }

  // 御花园：首次进入仍先设置唯一背景，完成后进入专属游园页
  if (pName === '御花园') {
    if (!palaceDetails[pName].bgUrl) {
      pbTitle.innerText = '御花园 · 园景';
      pbPrompt.value = '真实画风，中国古代皇家御花园，亭台水榭，四时花木，曲径与茶亭，华丽唯美，无人物';
      pbImg.style.display = 'none';
      pbPlaceholder.style.display = 'block';
      pbLoader.style.display = 'none';
      btnPbConfirm.style.display = 'none';
      tempPbDataUrl = null;
      pbModal.style.display = 'flex';
    } else {
      enterPalaceDetailView(pName);
    }
    return;
  }

  if (pName === '珍宝阁') {
    if (!palaceDetails[pName].bgUrl) {
      pbTitle.innerText = '珍宝阁 · 内景';
      pbPrompt.value = '真实画风，中国古代皇家珍宝阁内景，多宝格、锦盒、古董、珠玉与画卷，烛光温润，华丽雅致，无人物';
      pbImg.style.display='none'; pbPlaceholder.style.display='block'; pbLoader.style.display='none'; btnPbConfirm.style.display='none'; tempPbDataUrl=null; pbModal.style.display='flex';
    } else enterPalaceDetailView(pName);
    return;
  }

  // 华清宫自带默认温泉内景，玩家可进入后再自行更换。
  if (pName === '华清宫') {
    if (!palaceDetails[pName]) palaceDetails[pName] = { note: '温泉行宫' };
    if (!palaceDetails[pName].bgUrl) palaceDetails[pName].bgUrl = HUAQING_DEFAULT_BG;
    if (!palaceDetails[pName].description) palaceDetails[pName].description = HUAQING_DEFAULT_DESCRIPTION;
    if (!palaceDetails[pName].rules) palaceDetails[pName].rules = HUAQING_DEFAULT_RULES;
    enterPalaceDetailView(pName);
    return;
  }

  // 冷宫自带默认背景，不强制上传或生图。
  if (pName === '冷宫') {
    if (!palaceDetails[pName]) palaceDetails[pName] = { note: '幽禁失宠之人' };
    if (!palaceDetails[pName].bgUrl) palaceDetails[pName].bgUrl = COLD_PALACE_DEFAULT_BG;
    enterPalaceDetailView(pName);
    return;
  }
  
  if (!palaceDetails[pName].bgUrl) {
    pbTitle.innerText = `${pName} · 外景`;
    pbPrompt.value = `真实画风，中国古代皇宫室外，${pName}外景，大气，华丽，唯美，无人物`;
    pbImg.style.display = 'none';
    pbPlaceholder.style.display = 'block';
    pbLoader.style.display = 'none';
    btnPbConfirm.style.display = 'none';
    tempPbDataUrl = null;
    pbModal.style.display = 'flex';
  } else {
    enterPalaceDetailView(pName);
  }
}

// 已在上方统一处理 btn-pb-import 和 btn-pb-draw

document.getElementById('btn-pb-cancel').addEventListener('click', () => { pbModal.style.display = 'none'; });

function enterPalaceDetailView(pName) {
  // 养心殿的左侧人物入口与底部操作栏挂在公共宫殿视图上，离开养心殿时必须先清除。
  if (pName !== '养心殿') document.getElementById('yangxin-overlay')?.remove();
  document.getElementById('palace-detail-name').innerText = pName;
  document.getElementById('palace-detail-bg-layer').style.backgroundImage = `url('${palaceDetails[pName].bgUrl}')`;
  document.getElementById('room-carousel').style.display = '';

  // 养心殿走专属视图
  if (pName === '养心殿') {
    document.getElementById('room-carousel').innerHTML = '';
    document.getElementById('palace-actions').innerHTML = '';
    renderYangXinDian();
    switchView(vPalaceDetail);
    return;
  }

  // 御书房走专属视图
  if (pName === '御书房') {
    document.getElementById('room-carousel').innerHTML = '';
    document.getElementById('palace-actions').innerHTML = '';
    renderYuShuFang();
    switchView(vPalaceDetail);
    return;
  }

  if (pName === '珍宝阁') {
    document.getElementById('room-carousel').innerHTML='';
    document.getElementById('room-carousel').style.display='none';
    const actions=document.getElementById('palace-actions'); actions.innerHTML='';
    const button=document.createElement('button'); button.innerText='入阁选宝'; button.style.cssText='width:210px;padding:13px;border-radius:24px;background:rgba(0,0,0,.58);border:1px solid var(--primary-color);color:var(--primary-color);font-family:inherit;font-size:15px;letter-spacing:4px;'; button.onclick=()=>openTreasurePavilion(); actions.appendChild(button);
    const bg=document.createElement('button'); bg.innerText='重新设定背景'; bg.style.cssText='padding:8px 14px;border-radius:18px;background:rgba(0,0,0,.45);border:1px solid #715b3e;color:#bba277;font-family:inherit;'; bg.onclick=()=>{palaceDetails[pName].bgUrl='';openPalaceDetail(pName);}; actions.appendChild(bg);
    switchView(vPalaceDetail); return;
  }

  // 华清宫为单一温泉行宫视图，不出现正殿、偏殿等房间卡片。
  if (pName === '华清宫') {
    renderHuaQingPalace();
    switchView(vPalaceDetail);
    return;
  }

  if (pName === '冷宫') {
    renderColdPalace();
    switchView(vPalaceDetail);
    return;
  }

  // 乾清宫走单背景早朝入口，不展示正殿、偏殿等房间卡片
  if (pName === '乾清宫') {
    switchTrackByName('泱泱', true);
    const roomCarousel = document.getElementById('room-carousel');
    const actionsContainer = document.getElementById('palace-actions');
    roomCarousel.innerHTML = '';
    roomCarousel.style.display = 'none';
    actionsContainer.innerHTML = '';

    const courtHint = document.createElement('div');
    courtHint.style.cssText = 'color:#e9d7ad; font-size:13px; letter-spacing:3px; text-align:center; text-shadow:0 2px 4px #000; margin-bottom:4px;';
    courtHint.innerText = '丹墀肃立 · 百官候朝';
    actionsContainer.appendChild(courtHint);

    const courtTimeHint = document.createElement('div');
    courtTimeHint.style.cssText = 'max-width:300px;color:#b8a27c;font-size:11px;line-height:1.8;letter-spacing:1px;text-align:center;margin:0 auto 4px;';
    courtTimeHint.innerHTML = '常朝时辰：<span style="color:#e9d7ad;">上午 5 点至 12 点</span><br>其余时辰可凭<span style="color:#d6ae55;font-weight:bold;">金手指</span>强制升殿';
    actionsContainer.appendChild(courtTimeHint);

    const btnCourt = document.createElement('button');
    btnCourt.id = 'btn-start-morning-court';
    btnCourt.style.cssText = 'width:200px; padding:12px; border-radius:24px; background:rgba(0,0,0,0.55); border:1px solid var(--primary-color); color:var(--primary-color); font-size:15px; letter-spacing:4px; text-align:center; box-shadow:0 4px 12px rgba(0,0,0,0.5); font-family:inherit;';
    btnCourt.innerText = '升殿上朝';
    btnCourt.onclick = () => promptMorningCourt();
    actionsContainer.appendChild(btnCourt);

    const bgActions = document.createElement('div');
    bgActions.style.cssText = 'display:flex; gap:10px; justify-content:center;';
    const btnChangeBg = document.createElement('button');
    btnChangeBg.style.cssText = 'padding:8px 15px; border-radius:18px; background:rgba(0,0,0,0.5); border:1px solid rgba(201,163,106,0.55); color:#d9c296; font-size:12px; letter-spacing:2px; font-family:inherit;';
    btnChangeBg.innerText = '更换背景';
    btnChangeBg.onclick = () => openQianQingBackgroundEditor();
    const btnResetBg = document.createElement('button');
    btnResetBg.style.cssText = btnChangeBg.style.cssText;
    btnResetBg.innerText = '恢复默认';
    btnResetBg.onclick = () => resetQianQingBackground();
    bgActions.appendChild(btnChangeBg);
    bgActions.appendChild(btnResetBg);
    actionsContainer.appendChild(bgActions);

    switchView(vPalaceDetail);
    setTimeout(() => promptMorningCourt(), 120);
    return;
  }

  // 御花园走单背景游园入口，不展示正殿、偏殿等房间卡片
  if (pName === '御花园') {
    const roomCarousel = document.getElementById('room-carousel');
    const actionsContainer = document.getElementById('palace-actions');
    roomCarousel.innerHTML = '';
    roomCarousel.style.display = 'none';
    actionsContainer.innerHTML = '';

    const hint = document.createElement('div');
    hint.style.cssText = 'color:#eadbb8;font-size:14px;letter-spacing:4px;text-align:center;text-shadow:0 2px 5px #000;margin-bottom:8px;';
    hint.innerText = '御苑风日 · 随兴游赏';
    actionsContainer.appendChild(hint);

    const makeGardenButton = (label, handler, secondary = false) => {
      const button = document.createElement('button');
      button.style.cssText = `width:200px;padding:12px;border-radius:24px;background:${secondary ? 'rgba(20,20,20,0.72)' : 'rgba(0,0,0,0.52)'};border:1px solid ${secondary ? 'rgba(201,163,106,0.48)' : 'var(--primary-color)'};color:${secondary ? '#b9a27d' : 'var(--primary-color)'};font-size:15px;letter-spacing:4px;text-align:center;box-shadow:0 4px 12px rgba(0,0,0,0.5);font-family:inherit;`;
      button.innerText = label;
      button.onclick = handler;
      actionsContainer.appendChild(button);
    };
    makeGardenButton('喝茶', () => openImperialGardenTeaPicker());
    makeGardenButton('四处走走', () => openImperialGardenWalkPicker());
    makeGardenButton('赏花宴', () => api.ui.toast('赏花宴待开发，尚未设宴'));

    const timeHint = document.createElement('div');
    timeHint.style.cssText = 'max-width:310px;color:#9d8d72;font-size:11px;line-height:1.8;letter-spacing:1px;text-align:center;margin-top:2px;';
    timeHint.innerText = `当前时辰：${hudTime?.innerText || '时间不详'} · 剧情会依时辰与人物行迹推演`;
    actionsContainer.appendChild(timeHint);
    switchView(vPalaceDetail);
    return;
  }
  
  // 查找住在这里的后妃
  const residents = selectedCharsData.filter(c => c.assignedPalace && c.assignedPalace.startsWith(pName));
  const residentMap = {}; // "正殿" -> Char
  residents.forEach(c => {
    const rName = c.assignedPalace.replace(pName, '');
    residentMap[rName] = c;
  });

  const roomCarousel = document.getElementById('room-carousel');
  roomCarousel.innerHTML = '';
  
  const rooms = pName === '内务府'
    ? [] // 内务府不显示殿宇卡片
    : ["正殿", "东偏殿", "西偏殿", "耳房", "庭院"];
  rooms.forEach((rName, idx) => {
    const char = residentMap[rName];
    const card = document.createElement('div');
    card.className = 'char-card' + (idx === 0 ? ' active-card' : '');
    card.dataset.rname = rName;
    
    let innerHtml = '';
    if (pName === '内务府' || rName === '内务府') {
      // 内部不需要展示卡片，由外部控制
    } else if (rName === "庭院") {
      // 庭院特殊处理，不显示空置，显示背景提示
      const courtyardBg = palaceDetails[pName].courtyardBgUrl;
      if (courtyardBg) {
        innerHtml = `
          <div style="color:var(--primary-color); font-size:14px; margin-bottom:12px; letter-spacing:4px;">庭院</div>
          <div class="card-avatar-wrap" style="height:260px;">
            <img class="card-avatar" src="${courtyardBg}" style="height:260px; border-radius:10px; object-fit:cover;">
          </div>
          <div style="color:#aaa; font-size:14px; margin-top:20px; letter-spacing:2px;">闲庭信步</div>
        `;
      } else {
        innerHtml = `
          <div style="color:var(--primary-color); font-size:14px; margin-bottom:12px; letter-spacing:4px;">庭院</div>
          <div class="card-avatar-wrap" style="height:260px; display:flex; align-items:center; justify-content:center; background:rgba(0,0,0,0.3); border-radius:10px; border:1px dashed var(--primary-color); cursor:pointer;" onclick="openCourtyardModal('${pName}')">
            <span style="color:var(--primary-color); font-size:14px; letter-spacing:2px;">+ 设为景致</span>
          </div>
          <div style="color:#aaa; font-size:14px; margin-top:20px; letter-spacing:2px;">未置景</div>
        `;
      }
    } else if (rName === '耳房') {
      const attendants = typeof getPalaceStaffResidents === 'function' ? getPalaceStaffResidents(pName, 'attendant') : [];
      const maids = typeof getPalaceStaffResidents === 'function' ? getPalaceStaffResidents(pName, 'maid') : [];
      const earBgs = palaceDetails[pName].earRoomBgUrls || {};
      const previewBg = earBgs.attendant || earBgs.maid || '';
      innerHtml = `
        <div style="color:var(--primary-color); font-size:14px; margin-bottom:12px; letter-spacing:4px;">耳房 · 多人居所</div>
        <div class="card-avatar-wrap" style="height:260px;display:flex;align-items:center;justify-content:center;border-radius:10px;overflow:hidden;${previewBg ? `background:url('${previewBg}') center/cover no-repeat;` : 'background:rgba(0,0,0,0.35);border:1px dashed rgba(201,163,106,0.5);'}">
          <div style="background:rgba(0,0,0,0.58);border:1px solid rgba(201,163,106,0.35);border-radius:12px;padding:14px 20px;text-align:center;color:#e7d2a8;line-height:1.9;">
            <div>侍从房 ${attendants.length} 人</div><div>宫女房 ${maids.length} 人</div>
          </div>
        </div>
        <div style="color:#aaa; font-size:12px; margin-top:16px; letter-spacing:2px;">两间多人耳房 · 随主迁居</div>`;
    } else if (char) {
      const avatarUrl = getCharacterPortraitUrl(char);
      const cfg = char.cardAvatarCfg || { scale: 100, x: 0, y: 0 };
      const transformStyle = `transform: translate(${cfg.x}px, ${cfg.y}px) scale(${cfg.scale / 100});`;
      const disciplineBadge = typeof getCharacterDisciplineBadge === 'function' ? getCharacterDisciplineBadge(char) : '';
      
      innerHtml = `
        <div style="color:var(--primary-color); font-size:14px; margin-bottom:12px; letter-spacing:4px;">${rName}</div>
        <div class="card-avatar-wrap" style="height:260px; overflow:hidden; border-radius:10px; background:transparent;">
          ${avatarUrl ? `<img class="card-avatar" src="${avatarUrl}" style="height:260px; width:100%; border-radius:10px; object-fit:cover; background:transparent; ${transformStyle}">` : '<div style="height:260px;display:flex;align-items:center;justify-content:center;border:1px dashed rgba(201,163,106,.4);border-radius:10px;color:#746653;font-size:13px;letter-spacing:3px;">暂无立绘</div>'}
        </div>
        <div class="card-name" style="font-size:22px; margin-top:16px;">${char.name}</div>
        <div style="color:#aaa; font-size:12px; margin-top:6px; letter-spacing:2px;">${char.assignedRank || ''}</div>
        ${disciplineBadge ? `<div style="color:#f0ae98;background:rgba(93,25,22,.78);border:1px solid rgba(202,119,96,.55);border-radius:11px;padding:4px 8px;font-size:10px;margin-top:8px;">${escHtml(disciplineBadge)}</div>` : ''}
      `;
    } else {
      innerHtml = `
        <div style="color:var(--primary-color); font-size:14px; margin-bottom:12px; letter-spacing:4px;">${rName}</div>
        <div class="card-avatar-wrap" style="height:260px; display:flex; align-items:center; justify-content:center; background:rgba(0,0,0,0.3); border-radius:10px; border:1px dashed #555;">
          <span style="color:#666; font-size:14px; letter-spacing:2px;">空置</span>
        </div>
      `;
    }
    card.innerHTML = innerHtml;
    roomCarousel.appendChild(card);
  });

  // 绑定滚动高亮
  roomCarousel.addEventListener('scroll', () => {
    const cards = roomCarousel.querySelectorAll('.char-card');
    const center = roomCarousel.scrollLeft + roomCarousel.clientWidth / 2;
    let closest = 0, minDiff = Infinity;
    cards.forEach((card, i) => {
      const diff = Math.abs(card.offsetLeft + card.offsetWidth / 2 - center);
      if (diff < minDiff) { minDiff = diff; closest = i; }
    });
    cards.forEach((card, i) => {
      if (i === closest) {
        card.classList.add('active-card');
        updatePalaceActions(pName, card.dataset.rname, residentMap[card.dataset.rname]);
      } else {
        card.classList.remove('active-card');
      }
    });
  });
  
  // 初始化动作
  const initRName = pName === '内务府' ? '内务府' : '正殿';
  updatePalaceActions(pName, initRName, residentMap[initRName]);
  
  switchView(vPalaceDetail);
}

function openQianQingBackgroundEditor() {
  currentDetailPalaceName = '乾清宫';
  pbTitle.innerText = '乾清宫 · 更换朝堂背景';
  pbPrompt.value = '真实画风，中国古代皇宫乾清宫朝堂内景，御座居中，丹墀肃穆，百官上朝之地，晨光，庄严华丽，无人物';
  pbImg.style.display = 'none';
  pbPlaceholder.style.display = 'block';
  pbLoader.style.display = 'none';
  setPbActionBtnsVisible(false);
  tempPbDataUrl = null;
  isCourtyardMode = false;
  pbModal.style.display = 'flex';
}

async function resetQianQingBackground() {
  const ok = await api.ui.confirm({ title: '恢复默认背景', message: '确定将乾清宫恢复为默认朝堂内景吗？' });
  if (!ok) return;
  if (!palaceDetails['乾清宫']) palaceDetails['乾清宫'] = { note: '' };
  palaceDetails['乾清宫'].bgUrl = QIANQING_DEFAULT_BG;
  await saveProgress({ palaceDetails });
  enterPalaceDetailView('乾清宫');
  api.ui.toast('乾清宫已恢复默认背景');
}

function renderHuaQingPalace() {
  const details = palaceDetails['华清宫'] || (palaceDetails['华清宫'] = {});
  if (!details.bgUrl) details.bgUrl = HUAQING_DEFAULT_BG;
  if (!details.description) details.description = HUAQING_DEFAULT_DESCRIPTION;
  if (!details.rules) details.rules = HUAQING_DEFAULT_RULES;
  document.getElementById('palace-detail-bg-layer').style.backgroundImage = `url('${details.bgUrl}')`;
  const roomCarousel = document.getElementById('room-carousel');
  roomCarousel.innerHTML = '';
  roomCarousel.style.display = 'none';
  const actions = document.getElementById('palace-actions');
  actions.innerHTML = '';
  actions.style.gap = '10px';

  const title = document.createElement('div');
  title.style.cssText = 'color:#f3dfb4;font-size:13px;letter-spacing:5px;text-shadow:0 2px 6px #000;margin-bottom:2px;';
  title.innerText = '汤泉暖雾 · 华清别苑';
  actions.appendChild(title);

  const row = document.createElement('div');
  row.style.cssText = 'display:flex;gap:10px;justify-content:center;align-items:center;';
  const buttonData = [
    ['召见', '<svg viewBox="0 0 24 24" width="21" height="21" fill="none" stroke="currentColor" stroke-width="1.5"><path d="M4 20c.8-4 3.1-6 8-6s7.2 2 8 6"/><circle cx="12" cy="7" r="4"/><path d="M18 4v5m-2.5-2.5h5"/></svg>', () => openHuaQingSummonPicker()],
    ['沐浴', '<svg viewBox="0 0 24 24" width="21" height="21" fill="none" stroke="currentColor" stroke-width="1.5"><path d="M3 12h18v2a7 7 0 0 1-7 7H10a7 7 0 0 1-7-7z"/><path d="M7 12V6a3 3 0 0 1 6 0"/><path d="M6 4c1-2 3-2 4 0"/></svg>', () => startHuaQingBath()],
    ['自定义', '<svg viewBox="0 0 24 24" width="21" height="21" fill="none" stroke="currentColor" stroke-width="1.5"><path d="M4 21v-9l8-7 8 7v9"/><path d="M8 21v-6h8v6M3 12h18"/><circle cx="12" cy="10" r="1"/></svg>', () => openHuaQingSettings()]
  ];
  buttonData.forEach(([label, icon, handler]) => {
    const button = document.createElement('button');
    button.style.cssText = 'width:82px;height:58px;border-radius:17px;background:linear-gradient(180deg,rgba(29,22,17,.76),rgba(8,7,6,.76));border:1px solid rgba(224,188,119,.7);color:#e9cf9a;display:flex;flex-direction:column;align-items:center;justify-content:center;gap:3px;font-family:inherit;font-size:11px;letter-spacing:2px;box-shadow:0 5px 16px rgba(0,0,0,.45);';
    button.innerHTML = `${icon}<span>${label}</span>`;
    button.onclick = handler;
    row.appendChild(button);
  });
  actions.appendChild(row);

  const bgRow = document.createElement('div');
  bgRow.style.cssText = 'display:flex;gap:8px;justify-content:center;';
  bgRow.innerHTML = '<button id="huaqing-diy-bg" style="padding:7px 13px;border-radius:15px;background:rgba(0,0,0,.48);border:1px solid rgba(201,163,106,.45);color:#cbb083;font-family:inherit;font-size:11px;">DIY背景</button><button id="huaqing-reset-bg" style="padding:7px 13px;border-radius:15px;background:rgba(0,0,0,.48);border:1px solid rgba(201,163,106,.45);color:#cbb083;font-family:inherit;font-size:11px;">恢复默认</button>';
  actions.appendChild(bgRow);
  bgRow.querySelector('#huaqing-diy-bg').onclick = () => openHuaQingBackgroundEditor();
  bgRow.querySelector('#huaqing-reset-bg').onclick = () => resetHuaQingBackground();
}

function openHuaQingBackgroundEditor() {
  currentDetailPalaceName = '华清宫';
  pbTitle.innerText = '华清宫 · DIY温泉内景';
  pbPrompt.value = '真实画风，中国古代皇家温泉行宫内景，赤柱金檐，玉石汤池，暖雾与灯影，雕花帷幔，华丽幽静，无人物';
  pbImg.style.display = 'none';
  pbPlaceholder.style.display = 'block';
  pbLoader.style.display = 'none';
  setPbActionBtnsVisible(false);
  tempPbDataUrl = null;
  isCourtyardMode = false;
  pbModal.style.display = 'flex';
}

async function resetHuaQingBackground() {
  const ok = await api.ui.confirm({ title: '恢复默认背景', message: '确定恢复华清宫默认温泉内景吗？' });
  if (!ok) return;
  palaceDetails['华清宫'].bgUrl = HUAQING_DEFAULT_BG;
  await saveProgress({ palaceDetails });
  renderHuaQingPalace();
  api.ui.toast('华清宫已恢复默认背景');
}

function openColdPalaceBackgroundEditor() {
  currentDetailPalaceName = '冷宫';
  pbTitle.innerText = '冷宫 · 修改背景';
  pbPrompt.value = '真实画风，中国古代皇宫冷宫内景，院墙斑驳，旧殿寂静，荒草与枯枝，昏暗天光，清冷压抑，无人物';
  pbImg.style.display = 'none';
  pbPlaceholder.style.display = 'block';
  pbLoader.style.display = 'none';
  setPbActionBtnsVisible(false);
  tempPbDataUrl = null;
  isCourtyardMode = false;
  pbModal.style.display = 'flex';
}

async function resetColdPalaceBackground() {
  const ok = await api.ui.confirm({ title: '恢复默认背景', message: '确定恢复冷宫默认内景吗？' });
  if (!ok) return;
  palaceDetails['冷宫'].bgUrl = COLD_PALACE_DEFAULT_BG;
  await saveProgress({ palaceDetails });
  renderColdPalace();
  api.ui.toast('冷宫已恢复默认背景');
}

function enterColdPalaceInteraction(char, mode) {
  window._indoorSceneBgOverride = palaceDetails['冷宫']?.bgUrl || COLD_PALACE_DEFAULT_BG;
  openIndoorView('冷宫', '幽院', char);
  setTimeout(() => document.getElementById(mode === 'intimate' ? 'btn-indoor-intimate' : 'btn-xly-chat')?.click(), 180);
}

function renderColdPalaceActions(char) {
  const actions = document.getElementById('palace-actions');
  actions.innerHTML = '';
  const title = document.createElement('div');
  title.style.cssText = 'color:#e9d4aa;font-size:13px;letter-spacing:3px;text-shadow:0 2px 5px #000;';
  title.innerText = `探望 · ${char.name}`;
  actions.appendChild(title);
  const row = document.createElement('div');
  row.style.cssText = 'display:flex;flex-wrap:wrap;gap:8px;justify-content:center;max-width:330px;';
  [['闲聊', () => enterColdPalaceInteraction(char, 'chat')], ['临幸', () => enterColdPalaceInteraction(char, 'intimate')], ['管理', () => typeof openPalaceDisciplineManagement === 'function' ? openPalaceDisciplineManagement(char) : api.ui.toast('管理功能尚未载入')], ['记事', () => openCharRecords(char)]].forEach(([label, handler]) => {
    const button = document.createElement('button');
    button.innerText = label;
    button.style.cssText = 'min-width:72px;padding:10px 13px;border-radius:18px;background:rgba(8,7,6,.65);border:1px solid rgba(201,163,106,.55);color:#e2c997;font-family:inherit;letter-spacing:2px;';
    button.onclick = handler;
    row.appendChild(button);
  });
  actions.appendChild(row);
  appendColdPalaceBackgroundButtons(actions);
}

function appendColdPalaceBackgroundButtons(actions) {
  const bgRow = document.createElement('div');
  bgRow.style.cssText = 'display:flex;gap:8px;justify-content:center;margin-top:4px;';
  bgRow.innerHTML = '<button id="cold-diy-bg" style="padding:7px 13px;border-radius:15px;background:rgba(0,0,0,.55);border:1px solid rgba(201,163,106,.45);color:#cbb083;font-family:inherit;">修改背景</button><button id="cold-reset-bg" style="padding:7px 13px;border-radius:15px;background:rgba(0,0,0,.55);border:1px solid rgba(201,163,106,.45);color:#cbb083;font-family:inherit;">使用默认</button>';
  actions.appendChild(bgRow);
  bgRow.querySelector('#cold-diy-bg').onclick = openColdPalaceBackgroundEditor;
  bgRow.querySelector('#cold-reset-bg').onclick = resetColdPalaceBackground;
}

function renderColdPalace() {
  const details = palaceDetails['冷宫'] || (palaceDetails['冷宫'] = { note: '幽禁失宠之人', bgUrl: COLD_PALACE_DEFAULT_BG });
  if (!details.bgUrl) details.bgUrl = COLD_PALACE_DEFAULT_BG;
  document.getElementById('palace-detail-bg-layer').style.backgroundImage = `url('${details.bgUrl}')`;
  const roomCarousel = document.getElementById('room-carousel');
  const actions = document.getElementById('palace-actions');
  roomCarousel.style.display = 'flex';
  roomCarousel.innerHTML = '';
  actions.innerHTML = '';
  const residents = selectedCharsData.filter(char => typeof isCharacterInColdPalace === 'function' ? isCharacterInColdPalace(char) : String(char.assignedPalace || '').startsWith('冷宫'));
  if (!residents.length) {
    roomCarousel.style.display = 'none';
    actions.innerHTML = '<div style="color:#aaa;font-size:13px;letter-spacing:3px;text-shadow:0 2px 5px #000;">宫门深锁 · 暂无人居</div>';
    appendColdPalaceBackgroundButtons(actions);
    return;
  }
  residents.forEach((char, index) => {
    const cfg = char.cardAvatarCfg || { scale:100, x:0, y:0 };
    const portrait = getCharacterPortraitUrl(char);
    const card = document.createElement('button');
    card.className = `char-card${index === 0 ? ' active-card' : ''}`;
    card.style.cssText = 'flex:0 0 72%;max-width:270px;height:390px;position:relative;overflow:hidden;border-radius:17px;border:1px solid rgba(201,163,106,.48);background:rgba(12,10,9,.72);scroll-snap-align:center;color:#e5d0a3;font-family:inherit;';
    card.innerHTML = `${portrait ? `<img src="${portrait}" style="position:absolute;inset:0;width:100%;height:100%;object-fit:cover;object-position:top center;transform:translate(${cfg.x}px,${cfg.y}px) scale(${cfg.scale/100});transform-origin:top center;">` : '<div style="position:absolute;inset:0;display:flex;align-items:center;justify-content:center;color:#71685d;letter-spacing:3px;">暂无立绘</div>'}<div style="position:absolute;inset:auto 0 0;padding:45px 14px 16px;background:linear-gradient(transparent,rgba(5,4,3,.96));text-align:left;"><div style="font-size:21px;letter-spacing:4px;color:#eed6a4;">${escHtml(char.name)}</div><div style="font-size:11px;color:#a28d6a;margin-top:6px;">冷宫 · 无位份</div></div>`;
    card.onclick = () => {
      roomCarousel.querySelectorAll('.char-card').forEach(item => item.classList.remove('active-card'));
      card.classList.add('active-card');
      renderColdPalaceActions(char);
    };
    roomCarousel.appendChild(card);
  });
  renderColdPalaceActions(residents[0]);
}

function openHuaQingSettings() {
  document.getElementById('huaqing-settings-modal')?.remove();
  const details = palaceDetails['华清宫'];
  const modal = document.createElement('div');
  modal.id = 'huaqing-settings-modal';
  modal.style.cssText = 'position:fixed;inset:0;z-index:100600;background:rgba(5,4,3,.88);backdrop-filter:blur(12px);display:flex;align-items:flex-end;justify-content:center;font-family:"STZhongsong","STSong",serif;';
  modal.innerHTML = `<div style="width:100%;max-width:440px;max-height:88vh;overflow-y:auto;background:linear-gradient(180deg,#241910,#100c08);border:1px solid rgba(201,163,106,.55);border-radius:24px 24px 0 0;padding:20px 16px calc(var(--safe-bottom) + 18px);"><div style="color:#efd8a6;text-align:center;font-size:19px;letter-spacing:5px;">华清宫设</div><div style="color:#8f7a5c;text-align:center;font-size:11px;margin:8px 0 16px;">描述与规则会随每次华清宫剧情发送给AI</div><label style="color:#c6aa7b;font-size:12px;">行宫描述</label><textarea id="huaqing-description" maxlength="300" style="width:100%;height:115px;margin:7px 0 14px;padding:10px;background:rgba(0,0,0,.42);border:1px solid #665137;border-radius:9px;color:#e2d2b5;font-family:inherit;line-height:1.65;resize:vertical;">${escHtml(details.description)}</textarea><label style="color:#c6aa7b;font-size:12px;">行宫规则</label><textarea id="huaqing-rules" maxlength="300" style="width:100%;height:130px;margin:7px 0 16px;padding:10px;background:rgba(0,0,0,.42);border:1px solid #665137;border-radius:9px;color:#e2d2b5;font-family:inherit;line-height:1.65;resize:vertical;">${escHtml(details.rules)}</textarea><div style="display:flex;gap:10px;"><button id="huaqing-settings-cancel" style="flex:1;padding:11px;border-radius:20px;background:transparent;border:1px solid #5b5144;color:#8d8374;font-family:inherit;">取消</button><button id="huaqing-settings-save" style="flex:2;padding:11px;border-radius:20px;background:#c9a36a;border:none;color:#15100b;font-family:inherit;font-weight:bold;">保存宫设</button></div></div>`;
  document.body.appendChild(modal);
  modal.onclick = event => { if (event.target === modal) modal.remove(); };
  modal.querySelector('#huaqing-settings-cancel').onclick = () => modal.remove();
  modal.querySelector('#huaqing-settings-save').onclick = async () => {
    details.description = modal.querySelector('#huaqing-description').value.trim() || HUAQING_DEFAULT_DESCRIPTION;
    details.rules = modal.querySelector('#huaqing-rules').value.trim() || HUAQING_DEFAULT_RULES;
    await saveProgress({ palaceDetails });
    modal.remove();
    api.ui.toast('华清宫描述与规则已保存');
  };
}

function updatePalaceActions(pName, rName, char) {
  const actionsContainer = document.getElementById('palace-actions');
  actionsContainer.innerHTML = '';
  
  const btnStyle = "width:200px; padding:12px; border-radius:24px; background:rgba(0,0,0,0.5); border:1px solid var(--primary-color); color:var(--primary-color); font-size:15px; letter-spacing:4px; text-align:center; box-shadow:0 4px 12px rgba(0,0,0,0.5); font-family:inherit;";
  
  if (pName === '内务府' || rName === '内务府') {
    const btnHuizhi = document.createElement('button');
    btnHuizhi.style.cssText = btnStyle;
    btnHuizhi.innerText = "绘制台";
    btnHuizhi.onclick = () => openHuizhiTai();
    actionsContainer.appendChild(btnHuizhi);

    const btnMm = document.createElement('button');
    btnMm.style.cssText = btnStyle;
    btnMm.innerText = "查阅众生相";
    btnMm.onclick = () => openMemoryManage();
    actionsContainer.appendChild(btnMm);

    const btnWb = document.createElement('button');
    btnWb.style.cssText = btnStyle.replace('rgba(0,0,0,0.5)', 'rgba(20,20,20,0.8)');
    btnWb.innerText = "全局世界书（含预设）";
    btnWb.onclick = () => {
      document.getElementById('btn-global-worldbook').click();
    };
    actionsContainer.appendChild(btnWb);

    const btnCharWb = document.createElement('button');
    btnCharWb.style.cssText = btnStyle.replace('rgba(0,0,0,0.5)', 'rgba(20,20,20,0.8)');
    btnCharWb.innerText = "人物世界书（可新增）";
    btnCharWb.onclick = () => {
      if (typeof window.openCharExtraWbEditor === 'function') window.openCharExtraWbEditor();
      else document.getElementById('btn-char-worldbook')?.click();
    };
    actionsContainer.appendChild(btnCharWb);

    const btnDev = document.createElement('button');
    btnDev.style.cssText = btnStyle.replace('rgba(0,0,0,0.5)', 'rgba(20,20,20,0.8)');
    btnDev.innerText = "置度所";
    btnDev.onclick = () => {
      if (window.openDevToolsModal) window.openDevToolsModal();
    };
    actionsContainer.appendChild(btnDev);

    const btnScenario = document.createElement('button');
    btnScenario.style.cssText = btnStyle.replace('rgba(0,0,0,0.5)', 'rgba(20,20,20,0.8)');
    btnScenario.innerText = "名臣录";
    btnScenario.onclick = () => openMingChenLu();
    actionsContainer.appendChild(btnScenario);

    const btnCustomStudio = document.createElement('button');
    btnCustomStudio.style.cssText = btnStyle.replace('rgba(0,0,0,0.5)', 'rgba(20,20,20,0.8)');
    btnCustomStudio.innerText = "自设台";
    btnCustomStudio.onclick = () => openCustomStudio();
    actionsContainer.appendChild(btnCustomStudio);

    const btnRelation = document.createElement('button');
    btnRelation.style.cssText = btnStyle.replace('rgba(0,0,0,0.5)', 'rgba(20,20,20,0.8)');
    btnRelation.innerText = "关系图谱";
    btnRelation.onclick = () => openRelationGraph();
    actionsContainer.appendChild(btnRelation);
  } else if (rName === "庭院") {
    const btnStroll = document.createElement('button');
    btnStroll.style.cssText = btnStyle;
    btnStroll.innerText = "随便走走";
    btnStroll.onclick = () => api.ui.toast("庭院深深，花影摇曳...(功能开发中)");
    actionsContainer.appendChild(btnStroll);
    
    // 如果庭院已有图，提供重置选项
    if (palaceDetails[pName]?.courtyardBgUrl) {
      const btnRedraw = document.createElement('button');
      btnRedraw.style.cssText = btnStyle.replace("var(--primary-color)", "#aaa").replace("var(--primary-color)", "#666");
      btnRedraw.innerText = "重新布景";
      btnRedraw.onclick = () => openCourtyardModal(pName);
      actionsContainer.appendChild(btnRedraw);
    }
  } else if (rName === '耳房') {
    const earBgs = palaceDetails[pName]?.earRoomBgUrls || {};
    const makeEarButton = (label, handler, secondary = false) => {
      const button = document.createElement('button');
      button.style.cssText = secondary ? btnStyle.replace('rgba(0,0,0,0.5)', 'rgba(20,20,20,0.8)') : btnStyle;
      button.innerText = label;
      button.onclick = handler;
      actionsContainer.appendChild(button);
    };
    makeEarButton(`拜访侍从${typeof getPalaceStaffResidents === 'function' ? `（${getPalaceStaffResidents(pName, 'attendant').length}）` : ''}`, () => visitPalaceStaff(pName, 'attendant'));
    makeEarButton(`拜访宫女${typeof getPalaceStaffResidents === 'function' ? `（${getPalaceStaffResidents(pName, 'maid').length}）` : ''}`, () => visitPalaceStaff(pName, 'maid'));
    makeEarButton(earBgs.attendant ? '更换侍从房背景' : '设定侍从房背景', () => openEarRoomBackgroundEditor(pName, 'attendant'), true);
    makeEarButton(earBgs.maid ? '更换宫女房背景' : '设定宫女房背景', () => openEarRoomBackgroundEditor(pName, 'maid'), true);
  } else if (char) {
    const btnVisit = document.createElement('button');
    btnVisit.style.cssText = btnStyle;
    btnVisit.innerText = `摆驾入内`;
    btnVisit.onclick = () => openIndoorView(pName, rName, char);
    actionsContainer.appendChild(btnVisit);

    if (typeof isCharacterUnavailableForActivity === 'function' && isCharacterUnavailableForActivity(char)) {
      const stateHint = document.createElement('div');
      stateHint.style.cssText = 'max-width:300px;color:#d29a84;font-size:11px;line-height:1.7;text-align:center;letter-spacing:1px;';
      stateHint.innerText = `${getCharacterDisciplineBadge(char)}：仅能亲临住所闲聊、临幸、管理或查看记事，不能参与其他宫廷活动。`;
      actionsContainer.appendChild(stateHint);
      return;
    }
    
    const btnEavesdrop = document.createElement('button');
    btnEavesdrop.style.cssText = btnStyle.replace("rgba(0,0,0,0.5)", "rgba(20,20,20,0.8)");
    btnEavesdrop.innerText = "暗中探听";
    btnEavesdrop.onclick = () => typeof openPalaceEavesdrop === 'function' ? openPalaceEavesdrop(pName, char) : api.ui.toast('探听功能尚未就绪');
    actionsContainer.appendChild(btnEavesdrop);

    const btnAiStory = document.createElement('button');
    btnAiStory.style.cssText = btnStyle.replace("rgba(0,0,0,0.5)", "rgba(20,20,20,0.8)");
    btnAiStory.innerText = "窥见一幕";
    btnAiStory.onclick = () => startAiStory(pName, rName, char);
    actionsContainer.appendChild(btnAiStory);

    const topRank = rankData?.[0]?.rank;
    if (pName === '坤宁宫' && rName === '正殿' && char.ancientRole === '后妃' && char.assignedRank === topRank) {
      const btnAudience = document.createElement('button');
      btnAudience.id = 'btn-morning-audience';
      btnAudience.style.cssText = btnStyle.replace('rgba(0,0,0,0.5)', 'rgba(64,34,22,0.72)');
      btnAudience.innerText = '晨昏定省';
      btnAudience.onclick = () => promptMorningAudience();
      actionsContainer.appendChild(btnAudience);
    }
  } else {
    const btnEmpty = document.createElement('div');
    btnEmpty.style.cssText = "color:#666; font-size:13px; letter-spacing:2px; margin-top:20px;";
    btnEmpty.innerText = "殿内空无一人";
    actionsContainer.appendChild(btnEmpty);
  }
}

// 庭院绘景复用 pbModal
let isCourtyardMode = false;
function openCourtyardModal(pName) {
  isCourtyardMode = true;
  currentDetailPalaceName = pName;
  pbTitle.innerText = `${pName}庭院 · 绘景`;
  pbPrompt.value = `真实画风，古代宫殿庭院，${pName}内院，花草，唯美，无人物`;
  pbImg.style.display = 'none';
  pbPlaceholder.style.display = 'block';
  pbLoader.style.display = 'none';
  btnPbConfirm.style.display = 'none';
  tempPbDataUrl = null;
  pbModal.style.display = 'flex';
}

function openEarRoomBackgroundEditor(pName, npcType) {
  currentEarRoomPalaceName = pName;
  currentEarRoomType = npcType;
  currentDetailPalaceName = '__EAR_ROOM__';
  const roomLabel = npcType === 'maid' ? '宫女房' : '侍从房';
  pbTitle.innerText = `${pName}耳房 · ${roomLabel}`;
  pbPrompt.value = `真实画风，中国古代后宫${pName}耳房${roomLabel}内景，多人合住，整齐床铺、衣箱与日常器物，古朴生活气息，暖色烛光，无人物`;
  pbImg.style.display = 'none';
  pbPlaceholder.style.display = 'block';
  pbLoader.style.display = 'none';
  setPbActionBtnsVisible(false);
  tempPbDataUrl = null;
  isCourtyardMode = false;
  pbModal.style.display = 'flex';
}

function visitPalaceStaff(pName, npcType) {
  const residents = typeof getPalaceStaffResidents === 'function' ? getPalaceStaffResidents(pName, npcType) : [];
  if (!residents.length) {
    api.ui.toast(npcType === 'maid' ? '这座宫殿尚无宫女入住' : '这座宫殿尚无侍从入住');
    return;
  }
  const bgUrl = palaceDetails[pName]?.earRoomBgUrls?.[npcType];
  if (!bgUrl) {
    window._pendingEarRoomVisit = npcType;
    api.ui.toast('请先为这间多人耳房设定背景图');
    openEarRoomBackgroundEditor(pName, npcType);
    return;
  }
  openPalaceStaffList(pName, npcType);
}

function openPalaceStaffList(pName, npcType) {
  document.getElementById('palace-staff-list-modal')?.remove();
  const residents = typeof getPalaceStaffResidents === 'function' ? getPalaceStaffResidents(pName, npcType) : [];
  const modal = document.createElement('div');
  modal.id = 'palace-staff-list-modal';
  const roomLabel = npcType === 'maid' ? '宫女房' : '侍从房';
  const bgUrl = palaceDetails[pName]?.earRoomBgUrls?.[npcType] || '';
  modal.style.cssText = `position:fixed;inset:0;z-index:100300;display:flex;flex-direction:column;padding-top:var(--safe-top);background:linear-gradient(rgba(10,7,5,0.78),rgba(10,7,5,0.9)),url('${bgUrl}') center/cover no-repeat;font-family:'STZhongsong','STSong',serif;`;
  modal.innerHTML = `
    <div style="height:54px;display:flex;align-items:center;justify-content:space-between;padding:0 16px;border-bottom:1px solid rgba(201,163,106,0.28);background:rgba(15,10,7,0.62);">
      <button id="palace-staff-close" style="background:transparent;border:none;color:#aaa;font-family:inherit;font-size:15px;">‹ 返回耳房</button>
      <div style="color:#eed8aa;font-size:17px;letter-spacing:4px;">${escHtml(pName)} · ${roomLabel}</div><div style="width:72px;"></div>
    </div>
    <div style="padding:12px 16px;color:#9e8868;font-size:12px;line-height:1.7;border-bottom:1px solid rgba(201,163,106,0.12);">本房共住${residents.length}人。对话与宠幸会把所有同屋人的在场反应一并交给剧情推演。</div>
    <div style="flex:1;overflow-y:auto;padding:14px 16px calc(var(--safe-bottom) + 20px);display:flex;flex-direction:column;gap:10px;">${residents.map(npc => `
      <button data-staff-id="${escHtml(npc.id)}" style="display:flex;align-items:center;gap:12px;text-align:left;background:linear-gradient(135deg,rgba(59,43,27,0.88),rgba(23,17,12,0.9));border:1px solid rgba(201,163,106,0.34);border-radius:12px;padding:13px;color:#eee;font-family:inherit;">
        <div aria-hidden="true" style="width:8px;height:8px;border-radius:50%;flex-shrink:0;background:#c9a36a;box-shadow:0 0 10px rgba(201,163,106,0.65);"></div>
        <div style="flex:1;"><div style="font-size:15px;color:#f0ddb5;letter-spacing:2px;">${escHtml(npc.name)}</div><div style="font-size:11px;color:#a38b67;margin-top:5px;">${escHtml(npc.rosterPersonality || '性格未定')} · ${escHtml(npc.rosterMood || '状态未定')} · 忠诚度 ${escHtml(npc.loyalty ?? 0)}</div></div><span style="color:#b89a6b;">›</span>
      </button>`).join('')}</div>`;
  document.body.appendChild(modal);
  modal.querySelector('#palace-staff-close').onclick = () => modal.remove();
  modal.querySelectorAll('[data-staff-id]').forEach(button => button.onclick = () => {
    const npc = residents.find(item => item.id === button.dataset.staffId);
    if (npc) openPalaceStaffOptions(pName, npcType, npc);
  });
}

function openPalaceStaffOptions(pName, npcType, npc) {
  document.getElementById('palace-staff-options-modal')?.remove();
  const modal = document.createElement('div');
  modal.id = 'palace-staff-options-modal';
  modal.style.cssText = 'position:fixed;inset:0;z-index:100400;background:rgba(0,0,0,0.72);display:flex;align-items:flex-end;justify-content:center;font-family:"STZhongsong","STSong",serif;';
  modal.innerHTML = `<div style="width:100%;max-width:430px;background:#1b1510;border:1px solid rgba(201,163,106,0.45);border-radius:20px 20px 0 0;padding:20px 16px calc(var(--safe-bottom) + 18px);display:flex;flex-direction:column;gap:10px;"><div style="color:#efd9ad;text-align:center;font-size:18px;letter-spacing:4px;margin-bottom:4px;">${escHtml(npc.name)}</div>${['对话','查看','宠幸'].map(action => `<button data-staff-action="${action}" style="padding:12px;border-radius:22px;background:rgba(201,163,106,0.12);border:1px solid rgba(201,163,106,0.42);color:#e5cb98;font-family:inherit;font-size:14px;letter-spacing:3px;">${action}</button>`).join('')}<button id="staff-options-cancel" style="padding:10px;background:transparent;border:none;color:#777;font-family:inherit;">取消</button></div>`;
  document.body.appendChild(modal);
  modal.onclick = event => { if (event.target === modal) modal.remove(); };
  modal.querySelector('#staff-options-cancel').onclick = () => modal.remove();
  modal.querySelectorAll('[data-staff-action]').forEach(button => button.onclick = () => {
    const action = button.dataset.staffAction;
    modal.remove();
    if (action === '查看') {
      if (typeof openNpcMemoryFromStaff === 'function') openNpcMemoryFromStaff(npc);
    } else if (typeof startPalaceStaffInteraction === 'function') {
      document.getElementById('palace-staff-list-modal')?.remove();
      startPalaceStaffInteraction(pName, npcType, npc, action === '宠幸' ? 'intimate' : 'chat');
    }
  });
}

// 辅助函数：把配置了滤镜的图片画到 canvas 上并导出为新图片
function bakeFilterToDataUrl(imgEl) {
  const canvas = document.createElement('canvas');
  const w = imgEl.naturalWidth || imgEl.width;
  const h = imgEl.naturalHeight || imgEl.height;
  canvas.width = w;
  canvas.height = h;
  const ctx = canvas.getContext('2d');
  
  // Canvas 原生 filter 不支持 url(#svg-filter)，所以这里需要手动进行像素级 RGB 映射
  // 1. 先用原生 filter 烤出亮度/对比度
  ctx.filter = `brightness(${pbBrightness.value}%) contrast(${pbContrast.value}%)`;
  ctx.drawImage(imgEl, 0, 0, w, h);
  
  // 2. 再手动读取 ImageData 做 RGB 乘法映射
  const rv = pbR.value / 100;
  const gv = pbG.value / 100;
  const bv = pbB.value / 100;
  
  if (rv !== 1 || gv !== 1 || bv !== 1) {
    const imgData = ctx.getImageData(0, 0, w, h);
    const data = imgData.data;
    for (let i = 0; i < data.length; i += 4) {
      data[i] = Math.min(255, data[i] * rv);
      data[i+1] = Math.min(255, data[i+1] * gv);
      data[i+2] = Math.min(255, data[i+2] * bv);
    }
    ctx.putImageData(imgData, 0, 0);
  }
  
  return canvas.toDataURL('image/jpeg', 0.9);
}

// 下载按钮：把当前预览图（含滤镜）保存到手机相册
document.getElementById('btn-pb-download').addEventListener('click', async () => {
  if (!tempPbDataUrl) return;
  const finalDataUrl = bakeFilterToDataUrl(pbImg);
  try {
    await api.media.save({ dataUrl: finalDataUrl, type: 'image' });
    api.ui.toast('图片已保存到手机相册');
  } catch(e) {
    // 降级：用 <a> 触发浏览器下载
    try {
      const a = document.createElement('a');
      a.href = finalDataUrl;
      a.download = `故梦辞背景_${Date.now()}.jpg`;
      a.click();
      api.ui.toast('图片已开始下载');
    } catch(e2) {
      api.ui.toast('下载失败，请截图保存');
    }
  }
});

document.getElementById('btn-pb-confirm').addEventListener('click', async () => {
  if (!tempPbDataUrl) return;
  
  // 把当前在预览框调好的滤镜“烤”死进图片里
  const finalDataUrl = bakeFilterToDataUrl(pbImg);
  
  if (currentDetailPalaceName === '__MAP__') {
    currentMapDataUrl = finalDataUrl;
    memoryBg.src = finalDataUrl;
    await saveProgress({ mapUrl: currentMapDataUrl });
    api.ui.toast("皇城绘卷已更新");
    pbModal.style.display = 'none';
  } else if (currentDetailPalaceName === '__INDOOR__') {
    window.currentIndoorChar.indoorBgUrl = finalDataUrl;
    await saveProgress({ characters: selectedCharsData });
    document.getElementById('indoor-bg-layer').style.backgroundImage = `url('${finalDataUrl}')`;
    pbModal.style.display = 'none';
    // 如果是沐浴流程触发的绘景，绘景完成后继续进入沐浴
    if (window._pendingBathAfterBg) {
      window._pendingBathAfterBg = false;
      setTimeout(() => enterXlyBathView(), 200);
      return;
    }
  } else if (currentDetailPalaceName === '__EAR_ROOM__') {
    if (!palaceDetails[currentEarRoomPalaceName]) palaceDetails[currentEarRoomPalaceName] = { note: '' };
    if (!palaceDetails[currentEarRoomPalaceName].earRoomBgUrls) palaceDetails[currentEarRoomPalaceName].earRoomBgUrls = { attendant: '', maid: '' };
    palaceDetails[currentEarRoomPalaceName].earRoomBgUrls[currentEarRoomType] = finalDataUrl;
    await saveProgress({ palaceDetails });
    pbModal.style.display = 'none';
    const pendingType = window._pendingEarRoomVisit;
    window._pendingEarRoomVisit = '';
    if (pendingType && typeof openPalaceStaffList === 'function') openPalaceStaffList(currentEarRoomPalaceName, pendingType);
    else enterPalaceDetailView(currentEarRoomPalaceName);
  } else if (isCourtyardMode) {
    palaceDetails[currentDetailPalaceName].courtyardBgUrl = finalDataUrl;
    await saveProgress({ palaceDetails });
    pbModal.style.display = 'none';
    isCourtyardMode = false;
    enterPalaceDetailView(currentDetailPalaceName);
  } else if (currentDetailPalaceName === '东六宫' || currentDetailPalaceName === '西六宫') {
    palaceDetails[currentDetailPalaceName].bgUrl = finalDataUrl;
    await saveProgress({ palaceDetails });
    pbModal.style.display = 'none';
    openSixPalacesView(currentDetailPalaceName);
  } else {
    palaceDetails[currentDetailPalaceName].bgUrl = finalDataUrl;
    await saveProgress({ palaceDetails });
    pbModal.style.display = 'none';
    enterPalaceDetailView(currentDetailPalaceName);
  }
});

// === 10. Indoor View (摆驾入内) ===
const vIndoor = document.getElementById('view-indoor');

// 立绘微调弹窗
const storyAvatarAdjModal = document.getElementById('story-avatar-adj-modal');
const rangeAdjScale = document.getElementById('adj-scale');
const rangeAdjX = document.getElementById('adj-x');
const rangeAdjY = document.getElementById('adj-y');
let currentAdjChar = null;

document.getElementById('btn-story-avatar-adj').addEventListener('click', () => {
  if (!storyContext || !storyContext.history || storyContext.history.length === 0) {
    api.ui.toast("当前无角色在场"); return;
  }
  // 以屏幕上真实正在显示的人物为准，不能用本轮段落下标反推；多轮剧情后
  // currentSegmentIdx 会重新计数，而 history 不会，旧算法会误改主角并造成切回后“恢复原大小”。
  let targetName = window.currentStoryDisplayChar?.name || storyCardName.innerText || null;
  if (!targetName && storyContext.mainChar) targetName = storyContext.mainChar.name;
  
  if (!targetName) { api.ui.toast("当前无主要角色可微调"); return; }
  
  window.currentAdjChar = typeof getStoryCharacterByName === 'function'
    ? getStoryCharacterByName(targetName)
    : selectedCharsData.find(c => c.name === targetName);
  if (!window.currentAdjChar) return;
  
  if (!window.currentAdjChar.storyAvatarCfg) {
    window.currentAdjChar.storyAvatarCfg = { scale: 100, x: 0, y: 0 };
  }
  
  rangeAdjScale.value = window.currentAdjChar.storyAvatarCfg.scale;
  rangeAdjX.value = window.currentAdjChar.storyAvatarCfg.x;
  rangeAdjY.value = window.currentAdjChar.storyAvatarCfg.y;
  
  // 隐藏文字框以便观察
  document.getElementById('story-text-wrap').style.opacity = '0';
  document.getElementById('story-controls').style.opacity = '0';
  
  storyAvatarAdjModal.style.display = 'flex';
});

function updateRealTimeAvatarAdj() {
  if (!window.currentAdjChar) return;
  const s = rangeAdjScale.value / 100;
  const x = rangeAdjX.value;
  const y = rangeAdjY.value;
  
  if (storyAvatarAdjModal.dataset.fromDev === 'true') {
    const tempImg = document.getElementById('temp-avatar-preview-img');
    if (tempImg) tempImg.style.transform = `translate(${x}px, ${y}px) scale(${s})`;
  } else if (storyAvatarAdjModal.dataset.fromIndoor === 'true') {
    const indoorImg = document.getElementById('indoor-avatar-img');
    if (indoorImg) indoorImg.style.transform = `translate(${x}px, ${y}px) scale(${s})`;
  } else {
    storyCardImg.style.transform = `translate(${x}px, ${y}px) scale(${s})`;
  }
}

rangeAdjScale.addEventListener('input', updateRealTimeAvatarAdj);
rangeAdjX.addEventListener('input', updateRealTimeAvatarAdj);
rangeAdjY.addEventListener('input', updateRealTimeAvatarAdj);

document.getElementById('btn-close-avatar-adj').addEventListener('click', () => {
  storyAvatarAdjModal.style.display = 'none';
  
  if (storyAvatarAdjModal.dataset.fromDev === 'true') {
    const overlay = document.getElementById('temp-avatar-preview-overlay');
    if (overlay) overlay.remove();
    document.getElementById('dev-tools-modal').style.display = 'flex';
    delete storyAvatarAdjModal.dataset.fromDev;
  } else if (storyAvatarAdjModal.dataset.fromIndoor === 'true') {
    delete storyAvatarAdjModal.dataset.fromIndoor;
    if (window.currentAdjChar && window.currentAdjChar.storyAvatarCfg) {
      const cfg = window.currentAdjChar.storyAvatarCfg;
      document.getElementById('indoor-avatar-img').style.transform = `translate(${cfg.x}px, ${cfg.y}px) scale(${cfg.scale / 100})`;
    } else {
      document.getElementById('indoor-avatar-img').style.transform = 'translate(0px, 0px) scale(1)';
    }
  } else {
    document.getElementById('story-text-wrap').style.opacity = '1';
    document.getElementById('story-controls').style.opacity = '1';
    
    if (window.currentAdjChar && window.currentAdjChar.storyAvatarCfg) {
      const cfg = window.currentAdjChar.storyAvatarCfg;
      storyCardImg.style.transform = `translate(${cfg.x}px, ${cfg.y}px) scale(${cfg.scale / 100})`;
    } else {
      storyCardImg.style.transform = 'translate(0px, 0px) scale(1)';
    }
  }
});

document.getElementById('btn-reset-avatar-adj').addEventListener('click', () => {
  rangeAdjScale.value = 100;
  rangeAdjX.value = 0;
  rangeAdjY.value = 0;
  updateRealTimeAvatarAdj();
});

document.getElementById('btn-save-avatar-adj').addEventListener('click', async () => {
  if (!window.currentAdjChar) return;
  const nextCfg = {
    scale: parseInt(rangeAdjScale.value),
    x: parseInt(rangeAdjX.value),
    y: parseInt(rangeAdjY.value)
  };
  if (typeof saveStoryAvatarConfig === 'function') await saveStoryAvatarConfig(window.currentAdjChar, nextCfg);
  else {
    window.currentAdjChar.storyAvatarCfg = nextCfg;
    await saveProgress({ characters: selectedCharsData });
  }
  api.ui.toast("立绘配置已保存");
  document.getElementById('btn-close-avatar-adj').click();
});

// 图标调整逻辑
let currentConfigTarget = null; // 存 pd 对象，如果为 'GLOBAL' 则为全局设置
let currentTempConfig = null;
let currentTempUrl = null;

const iconCfgModal = document.getElementById('icon-config-modal');
const cfgPreviewImg = document.getElementById('icon-cfg-preview');
const cfgPreviewLabel = document.getElementById('icon-cfg-label');
const rangeScale = document.getElementById('cfg-scale');
const rangeOpacity = document.getElementById('cfg-opacity');
const rangeX = document.getElementById('cfg-x');
const rangeY = document.getElementById('cfg-y');
const rangeLY = document.getElementById('cfg-ly');
const radiosTextMode = document.getElementsByName('cfg-textmode');

function updatePreview() {
  // 如果弹窗元素不在DOM里则跳过，防止崩溃
  if (!cfgPreviewImg || !cfgPreviewLabel || !rangeX || !rangeY || !rangeScale || !rangeOpacity || !rangeLY) return;
  try {
    cfgPreviewImg.style.transform = `translate(${rangeX.value}px, ${rangeY.value}px) scale(${rangeScale.value / 100})`;
    cfgPreviewImg.style.opacity = rangeOpacity.value / 100;
    
    // 更新字牌
    const checkedMode = document.querySelector('input[name="cfg-textmode"]:checked');
    if (!checkedMode) return;
    const textMode = checkedMode.value;
    if (textMode === 'vertical') {
      cfgPreviewLabel.style.writingMode = 'vertical-rl';
      cfgPreviewLabel.style.textOrientation = 'upright';
      cfgPreviewLabel.style.left = '50%';
      cfgPreviewLabel.style.right = 'auto';
      cfgPreviewLabel.style.bottom = 'auto';
      cfgPreviewLabel.style.top = '50%';
      cfgPreviewLabel.style.transform = 'translate(-50%, -50%)';
      cfgPreviewLabel.style.letterSpacing = '2px';
      if (rangeLY.parentElement) rangeLY.parentElement.style.opacity = '0.3';
      rangeLY.disabled = true;
    } else {
      cfgPreviewLabel.style.writingMode = 'horizontal-tb';
      cfgPreviewLabel.style.textOrientation = 'mixed';
      cfgPreviewLabel.style.left = '50%';
      cfgPreviewLabel.style.right = 'auto';
      cfgPreviewLabel.style.bottom = `${rangeLY.value}px`;
      cfgPreviewLabel.style.top = 'auto';
      cfgPreviewLabel.style.transform = 'translateX(-50%)';
      cfgPreviewLabel.style.letterSpacing = '1px';
      if (rangeLY.parentElement) rangeLY.parentElement.style.opacity = '1';
      rangeLY.disabled = false;
    }
  } catch(e) { /* 静默处理，防止因DOM状态导致崩溃 */ }
}
[rangeScale, rangeOpacity, rangeX, rangeY, rangeLY].forEach(el => el.addEventListener('input', updatePreview));
radiosTextMode.forEach(el => el.addEventListener('change', updatePreview));

function openIconConfig(targetPd, url) {
  currentConfigTarget = targetPd;
  currentTempUrl = url;
  
  if (targetPd === 'GLOBAL') {
    document.getElementById('icon-cfg-title').innerText = '全局图标统一设置';
    cfgPreviewLabel.innerText = '示例宫殿';
    currentTempConfig = { scale:100, opacity:100, offsetX:0, offsetY:0, labelY:-20, textMode:'horizontal' };
  } else {
    document.getElementById('icon-cfg-title').innerText = `【${targetPd.name}】图标调整`;
    cfgPreviewLabel.innerText = targetPd.name;
    currentTempConfig = targetPd.iconConfig ? { ...targetPd.iconConfig } : { scale:100, opacity:100, offsetX:0, offsetY:0, labelY:-20, textMode:'horizontal' };
  }
  
  cfgPreviewImg.src = url;
  rangeScale.value = currentTempConfig.scale;
  rangeOpacity.value = currentTempConfig.opacity;
  rangeX.value = currentTempConfig.offsetX;
  rangeY.value = currentTempConfig.offsetY;
  rangeLY.value = currentTempConfig.labelY;
  
  const mode = currentTempConfig.textMode || 'horizontal';
  document.querySelector(`input[name="cfg-textmode"][value="${mode}"]`).checked = true;
  
  updatePreview();
  
  iconCfgModal.style.display = 'flex';
}

// 修复背景调试面板关闭时隐藏滤镜区和立绘
document.getElementById('btn-pb-cancel').addEventListener('click', () => {
  pbModal.style.display = 'none';
  pbFilterControls.style.display = 'none';
  document.getElementById('pb-preview-avatar').style.display = 'none';
  setPbActionBtnsVisible(false);
});

document.getElementById('btn-cfg-cancel').addEventListener('click', () => { iconCfgModal.style.display = 'none'; });
document.getElementById('btn-cfg-remove').addEventListener('click', async () => {
  if (currentConfigTarget === 'GLOBAL') {
    placedPalacesData.forEach(p => { p.icon = null; p.iconConfig = null; });
  } else {
    currentConfigTarget.icon = null;
    currentConfigTarget.iconConfig = null;
  }
  await saveProgress({ palacesData: placedPalacesData });
  renderDevPalaceIcons();
  initMemoryView();
  iconCfgModal.style.display = 'none';
});
document.getElementById('btn-cfg-reupload').addEventListener('click', async () => {
  try {
    const picked = await api.media.pick({ accept: "image/*" });
    if (picked?.file) {
      currentTempUrl = picked.file.dataUrl;
      cfgPreviewImg.src = currentTempUrl;
    }
  } catch(e) {}
});
document.getElementById('btn-cfg-save').addEventListener('click', async () => {
  const checkedTextMode = document.querySelector('input[name="cfg-textmode"]:checked');
  const cfg = {
    scale: parseInt(rangeScale.value),
    opacity: parseInt(rangeOpacity.value),
    offsetX: parseInt(rangeX.value),
    offsetY: parseInt(rangeY.value),
    labelY: parseInt(rangeLY.value),
    textMode: checkedTextMode ? checkedTextMode.value : 'horizontal'
  };
  
  if (currentConfigTarget === 'GLOBAL') {
    placedPalacesData.forEach(p => {
      p.icon = currentTempUrl;
      p.iconConfig = { ...cfg, url: currentTempUrl };
    });
    await saveProgress({ palacesData: placedPalacesData });
  } else {
    currentConfigTarget.icon = currentTempUrl;
    currentConfigTarget.iconConfig = { ...cfg, url: currentTempUrl };
    await saveProgress({ palacesData: placedPalacesData });
  }
  
  renderDevPalaceIcons();
  initMemoryView();
  iconCfgModal.style.display = 'none';
});

// 全局按钮绑定
document.getElementById('btn-global-icon-reset').addEventListener('click', async () => {
  const ok = await api.ui.confirm({ title: "确认重置", message: "确定要将所有宫殿恢复为默认文字牌吗？" });
  if (ok) {
    placedPalacesData.forEach(p => { p.icon = null; p.iconConfig = null; });
    await saveProgress({ palacesData: placedPalacesData });
    renderDevPalaceIcons();
    initMemoryView();
    api.ui.toast("已全部恢复");
  }
});
document.getElementById('btn-global-icon-set').addEventListener('click', async () => {
  try {
    const picked = await api.media.pick({ accept: "image/*" });
    if (picked?.file) openIconConfig('GLOBAL', picked.file.dataUrl);
  } catch(e) {}
});

// 新手指引正文与根目录功能手册同源；在指南中按章节、子标题逐级折叠展示。
const NOVICE_GUIDE_UPDATED_AT = '2026年9月12日';
let NOVICE_GUIDE_MARKDOWN = "# 故梦辞·目前已有的功能\n\n> 本文按当前游戏源码逐项整理。内容以玩家实际能看到、能点击、会触发的流程为准；带“开发中”的入口会明确标注，不把占位入口误写成已完成功能。\n\n## 一、阅读方式与通用规则\n\n### 1. 功能状态标记\n\n- 【已实现】：当前版本已有完整入口与实际逻辑。\n- 【部分实现】：已有界面或主流程，但仍有空置栏位、占位内容或依赖外部服务的环节。\n- 【开发中】：点击后只显示提示，尚未产生正式游戏结果。\n- 【条件功能】：只有满足人物数量、身份、时辰、背景或金手指等条件时才能进入。\n\n### 2. 全局共通交互\n\n- 顶部“音乐”或旋转音符图标：打开全局音乐播放器。播放器内可播放/暂停、上一首、下一首、直接点歌，并在“列表循环”和“单曲循环”之间切换；关闭小窗不会清空当前曲目。\n- 顶部时间文字：打开时间选择器。可在“与现实同步”和“自定义时间”之间切换；自定义时可选择永安年号、月份、日期、十二时辰与刻钟。\n- 全局时间会写入角色当前人设上下文，之后的剧情、信笺、记事、奏折和AI生成会读取这一时间。\n- 剧情页“展/卷”：切换对话框展开与收起，给立绘和背景留出不同的观看空间。\n- 立绘调节按钮：按当前人物保存大小、横向位置和纵向位置；不同人物的设置分别保存。\n- 背景按钮：进入绘景或换图功能；能上传本地图片，也能使用AI提示词生图，并可调亮度、对比度和RGB色彩。\n- 语音按钮：控制角色台词是否朗读。角色还可单独设置“仅朗读对话”“朗读全文”“不朗读”。\n- 履历按钮：打开当前剧情记录；可以编辑文字、删除某段、定位到某段、从指定位置重新推演。\n- AI失败时：界面会保留当前页面并显示失败提示，玩家可以重试，不会因为一次生成失败而主动删除已有存档。\n\n## 二、首页与忆尘录\n\n### 1. 首页【已实现】\n\n- “拾前尘”：开始一段全新的游戏流程。会清空当前内存中的临时地图、宫殿摆放、已选角色和当前存档编号，但不会删除忆尘录里已有的其他存档。\n- “忆尘录”：打开全部存档槽。每个存档显示存档名称、故人名单、皇城是否已经布局以及最近更新时间。\n- “调校台”：目前只显示“功能开发中”，没有实际设置内容。\n\n### 2. 忆尘录完整操作【已实现】\n\n- 点击存档：读取该存档的地图、角色、记忆、奏折、信笺、记事、背景、字体、时间、金手指等数据，并回到对应游戏进度。\n- 左滑存档槽：露出“命名”和“删除”。\n- “命名”：弹出输入框修改当前存档名；确认后立即更新该存档。\n- “删除”：直接删除对应存档，并从列表移除；若删除的是当前正在使用的存档，当前存档编号会被清空。\n- “＋新开一段前尘”：关闭忆尘录并进入新档的皇城绘卷步骤。\n- “关闭”：返回首页，不改变任何存档。\n\n### 3. 自动存档原则【已实现】\n\n- 角色、人设、记忆、记事、信笺、奏折、NPC、宫殿背景、地图、字体、头像调节、金手指到期时间等关键修改都会调用存档逻辑。\n- 新档首次保存时会生成独立存档编号；之后继续在同一存档上更新，不会每次都创建新存档。\n- 字体文件、图片和自定义背景以dataUrl或链接形式随对应配置保存；重新打开游戏后会恢复上一次设定。\n\n## 三、新档建立流程\n\n### 1. 皇城绘卷【已实现】\n\n- “就用这个”：使用游戏内置皇城地图并保存。\n- “本地导入”：从手机选择图片作为地图；选中后立即预览并保存。\n- “AI生成”：展开地图提示词输入区，调用玩家在宿主中配置的生图API绘制皇城俯视图。\n- “重新绘制”：沿用当前提示词再次生成。\n- “定案”：确认当前地图并进入宫殿布局；没有地图时不能继续。\n\n### 2. 皇城布局【已实现】\n\n- 底部宫殿栏列出可摆放宫殿；点选某宫殿后，再点地图位置即可放置。\n- 已放置的宫殿会以宫殿标记显示在地图上，并记录相对坐标。\n- “确认布局”：保存宫殿坐标并标记“皇城已定”。\n- 下一步箭头：进入“召见故人”的角色选择。\n- 置度所或修营缮完成新宫殿时，可重新进入布局模式，将新宫殿补放到地图上。\n\n### 3. 召见故人【已实现】\n\n- 从宿主角色列表读取可用角色；玩家至少选择一位才能继续。\n- 这里载入的是人物原始设定，不自动携带另一个游戏世界的剧情记忆。\n- 确认后为每位角色创建本游戏中的古代身份资料，并进入逐人编纂。\n\n### 4. 故人身份与古代人设【已实现】\n\n- 身份可选“帝师”“左相”“右相”“后妃”或“自定义”。\n- 自定义身份时会出现额外输入框。\n- 人设编辑区可手写古代生平，也可点击“AI生成古代人设”。\n- AI人设会参考角色原设和玩家指定身份；生成前后均可手动修改。\n- “保存设定”保存当前人物身份和人设。\n- 三个“范例”语音按钮用于试听预设声线，帮助选择角色语音感觉。\n- 角色头像可使用原头像、本地上传图片或根据外貌描述调用AI生成画像。\n\n### 5. 后妃位份表【已实现】\n\n- 位份按从高到低排列，每行包含位份、自称、备注。\n- “＋添加位份”：增加一行“新位份”，玩家可继续编辑。\n- 位份体系会进入全局世界书和角色剧情上下文，影响称呼、礼制和后宫关系。\n\n### 6. 赐定位份与赐居【已实现】\n\n- 皇帝人设输入框：填写玩家在古代世界中的身份、经历、性格和原则，之后会作为User人设提供给AI。\n- 后妃册封：为身份为后妃的角色选择初始位份。\n- “赐居所”：选择东六宫、西六宫或冷宫，再选择宫殿与正殿、东偏殿、西偏殿、耳房。\n- 宫殿环境/特色可统一填写，之后宫殿剧情会读取。\n- “确认赐居”会写入角色居所；名册里修改居所也会同步改变角色所在宫殿。\n- “开启前尘记忆”：保存皇帝人设、位份体系、角色身份和居所，正式进入皇城地图。\n\n## 四、皇城地图、时间与音乐\n\n### 1. 皇城主地图【已实现】\n\n- 显示已确定的皇城地图与所有已摆放宫殿。\n- 点击宫殿标记进入对应宫殿详情。\n- “更换地图”：重新打开绘景页；可上传新地图或AI重绘，确认后替换当前地图。\n- “音乐”：打开全局播放器。\n- 顶栏时间：打开时间选择器。\n\n### 2. 时间系统【已实现】\n\n- “与现实同步”：按现实时间换算古代时辰，每分钟刷新一次。\n- “自定义时间”：手动选择永安元年至永安一百年、十二个月、每月一日至三十一日、时辰及刻钟。\n- 点击“确定”后，HUD时间、角色人设中的当前时间和后续AI上下文一起更新。\n- 早朝会额外读取当前小时；普通状态只有上午5点至12点能上朝。\n\n### 3. 音乐播放器【已实现】\n\n- 当前曲库：山野煮雨、诀别书、镜月、浮光、托遗响于悲风、Sang（扶桑）、紫禁城里的端庄猫、泱泱。\n- 支持播放/暂停、上一首、下一首、点选曲目。\n- 列表模式：一首结束后自动播放下一首。\n- 单曲模式：当前曲目循环。\n- 地图、六宫、宫殿、室内剧情、朝堂剧情中的音乐按钮共享同一播放状态。\n\n## 五、六宫与宫殿通用功能\n\n### 1. 六宫总览【已实现】\n\n- 东六宫与西六宫以宫门卡片呈现；点击进入宫殿详情。\n- 宫门图标可在置度所中逐宫更换，也可统一设置。\n- 顶栏提供返回和音乐入口，并为iOS灵动岛/安全区预留顶部距离。\n\n### 2. 普通宫殿详情【已实现】\n\n- 首次进入没有背景的宫殿时，会先打开绘景弹窗。\n- 背景来源：本地上传、AI生图或已有图片；确认后保存为该宫殿背景。\n- 顶栏：返回、宫殿名、音乐、背景/绘景相关入口。\n- 页面会读取居住在该宫殿的所有后妃，并根据角色居所生成可进入房间。\n- 若宫殿内没有角色，会显示“殿内空无一人”。\n\n### 3. 绘制台与背景校准【已实现】\n\n- 可输入AI绘画提示词并生成宫殿内景、庭院、地图或图标。\n- 可选择本地图片替代AI生图。\n- 快捷提示词可快速指定宫殿、庭院、图标等方向。\n- 预览阶段支持亮度、对比度、红、绿、蓝色值调整。\n- “恢复”重置滤镜；“确认”保存处理后的背景。\n- 已保存背景会在退出APP、重新进入存档后恢复。\n\n### 4. 窥见一幕【已实现】\n\n- 从当前宫殿选择一位主要角色，读取同宫后妃名单、全部后妃人设、个人世界书、TA了解的、TA看到的、近期记事和关系图谱。\n- AI根据宫殿、时间和同宫人物生成一段当前正在发生的剧情。\n- 可指定主位是否在场、来访妃嫔和自定义剧情走向后重新推演。\n- 叙事按短段播放；识别到角色发言时自动切换对应立绘与语音。\n- User可在输入框输入言行继续剧情；系统不会替User作决定。\n- 退出时可选择不保存，或让AI生成小结；小结可由User编辑确认后写入在场角色的“TA看到的”。\n\n### 5. 暗中探听【已实现】\n\n- 当宫殿耳房中存在侍从或宫女时，可点击“暗中探听”。\n- AI读取宫殿主人、同宫后妃、耳房NPC的人设、状态、忠诚度、主人关系和记忆。\n- 生成内容以耳房众人对宫殿后妃的议论、私下观察与八卦为主，并体现不同NPC立场。\n- 若没有可参与的耳房NPC，会给出无可探听的提示。\n\n### 6. 随便走走【开发中】\n\n- 内务府宫殿操作中可见“随便走走”，当前没有正式剧情逻辑。\n\n## 六、乾清宫·早朝\n\n### 1. 入口与背景【已实现】\n\n- 乾清宫不再区分正殿、偏殿，进入后直接显示唯一朝堂背景。\n- 默认背景已内置；玩家可“更换背景”，也可“恢复默认”。\n- 自定义背景会随存档保存，下次进入继续使用。\n- 页面提示“丹墀肃立·百官候朝”，点击“升殿上朝”开始判断。\n\n### 2. 上朝条件【条件功能】\n\n- 正常时间：上午5点至12点。\n- 不在时段内且没有金手指：提示正常早朝时辰，并明确引导前往“养心殿—操作—金手指”；不会进入剧情。\n- 金手指有效：可无视时辰进入早朝；确认框会明确询问是否强制召集百官，进入前再次提示金手指已经生效。\n\n### 3. 朝议上下文【已实现】\n\n- 读取全部待批阅奏折，包括题目、作者、正文和时间。\n- 读取全部已批阅奏折，包括原奏折、御批和后续结果。\n- 读取身份为帝师、左相、右相、大臣、臣子的角色资料。\n- 读取由奏折和前朝记事识别到的NPC资料及“TA看到的”“TA了解的”“TA的思绪/记事”。\n- 读取“前朝”分类最新30条记事。\n- 同时读取皇帝人设、全局世界书、全局规矩和当前时间。\n\n### 4. 朝议剧情流程【已实现】\n\n- 开场从鸣鞭、百官入班开始。\n- AI优先挑选2至4件最紧要或互相牵连的奏折展开。\n- 待批奏折可被追问；已批奏折可产生执行反馈、反对意见或后续争议。\n- 朝臣会按照身份、人设、记忆和利益上奏、争辩、请旨；已有角色和NPC都能参与。\n- 可出现党争、证据矛盾、预算取舍、地方急报、官员互相拆台等变化，但必须与现有资料兼容。\n- 每段为短段落；人物台词带精确姓名，系统自动显示发言者立绘并播放该角色语音。\n- 提示词明确禁止输出“旁白”二字；解析器还会再次清理“旁白：”“【旁白】”等前缀。\n- 一轮结束后输入框显示“输入旨意、追问或决断”，User输入后继续下一轮朝议。\n\n### 5. 朝堂顶栏与总览【已实现】\n\n- “退朝”：结束早朝，不与立绘调节按钮错位。\n- “待批 N”：打开待批奏折列表；点某条可查看题目、作者、时间和全文。\n- “已批 N”：打开已批奏折列表；点某条可查看全文和御批。\n- “朝臣 N”：打开朝臣名单，显示姓名、身份/官职和人物资料摘要。\n- “下一议题”：在当前朝议基础上继续推进。\n- 音乐、语音、对话框展开和立绘调整与其他剧情页一致。\n\n### 6. 退朝与记忆【已实现】\n\n- 点击“退朝”后询问是否保留此次朝议。\n- 选择“否”：直接退出，不写入记忆。\n- 选择“是”：AI生成朝议小结，并交给User确认和编辑。\n- 最终小结写入所有在场角色及NPC的“TA看到的”。\n- 同时生成一条不超过100字、带“前朝”标记的记事，进入养心殿“记事—前朝”。\n\n## 七、养心殿总界面\n\n### 1. 左侧入口【已实现】\n\n- “御书房”：直接前往御书房。\n- “谢临渊”：使用谢临渊头像进入养心殿室内互动。\n\n### 2. 底部入口【已实现】\n\n- “休息”：翻牌子、独自休息、沐浴。\n- “召见”：召见妃嫔、召见其他、翻牌子。\n- “修营缮”：建造、修缮宫殿、建设中。\n- “操作”：飞鸽传书、管理后宫、惩罚妃嫔、奖赏妃嫔、金手指。\n- “记事”：后宫、前朝、秘闻总录。\n- “列表”：后宫列表、大臣列表、NPC列表、侍从名册。\n- “指南”：打开游戏说明弹窗。\n\n## 八、养心殿·休息与沐浴\n\n### 1. 休息菜单【部分实现】\n\n- “翻牌子”：进入完整翻牌流程。\n- “独自休息”：目前只显示“夜色沉沉，帝王独眠……”提示，时间流逝逻辑仍在开发中。\n- “沐浴”：进入“独自沐浴”或“谢临渊，你帮朕”。\n\n### 2. 独自沐浴【已实现】\n\n- 读取当前时间、皇帝人设以及养心殿总录中的近期记事。\n- 使用养心殿背景进入无立绘的沉浸式文本页。\n- AI以第二人称“你”生成600至900字古风小正文，内容会结合近期朝政、后宫事件或皇帝心绪。\n- 全程不生成角色对话，只写环境、动作和内心；每段保持短小。\n- 点击可跳过打字或推进下一段。\n- 播放完毕后自动返回养心殿，不进入记忆确认，也不生成记事。\n\n### 3. 谢临渊服侍沐浴【已实现】\n\n- 读取谢临渊完整人设、近期记忆、与皇帝关系和当前时间。\n- 若养心殿没有背景，先要求完成绘景，再继续沐浴。\n- 谢临渊立绘按其个人剧情立绘设置显示。\n- AI围绕备水、调温、备香料软巾、解外袍、服侍入浴等节点生成长剧情。\n- 谢临渊保持克制、恭顺、守礼的人设，避免夸张失态；关系阶段会影响情感张力。\n- 角色说话时自动显示谢临渊立绘并按语音偏好朗读。\n- 可通过退出按钮结束并返回养心殿。\n\n## 九、养心殿·翻牌子\n\n### 1. 选择与牌样【已实现】\n\n- 展示当前全部角色牌子，不限后妃身份；至少有一位角色才能使用。\n- 点击牌子可多选，再次点击取消。\n- “随机翻牌”：随机选择角色。\n- “传召入殿”：至少选中一人后进入侍寝剧情。\n- “牌样”：上传自定义牌面图片；确认后所有牌子同步更新。\n- 自定义牌样随存档保留，重新进入仍使用上次设置。\n\n### 2. 完整流程【已实现】\n\n- 传召后，对应角色进入养心殿剧情。\n- 系统向AI发送皇帝人设、角色全部人设、世界书、TA了解的、TA看到的、记事、关系以及同场人物资料。\n- AI生成多人或单人侍寝剧情，按短段播放；角色发言时自动切换说话者立绘和语音。\n- 一轮完成后，User可在输入框继续输入言行，角色会结合之前履历继续回应。\n- 点击“结束侍寝”后，选择“随风散去”或“录入彤史”。\n- “随风散去”：退出剧情，不保存本次记忆。\n- “录入彤史”：AI生成不超过300字的客观记忆小结，写入所有在场角色的“TA看到的”；同时用固定格式生成彤录记事，并同步进相关人物起居注。\n\n### 3. 顶栏与剧情控制【已实现】\n\n- “展/卷”：切换对话框显示方式。\n- 立绘调节：先点人物姓名，再调该人物的大小、横向和纵向位置；点击“保存”后按人物持久化。\n- 背景图片图标：更换养心殿剧情背景。\n- 喇叭图标：控制角色台词语音。\n- 旋转音符图标：打开音乐播放器。\n- “重听”：重新播放当前轮已有文本或语音。\n- “履历”：查看每段对话，支持编辑、删除、定位和从此重推。\n- “重新生成”：按当前上下文重新生成该轮。\n- “结束侍寝”：进入记忆与彤史选择。\n\n## 十、养心殿·召见\n\n### 1. 入口分类【已实现】\n\n- “召见妃嫔”：只列出身份为后妃的人物，副标题显示位份或“未册封”。\n- “召见其他”：列出非后妃角色，并将谢临渊加入最前。\n- “翻牌子”：直接跳转翻牌页。\n\n### 2. 人物选择页【已实现】\n\n- 人物以双列卡片展示姓名、身份/位份、头像和资料。\n- 点击人物卡进入对应互动。\n- 头像可打开设置弹窗，上传本地图片、恢复默认并调节卡片缩放。\n- 设置按人物保存，重新打开召见页继续生效。\n\n### 3. 召见剧情【已实现】\n\n- 读取人物完整人设、记忆、世界书、关系和当前时间。\n- 使用统一剧情页播放分段内容，识别角色姓名后自动切立绘、播放语音。\n- User可输入言行继续互动，并能使用履历、重推、背景、音乐和立绘调整。\n- 退出时可选择是否生成记忆小结；确认后的文字写入对应人物“TA看到的”。\n\n## 十一、养心殿·修营缮\n\n### 1. 建造【部分实现】\n\n- 当前正式建造项目为“储秀宫”，显示“西六宫之一，耗时3天”。\n- 未开始时显示“建设”；开始后创建三天倒计时并保存。\n- 已经在地图中放置时显示“已建成”。\n- 另有两个“空置地块”，目前没有具体项目。\n\n### 2. 修缮宫殿【开发中】\n\n- 页面已存在，目前固定显示“暂无需要修缮的宫殿”。\n\n### 3. 建设中【已实现】\n\n- 显示全部建设任务和剩余天、时、分、秒，每秒更新。\n- “加速”：只有金手指有效时可以立即完成。\n- 加速完成后自动进入地图重新布局，并选中新建宫殿等待放置。\n- 没有金手指时提示先前往“操作—金手指”。\n\n## 十二、养心殿·操作与金手指\n\n### 1. 操作菜单状态\n\n- “飞鸽传书”【已实现】：进入御笺广场。\n- “管理后宫”【开发中】：目前只显示提示。\n- “惩罚妃嫔”【开发中】：目前只显示提示。\n- “奖赏妃嫔”【开发中】：目前只显示提示。\n- “金手指”【已实现】：进入帝王特权购买页。\n\n### 2. 金手指【已实现】\n\n- 天卡：88，持续24小时。\n- 周卡：488，持续7天。\n- 月卡：2688，持续30天。\n- 选择卡片后按钮显示对应支付金额；通过平台钱包完成支付。\n- 已有效时显示剩余小时和分钟；重复购买会在原到期时间上累加。\n- 到期时间写入存档，退出APP后不会丢失。\n- 当前可见效果：早朝无视时间、修营缮立即加速；后续功能可继续读取同一状态。\n\n## 十三、养心殿·记事总录\n\n### 1. 分类【已实现】\n\n- “后宫”：聚合所有后妃个人记事，按最新记录在前排列并去除重复记录。\n- “前朝”：聚合帝师、左相、右相、大臣、臣子的个人记事，以及AI捏造的前朝人物记事。\n- “秘闻”：独立保存京城与宫廷秘闻，可包含系统未正式建档的虚构人物。\n\n### 2. 翰林落墨【已实现】\n\n- 后宫：读取全部后妃人设与记忆，生成8条近期后宫小记并归到对应人物。\n- 前朝：结合真实前朝角色生成4条，再允许AI捏造其他大臣生成4条；每条标记所有者。\n- 秘闻：生成8条20至40字的劲爆京城/宫廷秘闻，包括婚恋、嫡庶、权势、家族纠纷等。\n- AI输出必须为结构化记录；格式正确才会写入存档。\n\n### 3. 单条记事【已实现】\n\n- 显示时间、所属人物、正文、来源和标签。\n- 可在人物记事页编辑或删除；“众谈”类记录可能同步给所有参与者。\n- 朝议退朝小结进入“前朝”；侍寝固定记事进入“彤录”；闲聊可进入“众谈”。\n\n## 十四、养心殿·人物列表\n\n### 1. 顶栏与表格【已实现】\n\n- 顶部标签：“后宫列表”“大臣列表”“NPC列表”“侍从名册”。\n- 采用横向可滚动表格，顶部为字段名，人物一行一个。\n- “新增人物”：在当前分类增加一行，玩家可直接编辑。\n- “生成本页空白性情”：仅为空白人物生成性格和心情，已有结果保持不变。\n- 每行可单独重新生成性格与心情。\n\n### 2. 后宫列表【已实现】\n\n- 字段：姓名、位份、封号、居住宫殿、子嗣、性格、心情状态。\n- 姓名、位份、封号、居所、子嗣均直接读取游戏数据，不依赖AI判断。\n- 性格由AI生成恰好两个汉字；心情结合近期记忆生成不超过五个汉字。\n- 人工修改姓名会同步更新信笺、奏折、关系图谱、记事等引用。\n- 人工修改居住宫殿后，人物会出现在新宫殿；其侍从与宫女也会自动迁入新宫殿耳房。\n\n### 3. 大臣列表【已实现】\n\n- 收录帝师、左相、右相、大臣、臣子，并包含固定剧情角色谢临渊。\n- 字段：姓名、身份、官职/位阶、性格、心情状态。\n- 普通角色可编辑并同步；固定剧情人物不可从本局删除。\n\n### 4. NPC列表【已实现】\n\n- 字段：姓名、身份、人物资料、性格、心情状态。\n- NPC总量上限为60；达到上限后不能继续新增。\n- 奏折系统可复用现有NPC；只有NPC不足60时，才允许从奏折和前朝材料中识别、补入新NPC。\n- NPC自动具备“TA看到的”“TA了解的”“TA的思绪/记事”数据结构，并能在众生相中查看。\n\n### 5. 新增与删除【已实现】\n\n- 后宫新增：创建“新入宫者”，身份默认为后妃。\n- 大臣新增：创建“新任大臣”，身份默认为大臣。\n- NPC新增：创建“新NPC”。\n- 侍从新增：创建男性“新侍从”。\n- 删除前会明确提示：人物人设、记忆、思绪、记事和名册资料将从本局移除且不可撤销。\n- 删除后妃时，其名下侍从会解除主人和居所，不会继续错误跟随。\n- 删除固定剧情人物会被阻止。\n\n## 十五、侍从名册与耳房\n\n### 1. 批量生成【已实现】\n\n- 一次生成恰好4名成年男性侍从和2名成年女性宫女。\n- 自动生成：古风姓名、两字性格、40至80字介绍、五字以内状态、0至100忠诚度。\n- 六人默认没有主人，生成后由玩家分配。\n- 若NPC剩余名额不足6人，会提示当前数量与60人上限，不调用AI。\n\n### 2. 主人分配与迁居【已实现】\n\n- “主人”下拉框只列出身份为后妃的人物。\n- 分配主人后，NPC记录主人姓名与ID。\n- NPC会自动迁入主人所在宫殿的“耳房”。\n- 主人改名时，NPC的主人姓名同步更新。\n- 主人迁宫时，名下侍从和宫女一并迁入新宫殿耳房。\n\n### 3. 耳房多人间【已实现】\n\n- 每个宫殿耳房分为“侍从房”和“宫女房”两个多人间。\n- 两个房间可分别设置背景图；没有背景时会提醒先设定。\n- 同一宫殿住有多位后妃时，他们名下的侍从统一住在该宫殿对应多人间。\n- “拜访侍从”列出本宫全部男性侍从；“拜访宫女”列出本宫全部宫女。\n\n### 4. 人物操作【已实现】\n\n- 点击姓名出现“对话”“查看”“宠幸”。\n- “查看”：查看姓名、身份、主人、居所、性格、状态、忠诚度、介绍和已有记忆。\n- “对话”：进入室内对话模式，AI同时读取同屋人物；剧情需要描写同屋人的旁观与反应。\n- “宠幸”：进入亲密剧情，同样要求体现同屋人的反应与房间多人环境。\n- 对话与宠幸沿用室内剧情的分段、语音、输入、履历、重推和记忆确认；侍从与宫女NPC暂不配备立绘，剧情页只显示耳房背景和文本，不再生成姓名首字占位图。\n- 保存记忆时，主要人物写入完整小结；同屋人会收到“同屋见闻”。\n\n## 十六、御书房总界面\n\n### 1. 入口【已实现】\n\n- “批阅奏折”：进入奏折系统。\n- “信笺”：进入往来信笺、故人往来、密探截获。\n- “传召”：打开召见群臣页面。\n- 御书房首次没有背景时要求先绘景；背景确认后进入专属界面。\n\n## 十七、奏折系统\n\n### 1. 顶部分类【已实现】\n\n- “批阅”：调用AI生成一批新的待批奏折。\n- “待处理”：查看全部尚未朱批的奏折。\n- “已批阅”：查看已经发出朱批的奏折与回禀。\n- “颁布政令”：编辑并发布皇帝政令。\n- “传召”：进入召见群臣。\n\n### 2. 新奏折生成【已实现】\n\n- 读取当前时间、皇帝人设、全局世界书、角色资料、已有NPC、近期记事与历史奏折。\n- 生成内容包括题目、上奏人、正文、时间和关联人物。\n- NPC不足60时，奏折可以使用已有NPC，也可识别并补充新的前朝NPC。\n- NPC达到60后，提示词限制AI只能调用现有人物，不再新增。\n- 生成结果进入“待处理”，不会自动视为已批。\n\n### 3. 待处理列表【已实现】\n\n- 列表显示题目、作者、时间和正文摘要。\n- 可分别调整待处理列表的滚动配置、字体大小和显示密度。\n- 点击奏折进入卷轴详情。\n\n### 4. 奏折详情与朱批【已实现】\n\n- 完整显示题目、作者、上奏时间和正文。\n- “AI代写”：根据奏折、人设、世界书和上下文生成朱批草稿。\n- 玩家可在输入框手动修改或完全自行撰写。\n- “发出朱批”：保存御批，并调用AI生成大臣回禀/执行反馈。\n- 发出后奏折从待处理移动到已批阅。\n- “传召大臣回禀”：进入帝师/大臣商议对话；已有往来时按钮变为“往来记录”。\n\n### 5. 已批阅【已实现】\n\n- 展示原奏折、皇帝朱批和回禀。\n- 回禀可“重新回禀”，让AI在相同御批基础上重新生成。\n- 可删除单条回禀或对应记录。\n- 详情页可独立设置字体、字号；支持预设字体、字体链接和本地字体文件。\n\n### 6. 颁布政令【已实现】\n\n- 玩家输入政令主题和正文，也可点击AI代写。\n- 发布后形成政令记录，可用于后续朝议和前朝剧情。\n- 政令内容会带当前时间并保存。\n\n### 7. 帝师商议【已实现】\n\n- 围绕当前奏折与朱批进入谢临渊对话。\n- 读取谢临渊人设、记忆、奏折正文和User输入。\n- 可连续追问，保留往来记录。\n- “结束商议”退出；在代批辅助场景中可选择“就这个方案”。\n\n## 十八、信笺系统\n\n### 1. 共通界面【已实现】\n\n- 顶部标签：“往来信笺”“故人往来”“密探截获”。\n- 顶栏字体设置：预设马善政、楷体、宋体、仿宋、ZCOOL XiaoWei、Noto Serif SC；也可输入字体链接或上传TTF/OTF/WOFF。\n- 信笺字体独立于全局字体保存，恢复默认只影响信笺。\n\n### 2. 往来信笺【已实现】\n\n- 选择联络角色后，列表按最新在前显示“朕发”和“来函”。\n- “拆阅TA的来函”：AI读取角色人设、位份、居所、世界书、TA了解的、TA看到的、起居注、关系和最近信件，生成100至150字来函。\n- 打开来函后可回复；“AI代笔”生成皇帝回函草稿，玩家可编辑。\n- 发出回函后，系统继续以对方口吻生成回信。\n- 往来会写入角色“TA看到的”，并可能触发角色沉思。\n- 单封信可删除；关联的信件记忆会同步移除。\n\n### 3. 故人往来【已实现】\n\n- 至少需要两位故人。\n- 玩家选择发信人与收信人，或使用“随机配对”。\n- “截获往来函件”：AI按两人的完整人设、记忆、关系和世界书生成私信。\n- 打开详情可继续“截获下一封往来”，形成角色之间的连续通信。\n- 记录独立保存在故人信件数据中，不与皇帝来往混淆。\n\n### 4. 密探截获【已实现】\n\n- “令东厂截获密信”：AI从现有人物关系、记忆和宫廷局势中生成秘密往来。\n- 可选择或识别发信人、收信人，保存截获时间和正文。\n- 密信用于展示角色未直接告诉皇帝的私下信息，适合作为后续剧情线索。\n\n## 十九、飞鸽传书·御笺广场\n\n### 1. 投笺【已实现】\n\n- 玩家填写御笺标题与正文。\n- “AI代笔”：根据当前语境生成可编辑草稿。\n- “放飞”：将御笺写入云端广场；发布状态和失败会有提示。\n- 账号名通过平台用户资料读取并缓存。\n\n### 2. 拾笺【已实现】\n\n- “捞取御笺”：从广场随机取得一封其他玩家御笺。\n- 可展开全文、收起、点赞、查看评论和回复。\n- “AI代笔”可生成回信草稿；“放飞回信”提交评论式回复。\n- “再捞一封”继续随机获取。\n\n### 3. 笺匣与我的【已实现】\n\n- 笺匣区分“我捞到的”“我的回信”“收到回信”。\n- 可展开完整往来，查看对话链。\n- “我的”列出自己发布的御笺，可删除。\n- 点赞和评论点赞按当前账号记录，可再次点击取消。\n- 自己发布的评论可删除，其他人的评论不可由本账号删除。\n\n## 二十、内务府总界面\n\n### 1. 入口【已实现】\n\n- “绘制台”：AI生成或上传背景/图标并校准。\n- “查阅众生相”：进入人物记忆管理。\n- “全局世界书”：编辑皇朝共通设定。\n- “人物世界书”：选择角色后编辑专属设定。\n- “置度所”：开发与高级设置。\n- “名臣录”：查看固定名臣卡片并召见。\n- “自设台”：新建、导入和编辑角色。\n- “关系图谱”：查看和编辑人物关系。\n- “全局字体”：在众生相顶栏中提供独立入口。\n\n## 二十一、众生相与记忆系统\n\n### 1. 人物选择【已实现】\n\n- 顶栏列出主要角色；NPC不逐个挤在顶栏，而是统一显示一个“NPC”入口。\n- 点击“NPC”先进入NPC列表，再点具体人物查看记忆。\n- 固定角色谢临渊与普通角色使用同一记忆面板，但分别保存到对应数据。\n\n### 2. TA看到的【已实现】\n\n- 保存角色亲身经历或系统确认写入的剧情小结。\n- 每条显示时间和正文，可删除。\n- 剧情、信笺、早朝、侍寝、室内对话和同屋见闻都可能写入这里。\n- 可设置每个角色发送给AI的最近记忆条数；“全部”表示不截断。\n\n### 3. TA了解的【已实现】\n\n- 保存角色掌握的人物资料、关系认知、秘密和世界知识。\n- 可创建已知信息区块，编辑标题和正文。\n- 关系图谱中的“存入记忆”会把关系信息写进相关角色的TA了解的。\n- 人物完整档案可从记事区快捷跳转查看。\n\n### 4. TA的思绪【已实现】\n\n- 角色根据人设、近期见闻、已知信息、记事和关系产生内心思绪。\n- “自动”控制是否在新增重要经历后触发沉思。\n- “立即沉思”手动调用AI生成当前思绪。\n- 思绪可删除；没有内容时显示空状态提示。\n\n### 5. 起居注/个人记事【已实现】\n\n- 显示该角色个人记录；可从“记事”页生成。\n- “翰林落墨”按人物人设和近期记忆生成小记。\n- 可编辑正文与标签；众谈类会同步到参与人。\n\n### 6. 人设重新定制【已实现】\n\n- 可查看角色完整古代人设。\n- “重新定制人设”：AI依据宫规、身份和原设重新生成；玩家确认后覆盖。\n- 人物世界书、记忆和关系不会因为重新定制人设被自动清空。\n\n## 二十二、世界书\n\n### 1. 全局世界书【已实现】\n\n- “天下志/大世界设定”：皇朝背景、年代风貌、前朝局势等。\n- “后宫规矩/全局规则”：位份礼制、皇权边界、角色行为约束。\n- “皇帝人设”：来自开档时填写的User古代人设，可继续修改。\n- 位份体系：读取后妃位份表，供所有相关AI剧情使用。\n- 保存后，全局内容会进入奏折、早朝、宫殿剧情、室内聊天、信笺和角色生成上下文。\n\n### 2. 人物世界书【已实现】\n\n- 先选择角色，再编辑“人物传/人物专属世界书”。\n- 适合写角色秘密、家族背景、专属地点、只在该角色在场时需要发送的设定。\n- 支持附加书本/区块，避免把所有内容塞进一段人物简介。\n- 仅在该角色相关剧情中发送，减少无关上下文。\n\n## 二十三、关系图谱\n\n### 1. 图谱展示【已实现】\n\n- 所有角色以头像节点展示，关系以连线连接。\n- 节点可以拖动调整位置；位置保存后再次进入保持。\n- 点击人物或关系可查看双方关系说明。\n\n### 2. 关系生成与记忆【已实现】\n\n- 可为人物关系填写或生成文本，包括亲疏、利益、误解、敌意、依赖等。\n- 关系按方向保存，例如A对B与B对A可以不同。\n- “存入记忆”把关系写入相关人物“TA了解的”，让后续AI真正读取。\n- 人物改名时，关系键和双方姓名会同步迁移。\n\n## 二十四、名臣录\n\n### 1. 名臣卡片【部分实现】\n\n- 当前核心人物为谢临渊，显示姓名、身份、人设与头像。\n- 其他位置存在空槽，作为后续名臣扩展位。\n- 双击或点击头像区域可更换头像。\n\n### 2. 头像与召见【已实现】\n\n- 头像设置支持本地选择、恢复默认和缩放。\n- 保存后名臣录和相关召见卡片同步更新。\n- 点击召见进入室内互动；读取谢临渊人设、记忆、关系、语音与立绘配置。\n\n## 二十五、自设台\n\n### 1. 新建角色【已实现】\n\n- 手动填写姓名、身份、人设、记忆、世界书等信息。\n- 头像区域支持本地上传。\n- “AI生成人设”：先输入生成方向，再让AI结合当前资料生成古代人设。\n- “AI生成头像”：先从人物设定提炼外貌提示词，再调用玩家生图API；当前是纯提示词生图，不具备真正锁脸。\n\n### 2. 导入现有角色【已实现】\n\n- 从宿主角色列表选择角色并导入本游戏。\n- 导入后可继续修改古代身份、人设、记忆、世界书、头像和语音。\n\n### 3. 角色卡导入【已实现】\n\n- 支持JSON角色卡和包含嵌入数据的PNG角色卡。\n- 读取角色卡中的文字字段，并尽量按原文填入人物设定，不先做AI摘要。\n- 导入确认页显示解析出的姓名、描述和头像，玩家确认后加入游戏。\n\n### 4. 语音工作室【已实现】\n\n- 为角色设置情绪：平静、欢愉、悲戚、怒意、惶恐、厌恶、惊愕、沉静、流畅。\n- 设置朗读范围：仅朗读对话、朗读全文、不朗读。\n- 可读取角色第一句示例台词并调用TTS试听。\n- 保存后，室内、侍寝、早朝和其他剧情按角色配置播放。\n\n## 二十六、置度所\n\n### 1. API记录【已实现】\n\n- 显示游戏内AI调用日志，便于查看调用时间、功能来源、请求和结果状态。\n- 用于排查某个剧情为什么失败或返回格式异常。\n\n### 2. 提示词【已实现】\n\n- 列出游戏各项AI功能的系统提示词。\n- 玩家可修改单项提示词；留空使用游戏默认值。\n- “保存自定义提示词”后立即生效，并随存档保存。\n- 自定义提示词会影响人设、剧情、记事等生成质量，错误格式可能导致解析失败。\n\n### 3. 立绘【已实现】\n\n- 为每名角色选择自定义图片。\n- “校准卡片”：调整角色卡上的缩放和位置。\n- “恢复默认”：回到角色原头像/默认立绘。\n- 修改后刷新宫殿、召见和剧情中的对应显示。\n\n### 4. 宫殿【已实现】\n\n- 统一设置全部宫殿图标，或单独设置某一宫殿。\n- 可上传本地图标并调整预览。\n- “重新布景”进入地图布局，修改宫殿位置。\n\n### 5. 记事【已实现】\n\n- 管理自动记事开关，例如闲聊众谈、临幸彤录。\n- 自动记录开启时，完成对应互动后生成固定格式记事。\n\n### 6. 导卡【已实现】\n\n- 打开角色卡导入流程，支持JSON和PNG嵌入卡。\n- 解析后由玩家确认，不直接静默写入。\n\n### 7. API配置【已实现】\n\n- 可填写Base URL、API Key、模型名称、最大输出Token和Temperature。\n- “连通测试”：发送测试请求并显示状态。\n- “保存配置”：覆盖故梦辞使用的AI配置；留空则继续使用宿主默认配置。\n- API Key仅保存于本机配置，不显示为明文。\n\n### 8. 记忆量【已实现】\n\n- 全局统一设置每名角色发送给AI的“TA看到的”条数，可选全部或10至50条。\n- 可对单个角色设置覆盖值。\n- “统一应用到所有角色”会清除个别覆盖并使用全局上限。\n\n### 9. 字体【已实现】\n\n- 修改整个APP的全局字体和字号，保存后立即生效并在重启后恢复。\n- 预设：宋体、楷体、仿宋、马善政、ZCOOL XiaoWei、Noto Serif SC。\n- 可输入Google Fonts/CSS/字体直链，也可上传TTF、OTF、WOFF、WOFF2。\n- 部分奏折和信笺有自己的独立字体设置，不受全局字体覆盖。\n\n## 二十七、室内视图与通用对话\n\n### 1. 进入室内【已实现】\n\n- 从宫殿人物、召见、名臣录、耳房人员或谢临渊入口进入。\n- 使用当前宫殿背景；若没有背景，先要求绘景。\n- 角色型人物显示当前立绘，并读取该人物保存的缩放、横移和纵移；耳房侍从、宫女NPC暂不显示立绘，也不显示姓名首字占位图。\n\n### 2. 底部操作【已实现】\n\n- “闲聊”：生成日常对话。\n- “临幸/宠幸”：生成亲密剧情；是否显示取决于入口和人物类型。\n- “记事”：查看或生成当前人物记事。\n- “离去”：结束室内互动并进入是否保留记忆的确认。\n\n### 3. 对话流程【已实现】\n\n- AI读取当前时间、皇帝人设、全局世界书、人物专属世界书、人设、TA看到的、TA了解的、思绪、近期记事和关系。\n- 输出拆成旁白与人物台词；人物台词显示姓名、立绘并按语音设置朗读。\n- 点击对话框可跳过打字；一段结束后再点击进入下一段。\n- 一轮结束后显示User输入框，User可输入言行或剧情提示。\n- “重听”“履历”“重新生成”“展/卷”、音乐、背景和立绘调节均可使用。\n\n### 4. 退出与记忆【已实现】\n\n- “不保存/忘记”：关闭剧情，不写入本次小结。\n- “保存/记住”：AI将剧情总结为不超过200字的客观陈述。\n- User可在确认弹窗内编辑小结，确认后写入主要人物“TA看到的”。\n- 耳房多人互动时，同屋人会分别写入“同屋见闻”。\n- 若自动记事开启，闲聊生成“众谈”，临幸生成“彤录”。\n\n## 二十八、数据联动总览\n\n### 1. 人物改名联动【已实现】\n\n- 更新角色本体姓名。\n- 同步更新御书房信笺、故人信笺、密探信件、奏折、前朝记录、NPC主人姓名和关系图谱键。\n- 宿主正式角色会尝试同步调用角色更新接口。\n\n### 2. 居所联动【已实现】\n\n- 后妃迁宫后，宫殿详情中的居住人物随之变化。\n- 其侍从和宫女自动迁到新宫殿耳房。\n- 暗中探听、耳房名单和多人剧情自动使用新居所。\n\n### 3. 奏折—NPC—早朝联动【已实现】\n\n- 奏折生成和历史奏折可识别前朝NPC。\n- NPC少于60时可补充新NPC；达到60后只能复用现有人物。\n- 早朝读取所有待批、已批、前朝角色、识别到的NPC和最新30条前朝记事。\n- 退朝小结回写在场角色/NPC记忆，并产生前朝记事，成为下一次奏折与早朝的新上下文。\n\n### 4. 剧情—记忆—思绪—记事联动【已实现】\n\n- 玩家确认的剧情小结进入“TA看到的”。\n- 新见闻可触发角色自动沉思，形成“TA的思绪”。\n- 记事聚合角色经历，随后又会被宫殿剧情、信笺、奏折和早朝读取。\n- 关系图谱进入“TA了解的”后，会影响角色在后续剧情中的态度。\n\n## 二十九、当前仍为开发中或受限制的入口\n\n- 首页“调校台”：开发中。\n- 养心殿“独自休息”：仅有提示，尚无正式时间推进。\n- 操作—管理后宫：开发中。\n- 操作—惩罚妃嫔：开发中。\n- 操作—奖赏妃嫔：开发中。\n- 修营缮—修缮宫殿：当前没有可修缮项目。\n- 修营缮两个空置地块：尚无具体建筑。\n- 内务府“随便走走”：尚无正式剧情。\n- 名臣录除谢临渊外的空槽：预留扩展。\n- 角色参考图只能使用宿主已有的角色参考图机制；APP内临时上传图片不能直接作为锁脸参考图。\n- 生图API不保证透明PNG，平台也没有内置抠图接口。\n\n## 三十、玩家最常用的完整闭环\n\n### 1. 后宫剧情闭环\n\n- 建档选择角色并册封后妃 → 赐居宫殿 → 宫殿“窥见一幕”或养心殿“召见/翻牌子” → User输入互动 → 结束时确认小结 → 写入TA看到的 → 自动/手动沉思 → 生成记事 → 下一次剧情继续读取。\n\n### 2. 前朝剧情闭环\n\n- 御书房生成奏折 → 待处理查看全文 → AI代写或手写朱批 → 大臣回禀/帝师商议 → 奏折进入已批 → 乾清宫早朝讨论待批与已批 → 退朝写入朝臣/NPC记忆和前朝记事 → 下一批奏折继续读取。\n\n### 3. NPC与侍从闭环\n\n- 名册新增或批量生成侍从宫女 → 分配后妃主人 → 自动迁入主人宫殿耳房 → 设置侍从房/宫女房背景 → 对话或宠幸并描写同屋反应 → 主要人物与同屋人分别获得记忆 → 在众生相NPC列表中继续查看。\n\n### 4. 个性化闭环\n\n- 置度所修改全局字体、提示词、API、记忆发送量、角色立绘和宫殿图标 → 绘制台调整地图与背景 → 角色语音工作室设置朗读方式 → 所有相关页面即时读取并随存档恢复。\n";

NOVICE_GUIDE_MARKDOWN += "\n\n## 三十一、当前新版重点补充\n\n### 1. 正式账号与云笺阁【已实现】\n\n- 养心殿“操作—飞鸽传书”可进入云笺阁，顶部包含聊天室、问题反馈和私聊。\n- 右上角“账号”用于注册、登录和恢复正式账号；登录后会显示昵称与玩家ID。\n- 玩家ID用于好友、私聊和共享存档权限，不要只凭昵称识别好友。\n- 老云名仍用于兼容旧帖子和旧广场数据，正式账号用于新好友、私聊和共享能力。\n\n### 2. 好友、私聊与共享存档【已实现】\n\n- “好友”弹窗可查看好友列表、收到的申请和发起添加好友。\n- 私聊页可按好友进入一对一消息，也会显示收到的共享存档。\n- 上传共享存档会保存当前完整进度；大存档会自动走分片上传，并在云端保存一份适合分享的轻量副本。\n- 分享权限分为“仅查看”和“允许复制”：仅查看只能预览，允许复制可收入对方忆尘录。\n- 收入好友存档会创建新的本地存档槽，不覆盖当前正在玩的进度。\n\n### 3. 乾清宫、御书房与前朝闭环【已实现】\n\n- 进入乾清宫或开始早朝时，音乐会自动切到“泱泱”。\n- 早朝会读取待批奏折、已批奏折、前朝NPC、朝臣记忆和前朝记事。\n- 退朝后可把朝议小结写入所有在场朝臣/NPC的“TA看到的”，并生成前朝记事。\n- 御书房可批阅奏折、颁布政令、查看已批回禀，也可传召臣子或与帝师商议。\n\n### 4. 冷宫、禁足与后宫状态【已实现】\n\n- 冷宫已有默认背景，冷宫人物不会参与召见、翻牌、随机偶遇和普通宫廷活动。\n- 禁足有到期时间，到期后会自动恢复；未到期时召见会提示剩余时间。\n- 后宫名册中调整居所会同步宫殿详情、耳房归属和后续剧情读取。\n\n### 5. 华清宫与特殊场景【已实现】\n\n- 华清宫是单独的温泉行宫场景，带默认背景、场景说明和规则。\n- 可在华清宫进行多人召见、沐浴、册封等特殊剧情。\n- 华清宫剧情会读取人物人设、世界书、记忆、关系和当前时辰。\n\n### 6. NPC、侍从宫女与众生相【已实现】\n\n- NPC不再只当临时名字，前朝NPC、侍从、宫女都可进入众生相查看记忆。\n- 名册可新增或批量生成侍从宫女，分配主人、忠诚度和耳房。\n- 耳房闲聊、宠幸和暗中探听会读取主人关系、同屋人、忠诚度与历史记忆。\n- 奏折和早朝识别到的新前朝NPC会保存并复用，避免每次都重新编人。\n\n### 7. 置度所与个性化【已实现】\n\n- 置度所可管理提示词、API配置、全局字体、记忆发送量、宫殿图标、角色立绘和自动记事。\n- 奏折详情、待处理列表、已批列表和信笺均有部分独立字体/字号设置。\n- 角色卡导入支持JSON和含嵌入数据的PNG卡；导入后可继续编辑身份、人设、头像和语音。\n";

function parseNoviceGuideMarkdown() {
  const chapters = [];
  let chapter = null;
  let section = null;
  NOVICE_GUIDE_MARKDOWN.split('\n').forEach(rawLine => {
    const line = rawLine.trim();
    if (line.startsWith('## ')) {
      chapter = { title: line.slice(3).trim(), sections: [], items: [] };
      chapters.push(chapter);
      section = null;
    } else if (line.startsWith('### ') && chapter) {
      section = { title: line.slice(4).trim(), items: [] };
      chapter.sections.push(section);
    } else if (line.startsWith('- ') && chapter) {
      (section ? section.items : chapter.items).push(line.slice(2).trim());
    }
  });
  return chapters;
}

function formatNoviceGuideText(text) {
  let safe = String(text || '')
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;');
  safe = safe.replace(/【已实现】/g, '<b style="color:#d6ae55;">【已实现】</b>');
  safe = safe.replace(/【条件功能】/g, '<b style="color:#e6bd68;">【条件功能】</b>');
  safe = safe.replace(/【部分实现】/g, '<b style="color:#e5a96c;">【部分实现】</b>');
  safe = safe.replace(/【开发中】/g, '<b style="color:#ff8f8f;">【开发中】</b>');
  safe = safe.replace(/“([^”]{1,24})”/g, '<span style="color:#d8ba7f;">“$1”</span>');
  return safe;
}

function renderNoviceGuide(body) {
  const chapters = parseNoviceGuideMarkdown();
  body.innerHTML = '';
  body.style.gap = '12px';

  const intro = document.createElement('div');
  intro.style.cssText = 'position:sticky;top:0;z-index:5;flex-shrink:0;background:rgba(13,9,6,0.96);border:1px solid rgba(201,163,106,0.38);border-radius:14px;padding:13px 14px;box-shadow:0 6px 20px rgba(0,0,0,0.32);';
  intro.innerHTML = `<div style="display:flex;align-items:center;justify-content:space-between;gap:10px;"><button id="novice-guide-back" style="background:transparent;border:none;color:#aaa;font-family:inherit;font-size:14px;">‹ 返回指南</button><div style="color:#e8cf9c;font-size:15px;letter-spacing:3px;font-weight:bold;">新手指引</div><div style="width:70px;"></div></div><div style="color:#8f7959;font-size:11px;text-align:center;margin-top:7px;">教程更新：${NOVICE_GUIDE_UPDATED_AT} · 默认收起，按需逐级展开</div>`;
  body.appendChild(intro);

  const quickWrap = document.createElement('div');
  quickWrap.style.cssText = 'flex-shrink:0;background:rgba(0,0,0,0.42);border:1px solid rgba(201,163,106,0.22);border-radius:13px;padding:12px;';
  quickWrap.innerHTML = '<div style="color:#c9a36a;font-size:12px;letter-spacing:2px;margin-bottom:9px;">快捷标题 · 点击直达</div>';
  const quickGrid = document.createElement('div');
  quickGrid.style.cssText = 'display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:7px;max-height:190px;overflow-y:auto;';
  chapters.forEach((item, index) => {
    const button = document.createElement('button');
    button.type = 'button';
    button.dataset.guideJump = String(index);
    button.style.cssText = 'background:rgba(201,163,106,0.09);border:1px solid rgba(201,163,106,0.22);border-radius:9px;color:#cdb58a;padding:8px 7px;font-family:inherit;font-size:11px;line-height:1.45;text-align:left;';
    button.textContent = item.title;
    quickGrid.appendChild(button);
  });
  quickWrap.appendChild(quickGrid);
  body.appendChild(quickWrap);

  chapters.forEach((item, chapterIndex) => {
    const chapterDetails = document.createElement('details');
    chapterDetails.dataset.guideChapter = String(chapterIndex);
    chapterDetails.style.cssText = 'flex-shrink:0;background:rgba(0,0,0,0.48);border:1px solid rgba(201,163,106,0.28);border-radius:13px;overflow:hidden;';
    const chapterSummary = document.createElement('summary');
    chapterSummary.style.cssText = 'list-style:none;cursor:pointer;min-height:48px;box-sizing:border-box;padding:12px 15px;color:#e5ca95;font-size:14px;font-weight:bold;letter-spacing:1.5px;display:flex;justify-content:space-between;align-items:center;';
    chapterSummary.innerHTML = `<span>${formatNoviceGuideText(item.title)}</span><span style="color:#8e7550;font-size:11px;">展开 ▾</span>`;
    chapterDetails.appendChild(chapterSummary);
    const chapterBody = document.createElement('div');
    chapterBody.style.cssText = 'padding:0 12px 12px;display:flex;flex-direction:column;gap:8px;';

    if (item.items.length) {
      const looseList = document.createElement('div');
      looseList.style.cssText = 'padding:5px 8px;color:#c7c0b6;font-size:12px;line-height:1.8;';
      looseList.innerHTML = item.items.map(text => `<div style="display:flex;gap:8px;margin:7px 0;"><span style="color:#c9a36a;">•</span><div>${formatNoviceGuideText(text)}</div></div>`).join('');
      chapterBody.appendChild(looseList);
    }

    item.sections.forEach(sub => {
      const subDetails = document.createElement('details');
      subDetails.style.cssText = 'flex-shrink:0;background:rgba(201,163,106,0.045);border:1px solid rgba(201,163,106,0.16);border-radius:10px;overflow:hidden;';
      const subSummary = document.createElement('summary');
      subSummary.style.cssText = 'list-style:none;cursor:pointer;padding:11px 12px;color:#c9b083;font-size:12px;font-weight:bold;line-height:1.55;';
      subSummary.innerHTML = formatNoviceGuideText(sub.title);
      subDetails.appendChild(subSummary);
      const list = document.createElement('div');
      list.style.cssText = 'padding:0 12px 10px;color:#c7c0b6;font-size:12px;line-height:1.85;';
      list.innerHTML = sub.items.map(text => `<div style="display:flex;gap:8px;margin:8px 0;"><span style="color:#c9a36a;">•</span><div>${formatNoviceGuideText(text)}</div></div>`).join('');
      subDetails.appendChild(list);
      chapterBody.appendChild(subDetails);
    });
    chapterDetails.appendChild(chapterBody);
    body.appendChild(chapterDetails);
  });

  intro.querySelector('#novice-guide-back').onclick = () => {
    document.getElementById('guide-modal')?.remove();
    openGuideModal();
  };
  quickGrid.querySelectorAll('[data-guide-jump]').forEach(button => button.onclick = () => {
    const target = body.querySelector(`[data-guide-chapter="${button.dataset.guideJump}"]`);
    if (!target) return;
    target.open = true;
    target.scrollIntoView({ behavior: 'smooth', block: 'start' });
  });
}

// ===== 指南弹窗 =====
function openGuideModal() {
  const old = document.getElementById('guide-modal');
  if (old) old.remove();

  const modal = document.createElement('div');
  modal.id = 'guide-modal';
  modal.style.cssText = `
    position:fixed; inset:0; z-index:99999;
    background:url('https://www.imgfox.cn/apis/uploads/20260818/cd2a4b22f1ec4748/IMG_9643.jpeg') center/cover no-repeat;
    display:flex; flex-direction:column;
  `;

  const overlay = document.createElement('div');
  overlay.style.cssText = 'position:absolute; inset:0; background:rgba(8,6,4,0.88); backdrop-filter:blur(8px); -webkit-backdrop-filter:blur(8px); z-index:0;';
  modal.appendChild(overlay);

  const wrap = document.createElement('div');
  wrap.style.cssText = 'position:relative; z-index:1; display:flex; flex-direction:column; height:100%; overflow:hidden;';

  // 顶栏
  const header = document.createElement('div');
  header.style.cssText = 'padding-top:max(calc(var(--safe-top,44px) + 24px), 88px); padding-left:16px; padding-right:16px; padding-bottom:14px; display:flex; justify-content:space-between; align-items:center; border-bottom:1px solid rgba(201,163,106,0.2); flex-shrink:0;';
  header.innerHTML = `
    <button id="guide-close" style="background:transparent;border:none;color:#888;font-size:16px;font-family:inherit;">关闭</button>
    <div style="color:var(--primary-color);font-size:18px;font-weight:bold;letter-spacing:5px;font-family:'STZhongsong','STSong',serif;
      background:linear-gradient(to bottom,#ffe9b8,#c9a36a);-webkit-background-clip:text;-webkit-text-fill-color:transparent;
      filter:drop-shadow(0 1px 4px rgba(0,0,0,0.8));">指南</div>
    <div style="width:40px;"></div>
  `;
  wrap.appendChild(header);

  // 内容滚动区
  const body = document.createElement('div');
  body.style.cssText = 'flex:1; min-height:0; overflow-y:auto; -webkit-overflow-scrolling:touch; overscroll-behavior:contain; padding:20px 18px calc(var(--safe-bottom,24px)+20px); display:flex; flex-direction:column; gap:20px;';

  function makeSection(titleIcon, titleText, items) {
    const sec = document.createElement('div');
    sec.style.cssText = 'background:rgba(0,0,0,0.45); border:1px solid rgba(201,163,106,0.25); border-radius:14px; padding:16px; display:flex; flex-direction:column; gap:10px;';

    const titleEl = document.createElement('div');
    titleEl.style.cssText = 'color:var(--primary-color); font-size:15px; font-weight:bold; letter-spacing:3px; font-family:"STZhongsong","STSong",serif; border-bottom:1px solid rgba(201,163,106,0.2); padding-bottom:8px; margin-bottom:2px;';
    titleEl.innerHTML = `<span style="margin-right:6px;">${titleIcon}</span>${titleText}`;
    sec.appendChild(titleEl);

    items.forEach(item => {
      const row = document.createElement('div');
      row.style.cssText = 'display:flex; gap:10px; align-items:flex-start;';
      if (item.num !== undefined) {
        const num = document.createElement('div');
        num.style.cssText = 'flex-shrink:0; width:20px; height:20px; border-radius:50%; background:rgba(201,163,106,0.2); border:1px solid rgba(201,163,106,0.5); color:var(--primary-color); font-size:11px; display:flex; align-items:center; justify-content:center; margin-top:1px;';
        num.textContent = item.num;
        row.appendChild(num);
      }
      const txt = document.createElement('div');
      txt.style.cssText = 'color:#ccc; font-size:13px; line-height:1.8; letter-spacing:0.5px; flex:1;';
      txt.innerHTML = item.text;
      row.appendChild(txt);
      sec.appendChild(row);
    });

    return sec;
  }

  // ── 显眼的新手指引入口：完整教程默认折叠，按章节逐级展开 ──
  const noviceEntry = document.createElement('button');
  noviceEntry.id = 'guide-novice-entry';
  noviceEntry.type = 'button';
  noviceEntry.style.cssText = 'width:100%;text-align:left;background:linear-gradient(135deg,rgba(128,76,23,0.72),rgba(38,25,14,0.9));border:1px solid rgba(229,190,108,0.72);border-radius:16px;padding:16px 15px;color:#f0ddb1;font-family:inherit;box-shadow:0 5px 18px rgba(0,0,0,0.38),inset 0 0 22px rgba(201,163,106,0.09);';
  noviceEntry.innerHTML = `<div style="display:flex;align-items:center;justify-content:space-between;gap:12px;"><div><div style="color:#f2d28d;font-size:16px;font-weight:bold;letter-spacing:3px;">✦ 新手指引 · 完整教程</div><div style="color:#bda77e;font-size:11px;line-height:1.75;margin-top:7px;">覆盖当前全部功能与数据联动<br>章节快捷定位 · 一级一级展开</div></div><div style="color:#e9c87f;font-size:22px;">›</div></div><div style="margin-top:10px;color:#8f7959;font-size:10px;letter-spacing:1px;">更新日期：${NOVICE_GUIDE_UPDATED_AT}</div>`;
  noviceEntry.onclick = () => renderNoviceGuide(body);
  body.appendChild(noviceEntry);

  // ── 须知 ──
  body.appendChild(makeSection('📜', '须知', [
    { num: 1, text: '安装故梦辞以及参与故梦辞测试期间，请<b style="color:var(--primary-color)">勤备份小手机</b>。' },
    { num: 2, text: '关于后续升级方式，我会给新版本压缩包，在<b style="color:var(--primary-color)">应用市场选择「换包」</b>，而不是卸载重装，防止存档损坏。' },
    { num: 3, text: '既然是 char 的前世，所以 APP <b style="color:var(--primary-color)">不会</b>将「故梦辞」里的记忆发给你的 char 看。' },
    { num: 4, text: '默认世界观、思维链和宫规都可以在游戏内自定义，<b style="color:var(--primary-color)">万物皆可自定义。</b>' },
    { num: 5, text: '请在「圣旨」及「圣旨评论区」友善交流，不要发表不友善评论。' },
    { num: 6, text: '目前已开放<b style="color:var(--primary-color)">乾清宫、御书房、养心殿、内务府、东六宫、西六宫、冷宫与华清宫</b>；储秀宫可通过「修营缮」建成。各处包含早朝、奏折信笺、召见休息、后宫与人物管理、普通宫殿剧情、冷宫探望及温泉行宫等玩法。' },
    { num: 7, text: '反馈及建议QQ群：<b style="color:#ffe6a6;background:rgba(201,163,106,0.18);border:1px solid rgba(255,221,144,0.55);border-radius:999px;padding:3px 9px;margin:0 4px;white-space:nowrap;">1107924487</b><button id="guide-copy-feedback-qq" type="button" style="margin-left:6px;border:1px solid rgba(255,221,144,0.6);border-radius:999px;background:rgba(201,163,106,0.22);color:#ffe6a6;padding:4px 10px;font:12px inherit;">复制</button>' },
  ]));

  wrap.appendChild(body);
  modal.appendChild(wrap);
  document.body.appendChild(modal);

  document.getElementById('guide-close').addEventListener('click', () => modal.remove());
  document.getElementById('guide-copy-feedback-qq')?.addEventListener('click', async () => {
    const qq = '1107924487';
    try {
      if (navigator.clipboard?.writeText) {
        await navigator.clipboard.writeText(qq);
      } else {
        const temp = document.createElement('textarea');
        temp.value = qq;
        temp.style.cssText = 'position:fixed;left:-9999px;top:-9999px;';
        document.body.appendChild(temp);
        temp.focus();
        temp.select();
        document.execCommand('copy');
        temp.remove();
      }
      api.ui.toast('QQ群号已复制');
    } catch (err) {
      api.ui.toast('复制失败，请手动复制：' + qq);
    }
  });
}

document.getElementById('btn-back-palace-detail').addEventListener('click', () => {
  const yx = document.getElementById('yangxin-overlay');
  if (yx) yx.remove();
  const ysf = document.getElementById('yushufang-overlay');
  if (ysf) ysf.remove();
  switchView(vMemory);
});

// 宫殿详情页和大地图页的🎵按钮 — 点击直接打开/关闭音乐小窗
document.getElementById('btn-bgm-palace').addEventListener('click', (e) => {
  e.stopPropagation();
  musicPanel.classList.toggle('open');
});
document.getElementById('btn-bgm-map').addEventListener('click', (e) => {
  e.stopPropagation();
  musicPanel.classList.toggle('open');
});

// 宫殿详情页更换背景
document.getElementById('btn-change-bg-palace').addEventListener('click', () => {
  if (!currentDetailPalaceName) return;
  const isNeiFu = currentDetailPalaceName === '内务府';
  pbTitle.innerText = isNeiFu ? `内务府 · 重新布景` : `${currentDetailPalaceName} · 重新绘景`;
  pbPrompt.value = isNeiFu
    ? `真实画风，中国古代皇宫内务府室内，卷宗档案，烛光，华丽，唯美，无人物`
    : `真实画风，中国古代皇宫室外，${currentDetailPalaceName}外景，大气，华丽，唯美，无人物`;
  pbImg.style.display = 'none';
  pbPlaceholder.style.display = 'block';
  pbLoader.style.display = 'none';
  btnPbConfirm.style.display = 'none';
  tempPbDataUrl = null;
  isCourtyardMode = false;
  pbModal.style.display = 'flex';
});

// 大地图更换背景
document.getElementById('btn-change-bg-map').addEventListener('click', () => {
  // 复用绘景弹窗，但覆盖确认逻辑
  pbTitle.innerText = '皇城绘卷 · 重新绘景';
  pbPrompt.value = '仿照故宫样式的，真实画风的，航拍俯视视角的，只有建筑没有人物的地图';
  pbImg.style.display = 'none';
  pbPlaceholder.style.display = 'block';
  pbLoader.style.display = 'none';
  btnPbConfirm.style.display = 'none';
  tempPbDataUrl = null;
  isCourtyardMode = false;
  currentDetailPalaceName = '__MAP__'; // 特殊标记
  pbModal.style.display = 'flex';
});


// === Time Picker ===
let pickerData = { y:1, m:0, d:1, h:0, q:0 }; // 存 index
let timeMode = 'sync'; // 'sync' | 'manual'
let syncTimer = null;
let currentCustomTimeStr = "";
const timeModal = document.getElementById('time-modal');
const maskEl = document.getElementById('picker-mask');
const btnSync = document.getElementById('mode-sync');
const btnManual = document.getElementById('mode-manual');

function updateGlobalTime() {
  if (timeMode === 'sync') {
    const timeStr = getAncientTimeStr(new Date());
    hudTime.innerText = timeStr;
    syncGlobalMemory(timeStr);
  } else {
    hudTime.innerText = currentCustomTimeStr;
    syncGlobalMemory(currentCustomTimeStr);
  }
}

function startSyncTimer() {
  if(syncTimer) clearInterval(syncTimer);
  updateGlobalTime(); // 立即执行一次
  syncTimer = setInterval(updateGlobalTime, 60000); // 每分钟更新一次
}

// 同步时间到所有角色的记忆中（只更新内存，不每次写角色卡，防止高频操作崩溃）
let _lastSyncTimeStr = '';
function syncGlobalMemory(timeStr) {
  if (timeStr === _lastSyncTimeStr) return; // 时间没变就不处理
  _lastSyncTimeStr = timeStr;
  for (const char of selectedCharsData) {
    if (!char.ancientDesc) continue;
    const timePrefix = `【当前游戏时间】：${timeStr}\n`;
    const regex = /【当前游戏时间】：[^\n]*\n/;
    if (regex.test(char.ancientDesc)) {
      char.ancientDesc = char.ancientDesc.replace(regex, timePrefix);
    } else {
      char.ancientDesc = timePrefix + char.ancientDesc;
    }
  }
  // 不在这里写角色卡，改为在实际对话时才写入（避免高频 IO 崩溃）
}

document.getElementById('btn-time-map').addEventListener('click', event => {
  event.stopPropagation();
  openTimePicker();
});

function openTimePicker() {
  timeModal.style.display = 'flex';
  
  if (timeMode === 'sync') {
    btnSync.style.background = 'var(--primary-color)'; btnSync.style.color = '#000';
    btnManual.style.background = 'transparent'; btnManual.style.color = '#888';
    maskEl.style.display = 'flex';
  } else {
    btnManual.style.background = 'var(--primary-color)'; btnManual.style.color = '#000';
    btnSync.style.background = 'transparent'; btnSync.style.color = '#888';
    maskEl.style.display = 'none';
  }
  
  renderPickerCol('col-year', Array.from({length:100}, (_,i) => `永安${i===0?'元':convertNumberToChinese(i+1)}年`), pickerData.y);
  renderPickerCol('col-month', ancientMonths, pickerData.m);
  renderPickerCol('col-day', Array.from({length:31}, (_,i) => {
    let d = i+1;
    if(d<=10) return "初" + ["一","二","三","四","五","六","七","八","九","十"][d-1];
    if(d<20) return "十" + (d===10?"":["一","二","三","四","五","六","七","八","九"][d-11]);
    if(d===20) return "二十";
    if(d<30) return "廿" + ["一","二","三","四","五","六","七","八","九"][d-21];
    return d===30 ? "三十" : "三十一";
  }), pickerData.d);
  
  renderPickerColAdvanced('col-hour', ancientHours, pickerData.h);
  renderPickerColAdvanced('col-quarter', ancientQuarters, pickerData.q);
}

btnSync.addEventListener('click', () => {
  timeMode = 'sync';
  btnSync.style.background = 'var(--primary-color)'; btnSync.style.color = '#000';
  btnManual.style.background = 'transparent'; btnManual.style.color = '#888';
  maskEl.style.display = 'flex';
});

btnManual.addEventListener('click', () => {
  timeMode = 'manual';
  btnManual.style.background = 'var(--primary-color)'; btnManual.style.color = '#000';
  btnSync.style.background = 'transparent'; btnSync.style.color = '#888';
  maskEl.style.display = 'none';
});

function renderPickerCol(id, items, defaultIdx) {
  const col = document.getElementById(id);
  col.innerHTML = '<div class="picker-spacer"></div>';
  items.forEach((item, idx) => {
    const div = document.createElement('div');
    div.className = 'picker-item';
    div.innerText = item;
    div.dataset.idx = idx;
    col.appendChild(div);
  });
  col.innerHTML += '<div class="picker-spacer"></div>';
  
  // 滚动对齐
  setTimeout(() => {
    col.scrollTop = defaultIdx * 40;
    updatePickerStyle(col);
  }, 10);
  
  col.onscroll = () => {
    clearTimeout(col.scrollTimer);
    col.scrollTimer = setTimeout(() => {
      const idx = Math.round(col.scrollTop / 40);
      col.scrollTo({ top: idx * 40, behavior: 'smooth' });
      updatePickerStyle(col);
    }, 150);
  };
}

function renderPickerColAdvanced(id, itemsObj, defaultIdx) {
  const col = document.getElementById(id);
  col.innerHTML = '<div class="picker-spacer"></div>';
  itemsObj.forEach((item, idx) => {
    const div = document.createElement('div');
    div.className = 'picker-item';
    div.dataset.idx = idx;
    div.innerHTML = `<div>${item.name}</div><div class="p-note">${item.note}</div>`;
    col.appendChild(div);
  });
  col.innerHTML += '<div class="picker-spacer"></div>';
  
  setTimeout(() => { col.scrollTop = defaultIdx * 40; updatePickerStyle(col); }, 10);
  col.onscroll = () => {
    clearTimeout(col.scrollTimer);
    col.scrollTimer = setTimeout(() => {
      const idx = Math.round(col.scrollTop / 40);
      col.scrollTo({ top: idx * 40, behavior: 'smooth' });
      updatePickerStyle(col);
    }, 150);
  };
}

function updatePickerStyle(col) {
  const centerIdx = Math.round(col.scrollTop / 40);
  const items = col.querySelectorAll('.picker-item');
  items.forEach(item => {
    if (parseInt(item.dataset.idx) === centerIdx) {
      item.style.color = 'var(--primary-color)';
      item.style.fontWeight = 'bold';
    } else {
      item.style.color = '#888';
      item.style.fontWeight = 'normal';
    }
  });
  
  // 保存状态
  if(col.id === 'col-year') pickerData.y = centerIdx;
  if(col.id === 'col-month') pickerData.m = centerIdx;
  if(col.id === 'col-day') pickerData.d = centerIdx;
  if(col.id === 'col-hour') pickerData.h = centerIdx;
  if(col.id === 'col-quarter') pickerData.q = centerIdx;
}

document.getElementById('btn-cancel-time').addEventListener('click', () => {
  timeModal.style.display = 'none';
});

document.getElementById('btn-confirm-time').addEventListener('click', () => {
  if (timeMode === 'manual') {
    const yStr = `永安${pickerData.y===0?'元':convertNumberToChinese(pickerData.y+1)}年`;
    const mStr = ancientMonths[pickerData.m];
    
    let d = pickerData.d + 1;
    let dStr = "";
    if(d<=10) dStr = "初" + ["一","二","三","四","五","六","七","八","九","十"][d-1];
    else if(d<20) dStr = "十" + (d===10?"":["一","二","三","四","五","六","七","八","九"][d-11]);
    else if(d===20) dStr = "二十";
    else if(d<30) dStr = "廿" + ["一","二","三","四","五","六","七","八","九"][d-21];
    else dStr = d===30 ? "三十" : "三十一";
    
    const hStr = ancientHours[pickerData.h].name;
    const qStr = ancientQuarters[pickerData.q].name;
    
    currentCustomTimeStr = `${yStr}${mStr}${dStr} ${hStr}${qStr}`;
  }
  
  updateGlobalTime();
  if (timeMode === 'sync') startSyncTimer();
  else if (syncTimer) clearInterval(syncTimer);
  
  timeModal.style.display = 'none';
});

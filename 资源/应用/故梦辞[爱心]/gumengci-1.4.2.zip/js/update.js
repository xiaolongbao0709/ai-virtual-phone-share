// ===== 云更新：检查版本并把新版 ZIP 下载到设备 =====
const GMC_UPDATE_MANIFEST_URL = 'https://gumengci-updates-5020.netlify.app/latest.json';

function gmcCompareVersions(left, right) {
  const normalize = value => String(value || '')
    .replace(/^v/i, '')
    .split(/[.+-]/)
    .map(part => Number.parseInt(part, 10) || 0);
  const a = normalize(left);
  const b = normalize(right);
  const length = Math.max(a.length, b.length);
  for (let index = 0; index < length; index += 1) {
    const difference = (a[index] || 0) - (b[index] || 0);
    if (difference !== 0) return difference;
  }
  return 0;
}

function gmcFormatBytes(bytes) {
  const size = Number(bytes);
  if (!Number.isFinite(size) || size <= 0) return '未知大小';
  if (size < 1024 * 1024) return `${Math.ceil(size / 1024)} KB`;
  return `${(size / 1024 / 1024).toFixed(2)} MB`;
}

function gmcResolveUpdateUrl(value) {
  return new URL(String(value || ''), GMC_UPDATE_MANIFEST_URL).href;
}

async function gmcGetInstalledVersion() {
  try {
    const manifest = await api.app.getManifest();
    return String(manifest?.version || '0.0.0');
  } catch (error) {
    return '0.0.0';
  }
}

async function gmcFetchLatestVersion() {
  const separator = GMC_UPDATE_MANIFEST_URL.includes('?') ? '&' : '?';
  const response = await api.network.fetch({
    url: `${GMC_UPDATE_MANIFEST_URL}${separator}t=${Date.now()}`,
    method: 'GET',
    proxy: true,
    timeoutMs: 20000
  });
  if (!response?.ok) {
    throw new Error(`更新服务器返回 HTTP ${response?.status || 0}`);
  }
  let data = response.json;
  if (!data && response.text) {
    try { data = JSON.parse(response.text); } catch (error) {}
  }
  if (!data || data.appId !== 'custom-app' || !data.version || !data.packageUrl) {
    throw new Error('云端版本清单格式不正确');
  }
  return data;
}

function gmcCreateUpdateModal() {
  document.getElementById('gmc-update-modal')?.remove();
  const modal = document.createElement('div');
  modal.id = 'gmc-update-modal';
  modal.style.cssText = 'position:fixed;inset:0;z-index:100002;background:rgba(0,0,0,.84);display:flex;align-items:center;justify-content:center;padding:18px;touch-action:pan-y;';
  modal.innerHTML = `
    <div style="width:min(410px,92vw);max-height:min(560px,82vh);overflow:auto;background:rgba(26,20,15,.98);border:1px solid rgba(201,163,106,.55);border-radius:8px;box-shadow:0 18px 55px rgba(0,0,0,.7);padding:20px;color:#e9ddc9;font-family:'STSong','Noto Serif CJK SC',serif;touch-action:pan-y;">
      <div style="text-align:center;color:var(--primary-color);font-size:20px;letter-spacing:6px;font-weight:bold;">云更新</div>
      <div id="gmc-update-current" style="margin-top:14px;text-align:center;color:#a99579;font-size:12px;">正在读取当前版本...</div>
      <div id="gmc-update-status" style="margin-top:16px;min-height:86px;padding:14px;border:1px solid rgba(201,163,106,.2);background:rgba(201,163,106,.06);border-radius:6px;font-size:13px;line-height:1.8;text-align:center;">正在检查云端版本...</div>
      <div id="gmc-update-actions" style="display:flex;gap:10px;margin-top:16px;"></div>
      <div style="margin-top:14px;color:#8f806b;font-size:11px;line-height:1.7;text-align:center;">下载完成后，请回到 float 的应用管理中选择同名 ZIP 换包。应用 ID 不变，原有存档会保留。</div>
    </div>`;
  modal.addEventListener('click', event => {
    if (event.target === modal) modal.remove();
  });
  document.body.appendChild(modal);
  return modal;
}

function gmcAddUpdateButton(container, label, onClick, primary = false) {
  const button = document.createElement('button');
  button.type = 'button';
  button.textContent = label;
  button.style.cssText = `flex:1;padding:11px 8px;border-radius:4px;font-family:inherit;font-size:13px;letter-spacing:1px;${primary ? 'background:var(--primary-color);color:#17100a;border:1px solid var(--primary-color);font-weight:bold;' : 'background:transparent;color:#b9a78d;border:1px solid rgba(201,163,106,.35);'}`;
  button.addEventListener('click', onClick);
  container.appendChild(button);
  return button;
}

function gmcSetUpdateBadge(hasUpdate) {
  const button = document.getElementById('btn-cloud-update');
  if (!button) return;
  button.style.position = button.style.position || 'relative';
  let badge = button.querySelector('.gmc-update-badge');
  if (!hasUpdate) {
    badge?.remove();
    button.removeAttribute('data-has-update');
    return;
  }
  button.dataset.hasUpdate = 'true';
  if (!badge) {
    badge = document.createElement('span');
    badge.className = 'gmc-update-badge';
    badge.textContent = '!';
    badge.style.cssText = 'position:absolute;right:12px;top:8px;width:16px;height:16px;border-radius:50%;background:#d94b3d;color:#fff;border:1px solid rgba(255,232,196,.85);box-shadow:0 0 9px rgba(217,75,61,.65);font-family:Arial,sans-serif;font-size:12px;font-weight:bold;line-height:16px;text-align:center;letter-spacing:0;pointer-events:none;';
    button.appendChild(badge);
  }
}

async function gmcCheckUpdateBadgeSilently() {
  try {
    const [currentVersion, latest] = await Promise.all([
      gmcGetInstalledVersion(),
      gmcFetchLatestVersion()
    ]);
    gmcSetUpdateBadge(gmcCompareVersions(latest.version, currentVersion) > 0);
  } catch (error) {
    gmcSetUpdateBadge(false);
  }
}

async function openGmcUpdatePanel() {
  const modal = gmcCreateUpdateModal();
  const currentNode = modal.querySelector('#gmc-update-current');
  const statusNode = modal.querySelector('#gmc-update-status');
  const actionsNode = modal.querySelector('#gmc-update-actions');
  const close = () => modal.remove();
  let currentVersion = '0.0.0';

  try {
    currentVersion = await gmcGetInstalledVersion();
    currentNode.textContent = `当前版本：${currentVersion}`;
    const latest = await gmcFetchLatestVersion();
    actionsNode.innerHTML = '';

    if (gmcCompareVersions(latest.version, currentVersion) <= 0) {
      statusNode.innerHTML = `<div style="color:#d7bd91;font-size:15px;margin-bottom:6px;">已是最新版本</div><div>云端版本：${latest.version}</div>`;
      gmcAddUpdateButton(actionsNode, '关闭', close, true);
      return;
    }

    const packageUrl = gmcResolveUpdateUrl(latest.packageUrl);
    statusNode.innerHTML = `
      <div style="color:#e2c68f;font-size:16px;margin-bottom:5px;">发现新版本 ${latest.version}</div>
      <div style="color:#b9a78d;">安装包：${gmcFormatBytes(latest.size)}</div>
      <div style="margin-top:8px;color:#d0c0a8;">${String(latest.changelog || '版本更新').replace(/[<>]/g, '')}</div>`;

    gmcAddUpdateButton(actionsNode, '稍后', close, false);
    const download = document.createElement('a');
    download.href = packageUrl;
    download.download = String(latest.fileName || `故梦辞-${latest.version}.zip`);
    download.textContent = `下载 ${latest.version}`;
    download.style.cssText = 'flex:1;padding:11px 8px;border-radius:4px;background:var(--primary-color);color:#17100a;border:1px solid var(--primary-color);font-family:inherit;font-size:13px;font-weight:bold;letter-spacing:1px;text-align:center;text-decoration:none;';
    download.addEventListener('click', () => {
      statusNode.innerHTML += '<div style="margin-top:10px;color:#9fc08e;">已唤起系统下载，请在手机“文件/下载”中查看 ZIP。</div>';
    });
    actionsNode.appendChild(download);
  } catch (error) {
    currentNode.textContent = `当前版本：${currentVersion}`;
    statusNode.innerHTML = `<div style="color:#d38b7c;margin-bottom:7px;">检查失败</div><div>${String(error?.message || '请检查网络后重试').replace(/[<>]/g, '')}</div>`;
    actionsNode.innerHTML = '';
    gmcAddUpdateButton(actionsNode, '关闭', close, false);
    gmcAddUpdateButton(actionsNode, '重新检查', () => {
      modal.remove();
      openGmcUpdatePanel();
    }, true);
  }
}

window.openGmcUpdatePanel = openGmcUpdatePanel;
window.gmcCheckUpdateBadgeSilently = gmcCheckUpdateBadgeSilently;

window.addEventListener('DOMContentLoaded', () => {
  document.getElementById('btn-cloud-update')?.addEventListener('click', openGmcUpdatePanel);
  gmcCheckUpdateBadgeSilently();
});

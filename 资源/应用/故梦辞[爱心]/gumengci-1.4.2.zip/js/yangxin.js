

// 养心殿总录界面
let currentYxTab = 'hougong';

function openYangXinRecords() {
  const old = document.getElementById('yx-records-modal');
  if (old) old.remove();

  const modal = document.createElement('div');
  modal.id = 'yx-records-modal';
  modal.style.cssText = 'position:fixed; inset:0; z-index:99999; background:rgba(0,0,0,0.85); display:flex; flex-direction:column;';

  // 卷轴容器
  const scrollContainer = document.createElement('div');
  scrollContainer.className = 'scroll-container';
  
  // 将返回按钮、标题放在顶层
  const header = document.createElement('div');
  header.style.cssText = 'position:absolute; top:calc(var(--safe-top) + 12px); left:16px; right:16px; z-index:10; display:flex; justify-content:space-between; align-items:center; pointer-events:none;';
  header.innerHTML = `
    <button id="btn-close-yxrec" style="background:transparent; border:none; color:#ddd; font-size:16px; text-shadow:0 1px 2px #000; padding:8px; pointer-events:auto;">‹ 返回</button>
    <div style="color:#ffe9b8; font-size:18px; font-weight:bold; letter-spacing:4px; font-family:'STZhongsong','STSong',serif; text-shadow:0 2px 4px #000; pointer-events:none;">记事总录</div>
    <div style="width:48px;"></div>
  `;
  modal.appendChild(header);

  // 卷轴内部内容区
  const paneWrap = document.createElement('div');
  paneWrap.className = 'scroll-content-area';
  paneWrap.style.display = 'flex';
  paneWrap.style.flexDirection = 'column';
  paneWrap.style.pointerEvents = 'auto';
  
  // 将 Tab 放在卷轴内部，代替之前的 header 里的 Tab
  const tabBar = document.createElement('div');
  tabBar.style.cssText = 'display:flex; justify-content:center; gap:12px; margin-bottom:12px; flex-shrink:0;';
  
  const tabs = [
    { id: 'hougong', label: '后宫' },
    { id: 'qianchao', label: '前朝' },
    { id: 'qita', label: '秘闻' }
  ];
  
  tabs.forEach(t => {
    const btn = document.createElement('button');
    btn.dataset.id = t.id;
    btn.className = 'yx-tab-btn';
    // 调整样式以适应卷轴内部的纸张颜色
    btn.style.cssText = `padding:4px 12px; border-radius:12px; font-size:13px; font-family:"STZhongsong","STSong",serif; letter-spacing:2px; transition:all 0.2s; ${currentYxTab === t.id ? 'background:rgba(201,163,106,0.25); color:#5e3a11; border:1px solid #8a6d3b; font-weight:bold;' : 'background:transparent; color:#888; border:1px solid #888;'}`;
    btn.innerText = t.label;
    btn.onclick = () => {
      currentYxTab = t.id;
      paneWrap.querySelectorAll('.yx-tab-btn').forEach(b => {
        b.style.background = 'transparent'; b.style.color = '#888'; b.style.borderColor = '#888'; b.style.fontWeight = 'normal';
      });
      btn.style.background = 'rgba(201,163,106,0.25)'; btn.style.color = '#5e3a11'; btn.style.borderColor = '#8a6d3b'; btn.style.fontWeight = 'bold';
      renderAllRecordsPane(pane);
    };
    tabBar.appendChild(btn);
  });
  paneWrap.appendChild(tabBar);
  
  // 生成组记事按钮 (适配纸张颜色)
  const btnGroupGen = document.createElement('button');
  btnGroupGen.id = 'btn-yx-group-gen';
  btnGroupGen.style.cssText = 'width:100%; background:rgba(201,163,106,0.15); border:1px solid #8a6d3b; color:#5e3a11; padding:8px; border-radius:8px; font-size:13px; font-weight:bold; letter-spacing:2px; margin-bottom:10px; flex-shrink:0; font-family:"STZhongsong","STSong",serif;';
  btnGroupGen.innerText = '✦ 翰林落墨';
  btnGroupGen.onclick = async () => {
    const timeStr = hudTime ? hudTime.innerText : '未知时间';
    btnGroupGen.innerText = '撰写中...';
    btnGroupGen.disabled = true;

    if (currentYxTab === 'qita') {
      // 秘闻生成逻辑
      // 我们需要给出一个只包含 NPC 后台信息，不包含主角人设的提示词
      const sysPrompt = `你是一个古代文人，擅长撰写雅致、含蓄、充满古风韵味但又极度劲爆的宫廷与京城秘闻。
当前游戏时间：${timeStr}。
请撰写8条近期的【秘闻】（京城中发生的事情，例如谁家妻子丈夫出轨，京城谁家仗势欺人，谁家女儿儿子嫡庶争斗，谁家未婚男女在寺庙偷情等等）。
要求：
1. 越劲爆越好。
2. 由于目前系统未提供显式的 NPC 列表，请你自行捏造出合适的人名和家族背景（例如某某尚书之子、某某侯府千金）。
3. 每条记事的字数控制在 20-40 字左右，语言必须具有古韵古风。
4. 输出格式必须为 JSON 数组，包含8个对象，格式如下：
[
  { "time": "永安xxxx年x月", "owner": "捏造的人名", "text": "记事内容..." },
  ...
]
绝对不要输出 JSON 以外的任何分析或废话。`;

      try {
        const res = await api.ai.chat({ messages:[{role:"user", content:sysPrompt}] });
        const text = typeof res === 'string' ? res : (res?.content ?? res?.text ?? '');
        
        const jsonMatch = text.match(/\[\s*\{[\s\S]*\}\s*\]/);
        if (jsonMatch) {
          const arr = JSON.parse(jsonMatch[0]);
          if (!window._qitaRecords) window._qitaRecords = [];
          
          arr.reverse().forEach(item => {
            if (item.time && item.text) {
               const recId = generateId();
               window._qitaRecords.unshift({ id: recId, time: item.time, text: item.text, owner: item.owner || '无名氏', type: 'ai', tags: ['秘闻'] });
            }
          });
          
          // 保存秘闻到存档（这里存到外层，不挂在具体 char 下面）
          await saveProgress({ qitaRecords: window._qitaRecords });
          renderAllRecordsPane(pane);
        } else {
          api.ui.toast("AI 返回格式错误");
        }
      } catch(e) {
        console.error(e);
        api.ui.toast("秘闻生成失败");
      } finally {
        btnGroupGen.innerText = '✦ 让翰林院撰写近期小记';
        btnGroupGen.disabled = false;
      }
      return;
    }
    
    // 后宫和前朝的生成逻辑
    let targetChars = [];
    let groupName = "";
    if (currentYxTab === 'hougong') {
      targetChars = selectedCharsData.filter(c => c.ancientRole === '后妃' && !(typeof isCharacterUnavailableForActivity === 'function' && isCharacterUnavailableForActivity(c)));
      groupName = "后宫妃嫔";
    } else if (currentYxTab === 'qianchao') {
      // 左相、右相、臣子等
      targetChars = [...selectedCharsData.filter(c => c.ancientRole !== '后妃'), XLY_CHAR]
        .filter((char, index, list) => list.findIndex(item => (item.id || item.name) === (char.id || char.name)) === index);
      groupName = "前朝人物";
    }
    
    if (currentYxTab === 'qianchao' && targetChars.length === 0) {
      // 虽然没有角色，但要求可以自行捏造，所以我们把 targetChars 置空，让 AI 自己捏
    } else if (currentYxTab === 'hougong' && targetChars.length === 0) {
      api.ui.toast(`当前没有${groupName}`);
      btnGroupGen.innerText = '✦ 让翰林院撰写近期小记';
      btnGroupGen.disabled = false;
      return;
    }
    
    let allCharsInfo = "";
    if (targetChars.length > 0) {
      allCharsInfo = targetChars.map(c => {
        let desc = c.ancientDescOriginal || c.ancientDesc.replace(/^【当前游戏时间】：[^\n]*\n?/, '').replace(/【当前后宫位份体系（由高到低）】[\s\S]*/, '');
        let memoryText = (c.memorySeen || []).map(m => m.text).join('\n') || '无';
        return `【${c.name}】身份/位份：${c.ancientRole}${c.assignedRank ? '('+c.assignedRank+')' : ''}\n设定：${desc}\n记忆：${memoryText}`;
      }).join('\n\n');
    }
    
    let sysPrompt = "";
    if (currentYxTab === 'qianchao') {
      sysPrompt = `你是一个古代文人，擅长撰写雅致、含蓄、充满古风韵味的宫廷与朝堂笔记。
当前游戏时间：${timeStr}。
请为前朝人物（包括帝师、左右相、大臣及自定义身份人物）生成8条近期的【记事】（前朝争斗、政务，又或者是人物家务事如离婚、嫁娶等相关的）。
格式文风和后宫记事一样，区别在于内容必须是前朝相关的。
其中有四条是基于以下真实的前朝人物（如果有）：
${allCharsInfo || '（暂无真实前朝角色）'}
另外四条，请你自行捏造出其他前朝大臣的人名和事迹。
每条记事必须明确归属于某一个角色（真实或捏造的），并在 "owner" 字段填入该角色的姓名。
输出格式同上，JSON 数组包含8个对象，必须有 time, owner, text。`;
    } else {
      sysPrompt = customPrompts.generateGlobalRecords || defaultPrompts.generateGlobalRecords;
      sysPrompt = sysPrompt
        .replace('{{timeStr}}', timeStr)
        .replace('{{groupName}}', groupName)
        .replace('{{allCharsInfo}}', allCharsInfo);
    }
      
    try {
      const res = await api.ai.chat({ messages:[{role:"user", content:sysPrompt}] });
      const text = typeof res === 'string' ? res : (res?.content ?? res?.text ?? '');
      
      const jsonMatch = text.match(/\[\s*\{[\s\S]*\}\s*\]/);
      if (jsonMatch) {
        const arr = JSON.parse(jsonMatch[0]);
        let changed = false;
        
        arr.reverse().forEach(item => {
          if (item.time && item.text && item.owner) {
             const char = targetChars.find(c => c.name === item.owner);
             if (char) {
               const recId = generateId();
               if (!char.records) char.records = [];
               char.records.unshift({ id: recId, time: item.time, text: item.text, type: 'ai', tags: [] });
               
               targetChars.forEach(other => {
                 if (other.id !== char.id && item.text.includes(other.name)) {
                   if (!other.records) other.records = [];
                   other.records.unshift({ id: recId, time: item.time, text: item.text, type: 'ai', tags: ['涉客'] });
                 }
               });
               changed = true;
             } else if (currentYxTab === 'qianchao') {
               // 自己捏造的角色，挂在前朝全区记录里
               if (!window._qianchaoRecords) window._qianchaoRecords = [];
               window._qianchaoRecords.unshift({ id: generateId(), time: item.time, text: item.text, owner: item.owner, type: 'ai', tags: ['前朝'] });
               changed = true;
             }
          }
        });
        
        if (changed) {
          window._xlyRecords = XLY_CHAR.records;
          await saveProgress({ xlyRecords: XLY_CHAR.records, characters: selectedCharsData, qianchaoRecords: window._qianchaoRecords });
          renderAllRecordsPane(pane);
        }
      } else {
        api.ui.toast("AI 返回格式错误");
      }
    } catch(e) {
      console.error(e);
      api.ui.toast("生成失败");
    } finally {
      btnGroupGen.innerText = '✦ 让翰林院撰写近期小记';
      btnGroupGen.disabled = false;
    }
  };
  paneWrap.appendChild(btnGroupGen);

  const pane = document.createElement('div');
  pane.id = 'yx-records-pane';
  pane.style.cssText = 'display:flex; flex-direction:column; gap:6px;';
  paneWrap.appendChild(pane);
  
  scrollContainer.appendChild(paneWrap);
  modal.appendChild(scrollContainer);
  document.body.appendChild(modal);

  // 绑定返回按钮事件，因为 header 已移到 modal 的直接子元素下
  const closeBtn = document.getElementById('btn-close-yxrec');
  if (closeBtn) {
    closeBtn.onclick = () => modal.remove();
  }
  
  // 初始渲染
  renderAllRecordsPane(pane);
}

function renderAllRecordsPane(pane) {
  if (!pane) return;
  pane.innerHTML = '';
  
  let allRecs = [];
  
  if (currentYxTab === 'qita') {
    // 秘闻专区
    const qitaRecs = window._qitaRecords || [];
    qitaRecs.forEach(r => {
      allRecs.push({ char: { name: r.owner || '秘闻' }, rec: r });
    });
  } else if (currentYxTab === 'qianchao') {
    // 前朝专区：包括左相右相臣子的个人记事 + 捏造的前朝记事
    const chars = [...selectedCharsData.filter(c => c.ancientRole !== '后妃'), XLY_CHAR]
      .filter((char, index, list) => list.findIndex(item => (item.id || item.name) === (char.id || char.name)) === index);
    const seenRecords = new Set();
    chars.forEach(c => {
      if (c.records) {
        c.records.forEach(r => {
          if ((r.tags || []).includes('众谈')) return;
          const recordKey = (r.tags || []).includes('众闻') ? `众闻:${r.text}` : (r.id || `${r.time}:${r.text}`);
          if (!seenRecords.has(recordKey)) {
            seenRecords.add(recordKey);
            allRecs.push({ char: c, rec: r });
          }
        });
      }
    });
    const qcRecs = window._qianchaoRecords || [];
    qcRecs.filter(r => !(r.tags || []).includes('众谈')).forEach(r => {
      allRecs.push({ char: { name: r.owner }, rec: r });
    });
  } else {
    // 后宫专区
    const chars = selectedCharsData.filter(c => c.ancientRole === '后妃');
    const seenRecords = new Set();
    chars.forEach(c => {
      if (c.records) {
        c.records.forEach(r => {
          const recordKey = (r.tags || []).includes('众闻') ? `众闻:${r.text}` : (r.id || `${r.time}:${r.text}`);
          if (!seenRecords.has(recordKey)) {
            seenRecords.add(recordKey);
            allRecs.push({ char: c, rec: r });
          }
        });
      }
    });
  }
  
  // 简单按内部ID排序（包含了时间戳）
  allRecs.sort((a, b) => b.rec.id.localeCompare(a.rec.id));
  
  if (allRecs.length === 0) {
    pane.innerHTML += '<div style="color:#8a6d3b; text-align:center; padding:20px; font-size:13px; font-family:"STZhongsong","STSong",serif; opacity:0.8;">暂无记事，落墨留痕。</div>';
    return;
  }
  
  allRecs.forEach(item => {
    const el = renderSingleRecord(item.rec, item.char, true);
    // 同样给卷轴里的记事加上特殊类名
    const inner = el.querySelector('div');
    if (inner) {
      inner.classList.add('scroll-record-item');
      const timeEl = inner.querySelector('span');
      if (timeEl) timeEl.classList.add('rec-time');
      const textEl = inner.querySelector('div:last-child');
      if (textEl) textEl.classList.add('rec-text');
    }
    pane.appendChild(el);
  });
}

// 供其他地方直接调用的方法（兼容）
function renderAllRecordsPaneFallback() {
  const pane = document.getElementById('yx-records-pane');
  if (pane) renderAllRecordsPane(pane);
}

// ===== 养心殿专属界面 =====
function renderYangXinDian() {
  // 清空旧的养心殿 overlay
  const old = document.getElementById('yangxin-overlay');
  if (old) old.remove();

  const overlay = document.createElement('div');
  overlay.id = 'yangxin-overlay';
  overlay.style.cssText = 'position:absolute; inset:0; z-index:30; pointer-events:none;';

  // ── 左侧竖排菱形按钮栏 ──
  const leftBar = document.createElement('div');
  leftBar.style.cssText = `
    position:absolute; left:0; top:50%; transform:translateY(-50%);
    display:flex; flex-direction:column; align-items:center; gap:18px;
    padding:20px 0 20px 14px; pointer-events:auto;
  `;

  const leftItems = [
    { label: '御书房', icon: `<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/><polyline points="14 2 14 8 20 8"/><line x1="16" y1="13" x2="8" y2="13"/><line x1="16" y1="17" x2="8" y2="17"/><line x1="10" y1="9" x2="8" y2="9"/></svg>`, action: () => {
        const yxd = document.getElementById('yangxin-overlay');
        if (yxd) yxd.remove();
        openPalaceDetail('御书房');
    } },
    { label: XLY_CHAR.name, icon: null, action: () => {
        XLY_CHAR.indoorBgUrl = palaceDetails['养心殿'].bgUrl;
        openIndoorView('养心殿', XLY_CHAR.name, XLY_CHAR);
    } },
    { label: '云笺阁', icon: `<svg width="19" height="19" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.55" stroke-linecap="round" stroke-linejoin="round"><path d="M4 5.5h16v11.8a1.7 1.7 0 0 1-1.7 1.7H5.7A1.7 1.7 0 0 1 4 17.3z"/><path d="m4 6 8 6 8-6"/><path d="M7.5 15.5h4"/><path d="M14.5 15.5h2"/></svg>`, action: () => {
        if (typeof openGmcCommunityPanel === 'function') openGmcCommunityPanel();
        else api.ui.toast('云笺阁正在加载，请稍后再试');
    } },
  ];

  leftItems.forEach(item => {
    const wrap = document.createElement('div');
    wrap.style.cssText = 'display:flex; flex-direction:column; align-items:center; gap:6px; cursor:pointer;';

    // 菱形容器
    const diamond = document.createElement('div');
    diamond.style.cssText = `
      width:44px; height:44px;
      background:rgba(10,8,6,0.55);
      backdrop-filter:blur(12px); -webkit-backdrop-filter:blur(12px);
      border:1px solid rgba(201,163,106,0.55);
      transform:rotate(45deg);
      display:flex; align-items:center; justify-content:center;
      box-shadow:0 2px 12px rgba(0,0,0,0.5), inset 0 0 8px rgba(201,163,106,0.08);
      transition:all 0.22s;
      flex-shrink:0;
    `;

    // 内容（反向旋转回来）
    const inner = document.createElement('div');
    inner.style.cssText = 'transform:rotate(-45deg); display:flex; align-items:center; justify-content:center; width:100%; height:100%;';

    if (item.icon) {
      inner.style.color = 'rgba(201,163,106,0.9)';
      inner.innerHTML = item.icon;
    } else {
      // 谢临渊用头像
      const cfg = getScenarioAvatarCfg('xly');
      const avatarUrl = (cfg && cfg.url) ? cfg.url : SCENARIO_DEFAULT_AVATAR;
      const img = document.createElement('img');
      img.src = avatarUrl;
      img.style.cssText = 'width:32px; height:32px; border-radius:50%; object-fit:cover; border:1px solid rgba(201,163,106,0.5);';
      img.onerror = () => { img.style.display='none'; inner.textContent='臣'; inner.style.fontSize='14px'; inner.style.color='var(--primary-color)'; };
      inner.appendChild(img);
    }

    diamond.appendChild(inner);

    // 标签
    const labelEl = document.createElement('div');
    labelEl.style.cssText = `
      font-size:11px; color:rgba(201,163,106,0.85); letter-spacing:2px;
      font-family:'STZhongsong','STSong',serif;
      text-shadow:0 1px 4px rgba(0,0,0,0.9);
      white-space:nowrap;
    `;
    labelEl.textContent = item.label;

    // 点击 & 悬停效果
    wrap.addEventListener('click', item.action);
    wrap.addEventListener('touchstart', () => {
      diamond.style.background = 'rgba(201,163,106,0.18)';
      diamond.style.borderColor = 'rgba(201,163,106,0.9)';
      diamond.style.boxShadow = '0 0 16px rgba(201,163,106,0.3), inset 0 0 8px rgba(201,163,106,0.15)';
    }, {passive:true});
    wrap.addEventListener('touchend', () => {
      setTimeout(() => {
        diamond.style.background = 'rgba(10,8,6,0.55)';
        diamond.style.borderColor = 'rgba(201,163,106,0.55)';
        diamond.style.boxShadow = '0 2px 12px rgba(0,0,0,0.5), inset 0 0 8px rgba(201,163,106,0.08)';
      }, 200);
    }, {passive:true});

    wrap.appendChild(diamond);
    wrap.appendChild(labelEl);
    leftBar.appendChild(wrap);
  });

  overlay.appendChild(leftBar);

  // ── 底部精致操作栏 ──
  const bottomBar = document.createElement('div');
  bottomBar.style.cssText = `
    position:absolute; bottom:calc(var(--safe-bottom) + 16px);
    left:50%; transform:translateX(-50%);
    width:92%; max-width:420px;
    background:rgba(12,10,8,0.52);
    backdrop-filter:blur(20px); -webkit-backdrop-filter:blur(20px);
    border-radius:28px;
    border-bottom:1px solid rgba(201,163,106,0.35);
    padding:10px 8px calc(10px);
    display:flex; justify-content:space-around; align-items:center;
    pointer-events:auto;
    box-shadow:0 8px 32px rgba(0,0,0,0.45);
  `;

  const bottomItems = [
    { label: '休息', icon: `<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round"><path d="M21 12.79A9 9 0 1 1 11.21 3 7 7 0 0 0 21 12.79z"/></svg>`, action: () => openRestMenu() },
    { label: '召见', icon: `<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round"><path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M23 21v-2a4 4 0 0 0-3-3.87"/><path d="M16 3.13a4 4 0 0 1 0 7.75"/></svg>`, action: () => openZhaoJianMenu() },
    { label: '修营缮', icon: `<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/><polyline points="14 2 14 8 20 8"/><line x1="16" y1="13" x2="8" y2="13"/><line x1="16" y1="17" x2="8" y2="17"/><line x1="10" y1="9" x2="8" y2="9"/></svg>`, action: () => openBuildPanel() },
    { label: '操作', icon: `<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="3"/><path d="M19.07 4.93l-1.41 1.41M4.93 4.93l1.41 1.41M19.07 19.07l-1.41-1.41M4.93 19.07l1.41-1.41M12 2v2M12 20v2M2 12h2M20 12h2"/></svg>`, action: () => openOpMenu() },
    { label: '记事', icon: `<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round"><path d="M12 20h9"/><path d="M16.5 3.5a2.121 2.121 0 0 1 3 3L7 19l-4 1 1-4L16.5 3.5z"/></svg>`, action: () => openYangXinRecords() },
    { label: '列表', icon: `<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round"><line x1="8" y1="6" x2="21" y2="6"/><line x1="8" y1="12" x2="21" y2="12"/><line x1="8" y1="18" x2="21" y2="18"/><line x1="3" y1="6" x2="3.01" y2="6"/><line x1="3" y1="12" x2="3.01" y2="12"/><line x1="3" y1="18" x2="3.01" y2="18"/></svg>`, action: () => openYangXinRoster() },
    { label: '指南', icon: `<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"/><polygon points="16.24 7.76 14.12 14.12 7.76 16.24 9.88 9.88 16.24 7.76"/></svg>`, action: () => openGuideModal() },
  ];

  bottomItems.forEach(item => {
    const btn = document.createElement('button');
    btn.style.cssText = `
      display:flex; flex-direction:column; align-items:center; gap:4px;
      background:transparent; border:none; cursor:pointer;
      padding:6px 4px; border-radius:12px;
      transition:background 0.18s;
      min-width:44px;
    `;

    const iconEl = document.createElement('div');
    iconEl.style.cssText = 'width:20px; height:20px; display:flex; align-items:center; justify-content:center; color:rgba(201,163,106,0.88); filter:drop-shadow(0 1px 3px rgba(0,0,0,0.7));';
    iconEl.innerHTML = item.icon;

    const labelEl = document.createElement('div');
    labelEl.style.cssText = `
      font-size:10px; color:rgba(201,163,106,0.82); letter-spacing:1px;
      font-family:'STZhongsong','STSong',serif;
      text-shadow:0 1px 3px rgba(0,0,0,0.8);
    `;
    labelEl.textContent = item.label;

    btn.appendChild(iconEl);
    btn.appendChild(labelEl);

    btn.addEventListener('click', () => {
      if (item.action) item.action();
      else api.ui.toast(`${item.label}（功能开发中）`);
    });
    btn.addEventListener('touchstart', () => { btn.style.background = 'rgba(201,163,106,0.1)'; }, {passive:true});
    btn.addEventListener('touchend', () => { setTimeout(() => { btn.style.background = 'transparent'; }, 200); }, {passive:true});

    bottomBar.appendChild(btn);
  });

  overlay.appendChild(bottomBar);

  // 挂到宫殿详情 view 下
  document.getElementById('view-palace-detail').appendChild(overlay);
}

// ===== 养心殿 · 人物名册 =====
const YX_ROSTER_MINISTER_ROLES = ['帝师', '左相', '右相', '大臣', '臣子'];
const GAME_NPC_LIMIT = 60;
let currentYangXinRosterTab = 'hougong';

function isMinisterRosterCharacter(char) {
  return Boolean(char && (YX_ROSTER_MINISTER_ROLES.includes(char.ancientRole) || char._rosterCategory === 'minister'));
}

function isSpecialRosterCharacter(char) {
  if (!char || char._isGameNpc) return false;
  if (char._isScenarioChar || (typeof XLY_CHAR !== 'undefined' && char === XLY_CHAR)) return true;
  return char.ancientRole !== '后妃' && !isMinisterRosterCharacter(char);
}

function normalizeGameNpc(npc) {
  if (!npc.id) npc.id = `npc_${generateId()}`;
  npc._isGameNpc = true;
  if (!Array.isArray(npc.memorySeen)) npc.memorySeen = [];
  npc.memorySeen = npc.memorySeen.map(item => typeof item === 'string' ? { time: '时间不详', text: item } : item);
  if (!Array.isArray(npc.memoryKnown)) npc.memoryKnown = [];
  npc.memoryKnown = npc.memoryKnown.map(item => typeof item === 'string' ? item : (item?.text || JSON.stringify(item)));
  if (!Array.isArray(npc.records)) npc.records = [];
  if (!npc.ancientRole) npc.ancientRole = 'NPC';
  if (!npc.ancientDesc) npc.ancientDesc = '尚未录入人物介绍。';
  if (!npc.ancientDescOriginal) npc.ancientDescOriginal = npc.ancientDesc;
  if (!npc.cardAvatarCfg) npc.cardAvatarCfg = { scale: 100, x: 0, y: 0 };
  if (!npc.storyAvatarCfg) npc.storyAvatarCfg = { scale: 100, x: 0, y: 0 };
  if (typeof npc.avatar !== 'string') npc.avatar = '';
  if (npc.customAvatar === undefined) npc.customAvatar = null;
  return npc;
}

function getAllGameNpcs() {
  if (!Array.isArray(window._courtNpcData)) window._courtNpcData = [];
  window._courtNpcData.forEach(npc => {
    normalizeGameNpc(npc);
    if ((npc.npcType === 'attendant' || npc.npcType === 'maid') && npc.masterId) {
      const master = selectedCharsData.find(char => char.id === npc.masterId);
      if (master) {
        npc.masterName = master.name;
        const palaceName = getPalaceRootName(master.assignedPalace);
        npc.assignedPalace = palaceName ? `${palaceName}耳房` : '';
      }
    }
  });
  return window._courtNpcData;
}

function getYangXinRosterNpcs() {
  const npcList = getAllGameNpcs();
  if (typeof discoverMorningCourtNpcs === 'function' && typeof getMorningCourtOfficials === 'function' && typeof getMorningCourtRecords === 'function') {
    const discovered = discoverMorningCourtNpcs(getMorningCourtOfficials(), getMorningCourtRecords());
    discovered.forEach(npc => {
      if (npcList.length < GAME_NPC_LIMIT && !npcList.some(item => item.name === npc.name)) npcList.push(normalizeGameNpc(npc));
    });
  }
  return npcList;
}

function getYangXinRosterRows(tab) {
  if (tab === 'hougong') return selectedCharsData.filter(char => char.ancientRole === '后妃').map(char => ({ source: 'char', data: char }));
  if (tab === 'minister') {
    const all = [...selectedCharsData];
    const seen = new Set();
    return all.filter(char => {
      const key = char.id || char.name;
      if (!isMinisterRosterCharacter(char) || seen.has(key)) return false;
      seen.add(key);
      return true;
    }).map(char => ({ source: char === XLY_CHAR ? 'xly' : 'char', data: char }));
  }
  if (tab === 'special') {
    const all = [...selectedCharsData.filter(isSpecialRosterCharacter)];
    if (typeof XLY_CHAR !== 'undefined' && XLY_CHAR) all.push(XLY_CHAR);
    const seen = new Set();
    return all.filter(char => {
      const key = char.id || char.name;
      if (seen.has(key)) return false;
      seen.add(key);
      return true;
    }).map(char => ({ source: char === XLY_CHAR ? 'xly' : 'char', data: char }));
  }
  if (tab === 'npc') return getYangXinRosterNpcs().filter(npc => !npc.npcType).map(npc => ({ source: 'npc', data: npc }));
  if (tab === 'attendant') return getYangXinRosterNpcs().filter(npc => npc.npcType === 'attendant' || npc.npcType === 'maid').map(npc => ({ source: 'npc', data: npc }));
  return [];
}

function getPalaceRootName(assignedPalace) {
  return String(assignedPalace || '').replace(/(正殿|东偏殿|西偏殿|耳房|庭院).*$/, '');
}

function syncStaffResidencesForMaster(master) {
  const palaceName = getPalaceRootName(master?.assignedPalace);
  getAllGameNpcs().filter(npc => npc.masterId === master?.id).forEach(npc => {
    npc.masterName = master.name;
    npc.assignedPalace = palaceName ? `${palaceName}耳房` : '';
  });
}

function replaceRosterKnowledge(char, marker, content) {
  if (!char) return;
  if (!Array.isArray(char.memoryKnown)) char.memoryKnown = [];
  char.memoryKnown = char.memoryKnown.filter(item => !String(item || '').startsWith(marker));
  char.memoryKnown.push(`${marker}\n${content || '当前名册为空'}`);
}

function syncRosterKnowledgeToCharacters() {
  const harem = getYangXinRosterRows('hougong').map(row => row.data);
  const ministers = getYangXinRosterRows('minister').map(row => row.data);
  const npcs = getYangXinRosterRows('npc').map(row => row.data);
  const attendants = getYangXinRosterRows('attendant').map(row => row.data);
  const specials = getYangXinRosterRows('special').map(row => row.data);
  const haremText = harem.map(char => `${char.assignedRank || '未册封'}${char.honorificTitle ? `·${char.honorificTitle}` : ''} ${char.name}；居所${char.assignedPalace || '未赐居'}；子嗣${char.childrenInfo || '无记录'}；性格${char.rosterPersonality || '未生成'}；心情${char.rosterMood || '未生成'}`).join('\n');
  const attendantText = attendants.map(char => `${char.ancientRole || '侍从'} ${char.name}；主人${char.masterName || '未分配'}；居所${char.assignedPalace || '未分配'}；性格${char.rosterPersonality || '未生成'}；状态${char.rosterMood || '未生成'}；忠诚度${char.loyalty ?? 0}`).join('\n');
  const ministerText = ministers.map(char => `${char.ancientRole || '大臣'}${char.assignedRank ? `·${char.assignedRank}` : ''} ${char.name}；性格${char.rosterPersonality || '未生成'}；状态${char.rosterMood || '未生成'}`).join('\n');
  const npcText = npcs.map(char => `${char.ancientRole || 'NPC'} ${char.name}；资料${char.ancientDesc || '无'}；性格${char.rosterPersonality || '未生成'}；状态${char.rosterMood || '未生成'}`).join('\n');
  const specialText = specials.map(char => `${char.ancientRole || '特殊身份'} ${char.name}；性格${char.rosterPersonality || '未生成'}；状态${char.rosterMood || '未生成'}`).join('\n');

  const nonNpcCharacters = [...selectedCharsData, (typeof XLY_CHAR !== 'undefined' ? XLY_CHAR : null)].filter(char => char && !char._isGameNpc);
  nonNpcCharacters.forEach(char => {
    replaceRosterKnowledge(char, '【宫中名册·后宫列表】', haremText);
    replaceRosterKnowledge(char, '【宫中名册·侍从列表】', attendantText);
    replaceRosterKnowledge(char, '【宫中名册·特殊列表】', specialText);
  });

  const courtKnowledgeRecipients = [
    ...nonNpcCharacters.filter(char => char.ancientRole !== '后妃'),
    ...getAllGameNpcs()
  ];
  courtKnowledgeRecipients.forEach(char => {
    replaceRosterKnowledge(char, '【宫中名册·大臣列表】', ministerText);
    replaceRosterKnowledge(char, '【宫中名册·NPC列表】', npcText);
    replaceRosterKnowledge(char, '【宫中名册·特殊列表】', specialText);
  });
}

function getPalaceStaffResidents(palaceName, npcType = '') {
  return getAllGameNpcs().filter(npc => {
    if (npcType && npc.npcType !== npcType) return false;
    if (npc.npcType !== 'attendant' && npc.npcType !== 'maid') return false;
    const master = selectedCharsData.find(char => char.id === npc.masterId);
    const currentPalace = getPalaceRootName(master?.assignedPalace || npc.assignedPalace);
    return currentPalace === palaceName;
  });
}

function renameRosterReferences(oldName, newName) {
  if (!oldName || !newName || oldName === newName) return;
  const replaceExactFields = value => {
    if (!value || typeof value !== 'object') return;
    if (Array.isArray(value)) { value.forEach(replaceExactFields); return; }
    const exactFields = ['name', 'charName', 'fromName', 'toName', 'senderName', 'receiverName', 'owner', 'from', 'to', 'masterName'];
    Object.entries(value).forEach(([key, fieldValue]) => {
      if (exactFields.includes(key) && fieldValue === oldName) value[key] = newName;
      else if (key === 'author' && typeof fieldValue === 'string' && fieldValue.includes(oldName)) value[key] = fieldValue.replaceAll(oldName, newName);
      else if (fieldValue && typeof fieldValue === 'object') replaceExactFields(fieldValue);
    });
  };
  [ysfLettersData, ysfCharLettersData, ysfSpyData, zouZheData, window._qianchaoRecords, window._courtNpcData].forEach(replaceExactFields);
  if (window._relationData) {
    const renamed = {};
    Object.entries(window._relationData).forEach(([key, relation]) => {
      const nextKey = key.split('->').map(part => part === oldName ? newName : part).join('->');
      if (relation?.from === oldName) relation.from = newName;
      if (relation?.to === oldName) relation.to = newName;
      renamed[nextKey] = relation;
    });
    window._relationData = renamed;
  }
}

async function saveYangXinRosterState() {
  syncRosterKnowledgeToCharacters();
  const xlyRosterData = typeof XLY_CHAR !== 'undefined' ? {
    name: XLY_CHAR.name,
    ancientRole: XLY_CHAR.ancientRole,
    _rosterCategory: XLY_CHAR._rosterCategory || '',
    assignedRank: XLY_CHAR.assignedRank || '',
    honorificTitle: XLY_CHAR.honorificTitle || '',
    rosterPersonality: XLY_CHAR.rosterPersonality || '',
    rosterMood: XLY_CHAR.rosterMood || ''
  } : undefined;
  await saveProgress({
    characters: selectedCharsData,
    courtNpcData: window._courtNpcData || [],
    xlyRosterData,
    xlyMemoryKnown: typeof XLY_CHAR !== 'undefined' ? XLY_CHAR.memoryKnown : [],
    relationData: window._relationData || {},
    ysfLettersData,
    ysfCharLettersData,
    ysfSpyData,
    zouZheData,
    qianchaoRecords: window._qianchaoRecords || []
  });
}

async function updateYangXinRosterField(row, field, value) {
  const char = row.data;
  const nextValue = String(value ?? '').trim();
  if (field === 'name') {
    if (!nextValue) { api.ui.toast('姓名不可为空'); return false; }
    const oldName = char.name;
    char.name = nextValue;
    renameRosterReferences(oldName, nextValue);
    if (row.source === 'char') {
      try { await api.characters.update(char.id, { name: nextValue, description: char.ancientDesc || '' }); } catch (error) {}
    }
  } else {
    char[field] = nextValue;
    if (field === 'ancientRole' && currentYangXinRosterTab === 'minister') char._rosterCategory = 'minister';
    if (field === 'ancientRole' && currentYangXinRosterTab === 'special') delete char._rosterCategory;
  }
  if (row.source === 'char' && (field === 'name' || field === 'assignedPalace')) syncStaffResidencesForMaster(char);
  await saveYangXinRosterState();
  return true;
}

async function assignYangXinStaffMaster(row, masterId) {
  const master = selectedCharsData.find(char => char.id === masterId && char.ancientRole === '后妃');
  row.data.masterId = master?.id || '';
  row.data.masterName = master?.name || '';
  row.data.assignedPalace = master ? `${getPalaceRootName(master.assignedPalace)}耳房` : '';
  await saveYangXinRosterState();
  renderYangXinRosterPane();
}

function makeNewRosterPerson(tab) {
  const suffix = Date.now().toString().slice(-5);
  const base = {
    id: `${tab}_${generateId()}`, name: `新录人物${suffix}`, avatar: '', customAvatar: null,
    ancientDesc: '', ancientDescOriginal: '', assignedRank: '', assignedPalace: '',
    memorySeen: [], memoryKnown: [], records: [], charWorldDesc: '',
    cardAvatarCfg: { scale: 100, x: 0, y: 0 }, storyAvatarCfg: { scale: 100, x: 0, y: 0 },
    rosterPersonality: '', rosterMood: '', _isCustom: true
  };
  if (tab === 'hougong') return { ...base, ancientRole: '后妃', name: `新入宫者${suffix}` };
  if (tab === 'minister') return { ...base, ancientRole: '大臣', _rosterCategory: 'minister', name: `新任大臣${suffix}` };
  if (tab === 'special') return { ...base, ancientRole: '自定义身份', name: `特殊人物${suffix}` };
  if (tab === 'attendant') return normalizeGameNpc({ ...base, ancientRole: '侍从', name: `新侍从${suffix}`, npcType: 'attendant', gender: '男', loyalty: 50, masterId: '', masterName: '' });
  return normalizeGameNpc({ ...base, ancientRole: 'NPC', name: `新NPC${suffix}` });
}

async function addYangXinRosterPerson() {
  const tab = currentYangXinRosterTab;
  if ((tab === 'npc' || tab === 'attendant') && getAllGameNpcs().length >= GAME_NPC_LIMIT) {
    api.ui.toast(`NPC已达${GAME_NPC_LIMIT}人上限，请先删除人物`);
    return;
  }
  const person = makeNewRosterPerson(tab);
  if (tab === 'hougong' || tab === 'minister' || tab === 'special') {
    selectedCharsData.push(person);
    selectedCharIds?.add?.(person.id);
  } else {
    getAllGameNpcs().push(person);
  }
  await saveYangXinRosterState();
  renderYangXinRosterPane();
  api.ui.toast('已新增一行，可直接在表格中修改');
}

async function deleteYangXinRosterPerson(row) {
  const person = row.data;
  const ok = await api.ui.confirm({
    title: `删除「${person.name}」`,
    message: '删除后，此人物的人设、记忆、思绪、记事及名册资料会直接从本局游戏中移除，且无法撤销。确定删除吗？'
  });
  if (!ok) return;
  if (row.source === 'char') {
    getAllGameNpcs().filter(npc => npc.masterId === person.id).forEach(npc => {
      npc.masterId = '';
      npc.masterName = '';
      npc.assignedPalace = '';
    });
    const index = selectedCharsData.findIndex(char => char.id === person.id);
    if (index >= 0) selectedCharsData.splice(index, 1);
    selectedCharIds?.delete?.(person.id);
  } else if (row.source === 'npc') {
    const index = getAllGameNpcs().findIndex(npc => npc.id === person.id);
    if (index >= 0) getAllGameNpcs().splice(index, 1);
  } else {
    api.ui.toast('固定剧情人物不可从本局删除');
    return;
  }
  await saveYangXinRosterState();
  renderYangXinRosterPane();
  api.ui.toast('人物及其本局资料已删除');
}

async function generatePalaceStaffBatch(button) {
  const npcs = getAllGameNpcs();
  if (npcs.length + 6 > GAME_NPC_LIMIT) {
    api.ui.toast(`生成六人需要6个空位；当前NPC为${npcs.length}/${GAME_NPC_LIMIT}`);
    return;
  }
  button.disabled = true;
  const oldText = button.innerText;
  button.innerText = '正在择选…';
  const prompt = `为古代皇帝后宫生成一组六名已经成年的新入宫下人：必须恰好4名男性侍从、2名女性宫女。只输出合法JSON数组，不要Markdown和解释。每个对象必须包含：name（古风姓名且六人不重名）、npcType（侍从或宫女）、gender（男或女）、personality（恰好两个汉字）、intro（40至80字人物介绍，包含成年信息、来历与擅长之事）、status（不超过5个汉字的当前状态）、loyalty（0到100整数）。侍从必须全部为男，宫女必须全部为女，六人年龄均不得低于18岁。主人暂不分配。`;
  try {
    const result = await api.ai.chat({ messages: [{ role: 'user', content: prompt }] });
    const text = typeof result === 'string' ? result : (result?.content ?? result?.text ?? '');
    const match = text.match(/\[\s*\{[\s\S]*\}\s*\]/);
    const parsed = match ? JSON.parse(match[0]) : [];
    const attendants = parsed.filter(item => item.npcType === '侍从').slice(0, 4);
    const maids = parsed.filter(item => item.npcType === '宫女').slice(0, 2);
    if (attendants.length !== 4 || maids.length !== 2) throw new Error('人数或身份不符');
    const existingNames = new Set(npcs.map(npc => npc.name));
    [...attendants, ...maids].forEach((item, index) => {
      let generatedName = String(item.name || '').trim() || `${item.npcType}${Date.now().toString().slice(-4)}${index + 1}`;
      while (existingNames.has(generatedName)) generatedName += '·新';
      existingNames.add(generatedName);
      npcs.push(normalizeGameNpc({
      id: `staff_${generateId()}`, name: generatedName,
      npcType: item.npcType === '宫女' ? 'maid' : 'attendant', ancientRole: item.npcType,
      gender: item.npcType === '宫女' ? '女' : '男',
      rosterPersonality: String(item.personality || '').replace(/\s/g, '').slice(0, 2),
      rosterMood: String(item.status || '').replace(/\s/g, '').slice(0, 5),
      ancientDesc: String(item.intro || '').trim(), ancientDescOriginal: String(item.intro || '').trim(),
      loyalty: Math.max(0, Math.min(100, Number(item.loyalty) || 0)),
      masterId: '', masterName: '', assignedPalace: '', memorySeen: [], memoryKnown: [], records: []
    }));
    });
    await saveYangXinRosterState();
    renderYangXinRosterPane();
    api.ui.toast('已生成4名侍从与2名宫女，请为他们分配主人');
  } catch (error) {
    api.ui.toast('侍从名册生成失败，请重试');
  } finally {
    button.disabled = false;
    button.innerText = oldText;
  }
}

async function generateYangXinRosterTraits(row, button) {
  const char = row.data;
  const memoryText = (char.memorySeen || []).slice(0, 20).map(item => typeof item === 'string' ? item : item.text).filter(Boolean).join('\n') || '无';
  const prompt = `根据以下人物资料生成两个极短字段，只输出JSON对象，不要Markdown和解释：\n{"personality":"恰好两个汉字的核心性格","mood":"不超过五个汉字的当前心情状态"}\n\n姓名：${char.name || '无名'}\n身份：${char.ancientRole || '未知'}\n位份/官职：${char.assignedRank || '无'}\n人物设定：${char.ancientDescOriginal || char.ancientDesc || '无'}\n当前时间：${hudTime?.innerText || '未知'}\n近期记忆：${memoryText}\n\n性格必须稳定概括人物底色；心情结合当前时间和近期记忆。personality不得超过2个汉字，mood不得超过5个汉字。`;
  const oldText = button.innerText;
  button.disabled = true;
  button.innerText = '推演中…';
  try {
    const result = await api.ai.chat({ messages: [{ role: 'user', content: prompt }] });
    const text = typeof result === 'string' ? result : (result?.content ?? result?.text ?? '');
    const match = text.match(/\{[\s\S]*\}/);
    const parsed = match ? JSON.parse(match[0]) : null;
    const personality = String(parsed?.personality || '').replace(/\s/g, '').slice(0, 2);
    const mood = String(parsed?.mood || '').replace(/\s/g, '').slice(0, 5);
    if (!personality || !mood) throw new Error('AI字段为空');
    char.rosterPersonality = personality;
    char.rosterMood = mood;
    await saveYangXinRosterState();
    renderYangXinRosterPane();
  } catch (error) {
    api.ui.toast('性格与心情生成失败，请重试');
    button.disabled = false;
    button.innerText = oldText;
  }
}

function getYangXinRosterColumns(tab) {
  if (tab === 'hougong') return [
    ['name', '姓名', 105], ['assignedRank', '位份', 90], ['honorificTitle', '封号', 90], ['assignedPalace', '居住宫殿', 125],
    ['childrenInfo', '子嗣', 95], ['rosterPersonality', '性格', 72], ['rosterMood', '心情状态', 92]
  ];
  if (tab === 'minister' || tab === 'special') return [
    ['name', '姓名', 110], ['ancientRole', '身份（可自定义）', 135], ['assignedRank', '官职/位阶', 120], ['rosterPersonality', '性格', 72], ['rosterMood', '心情状态', 92]
  ];
  if (tab === 'attendant') return [
    ['name', '姓名', 105], ['ancientRole', '身份', 72], ['gender', '性别', 62], ['rosterPersonality', '性格', 72],
    ['ancientDesc', '介绍', 220], ['rosterMood', '状态', 88], ['loyalty', '忠诚度', 76], ['masterId', '主人', 125]
  ];
  return [
    ['name', '姓名', 110], ['ancientRole', '身份', 100], ['ancientDesc', '人物资料', 220], ['rosterPersonality', '性格', 72], ['rosterMood', '心情状态', 92]
  ];
}

function getYangXinRosterPalaceOptions(currentValue = '') {
  const rooms = ['正殿', '东偏殿', '西偏殿', '耳房'];
  const palaceNames = ['坤宁宫', ...eastPalaces, ...westPalaces.filter(name => name !== '储秀宫' || placedPalacesData.some(item => item.name === '储秀宫')), '冷宫'];
  const values = palaceNames.flatMap(name => rooms.map(room => `${name}${room}`));
  if (currentValue && !values.includes(currentValue)) values.unshift(currentValue);
  return values;
}

function renderYangXinRosterCell(row, rowIndex, column) {
  const [field, , width] = column;
  if (field === 'masterId') {
    return `<select data-master-row="${rowIndex}" style="width:${width - 14}px;background:rgba(255,255,255,0.35);border:1px solid rgba(100,65,30,0.2);border-radius:5px;padding:7px 4px;color:#3f2b17;font-family:inherit;font-size:12px;"><option value="">未分配</option>${selectedCharsData.filter(char => char.ancientRole === '后妃').map(master => `<option value="${escHtml(master.id)}" ${row.data.masterId === master.id ? 'selected' : ''}>${escHtml(master.name)}</option>`).join('')}</select>`;
  }
  if (currentYangXinRosterTab === 'hougong' && field === 'assignedRank') {
    const values = rankData.map(item => item.rank).filter(Boolean);
    if (row.data.assignedRank && !values.includes(row.data.assignedRank)) values.unshift(row.data.assignedRank);
    return `<select data-roster-select="${rowIndex}" data-field="assignedRank" style="width:${width - 14}px;background:rgba(255,255,255,0.35);border:1px solid rgba(100,65,30,0.2);border-radius:5px;padding:7px 4px;color:#3f2b17;font-family:inherit;font-size:12px;"><option value="">未册封</option>${values.map(value => `<option value="${escHtml(value)}" ${row.data.assignedRank === value ? 'selected' : ''}>${escHtml(value)}</option>`).join('')}</select>`;
  }
  if (currentYangXinRosterTab === 'hougong' && field === 'assignedPalace') {
    const values = getYangXinRosterPalaceOptions(row.data.assignedPalace || '');
    return `<select data-roster-select="${rowIndex}" data-field="assignedPalace" style="width:${width - 14}px;background:rgba(255,255,255,0.35);border:1px solid rgba(100,65,30,0.2);border-radius:5px;padding:7px 4px;color:#3f2b17;font-family:inherit;font-size:12px;"><option value="">未赐居</option>${values.map(value => `<option value="${escHtml(value)}" ${row.data.assignedPalace === value ? 'selected' : ''}>${escHtml(value)}</option>`).join('')}</select>`;
  }
  if ((currentYangXinRosterTab === 'minister' || currentYangXinRosterTab === 'special') && field === 'ancientRole') {
    return `<input data-row="${rowIndex}" data-field="ancientRole" list="yx-minister-role-options" placeholder="可输入任意身份" value="${escHtml(row.data.ancientRole || '')}" maxlength="30" style="width:${width - 14}px;background:rgba(255,255,255,0.35);border:1px solid rgba(100,65,30,0.2);border-radius:5px;padding:7px 6px;color:#3f2b17;font-family:inherit;font-size:12px;">`;
  }
  return `<input data-row="${rowIndex}" data-field="${field}" value="${escHtml(row.data[field] ?? '')}" maxlength="${field === 'rosterPersonality' ? 2 : (field === 'rosterMood' ? 5 : 120)}" style="width:${width - 14}px;background:rgba(255,255,255,0.35);border:1px solid rgba(100,65,30,0.2);border-radius:5px;padding:7px 6px;color:#3f2b17;font-family:inherit;font-size:12px;">`;
}

function renderYangXinRosterPane() {
  const pane = document.getElementById('yx-roster-pane');
  if (!pane) return;
  const rows = getYangXinRosterRows(currentYangXinRosterTab);
  const columns = getYangXinRosterColumns(currentYangXinRosterTab);
  if (!rows.length) {
    pane.innerHTML = '<div style="height:50vh;display:flex;align-items:center;justify-content:center;color:#8b7658;letter-spacing:3px;">当前名册为空</div>';
    return;
  }
  pane.innerHTML = `
    <datalist id="yx-minister-role-options"><option value="帝师"><option value="左相"><option value="右相"><option value="大臣"><option value="臣子"><option value="尚书"><option value="侍郎"><option value="将军"><option value="御史"></datalist>
    <div style="overflow:auto;border:1px solid rgba(105,73,36,0.3);border-radius:12px;background:rgba(236,219,177,0.9);box-shadow:0 8px 28px rgba(0,0,0,0.25);">
      <table style="border-collapse:collapse;min-width:100%;width:max-content;color:#3f2b17;font-size:12px;">
        <thead><tr>${columns.map(column => `<th style="position:sticky;top:0;z-index:2;width:${column[2]}px;min-width:${column[2]}px;padding:11px 7px;background:#5d4127;color:#f2dfb3;border-right:1px solid rgba(255,255,255,0.1);letter-spacing:2px;">${column[1]}</th>`).join('')}<th style="position:sticky;top:0;z-index:2;min-width:150px;padding:11px 7px;background:#5d4127;color:#f2dfb3;">操作</th></tr></thead>
        <tbody>${rows.map((row, rowIndex) => `<tr style="background:${rowIndex % 2 ? 'rgba(255,250,232,0.45)' : 'transparent'};">${columns.map(column => `<td style="padding:7px;border-right:1px solid rgba(80,50,20,0.12);border-bottom:1px solid rgba(80,50,20,0.14);">${renderYangXinRosterCell(row, rowIndex, column)}</td>`).join('')}<td style="padding:7px;border-bottom:1px solid rgba(80,50,20,0.14);white-space:nowrap;"><button data-ai-row="${rowIndex}" style="background:#765635;border:1px solid #9a7950;color:#f2dfb3;border-radius:14px;padding:6px 9px;font-family:inherit;font-size:11px;">${row.data.rosterPersonality && row.data.rosterMood ? '重新生成' : '生成性情'}</button><button data-delete-row="${rowIndex}" style="margin-left:5px;background:transparent;border:1px solid #9b4c3f;color:#8b3029;border-radius:14px;padding:6px 9px;font-family:inherit;font-size:11px;">删除</button></td></tr>`).join('')}</tbody>
      </table>
    </div>`;
  pane.querySelectorAll('input[data-row]').forEach(input => {
    input.addEventListener('change', async () => {
      const row = rows[Number(input.dataset.row)];
      const ok = await updateYangXinRosterField(row, input.dataset.field, input.value);
      if (!ok) input.value = row.data[input.dataset.field] || '';
      else if (input.dataset.field === 'name') renderYangXinRosterPane();
    });
  });
  pane.querySelectorAll('[data-ai-row]').forEach(button => {
    button.onclick = () => generateYangXinRosterTraits(rows[Number(button.dataset.aiRow)], button);
  });
  pane.querySelectorAll('[data-delete-row]').forEach(button => {
    button.onclick = () => deleteYangXinRosterPerson(rows[Number(button.dataset.deleteRow)]);
  });
  pane.querySelectorAll('[data-master-row]').forEach(select => {
    select.onchange = () => assignYangXinStaffMaster(rows[Number(select.dataset.masterRow)], select.value);
  });
  pane.querySelectorAll('[data-roster-select]').forEach(select => {
    select.onchange = async () => {
      const row = rows[Number(select.dataset.rosterSelect)];
      await updateYangXinRosterField(row, select.dataset.field, select.value);
      if (select.dataset.field === 'assignedPalace') syncStaffResidencesForMaster(row.data);
      renderYangXinRosterPane();
    };
  });
}

async function generateBlankYangXinRosterTraits(button) {
  const rows = getYangXinRosterRows(currentYangXinRosterTab).filter(row => !row.data.rosterPersonality || !row.data.rosterMood);
  if (!rows.length) { api.ui.toast('本页性格与心情均已有记录'); return; }
  button.disabled = true;
  for (let index = 0; index < rows.length; index++) {
    button.innerText = `推演 ${index + 1}/${rows.length}`;
    await generateYangXinRosterTraits(rows[index], button);
  }
  button.disabled = false;
  button.innerText = '生成本页空白性情';
}

function openYangXinRoster() {
  syncRosterKnowledgeToCharacters();
  document.getElementById('yx-roster-modal')?.remove();
  const modal = document.createElement('div');
  modal.id = 'yx-roster-modal';
  modal.style.cssText = `position:fixed;inset:0;z-index:100100;background:
    linear-gradient(rgba(25,18,12,0.7),rgba(25,18,12,0.7)),
    url('https://www.imgfox.cn/apis/uploads/20260818/cd2a4b22f1ec4748/IMG_9643.jpeg') center/cover no-repeat;
    display:flex;flex-direction:column;padding-top:var(--safe-top);font-family:'STZhongsong','STSong',serif;`;
  modal.innerHTML = `
    <div style="height:54px;display:flex;align-items:center;justify-content:space-between;padding:0 15px;background:rgba(20,14,9,0.82);border-bottom:1px solid rgba(201,163,106,0.3);backdrop-filter:blur(14px);">
      <button id="yx-roster-close" style="background:transparent;border:none;color:#b9a17b;font-family:inherit;font-size:15px;">‹ 返回</button>
      <div style="color:#f0d9a7;font-size:18px;letter-spacing:5px;text-shadow:0 2px 5px #000;">宫中名册</div>
      <button id="yx-roster-add" style="background:rgba(201,163,106,0.15);border:1px solid rgba(201,163,106,0.45);color:#e4c891;border-radius:16px;padding:6px 11px;font-family:inherit;font-size:11px;">＋ 新增</button>
    </div>
    <div style="display:flex;justify-content:flex-end;gap:7px;padding:8px 12px 0;background:rgba(17,12,8,0.75);"><button id="yx-roster-generate-blank" style="background:rgba(201,163,106,0.15);border:1px solid rgba(201,163,106,0.45);color:#e4c891;border-radius:16px;padding:6px 11px;font-family:inherit;font-size:10px;">生成本页空白性情</button><button id="yx-roster-generate-staff" style="display:none;background:rgba(135,35,35,0.3);border:1px solid rgba(201,163,106,0.55);color:#f0d7a3;border-radius:16px;padding:6px 11px;font-family:inherit;font-size:10px;">生成4侍从＋2宫女</button></div>
    <div id="yx-roster-tabs" style="display:flex;gap:7px;padding:12px;background:rgba(17,12,8,0.75);overflow-x:auto;"></div>
    <div id="yx-roster-pane" style="flex:1;overflow:auto;padding:12px 12px calc(var(--safe-bottom) + 18px);"></div>`;
  document.body.appendChild(modal);
  const tabs = [
    ['hougong', '后宫列表'], ['minister', '大臣列表'], ['special', '特殊列表'], ['npc', 'NPC列表'], ['attendant', '侍从列表']
  ];
  const tabBar = modal.querySelector('#yx-roster-tabs');
  const renderTabs = () => {
    modal.querySelector('#yx-roster-generate-staff').style.display = currentYangXinRosterTab === 'attendant' ? 'block' : 'none';
    modal.querySelector('#yx-roster-generate-blank').style.display = currentYangXinRosterTab === 'attendant' ? 'none' : 'block';
    tabBar.innerHTML = tabs.map(tab => `<button data-tab="${tab[0]}" style="min-width:88px;flex:1;padding:8px 10px;border-radius:18px;font-family:inherit;font-size:12px;letter-spacing:1px;${currentYangXinRosterTab === tab[0] ? 'background:rgba(201,163,106,0.25);border:1px solid #c9a36a;color:#ffe7b2;' : 'background:rgba(0,0,0,0.25);border:1px solid #5e503e;color:#88765c;'}">${tab[1]}</button>`).join('');
    tabBar.querySelectorAll('[data-tab]').forEach(button => button.onclick = () => {
      currentYangXinRosterTab = button.dataset.tab;
      modal.querySelector('#yx-roster-generate-staff').style.display = currentYangXinRosterTab === 'attendant' ? 'block' : 'none';
      modal.querySelector('#yx-roster-generate-blank').style.display = currentYangXinRosterTab === 'attendant' ? 'none' : 'block';
      renderTabs();
      renderYangXinRosterPane();
    });
  };
  modal.querySelector('#yx-roster-close').onclick = () => {
    modal.remove();
    if (currentDetailPalaceName === '养心殿') renderYangXinDian();
  };
  modal.querySelector('#yx-roster-generate-blank').onclick = event => generateBlankYangXinRosterTraits(event.currentTarget);
  modal.querySelector('#yx-roster-add').onclick = () => addYangXinRosterPerson();
  modal.querySelector('#yx-roster-generate-staff').onclick = event => generatePalaceStaffBatch(event.currentTarget);
  renderTabs();
  renderYangXinRosterPane();
}

// ===== 修营缮系统 =====
let buildTasks = []; // [{ palaceName: '储秀宫', endTime: 123456789 }]

function getBuildCardHtml(palaceName, description, buttonId, days = 3) {
  const task = buildTasks.find(item => item.palaceName === palaceName);
  const placed = placedPalacesData.some(item => item.name === palaceName);
  let button = `<button id="${buttonId}" style="background:var(--primary-color);border:none;color:#000;padding:6px 16px;border-radius:16px;font-size:13px;font-weight:bold;">建设</button>`;
  if (placed) button = '<button disabled style="background:transparent;border:1px solid #555;color:#555;padding:6px 16px;border-radius:16px;font-size:13px;">已建成</button>';
  else if (task) button = '<button disabled style="background:rgba(201,163,106,0.1);border:1px solid var(--primary-color);color:var(--primary-color);padding:6px 16px;border-radius:16px;font-size:13px;opacity:.6;">建设中</button>';
  return `<div style="background:rgba(0,0,0,.4);border:1px solid rgba(201,163,106,.3);border-radius:12px;padding:16px;display:flex;align-items:center;justify-content:space-between;">
    <div><div style="color:var(--primary-color);font-size:16px;font-weight:bold;letter-spacing:2px;">${palaceName}</div><div style="color:#aaa;font-size:11px;margin-top:4px;">${description} · 耗时${days}天</div></div><div>${button}</div></div>`;
}

async function startPalaceBuild(palaceName, days = 3) {
  if (buildTasks.some(item => item.palaceName === palaceName) || placedPalacesData.some(item => item.name === palaceName)) return;
  buildTasks.push({ palaceName, days, endTime: Date.now() + days * 24 * 60 * 60 * 1000 });
  await saveProgress({ buildTasks });
  api.ui.toast(`${palaceName}开始建设，耗时${days}天`);
  openBuildPanel();
}

async function finishPalaceBuild(index) {
  const task = buildTasks[index];
  if (!task) return;
  buildTasks.splice(index, 1);
  await saveProgress({ buildTasks });
  document.getElementById('build-panel-modal')?.remove();
  isRePlacementMode = true;
  if (!palaces.includes(task.palaceName)) palaces.push(task.palaceName);
  document.querySelectorAll('.view').forEach(view => view.classList.remove('active'));
  currentMapDataUrl = currentMapDataUrl || memoryBg.src;
  initPlacementView();
  const button = document.querySelector(`.palace-btn[data-name="${task.palaceName}"]`);
  if (button) selectPalaceToPlace(button, task.palaceName);
  switchView(vPlacement);
}

function openBuildPanel() {
  const old = document.getElementById('build-panel-modal');
  if (old) old.remove();

  const modal = document.createElement('div');
  modal.id = 'build-panel-modal';
  modal.style.cssText = `
    position:fixed; inset:0; z-index:99999;
    background:url('https://www.imgfox.cn/apis/uploads/20260818/cd2a4b22f1ec4748/IMG_9643.jpeg') center/cover no-repeat;
    display:flex; flex-direction:column;
  `;

  // 磨砂遮罩
  const overlay = document.createElement('div');
  overlay.style.cssText = 'position:absolute; inset:0; background:rgba(10,8,6,0.6); backdrop-filter:blur(8px); -webkit-backdrop-filter:blur(8px);';
  modal.appendChild(overlay);

  const content = document.createElement('div');
  content.style.cssText = 'position:relative; z-index:1; display:flex; flex-direction:column; height:100%;';

  // 顶栏
  const header = document.createElement('div');
  header.style.cssText = 'padding:calc(var(--safe-top) + 12px) 16px 12px; display:flex; justify-content:space-between; align-items:center; border-bottom:1px solid rgba(201,163,106,0.2);';
  header.innerHTML = `
    <button id="btn-close-build" style="background:transparent; border:none; color:#888; font-size:16px;">‹ 返回</button>
    <div style="color:var(--primary-color); font-size:18px; font-weight:bold; letter-spacing:4px; font-family:'STZhongsong','STSong',serif;">修营缮</div>
    <div style="width:48px;"></div>
  `;
  content.appendChild(header);

  // 标签栏
  const tabBar = document.createElement('div');
  tabBar.style.cssText = 'display:flex; padding:16px 20px; gap:12px;';
  tabBar.innerHTML = `
    <button class="build-tab active" data-target="build-pane-construct" style="flex:1; background:rgba(201,163,106,0.2); border:1px solid var(--primary-color); color:var(--primary-color); padding:8px; border-radius:6px; font-size:14px; letter-spacing:2px;">建造</button>
    <button class="build-tab" data-target="build-pane-repair" style="flex:1; background:transparent; border:1px solid #555; color:#aaa; padding:8px; border-radius:6px; font-size:14px; letter-spacing:2px;">修缮宫殿</button>
    <button class="build-tab" data-target="build-pane-progress" style="flex:1; background:transparent; border:1px solid #555; color:#aaa; padding:8px; border-radius:6px; font-size:14px; letter-spacing:2px;">建设中</button>
  `;
  content.appendChild(tabBar);

  // 内容区
  const mainArea = document.createElement('div');
  mainArea.style.cssText = 'flex:1; overflow-y:auto; padding:0 20px 20px;';

  // 建造面板
  const paneConstruct = document.createElement('div');
  paneConstruct.id = 'build-pane-construct';
  paneConstruct.className = 'build-pane';
  paneConstruct.style.cssText = 'display:flex; flex-direction:column; gap:16px;';
  
  paneConstruct.innerHTML = `
    ${getBuildCardHtml('储秀宫', '西六宫之一', 'btn-start-chuxiu')}
    ${getBuildCardHtml('珍宝阁', '收藏御用珍玩与赏赐之物', 'btn-start-treasure')}
    ${getBuildCardHtml('华清宫', '暖泉绕殿的皇家温泉行宫', 'btn-start-huaqing', 5)}
    <div style="background:rgba(0,0,0,0.2); border:1px dashed #555; border-radius:12px; padding:16px; display:flex; align-items:center; justify-content:center; height:72px;">
      <span style="color:#555; font-size:13px; letter-spacing:2px;">空置地块</span>
    </div>
  `;

  // 修缮面板
  const paneRepair = document.createElement('div');
  paneRepair.id = 'build-pane-repair';
  paneRepair.className = 'build-pane';
  paneRepair.style.cssText = 'display:none; flex-direction:column; align-items:center; justify-content:center; height:100%; color:#888; font-size:14px; letter-spacing:2px;';
  paneRepair.innerText = '暂无需要修缮的宫殿';

  // 建设中面板
  const paneProgress = document.createElement('div');
  paneProgress.id = 'build-pane-progress';
  paneProgress.className = 'build-pane';
  paneProgress.style.cssText = 'display:none; flex-direction:column; gap:16px;';

  mainArea.appendChild(paneConstruct);
  mainArea.appendChild(paneRepair);
  mainArea.appendChild(paneProgress);
  content.appendChild(mainArea);
  modal.appendChild(content);
  document.body.appendChild(modal);

  // 事件绑定
  document.getElementById('btn-close-build').onclick = () => modal.remove();

  const tabs = modal.querySelectorAll('.build-tab');
  tabs.forEach(btn => {
    btn.onclick = () => {
      tabs.forEach(b => { b.classList.remove('active'); b.style.background = 'transparent'; b.style.borderColor = '#555'; b.style.color = '#aaa'; });
      btn.classList.add('active');
      btn.style.background = 'rgba(201,163,106,0.2)'; btn.style.borderColor = 'var(--primary-color)'; btn.style.color = 'var(--primary-color)';
      
      modal.querySelectorAll('.build-pane').forEach(p => p.style.display = 'none');
      document.getElementById(btn.dataset.target).style.display = 'flex';
      
      if (btn.dataset.target === 'build-pane-progress') {
        renderBuildProgress();
      }
    };
  });

  const startBtn = document.getElementById('btn-start-chuxiu');
  if (startBtn) startBtn.onclick = () => startPalaceBuild('储秀宫');
  const treasureBtn = document.getElementById('btn-start-treasure');
  if (treasureBtn) treasureBtn.onclick = () => startPalaceBuild('珍宝阁');
  const huaqingBtn = document.getElementById('btn-start-huaqing');
  if (huaqingBtn) huaqingBtn.onclick = () => startPalaceBuild('华清宫', 5);
}

let buildProgressTimer = null;
function renderBuildProgress() {
  const pane = document.getElementById('build-pane-progress');
  if (!pane) return;
  
  if (buildTasks.length === 0) {
    pane.innerHTML = '<div style="color:#888; text-align:center; margin-top:40px; letter-spacing:2px; font-size:14px;">当前无建设中项目</div>';
    if (buildProgressTimer) clearInterval(buildProgressTimer);
    return;
  }

  pane.innerHTML = '';
  buildTasks.forEach((task, idx) => {
    const item = document.createElement('div');
    item.style.cssText = 'background:rgba(0,0,0,0.4); border:1px solid rgba(201,163,106,0.3); border-radius:12px; padding:16px; display:flex; flex-direction:column; gap:12px;';
    
    // 我们用一个 span 来显示倒计时，方便 setInterval 更新
    item.innerHTML = `
      <div style="display:flex; justify-content:space-between; align-items:center;">
        <span style="color:var(--primary-color); font-size:15px; font-weight:bold; letter-spacing:2px;">${task.palaceName}</span>
        <button class="btn-accel" data-idx="${idx}" style="background:var(--primary-color); border:none; color:#000; padding:4px 12px; border-radius:12px; font-size:12px; font-weight:bold;">${task.endTime <= Date.now() ? '落成' : '加速'}</button>
      </div>
      <div style="display:flex; justify-content:space-between; align-items:center;">
        <span style="color:#aaa; font-size:12px;">剩余时间：</span>
        <span class="countdown-text" data-end="${task.endTime}" style="color:#fff; font-size:13px; font-family:monospace;">计算中...</span>
      </div>
    `;
    pane.appendChild(item);
  });

  pane.querySelectorAll('.btn-accel').forEach(btn => {
    btn.onclick = async (e) => {
      const idx = e.target.dataset.idx;
      const task = buildTasks[idx];
      
      const now = Date.now();
      if (task.endTime <= now || cheatExpireTime > now) {
        api.ui.toast(task.endTime <= now ? `${task.palaceName}已落成` : `金手指生效！${task.palaceName}立即落成`);
        await finishPalaceBuild(Number(idx));
      } else {
        // 没有金手指
        api.ui.toast("加速需要帝王特权，请前往「操作」面板开通金手指");
      }
    };
  });

  const updateTimers = () => {
    const els = pane.querySelectorAll('.countdown-text');
    if (els.length === 0) { clearInterval(buildProgressTimer); return; }
    const now = Date.now();
    els.forEach(el => {
      const end = parseInt(el.dataset.end);
      let diff = Math.floor((end - now) / 1000);
      if (diff <= 0) {
        el.innerText = '已完成';
        el.style.color = '#99ff99';
      } else {
        const d = Math.floor(diff / 86400); diff %= 86400;
        const h = Math.floor(diff / 3600); diff %= 3600;
        const m = Math.floor(diff / 60);
        const s = diff % 60;
        el.innerText = `${d}天 ${h}时 ${m}分 ${s}秒`;
      }
    });
  };

  if (buildProgressTimer) clearInterval(buildProgressTimer);
  updateTimers();
  buildProgressTimer = setInterval(updateTimers, 1000);
}


// ===== 养心殿·休息小窗 =====
function openRestMenu() {
  const old = document.getElementById('rest-menu-modal');
  if (old) old.remove();

  const modal = document.createElement('div');
  modal.id = 'rest-menu-modal';
  modal.style.cssText = 'position:absolute; inset:0; z-index:9999; display:flex; align-items:center; justify-content:center;';

  const panel = document.createElement('div');
  panel.style.cssText = `
    width:240px;
    background:rgba(14,12,10,0.88);
    backdrop-filter:blur(20px); -webkit-backdrop-filter:blur(20px);
    border:1px solid rgba(201,163,106,0.45);
    border-radius:20px;
    padding:20px 0 12px;
    display:flex; flex-direction:column; align-items:center; gap:0;
    box-shadow:0 12px 40px rgba(0,0,0,0.7), 0 0 0 1px rgba(201,163,106,0.08);
  `;

  const title = document.createElement('div');
  title.style.cssText = 'color:rgba(201,163,106,0.6); font-size:11px; letter-spacing:4px; font-family:"STZhongsong","STSong",serif; margin-bottom:14px;';
  title.textContent = '— 休 息 —';
  panel.appendChild(title);

  const items = [
    {
      icon: `<svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round"><rect x="2" y="3" width="4" height="18" rx="1"/><rect x="10" y="3" width="4" height="18" rx="1"/><rect x="18" y="3" width="4" height="18" rx="1"/></svg>`,
      label: '翻牌子',
      sub: '召幸妃嫔侍寝',
      action: () => { modal.remove(); openFanPaiModal(); }
    },
    {
      icon: `<svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round"><path d="M21 12.79A9 9 0 1 1 11.21 3 7 7 0 0 0 21 12.79z"/></svg>`,
      label: '独自休息',
      sub: '安然入眠，时间流逝',
      action: () => { modal.remove(); api.ui.toast('夜色沉沉，帝王独眠…（功能开发中）'); }
    },
    {
      icon: `<svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round"><path d="M4 12h16"/><path d="M4 12a8 8 0 0 1 16 0"/><path d="M6 12v6a2 2 0 0 0 2 2h8a2 2 0 0 0 2-2v-6"/><path d="M12 2v3"/><path d="M8 4l1.5 2"/><path d="M16 4l-1.5 2"/></svg>`,
      label: '沐浴',
      sub: '沐浴更衣，焕然一新',
      action: () => { modal.remove(); openBathModal(); }
    }
  ];

  items.forEach((item, idx) => {
    const btn = document.createElement('button');
    btn.style.cssText = `
      width:100%; background:transparent; border:none;
      padding:14px 20px;
      display:flex; align-items:center; gap:14px;
      cursor:pointer; transition:background 0.18s;
      ${idx < items.length - 1 ? 'border-bottom:1px solid rgba(201,163,106,0.1);' : ''}
    `;

    const iconEl = document.createElement('div');
    iconEl.style.cssText = 'width:28px; height:28px; display:flex; align-items:center; justify-content:center; flex-shrink:0; color:rgba(201,163,106,0.85);';
    iconEl.innerHTML = item.icon;

    const textWrap = document.createElement('div');
    textWrap.style.cssText = 'display:flex; flex-direction:column; gap:3px; text-align:left;';

    const labelEl = document.createElement('div');
    labelEl.style.cssText = 'color:rgba(201,163,106,0.95); font-size:15px; letter-spacing:3px; font-family:"STZhongsong","STSong",serif;';
    labelEl.textContent = item.label;

    const subEl = document.createElement('div');
    subEl.style.cssText = 'color:#666; font-size:11px; letter-spacing:1px;';
    subEl.textContent = item.sub;

    textWrap.appendChild(labelEl);
    textWrap.appendChild(subEl);
    btn.appendChild(iconEl);
    btn.appendChild(textWrap);

    btn.addEventListener('click', item.action);
    btn.addEventListener('touchstart', () => { btn.style.background = 'rgba(201,163,106,0.08)'; }, {passive:true});
    btn.addEventListener('touchend', () => { setTimeout(() => btn.style.background = 'transparent', 200); }, {passive:true});

    panel.appendChild(btn);
  });

  const cancelBtn = document.createElement('button');
  cancelBtn.style.cssText = 'margin-top:8px; background:transparent; border:none; color:#555; font-size:13px; font-family:inherit; padding:8px; cursor:pointer; letter-spacing:2px;';
  cancelBtn.textContent = '取消';
  cancelBtn.onclick = () => modal.remove();
  panel.appendChild(cancelBtn);

  modal.appendChild(panel);
  modal.addEventListener('click', e => { if (e.target === modal) modal.remove(); });
  document.getElementById('view-palace-detail').appendChild(modal);
}

// ===== 养心殿·沐浴 =====
function openBathModal() {
  const old = document.getElementById('bath-modal');
  if (old) old.remove();

  const modal = document.createElement('div');
  modal.id = 'bath-modal';
  modal.style.cssText = 'position:absolute; inset:0; z-index:9999; display:flex; align-items:center; justify-content:center;';

  const panel = document.createElement('div');
  panel.style.cssText = `
    width:260px;
    background:rgba(14,12,10,0.92);
    backdrop-filter:blur(20px); -webkit-backdrop-filter:blur(20px);
    border:1px solid rgba(201,163,106,0.45);
    border-radius:20px;
    padding:24px 0 14px;
    display:flex; flex-direction:column; align-items:center; gap:0;
    box-shadow:0 12px 40px rgba(0,0,0,0.7), 0 0 0 1px rgba(201,163,106,0.08);
  `;

  const title = document.createElement('div');
  title.style.cssText = 'color:rgba(201,163,106,0.6); font-size:11px; letter-spacing:4px; font-family:"STZhongsong","STSong",serif; margin-bottom:16px;';
  title.textContent = '— 沐 浴 —';
  panel.appendChild(title);

  const items = [
    {
      icon: `<svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="8" r="4"/><path d="M4 20c0-4 3.6-7 8-7s8 3 8 7"/></svg>`,
      label: '独自沐浴',
      sub: '屏退众人，独自静沐',
      action: () => { modal.remove(); startSoloBath(); }
    },
    {
      icon: `<svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round"><path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M23 21v-2a4 4 0 0 0-3-3.87"/><path d="M16 3.13a4 4 0 0 1 0 7.75"/></svg>`,
      label: '谢临渊，你帮朕',
      sub: '命谢临渊亲自服侍',
      action: () => { modal.remove(); startXlyBath(); }
    }
  ];

  items.forEach((item, idx) => {
    const btn = document.createElement('button');
    btn.style.cssText = `
      width:100%; background:transparent; border:none;
      padding:14px 20px;
      display:flex; align-items:center; gap:14px;
      cursor:pointer; transition:background 0.18s;
      ${idx < items.length - 1 ? 'border-bottom:1px solid rgba(201,163,106,0.1);' : ''}
    `;

    const iconEl = document.createElement('div');
    iconEl.style.cssText = 'width:28px; height:28px; display:flex; align-items:center; justify-content:center; flex-shrink:0; color:rgba(201,163,106,0.85);';
    iconEl.innerHTML = item.icon;

    const textWrap = document.createElement('div');
    textWrap.style.cssText = 'display:flex; flex-direction:column; gap:3px; text-align:left;';

    const labelEl = document.createElement('div');
    labelEl.style.cssText = 'color:rgba(201,163,106,0.95); font-size:15px; letter-spacing:3px; font-family:"STZhongsong","STSong",serif;';
    labelEl.textContent = item.label;

    const subEl = document.createElement('div');
    subEl.style.cssText = 'color:#666; font-size:11px; letter-spacing:1px;';
    subEl.textContent = item.sub;

    textWrap.appendChild(labelEl);
    textWrap.appendChild(subEl);
    btn.appendChild(iconEl);
    btn.appendChild(textWrap);

    btn.addEventListener('click', item.action);
    btn.addEventListener('touchstart', () => { btn.style.background = 'rgba(201,163,106,0.08)'; }, {passive:true});
    btn.addEventListener('touchend', () => { setTimeout(() => btn.style.background = 'transparent', 200); }, {passive:true});

    panel.appendChild(btn);
  });

  const cancelBtn = document.createElement('button');
  cancelBtn.style.cssText = 'margin-top:8px; background:transparent; border:none; color:#555; font-size:13px; font-family:inherit; padding:8px; cursor:pointer; letter-spacing:2px;';
  cancelBtn.textContent = '取消';
  cancelBtn.onclick = () => modal.remove();
  panel.appendChild(cancelBtn);

  modal.appendChild(panel);
  modal.addEventListener('click', e => { if (e.target === modal) modal.remove(); });
  document.getElementById('view-palace-detail').appendChild(modal);
}

// ===== 独自沐浴 =====
async function startSoloBath() {
  // 收集养心殿记事（养心殿总录里所有人的记事）
  const allChars = [...selectedCharsData, XLY_CHAR];
  let allRecordsText = '';
  const seenIds = new Set();
  allChars.forEach(c => {
    if (c.records && c.records.length > 0) {
      c.records.forEach(r => {
        if (!seenIds.has(r.id)) {
          seenIds.add(r.id);
          allRecordsText += `【${r.time}】${r.text}\n`;
        }
      });
    }
  });
  if (!allRecordsText.trim()) allRecordsText = '（近日无特别记事）';

  // user人设
  const userDesc = userAncientDesc ? `【皇帝人设】：\n${userAncientDesc}` : '';
  const timeStr = hudTime ? hudTime.innerText : '未知时辰';

  // 获取养心殿背景
  const yangXinBg = palaceDetails['养心殿']?.bgUrl || '';

  // 切换到室内视图展示
  const vIndoor = document.getElementById('view-indoor');
  document.getElementById('indoor-bg-layer').style.backgroundImage = `url('${yangXinBg}')`;
  document.getElementById('indoor-avatar-container').style.display = 'none';
  document.getElementById('indoor-bottom-bar').style.display = 'none';

  const chatWrap = document.getElementById('indoor-chat-wrap');
  const chatBox = document.getElementById('indoor-chat-box');
  const blocker = document.getElementById('indoor-blocker');

  chatWrap.style.display = 'flex';
  chatBox.innerHTML = '<span style="color:var(--primary-color);">热汤已备，水雾氤氲中…</span>';
  chatBox.style.opacity = '1';
  chatWrap.style.opacity = '1';
  blocker.style.display = 'block';

  indoorChatContext.history = [];
  indoorChatContext.mode = 'bath_solo';

  switchView(vIndoor);

  const sysPrompt = `你是一位古代宫廷文学创作者，擅长撰写唯美、细腻、充满古典意境的宫廷小正文。当前游戏时间：${timeStr}。

【本次场景：养心殿·独自沐浴】
你（User，皇帝）屏退了所有内侍与宫女，内侍已将浴桶中注满了热汤，桶边摆好了香皂、香料与软巾，随后悄悄退下，殿中只剩你一人。

${userDesc}

【近日养心殿记事（你的近期经历与心事）】：
${allRecordsText}

【创作指令，逐条遵守】：
1. 请以第二人称（"你"）视角，写一段你独自沐浴的小正文，字数在600~900字之间。全程以"你"指代皇帝，绝不使用"她"或"帝"等第三人称。
2. 请结合上方的记事内容，让你在沐浴时自然地思索近日发生的事情——可以是在心中默默盘算某件朝政，可以是想起某位妃嫔的趣事，可以是发呆出神，可以是自己无聊地玩起了水，也可以是不知不觉困倦，几乎在汤中睡着。创意自由发挥，选择其中一到两个方向展开。
3. 文字须古风雅致，充满感官细节（水温、香气、灯火摇曳、水声等），营造出一种沉浸、私密、慵懒的氛围。
4. 绝对不要生成任何对话台词，这是纯粹的环境与内心描写。
5. 【分段铁律】：每个 <p> 段落不超过50字，约两三句话即换段，宁可多段也绝不堆砌长段。
6. 正文分段输出，每段用 <p> 标签包裹，不需要 data-speaker 属性。`;

  try {
    const res = await api.ai.chat({ messages: [{ role: 'user', content: sysPrompt }] });
    const text = typeof res === 'string' ? res : (res?.content ?? res?.text ?? '');
    playSoloBathText(text);
  } catch(e) {
    chatBox.innerHTML = '<span style="color:#d9534f;">推演失败，请重试。</span>';
    blocker.style.display = 'none';
  }
}

function playSoloBathText(fullText) {
  const pRegex = /<p(?:[^>]*)>(.*?)<\/p>/g;
  const segments = [];
  let match;
  while ((match = pRegex.exec(fullText)) !== null) {
    segments.push(match[1]);
  }
  const finalSegs = segments.length > 0 ? segments : fullText.replace(/<[^>]+>/g, '').split('\n').filter(x => x.trim());

  let idx = 0;
  const chatBox = document.getElementById('indoor-chat-box');
  const chatWrap = document.getElementById('indoor-chat-wrap');
  const blocker = document.getElementById('indoor-blocker');

  function showNext() {
    if (idx >= finalSegs.length) {
      // 所有段落播完，直接关闭，不进入记忆
      setTimeout(() => {
        chatWrap.style.display = 'none';
        chatBox.innerHTML = '';
        blocker.style.display = 'none';
        document.getElementById('indoor-avatar-container').style.display = 'flex';
        document.getElementById('indoor-bottom-bar').style.display = 'flex';
        document.getElementById('indoor-bottom-bar').style.opacity = '1';
        // 退出室内视图，回到宫殿详情
        switchView(vPalaceDetail);
      }, 1200);
      return;
    }

    const seg = finalSegs[idx];
    chatWrap.style.opacity = '0';
    chatBox.style.opacity = '0';

    setTimeout(async () => {
      chatBox.innerHTML = '';
      chatWrap.style.opacity = '1';
      chatBox.style.opacity = '1';

      // 可点击跳过打字
      const tapSkip = () => skipTypewriter();
      blocker.addEventListener('click', tapSkip);
      await playTypewriter(chatBox, seg, 2500);
      blocker.removeEventListener('click', tapSkip);

      idx++;
      // 点击推进下一段
      const tapNext = () => {
        blocker.removeEventListener('click', tapNext);
        chatWrap.querySelector('#indoor-chat-box').parentElement.removeEventListener('click', tapNext);
        showNext();
      };
      blocker.addEventListener('click', tapNext);
      chatWrap.addEventListener('click', tapNext);
    }, 350);
  }

  showNext();
}

// ===== 谢临渊帮朕沐浴 =====
async function startXlyBath() {
  // 设置谢临渊立绘
  XLY_CHAR.indoorBgUrl = palaceDetails['养心殿']?.bgUrl || XLY_CHAR.indoorBgUrl || null;
  window.currentIndoorChar = XLY_CHAR;
  window._indoorSceneContext = { type:'bath_xly', pName:'养心殿', rName:'浴室', premise:`皇帝正在养心殿沐浴，${XLY_CHAR.name}奉命在养心殿浴室服侍；不得改写成普通传召或其他宫殿。` };

  // 如果还没有养心殿背景，先绘景
  if (!XLY_CHAR.indoorBgUrl) {
    currentDetailPalaceName = '__INDOOR__';
    pbTitle.innerText = `养心殿 · 室内绘景`;
    pbPrompt.value = `真实画风，中国古代皇宫室内，养心殿内景，华丽，唯美，无人物`;
    pbImg.style.display = 'none';
    pbPlaceholder.style.display = 'block';
    pbLoader.style.display = 'none';
    btnPbConfirm.style.display = 'none';
    tempPbDataUrl = null;
    isCourtyardMode = false;
    pbModal.style.display = 'flex';
    // 在绘景确认后，pbModal confirm 会调用 enterIndoorView，
    // 但此时 currentIndoorChar 已经是 XLY_CHAR，
    // 所以我们需要覆盖 pbModal 的确认逻辑让其在确认后继续沐浴流程
    // 使用一次性标记
    window._pendingBathAfterBg = true;
    return;
  }

  enterXlyBathView();
}

async function enterXlyBathView() {
  const char = XLY_CHAR;
  const yangXinBg = palaceDetails['养心殿']?.bgUrl || '';

  const vIndoor = document.getElementById('view-indoor');
  document.getElementById('indoor-bg-layer').style.backgroundImage = `url('${yangXinBg}')`;

  // 显示谢临渊立绘
  const displayAvatar = char.customAvatar || char.avatar;
  const indoorAvatarImgEl = document.getElementById('indoor-avatar-img');
  indoorAvatarImgEl.src = displayAvatar;
  if (char.storyAvatarCfg) {
    const cfg = char.storyAvatarCfg;
    indoorAvatarImgEl.style.transform = `translate(${cfg.x}px, ${cfg.y}px) scale(${cfg.scale / 100})`;
  }
  document.getElementById('indoor-avatar-container').style.display = 'flex';
  document.getElementById('indoor-bottom-bar').style.display = 'none';

  const chatWrap = document.getElementById('indoor-chat-wrap');
  const chatBox = document.getElementById('indoor-chat-box');
  const blocker = document.getElementById('indoor-blocker');

  chatWrap.style.display = 'flex';
  chatBox.innerHTML = '<span style="color:var(--primary-color);">谢临渊正在前来…</span>';
  chatBox.style.opacity = '1';
  chatWrap.style.opacity = '1';
  blocker.style.display = 'block';

  indoorChatContext.history = [];
  indoorChatContext.mode = 'bath_xly';

  switchView(vIndoor);

  // 绑定退出按钮
  const origExitHandler = document.getElementById('btn-exit-indoor').onclick;
  document.getElementById('btn-exit-indoor').onclick = () => {
    chatWrap.style.display = 'none';
    chatBox.innerHTML = '';
    blocker.style.display = 'none';
    document.getElementById('indoor-avatar-container').style.display = 'flex';
    document.getElementById('indoor-bottom-bar').style.display = 'flex';
    document.getElementById('indoor-bottom-bar').style.opacity = '1';
    indoorChatContext.history = [];
    document.getElementById('btn-exit-indoor').onclick = origExitHandler;
    switchView(vPalaceDetail);
  };

  const timeStr = hudTime ? hudTime.innerText : '未知时辰';
  const userDesc = userAncientDesc ? `【皇帝人设】：\n${userAncientDesc}` : '';
  // 分析谢临渊与user的关系阶段
  const relKey = `谢临渊->user`;
  const relData = window._relationData?.[relKey];
  const relText = relData?.text ? `【谢临渊与皇帝的当前关系】：\n${relData.text}` : '';

  const sysPrompt = `你是一位古代宫廷文学创作者，擅长撰写唯美、细腻、充满古典意境与禁忌张力的宫廷小正文。当前游戏时间：${timeStr}。

【本次场景：养心殿·命谢临渊服侍沐浴】
皇帝（User）命谢临渊前来服侍沐浴。谢临渊需要亲自去放水调温、替皇帝脱去衣物、服侍皇帝入浴，并在旁照料。

${userDesc}

【谢临渊本轮重新读取的人设、人物世界书与全部记忆】：
${buildCharacterAiContext(XLY_CHAR)}

${relText}

【谢临渊的外在表现铁律——必须逐条遵守，违者视为创作失败】：
A. 【绝对禁止】以下任何表现形式，均为油腻、失真、破坏人设的败笔，一经出现即视为不合格：
   - 握紧拳头、指甲嵌入掌心、手背青筋、捏紧袖口等"暗中用力"的夸张肢体动作；
   - 喉结滚动、呼吸急促、心跳加速等生理反应的直白描写；
   - 视线失控地打量、目光流连等"偷看"行为；
   - 任何表情上的明显变化（皱眉、抿唇、眼神动摇等）；
   - 任何形式的慌乱、失神、怔愣超过一瞬。
B. 【谢临渊的唯一正确表现】：他的外在始终是平静无波、公事公办的职业状态，仿佛这不过是一件需要完成的差事。他内心的挣扎、克制与煎熬，只允许通过以下极微小的、几乎难以察觉的细节来渗透：
   - 动作之间一个极短暂的停顿；
   - 几不可闻的、压在喉间的一声轻叹；
   - 手指指尖力道稍重或稍轻一分，随即恢复如常；
   - 收拾器皿或整理物件时，多余地重复了一个已完成的动作；
   - 语气一如往常，但某句话说完后，沉默了比平时稍长的半息。
   这些细节，读者甚至可以怀疑是否真的存在——这才是谢临渊。

【创作指令，逐条严格遵守】：
1. 以第三人称视角，写一段谢临渊服侍皇帝沐浴的小正文，字数在1500~2000字之间。
2. 【关系分析铁律】：请先在 <think></think> 中分析二人目前的关系阶段，再开始正文。
   - 若二人关系仍处于暧昧期或君臣主从的克制阶段：谢临渊会以礼法为由明确表达"此事不合规矩"，表现出一种"知道不可以，但又拗不过皇帝"的无奈，言辞上做出"不可以"的姿态，但身体最终仍会执行每一道命令，将所有逾矩的情绪用完美的职业外壳封印。
   - 若二人已有更深层的情感基础：可以展现更多微妙的情感流动，但谢临渊的外在仍要维持克制与恭顺。
3. 正文必须包含以下几个场景节点，按顺序展开：
   a. 谢临渊接到命令时的内心反应与应对（言辞上的礼法婉拒，身体上的无声服从）
   b. 亲自去张罗放水、调水温、备好香料软巾的过程（展现其一丝不苟的完美主义，每一步都精准）
   c. 替皇帝解去外袍的场景（张力核心：动作必须精准、克制、不多余，内心的分寸全靠B条中的微小细节渗透）
   d. 服侍皇帝入浴、在旁照料的过程（他就是一道安静的影子，专注而沉默）
4. 谢临渊的对话：语气永远恭顺，言辞中带有对礼法的坚守与隐隐的提醒，绝不失态，绝不主动逾矩。
5. 【称谓铁律】：正文全程用"你"指代User（皇帝），严禁使用"她"、"皇帝"、"陛下"等任何第三人称或称谓来指代User；谢临渊的对话中对User的称呼用"陛下"符合人设，但叙事段必须用"你"。
6. 绝对不要替你（皇帝）说话或做决定，只能描写谢临渊的动作、神态、内心，以及你作为一个存在的模糊轮廓。
7. 【分段铁律】：每个叙事 <p> 段落不超过50字，约两三句话即换段，宁可多段也绝不堆砌长段。
8. 正文分段输出，每段用 <p> 标签包裹；谢临渊的对话单独占一个 <p> 标签，格式：<p data-speaker="谢临渊">"说的话"</p>，只用英文双引号。

${getAiParagraphFormatGuard()}`;

  try {
    const res = await api.ai.chat({ messages: [{ role: 'user', content: sysPrompt }] });
    const text = typeof res === 'string' ? res : (res?.content ?? res?.text ?? '');
    playIndoorChat(text);
  } catch(e) {
    chatBox.innerHTML = '<span style="color:#d9534f;">推演失败，请重试。</span>';
    blocker.style.display = 'none';
  }
}

// ===== 养心殿·翻牌子 =====
// 牌子图标默认地址
const FAN_PAI_DEFAULT_ICON = 'https://www.imgfox.cn/apis/uploads/20260822/6392cfb4cada448d/cf6bf58f4nbfc400d98895d8bdfee48c.png';

function openFanPaiModal() {
  const old = document.getElementById('fanpai-modal');
  if (old) old.remove();

  // 所有角色（不论身份）
  const allChars = [...selectedCharsData, XLY_CHAR].filter(c => c.name);
  if (allChars.length === 0) { api.ui.toast('尚无故人，请先引入角色'); return; }

  // 读取已存的牌子图标自定义
  if (!window._fanPaiIconUrl) window._fanPaiIconUrl = null; // null = 用默认

  const modal = document.createElement('div');
  modal.id = 'fanpai-modal';
  modal.style.cssText = `
    position:fixed; inset:0; z-index:99999;
    background:url('https://www.imgfox.cn/apis/uploads/20260822/32adb14451714917/IMG_9798.png') center/cover no-repeat;
    display:flex; flex-direction:column;
  `;

  const bg = document.createElement('div');
  bg.style.cssText = 'position:absolute; inset:0; background:transparent; z-index:0;';
  modal.appendChild(bg);

  const wrap = document.createElement('div');
  wrap.style.cssText = 'position:relative; z-index:1; display:flex; flex-direction:column; height:100%; overflow:hidden;';

  // ── 顶栏 ──
  const header = document.createElement('div');
  header.style.cssText = 'padding-top:calc(var(--safe-top,44px) + 6px); padding-bottom:10px; padding-left:16px; padding-right:16px; display:flex; justify-content:space-between; align-items:center; border-bottom:1px solid rgba(201,163,106,0.2); flex-shrink:0;';
  header.innerHTML = `
    <button id="fanpai-close" style="background:transparent;border:none;color:#888;font-size:16px;font-family:inherit;padding:8px 4px;">关闭</button>
    <div style="color:var(--primary-color);font-size:18px;font-weight:bold;letter-spacing:5px;font-family:'STZhongsong','STSong',serif;
      background:linear-gradient(to bottom,#ffe9b8,#c9a36a);-webkit-background-clip:text;-webkit-text-fill-color:transparent;
      filter:drop-shadow(0 1px 4px rgba(0,0,0,0.8));">翻牌子</div>
    <button id="fanpai-icon-cfg" style="background:transparent;border:1px solid rgba(201,163,106,0.3);color:rgba(201,163,106,0.7);padding:4px 10px;border-radius:12px;font-size:11px;font-family:inherit;">牌样</button>
  `;
  wrap.appendChild(header);

  // ── 说明文字 ──
  const hint = document.createElement('div');
  hint.style.cssText = 'color:#888; font-size:12px; text-align:center; padding:10px 16px 4px; letter-spacing:1px; flex-shrink:0;';
  hint.textContent = '点击牌子选中（可多选），或使用随机';
  wrap.appendChild(hint);

  // ── 牌子滚动区 ──
  const trayWrap = document.createElement('div');
  trayWrap.style.cssText = 'flex:1; overflow:hidden; position:relative; display:flex; align-items:center;';

  const tray = document.createElement('div');
  tray.id = 'fanpai-tray';
  tray.style.cssText = `
    display:flex; gap:18px; overflow-x:auto; overflow-y:visible;
    padding:20px 40px 30px;
    scrollbar-width:none; -webkit-overflow-scrolling:touch;
    align-items:flex-end;
    scroll-snap-type:x mandatory;
    height:100%;
  `;
  tray.style.setProperty('-webkit-overflow-scrolling', 'touch');

  const selectedPaiIds = new Set();

  allChars.forEach((char, idx) => {
    // 牌面文字：身份非后妃显示身份，后妃显示具体位份
    const paiText = (char.ancientRole === '后妃')
      ? (char.assignedRank || '后妃')
      : (char.ancientRole || char.assignedRank || '故人');

    const paiWrap = document.createElement('div');
    paiWrap.className = 'fanpai-item';
    paiWrap.dataset.id = char.id || char.name;
    // 错落排列
    const isOdd = idx % 2 === 1;
    paiWrap.style.cssText = `
      flex-shrink:0; scroll-snap-align:center;
      display:flex; flex-direction:column; align-items:center; gap:10px;
      cursor:pointer; user-select:none;
      transform:translateY(${isOdd ? '-20px' : '0px'});
      transition:transform 0.3s, filter 0.3s;
    `;

    // 牌子本体：直接把图标拉成3倍高，宽度不变
    const paiBody = document.createElement('div');
    paiBody.className = 'fanpai-body';
    paiBody.style.cssText = `
      width:52px; height:468px;
      position:relative; border-radius:4px;
      overflow:hidden;
      box-shadow:2px 4px 12px rgba(0,0,0,0.7);
      transition:box-shadow 0.3s, transform 0.5s cubic-bezier(0.25,0.8,0.25,1);
      transform-style:preserve-3d;
    `;

    const paiFront = document.createElement('div');
    paiFront.style.cssText = `
      position:absolute; inset:0;
      display:flex; align-items:center; justify-content:center;
      backface-visibility:hidden;
    `;
    const iconUrl = window._fanPaiIconUrl || FAN_PAI_DEFAULT_ICON;

    // 图标直接拉伸到 52×468（宽不变，高3倍）
    const iconImg = document.createElement('img');
    iconImg.src = iconUrl;
    iconImg.style.cssText = `
      width:52px; height:468px;
      object-fit:fill;
      position:absolute; inset:0;
    `;
    paiFront.appendChild(iconImg);

    // 竖排文字叠在图标正中
    const paiRoleText = document.createElement('div');
    paiRoleText.className = 'gilded-text';
    paiRoleText.style.cssText = `
      position:relative; z-index:2;
      writing-mode:vertical-rl; text-orientation:upright;
      font-size:16px; letter-spacing:6px; font-weight:300;
      font-family:'STZhongsong','STSong',serif;
    `;
    paiRoleText.textContent = paiText;
    paiFront.appendChild(paiRoleText);

    // 选中后的金光遮罩
    const selectedGlow = document.createElement('div');
    selectedGlow.className = 'pai-glow';
    selectedGlow.style.cssText = `
      position:absolute; inset:0;
      background:linear-gradient(135deg, rgba(255,220,100,0.45) 0%, rgba(201,163,106,0.2) 100%);
      border:2px solid rgba(255,220,100,0.8);
      border-radius:6px 6px 4px 4px;
      opacity:0; transition:opacity 0.3s;
      pointer-events:none;
    `;
    paiFront.appendChild(selectedGlow);

    paiBody.appendChild(paiFront);

    // 名字小字
    const nameEl = document.createElement('div');
    nameEl.style.cssText = `
      font-size:11px; color:rgba(201,163,106,0.75); letter-spacing:2px;
      font-family:'STZhongsong','STSong',serif;
      text-shadow:0 1px 4px rgba(0,0,0,0.9);
      white-space:nowrap;
    `;
    nameEl.textContent = char.name;

    paiWrap.appendChild(paiBody);
    paiWrap.appendChild(nameEl);
    const disciplineBadge = typeof getCharacterDisciplineBadge === 'function' ? getCharacterDisciplineBadge(char) : '';
    if (disciplineBadge) {
      const badge = document.createElement('div');
      badge.style.cssText = 'max-width:110px;color:#f0b09a;background:rgba(91,25,23,.86);border:1px solid rgba(210,126,103,.7);padding:4px 7px;border-radius:10px;font-size:9px;text-align:center;line-height:1.4;';
      badge.innerText = disciplineBadge;
      paiWrap.appendChild(badge);
      paiWrap.style.filter = 'grayscale(.7) brightness(.65)';
    }
    tray.appendChild(paiWrap);

    // 点击选中/取消
    paiWrap.addEventListener('click', async () => {
      if (typeof isCharacterUnavailableForActivity === 'function' && isCharacterUnavailableForActivity(char)) {
        await notifyCharacterUnavailable(char);
        return;
      }
      const id = paiWrap.dataset.id;
      if (selectedPaiIds.has(id)) {
        selectedPaiIds.delete(id);
        paiBody.style.transform = '';
        paiBody.style.boxShadow = '2px 4px 12px rgba(0,0,0,0.7), inset 0 1px 0 rgba(255,255,255,0.08)';
        selectedGlow.style.opacity = '0';
        paiWrap.style.filter = '';
      } else {
        selectedPaiIds.add(id);
        // 翻牌动画：先往后倾，再翻回来
        paiBody.style.transform = 'rotateY(20deg) scale(1.08)';
        paiBody.style.boxShadow = '0 0 24px rgba(255,220,100,0.6), 4px 6px 16px rgba(0,0,0,0.8)';
        selectedGlow.style.opacity = '1';
        paiWrap.style.filter = 'brightness(1.15)';
        setTimeout(() => {
          paiBody.style.transform = 'rotateY(0deg) scale(1.08)';
        }, 160);
      }
      updateConfirmBtn();
    });
  });

  trayWrap.appendChild(tray);
  wrap.appendChild(trayWrap);

  // ── 底部操作区 ──
  const bottomArea = document.createElement('div');
  bottomArea.style.cssText = `
    padding:12px 20px calc(var(--safe-bottom,24px)+16px);
    display:flex; flex-direction:column; gap:10px; flex-shrink:0;
    border-top:1px solid rgba(201,163,106,0.15);
    background:rgba(6,4,2,0.5);
  `;

  // 随机区
  const randomRow = document.createElement('div');
  randomRow.style.cssText = 'display:flex; align-items:center; gap:10px;';

  const randomBtn = document.createElement('button');
  randomBtn.style.cssText = 'flex:1; background:rgba(201,163,106,0.1); border:1px solid rgba(201,163,106,0.4); color:rgba(201,163,106,0.9); padding:10px; border-radius:10px; font-size:14px; letter-spacing:2px; font-family:inherit;';
  randomBtn.textContent = '🎲 随机翻牌';

  const randomCountWrap = document.createElement('div');
  randomCountWrap.style.cssText = 'display:flex; align-items:center; gap:6px; flex-shrink:0;';
  randomCountWrap.innerHTML = `
    <span style="color:#888; font-size:12px;">随机</span>
    <button id="fp-cnt-minus" style="width:26px;height:26px;border-radius:50%;background:rgba(201,163,106,0.1);border:1px solid rgba(201,163,106,0.3);color:var(--primary-color);font-size:16px;display:flex;align-items:center;justify-content:center;">−</button>
    <span id="fp-cnt" style="color:var(--primary-color);font-size:15px;font-weight:bold;min-width:16px;text-align:center;">1</span>
    <button id="fp-cnt-plus" style="width:26px;height:26px;border-radius:50%;background:rgba(201,163,106,0.1);border:1px solid rgba(201,163,106,0.3);color:var(--primary-color);font-size:16px;display:flex;align-items:center;justify-content:center;">+</button>
    <span style="color:#888; font-size:12px;">人</span>
  `;

  randomRow.appendChild(randomBtn);
  randomRow.appendChild(randomCountWrap);
  bottomArea.appendChild(randomRow);

  // 确认按钮
  const confirmBtn = document.createElement('button');
  confirmBtn.id = 'fanpai-confirm';
  confirmBtn.style.cssText = `
    width:100%; padding:14px;
    background:linear-gradient(135deg,#c9a36a,#8a6d3b);
    border:2px solid rgba(255,233,184,0.4);
    color:#1a1208; font-size:15px; font-weight:bold; letter-spacing:4px;
    font-family:'STZhongsong','STSong',serif;
    border-radius:12px;
    box-shadow:0 4px 16px rgba(201,163,106,0.3);
    opacity:0.4; pointer-events:none;
    transition:opacity 0.2s;
  `;
  confirmBtn.textContent = '传召入殿';
  bottomArea.appendChild(confirmBtn);

  wrap.appendChild(bottomArea);
  modal.appendChild(wrap);
  document.body.appendChild(modal);

  // ── 事件绑定 ──
  document.getElementById('fanpai-close').onclick = () => modal.remove();

  // 牌子图标自定义
  document.getElementById('fanpai-icon-cfg').onclick = async () => {
    const cfgDiv = document.createElement('div');
    cfgDiv.style.cssText = 'position:fixed;inset:0;z-index:200000;background:rgba(0,0,0,0.85);display:flex;align-items:flex-end;justify-content:center;';
    cfgDiv.innerHTML = `
      <div style="width:100%;max-width:360px;background:#1a1816;border:1px solid var(--primary-color);border-radius:20px 20px 0 0;padding:20px 16px calc(var(--safe-bottom,24px)+16px);display:flex;flex-direction:column;gap:12px;">
        <div style="color:var(--primary-color);font-size:16px;text-align:center;letter-spacing:3px;font-family:'STZhongsong','STSong',serif;">牌子图样</div>
        <div style="display:flex;justify-content:center;">
          <div style="width:52px;height:156px;background:no-repeat center/cover;border-radius:6px;box-shadow:2px 4px 12px rgba(0,0,0,0.7);" id="fp-cfg-preview"></div>
        </div>
        <div style="display:flex;gap:10px;">
          <button id="fp-cfg-pick" style="flex:1;background:rgba(201,163,106,0.1);border:1px solid var(--primary-color);color:var(--primary-color);padding:10px;border-radius:8px;font-family:inherit;font-size:13px;">从相册选图</button>
          <button id="fp-cfg-reset" style="flex:1;background:transparent;border:1px solid #666;color:#aaa;padding:10px;border-radius:8px;font-family:inherit;font-size:13px;">恢复默认</button>
        </div>
        <button id="fp-cfg-close" style="background:transparent;border:none;color:#555;font-family:inherit;font-size:13px;padding:4px;">关闭</button>
      </div>
    `;
    document.body.appendChild(cfgDiv);
    const preview = cfgDiv.querySelector('#fp-cfg-preview');
    preview.style.backgroundImage = `url('${window._fanPaiIconUrl || FAN_PAI_DEFAULT_ICON}')`;

    cfgDiv.querySelector('#fp-cfg-pick').onclick = async () => {
      try {
        const picked = await api.media.pick({ accept: 'image/*' });
        if (picked?.file) {
          window._fanPaiIconUrl = picked.file.dataUrl;
          preview.style.backgroundImage = `url('${picked.file.dataUrl}')`;
          await saveProgress({ fanPaiIconUrl: window._fanPaiIconUrl });
          // 刷新所有牌子背景
          tray.querySelectorAll('.fanpai-body').forEach(b => {
            b.querySelector('div').style.backgroundImage = `url('${picked.file.dataUrl}')`;
          });
          api.ui.toast('牌样已更新');
        }
      } catch(e) {}
    };
    cfgDiv.querySelector('#fp-cfg-reset').onclick = async () => {
      window._fanPaiIconUrl = null;
      preview.style.backgroundImage = `url('${FAN_PAI_DEFAULT_ICON}')`;
      await saveProgress({ fanPaiIconUrl: null });
      tray.querySelectorAll('.fanpai-body').forEach(b => {
        b.querySelector('div').style.backgroundImage = `url('${FAN_PAI_DEFAULT_ICON}')`;
      });
      api.ui.toast('已恢复默认牌样');
    };
    cfgDiv.querySelector('#fp-cfg-close').onclick = () => cfgDiv.remove();
    cfgDiv.addEventListener('click', e => { if (e.target === cfgDiv) cfgDiv.remove(); });
  };

  // 随机数量控制
  let randomCount = 1;
  const cntEl = document.getElementById('fp-cnt');
  document.getElementById('fp-cnt-minus').onclick = () => { randomCount = Math.max(1, randomCount - 1); cntEl.textContent = randomCount; };
  const randomEligibleChars = allChars.filter(char => !(typeof isCharacterUnavailableForActivity === 'function' && isCharacterUnavailableForActivity(char)));
  document.getElementById('fp-cnt-plus').onclick = () => { randomCount = Math.min(Math.max(1, randomEligibleChars.length), randomCount + 1); cntEl.textContent = randomCount; };

  // 随机翻牌
  randomBtn.onclick = () => {
    // 先清除所有已选
    selectedPaiIds.clear();
    tray.querySelectorAll('.fanpai-item').forEach(item => {
      const body = item.querySelector('.fanpai-body');
      const glow = item.querySelector('.pai-glow');
      body.style.transform = '';
      body.style.boxShadow = '2px 4px 12px rgba(0,0,0,0.7), inset 0 1px 0 rgba(255,255,255,0.08)';
      glow.style.opacity = '0';
      const itemChar = allChars.find(char => String(char.id || char.name) === item.dataset.id);
      item.style.filter = itemChar && typeof isCharacterUnavailableForActivity === 'function' && isCharacterUnavailableForActivity(itemChar) ? 'grayscale(.7) brightness(.65)' : '';
    });

    // 随机选 randomCount 个
    if (!randomEligibleChars.length) { api.ui.toast('当前没有可翻牌召幸的人物'); return; }
    const shuffled = [...randomEligibleChars].sort(() => Math.random() - 0.5).slice(0, randomCount);
    shuffled.forEach(c => {
      const id = c.id || c.name;
      selectedPaiIds.add(id);
      const item = tray.querySelector(`.fanpai-item[data-id="${id}"]`);
      if (item) {
        const body = item.querySelector('.fanpai-body');
        const glow = item.querySelector('.pai-glow');
        body.style.transform = 'rotateY(20deg) scale(1.08)';
        body.style.boxShadow = '0 0 24px rgba(255,220,100,0.6), 4px 6px 16px rgba(0,0,0,0.8)';
        glow.style.opacity = '1';
        item.style.filter = 'brightness(1.15)';
        setTimeout(() => { body.style.transform = 'rotateY(0deg) scale(1.08)'; }, 160);
        // 滚动到该牌
        item.scrollIntoView({ behavior: 'smooth', block: 'nearest', inline: 'center' });
      }
    });
    updateConfirmBtn();
  };

  function updateConfirmBtn() {
    if (selectedPaiIds.size > 0) {
      confirmBtn.style.opacity = '1';
      confirmBtn.style.pointerEvents = 'auto';
      const names = allChars.filter(c => selectedPaiIds.has(c.id || c.name)).map(c => c.name).join('、');
      confirmBtn.textContent = `传召 ${names} 入殿`;
    } else {
      confirmBtn.style.opacity = '0.4';
      confirmBtn.style.pointerEvents = 'none';
      confirmBtn.textContent = '传召入殿';
    }
  }

  // 确认传召
  confirmBtn.onclick = () => {
    const chosen = allChars.filter(c => selectedPaiIds.has(c.id || c.name) && !(typeof isCharacterUnavailableForActivity === 'function' && isCharacterUnavailableForActivity(c)));
    if (chosen.length === 0) return;
    modal.remove();
    startFanPaiSession(chosen);
  };
}

// ===== 翻牌子·多人侍寝场景 =====
function startFanPaiSession(chosenChars) {
  chosenChars = chosenChars.filter(char => !(typeof isCharacterUnavailableForActivity === 'function' && isCharacterUnavailableForActivity(char)));
  if (!chosenChars.length) { api.ui.toast('所选人物当前均不可召幸'); return; }
  // 获取养心殿背景
  const yangXinBg = palaceDetails['养心殿']?.bgUrl || '';

  // 复用 view-indoor，但多人模式下特殊处理
  const vIndoor = document.getElementById('view-indoor');
  document.getElementById('indoor-bg-layer').style.backgroundImage = `url('${yangXinBg}')`;

  // 隐藏单人底部操作栏，换成多人版
  const singleBar = document.getElementById('indoor-bottom-bar');
  singleBar.style.display = 'none';

  // 隐藏单人立绘容器，改用多人
  const singleAvatarContainer = document.getElementById('indoor-avatar-container');
  singleAvatarContainer.style.display = 'none';

  // 清掉旧的多人容器
  const oldMulti = document.getElementById('fanpai-multi-container');
  if (oldMulti) oldMulti.remove();
  const oldBar = document.getElementById('fanpai-multi-bar');
  if (oldBar) oldBar.remove();

  // ── 多人立绘容器（仿窥见一幕，默认隐藏，谁说话显示谁）──
  const multiAvatarContainer = document.createElement('div');
  multiAvatarContainer.id = 'fanpai-multi-container';
  multiAvatarContainer.style.cssText = `
    position:absolute; bottom:0; left:50%; transform:translateX(-50%); z-index:18;
    display:none; flex-direction:column; align-items:center; transition:opacity 0.5s;
    pointer-events:none; width:100%; height:100vh; justify-content:flex-end;
  `;

  const avatarImg = document.createElement('img');
  avatarImg.id = 'fanpai-multi-avatar-img';
  avatarImg.style.cssText = `width:100%; height:100%; object-fit:contain; object-position:bottom; filter:drop-shadow(0 4px 20px rgba(0,0,0,0.8)); transform-origin:bottom center;`;
  
  const avatarName = document.createElement('div');
  avatarName.id = 'fanpai-multi-avatar-name';
  avatarName.style.display = 'none';

  multiAvatarContainer.appendChild(avatarImg);
  multiAvatarContainer.appendChild(avatarName);
  vIndoor.appendChild(multiAvatarContainer);

  // 无需独立按钮，「结束侍寝」已覆盖到 btn-inchat-exit

  // ── 覆盖顶部立绘调整按钮 → 弹出多人选择下拉 ──
  const adjBtnOrig = document.getElementById('btn-indoor-avatar-adj');
  const adjBtnClone = adjBtnOrig.cloneNode(true);
  adjBtnOrig.parentNode.replaceChild(adjBtnClone, adjBtnOrig);
  adjBtnClone.addEventListener('click', (e) => {
    e.stopPropagation();
    // 弹出选人小菜单
    const old = document.getElementById('fanpai-adj-picker');
    if (old) { old.remove(); return; }
    const picker = document.createElement('div');
    picker.id = 'fanpai-adj-picker';
    picker.style.cssText = `
      position:absolute; top:calc(var(--safe-top,44px)+56px); right:148px;
      z-index:30; background:rgba(14,12,10,0.92);
      backdrop-filter:blur(12px); -webkit-backdrop-filter:blur(12px);
      border:1px solid rgba(201,163,106,0.4); border-radius:12px;
      padding:6px 0; display:flex; flex-direction:column;
      box-shadow:0 8px 24px rgba(0,0,0,0.6); min-width:110px;
    `;
    chosenChars.forEach((char, idx) => {
      const item = document.createElement('button');
      item.style.cssText = `background:transparent; border:none; padding:10px 16px; color:rgba(201,163,106,0.9); font-size:13px; letter-spacing:2px; font-family:'STZhongsong','STSong',serif; text-align:left; width:100%; ${idx < chosenChars.length-1 ? 'border-bottom:1px solid rgba(201,163,106,0.1);' : ''}`;
      item.textContent = char.name;
      item.onclick = () => { picker.remove(); openFanPaiAvatarAdj(char, multiAvatarContainer); };
      picker.appendChild(item);
    });
    document.getElementById('view-indoor').appendChild(picker);
    // 点外面关闭
    setTimeout(() => {
      const close = (e) => { if (!picker.contains(e.target)) { picker.remove(); document.removeEventListener('click', close); } };
      document.addEventListener('click', close);
    }, 0);
  });

  window.currentIndoorChar = chosenChars[0];
  window._fanPaiChosenChars = chosenChars;
  window._indoorSceneContext = { type:'fanpai', pName:'养心殿', rName:'寝殿', premise:`皇帝在养心殿翻牌召幸${chosenChars.map(char => char.name).join('、')}，所有人均已奉召入养心殿共同侍寝；后续每轮必须保持全部在场人物，不得改写成皇帝去其他宫殿探望。` };

  // 退出时恢复 UI + 还原立绘调整按钮
  function exitFanPaiSession() {
    multiAvatarContainer.remove();
    const adjPanel = document.getElementById('fanpai-adj-panel');
    if (adjPanel) adjPanel.remove();
    const picker = document.getElementById('fanpai-adj-picker');
    if (picker) picker.remove();
    window._fanPaiChosenChars = null;
    const fanPaiExitButton = document.getElementById('btn-inchat-exit');
    fanPaiExitButton.onclick = null;
    fanPaiExitButton.textContent = '离去';
    fanPaiExitButton.style.background = 'rgba(139,32,32,0.2)';
    fanPaiExitButton.style.borderColor = '#8b2020';
    fanPaiExitButton.style.color = '#ff9999';
    // 还原立绘调整按钮为原来的单人逻辑
    const cloned = document.getElementById('btn-indoor-avatar-adj');
    if (cloned) {
      const restored = cloned.cloneNode(true);
      cloned.parentNode.replaceChild(restored, cloned);
      restored.addEventListener('click', () => {
        const char = window.currentIndoorChar;
        if (!char || !char.storyAvatarCfg) return;
        window.currentAdjChar = char;
        const modal = document.getElementById('story-avatar-adj-modal');
        document.getElementById('adj-scale').value = char.storyAvatarCfg.scale;
        document.getElementById('adj-x').value = char.storyAvatarCfg.x;
        document.getElementById('adj-y').value = char.storyAvatarCfg.y;
        modal.dataset.fromIndoor = 'true';
        modal.style.display = 'flex';
      });
    }
    singleAvatarContainer.style.display = 'flex';
    singleBar.style.display = 'flex';
    setTimeout(() => singleBar.style.opacity = '1', 50);
    switchView(vPalaceDetail);
  }

  function restoreFanPaiMemoryMoment(message) {
    const chatBox = document.getElementById('indoor-chat-box');
    const chatWrap = document.getElementById('indoor-chat-wrap');
    const controls = document.getElementById('indoor-chat-controls');
    const last = indoorChatContext.history[indoorChatContext.history.length - 1];
    chatWrap.style.display = 'flex';
    chatWrap.style.opacity = '1';
    chatBox.style.opacity = '1';
    chatBox.innerText = last ? `${last.speaker ? `${last.speaker}：` : ''}${last.text}` : '本轮侍寝剧情仍在，可重新选择录入记忆。';
    controls.style.display = 'flex';
    chatWrap.style.bottom = `calc(var(--safe-bottom) + ${controls.offsetHeight + 20}px)`;
    document.getElementById('indoor-blocker').style.display = 'none';
    if (typeof setIndoorTapHandler === 'function') setIndoorTapHandler(null);
    api.ui.toast(message);
  }

  // （结束侍寝逻辑已移至 btn-inchat-exit 的覆盖回调中）

  const origBack = document.getElementById('btn-exit-indoor').onclick;
  document.getElementById('btn-exit-indoor').onclick = () => {
    exitFanPaiSession();
    document.getElementById('btn-exit-indoor').onclick = origBack;
  };

  // ── 立即开始推演侍寝剧情 ──
  setTimeout(async () => {
    const chatBox = document.getElementById('indoor-chat-box');
    const chatWrap = document.getElementById('indoor-chat-wrap');
    const blocker = document.getElementById('indoor-blocker');

    chatWrap.style.display = 'flex';
    chatBox.innerHTML = '<span style="color:var(--primary-color);">红烛摇曳，正在推演…</span>';
    chatBox.style.opacity = '1';
    chatWrap.style.opacity = '1';
    blocker.style.display = 'block';

    indoorChatContext.history = [];
    indoorChatContext.mode = 'intimate';

    const timeStr = hudTime.innerText;
    let wbText = '';
    if (userAncientDesc) wbText += `【皇帝（User）人设】：\n${userAncientDesc}\n\n`;
    if (window.globalWorldDesc) wbText += `【大世界设定】：\n${window.globalWorldDesc}\n\n`;
    if (window.globalRulesDesc) wbText += `【后宫规矩与皇权设定】：\n${window.globalRulesDesc}\n\n`;
    if (rankData && rankData.length > 0) {
      wbText += `【后宫位份体系】：\n` + rankData.map(r => `- ${r.rank} (自称:${r.selfClaim})`).join('\n') + `\n\n`;
    }

    // 收集角色间关系（从 memoryKnown 的关系图谱条目）
    const relLines = [];
    chosenChars.forEach(a => {
      chosenChars.forEach(b => {
        if (a.name === b.name) return;
        const key = `${a.name}->${b.name}`;
        const rel = window._relationData?.[key];
        if (rel && rel.text) relLines.push(`${a.name}对${b.name}：${rel.text}`);
      });
    });
    const relText = relLines.length > 0 ? `\n【他们彼此之间的关系】：\n${relLines.join('\n')}\n` : '';

    const charsInfo = chosenChars.map(c => {
      const desc = c.ancientDescOriginal || (c.ancientDesc || '').replace(/^【当前游戏时间】：[^\n]*\n?/, '').replace(/【当前后宫位份体系（由高到低）】[\s\S]*/, '');
      const charWb = c.charWorldDesc ? `\n【专属世界书】：\n${c.charWorldDesc}` : '';
      const knownText = (c.memoryKnown || []).join('\n') || '无';
      const seenText = (c.memorySeen || []).map(m => `[${m.time}] ${m.text}`).join('\n') || '无';
      const recText = (c.records || []).slice(0, 5).map(r => `[${r.time}] ${r.text}`).join('\n') || '无';
      const relLines = [];
      chosenChars.filter(o => o.name !== c.name).forEach(other => {
        const key = `${c.name}->${other.name}`;
        const rel = window._relationData?.[key];
        if (rel?.text) relLines.push(`对${other.name}：${rel.text}`);
      });
      const relText = relLines.length > 0 ? relLines.join('\n') : '无';
      return `【${c.name}】
性别：${c.gender || '未知'} | 位份：${c.assignedRank || c.ancientRole || '无'} | 居所：${c.assignedPalace || '无'}
人物设定：${desc}${charWb}
TA了解的：${knownText}
TA看到的：${seenText}
起居注：${recText}
关系图谱：${relText}`;
    }).join('\n\n');

    const sysPrompt = `你是一个古代后宫文字互动引擎。当前游戏时间：${timeStr}。

【本次场景：养心殿·翻牌共侍】
今夜皇帝翻了牌子，传召以下妃嫔共同侍寝：${chosenChars.map(c => c.name).join('、')}。

【全局世界书】：
${wbText}
【在场妃嫔完整档案】：
${charsInfo}
${relText}
【剧情推演指令，逐条严格遵守】：
请在正文前先进行思考（用 <think></think> 包裹），分析：
1. 这几人各自的性格、位份高低、与皇帝的亲疏，进殿前各自心中在想什么？
2. 他们知道今夜要与对方一同侍寝，各人心中对此是何态度（嫉妒？窃喜？惶恐？漠然？）？
3. 他们彼此之间的关系如何，进殿时会有何互动？

思考完毕后，输出正文（约2000字）：
1. 【性别铁律】每人的性别见档案，所有外貌、动作、神态描写必须与其性别完全相符，绝不可混淆。
2. 描写太监传旨、各人接旨时的神情与内心；描写他们梳妆备嫁、前往养心殿路上的心理活动。
3. 描写他们依次或同时进殿、向皇帝行礼请安的场景，以及彼此相遇时细微的情绪流动。
4. 描写红烛摇曳、香气氤氲的殿内氛围，以及他们各自等候皇帝的姿态。
5. 结尾留在他们行礼后静候的瞬间，不要替皇帝说话或做任何决定。
6. 每段用 <p> 标签，对话用 <p data-speaker="角色名">"说的话"</p>，只用英文双引号。

${getAiParagraphFormatGuard()}`;

    try {
      const res = await api.ai.chat({ messages: [{ role: 'user', content: sysPrompt }] });
      const text = typeof res === 'string' ? res : (res?.content ?? res?.text ?? '');
      window.currentIndoorChar = chosenChars[0];
      playIndoorChat(text);
    } catch(e) {
      chatBox.innerHTML = '<span style="color:#d9534f;">推演失败，请重试。</span>';
      blocker.style.display = 'none';
    }

    // 覆盖室内"离去"按钮 → 变成「结束侍寝」
    const exitBtn = document.getElementById('btn-inchat-exit');
    exitBtn.textContent = '结束侍寝';
    exitBtn.style.background = 'rgba(201,163,106,0.15)';
    exitBtn.style.borderColor = 'var(--primary-color)';
    exitBtn.style.color = 'var(--primary-color)';
    
    // 覆盖离去按钮的点击事件，弹出确认弹窗
    exitBtn.onclick = () => {
      // 先隐藏控制区
      document.getElementById('indoor-chat-controls').style.display = 'none';
      chatWrap.style.display = 'none';
      chatWrap.style.bottom = 'calc(var(--safe-bottom) + 8px)';
      chatBox.innerHTML = '';
      blocker.style.display = 'none';

      // 弹出确认弹窗
      const confirmModal = document.createElement('div');
      confirmModal.style.cssText = 'position:fixed;inset:0;z-index:99999;background:rgba(0,0,0,0.8);display:flex;align-items:center;justify-content:center;';
      confirmModal.innerHTML = `
        <div style="background:rgba(26,24,22,0.97);border:1px solid var(--primary-color);border-radius:12px;width:80%;max-width:320px;padding:20px;text-align:center;">
          <div style="color:var(--primary-color);font-size:18px;margin-bottom:10px;font-family:'STZhongsong','STSong',serif;letter-spacing:3px;">结束侍寝</div>
          <div style="color:#ccc;font-size:13px;margin-bottom:18px;line-height:1.6;">是否将此次侍寝录入彤史？<br><span style="color:#888;font-size:11px;">选「是」将由AI总结剧情并录入各人记忆，同时生成彤录记事</span></div>
          <div style="display:flex;gap:12px;">
            <button id="fp-confirm-forget" style="flex:1;background:transparent;border:1px solid #666;color:#aaa;padding:10px;border-radius:6px;font-family:inherit;">随风散去</button>
            <button id="fp-confirm-remember" style="flex:1;background:var(--primary-color);border:none;color:#000;padding:10px;border-radius:6px;font-weight:bold;font-family:inherit;">录入彤史</button>
          </div>
        </div>
      `;
      document.body.appendChild(confirmModal);

      document.getElementById('fp-confirm-forget').onclick = () => {
        confirmModal.remove();
        exitFanPaiSession();
      };

      document.getElementById('fp-confirm-remember').onclick = async () => {
        confirmModal.remove();

        // 显示处理中
        chatWrap.style.display = 'flex';
        chatBox.innerHTML = '<span style="color:var(--primary-color);">正在提炼记忆，史官执笔中…</span>';

        const timeStr = hudTime.innerText;
        const nameList = chosenChars.map(c => c.name).join('、');
        const historyText = indoorChatContext.history.map(x => `${x.speaker || '叙事段'}：${x.text}`).join('\n');

        // ── 步骤1：AI 生成不超过300字的记忆总结 ──
        const summaryPrompt = `请把以下侍寝剧情总结为一段不超过300字的客观陈述，作为各妃嫔的核心记忆。
要写明：皇帝翻牌召幸了${nameList}，他们进殿的情形、彼此的互动与心理，以及整体氛围。
剧情记录：
${historyText.slice(0, 1200)}`;

        let summary = '';
        try {
          const res = await api.ai.chat({ messages: [{ role: 'user', content: summaryPrompt }] });
          summary = (typeof res === 'string' ? res : (res?.content ?? res?.text ?? '')).trim();
          if (!summary) throw new Error('empty fanpai memory summary');
        } catch(e) {
          restoreFanPaiMemoryMoment('小结生成失败，侍寝剧情已保留，可重新生成');
          return;
        }

        const allC = [...selectedCharsData, XLY_CHAR];
        const memorySnapshots = chosenChars.map(c => ({ c, items: Array.isArray(c.memorySeen) ? c.memorySeen.slice() : [] }));
        const recordSnapshots = allC.map(c => ({ c, items: Array.isArray(c.records) ? c.records.slice() : [] }));
        const recText = `${timeStr}，皇帝翻牌，于养心殿召${nameList}共侍，雨露均沾，同承恩泽。`;
        try {
          // 将总结写入所有在场角色的「TA看到的」记忆
          chosenChars.forEach(c => {
            if (!c.memorySeen) c.memorySeen = [];
            c.memorySeen.unshift({ time: timeStr, text: `【翻牌共侍记忆】\n${summary}` });
          });

          // ── 步骤2：系统固定文案生成彤录记事（不调用AI）──
          const rec = {
            id: generateId(),
            time: timeStr,
            text: recText,
            type: 'system',
            tags: ['彤录', '众谈']
          };

          // 写入所有人的起居注
          allC.forEach(c => {
            if (!c.records) c.records = [];
            c.records.unshift(rec);
          });
          window._xlyRecords = XLY_CHAR.records;
          await saveProgress({ characters: selectedCharsData, xlyRecords: XLY_CHAR.records });
        } catch (error) {
          memorySnapshots.forEach(item => { item.c.memorySeen = item.items; });
          recordSnapshots.forEach(item => { item.c.records = item.items; });
          window._xlyRecords = XLY_CHAR.records;
          restoreFanPaiMemoryMoment('记忆保存失败，侍寝剧情已保留，可重新尝试');
          return;
        }

        // 显示结果
        chatBox.innerHTML = `
          <div style="display:flex;flex-direction:column;gap:10px;">
            <span style="color:var(--primary-color);font-size:12px;letter-spacing:1px;">— 记忆已录入 —</span>
            <span style="color:#ddd;font-size:13px;line-height:1.8;font-family:'STSong','Noto Serif CJK SC',serif;">${summary.slice(0, 200)}${summary.length > 200 ? '…' : ''}</span>
            <span style="color:#888;font-size:11px;border-top:1px solid rgba(201,163,106,0.15);padding-top:8px;">彤录：${recText}</span>
          </div>
        `;

        setTimeout(() => {
          chatWrap.style.display = 'none';
          chatBox.innerHTML = '';
          exitFanPaiSession();
        }, 4000);
      };
    };
  }, 100); // 稍微延迟一下确保 UI 渲染完再发起网络请求

  // 切换到室内视图
  switchView(vIndoor);
}

// ===== 翻牌子·多人立绘微调面板 =====
function openFanPaiAvatarAdj(char, container) {
  const old = document.getElementById('fanpai-adj-panel');
  if (old) old.remove();

  const panel = document.createElement('div');
  panel.id = 'fanpai-adj-panel';
  panel.style.cssText = `
    position:absolute; bottom:0; left:0; width:100%;
    background:rgba(20,18,16,0.88); backdrop-filter:blur(8px); -webkit-backdrop-filter:blur(8px);
    border-top:1px solid var(--primary-color); border-radius:20px 20px 0 0;
    z-index:25; display:flex; flex-direction:column;
    padding:16px 20px calc(var(--safe-bottom,24px)+16px);
    gap:14px;
  `;

  const cfg = char.storyAvatarCfg || { scale: 100, x: 0, y: 0 };

  panel.innerHTML = `
    <div style="display:flex; justify-content:space-between; align-items:center;">
      <div style="color:var(--primary-color); font-size:15px; font-weight:bold; letter-spacing:2px; font-family:'STZhongsong','STSong',serif;">
        调整「${char.name}」立绘
      </div>
      <button id="fp-adj-done" style="background:transparent; border:none; color:#888; font-size:14px; font-family:inherit;">完成</button>
    </div>
    <div style="display:flex; align-items:center; gap:12px;">
      <span style="color:#aaa; font-size:13px; width:40px;">大小</span>
      <input type="range" id="fp-adj-scale" min="20" max="1000" value="${cfg.scale}" style="flex:1;">
    </div>
    <div style="display:flex; align-items:center; gap:12px;">
      <span style="color:#aaa; font-size:13px; width:40px;">横向</span>
      <input type="range" id="fp-adj-x" min="-500" max="500" value="${cfg.x}" style="flex:1;">
    </div>
    <div style="display:flex; align-items:center; gap:12px;">
      <span style="color:#aaa; font-size:13px; width:40px;">纵向</span>
      <input type="range" id="fp-adj-y" min="-1000" max="800" value="${cfg.y}" style="flex:1;">
    </div>
    <div style="display:flex; justify-content:space-between;">
      <button id="fp-adj-reset" style="background:transparent; border:1px solid #666; color:#aaa; padding:8px 16px; border-radius:6px; font-size:13px; font-family:inherit;">恢复默认</button>
      <button id="fp-adj-save" style="background:var(--primary-color); border:none; color:#000; padding:8px 24px; border-radius:6px; font-size:13px; font-weight:bold; font-family:inherit;">保存</button>
    </div>
  `;

  document.getElementById('view-indoor').appendChild(panel);

  // 翻牌剧情使用同一个动态立绘节点；选中姓名后先切换为该角色，才能实时预览。
  const targetImg = container.querySelector('#fanpai-multi-avatar-img');
  const targetName = container.querySelector('#fanpai-multi-avatar-name');
  if (targetImg) {
    targetImg.src = char.customAvatar || char.avatar || '';
    targetImg.dataset.charId = char.id || char.name;
  }
  if (targetName) targetName.innerText = char.name;
  container.style.display = 'flex';
  container.style.opacity = '1';

  function applyAdj() {
    if (!targetImg) return;
    const s = parseInt(document.getElementById('fp-adj-scale').value) / 100;
    const x = parseInt(document.getElementById('fp-adj-x').value);
    const y = parseInt(document.getElementById('fp-adj-y').value);
    targetImg.style.transform = `translate(${x}px, ${y}px) scale(${s})`;
  }

  applyAdj();

  ['fp-adj-scale', 'fp-adj-x', 'fp-adj-y'].forEach(id => {
    document.getElementById(id).addEventListener('input', applyAdj);
  });

  document.getElementById('fp-adj-reset').onclick = () => {
    document.getElementById('fp-adj-scale').value = 100;
    document.getElementById('fp-adj-x').value = 0;
    document.getElementById('fp-adj-y').value = 0;
    applyAdj();
  };

  document.getElementById('fp-adj-done').onclick = () => panel.remove();

  document.getElementById('fp-adj-save').onclick = async () => {
    const nextCfg = {
      scale: parseInt(document.getElementById('fp-adj-scale').value),
      x: parseInt(document.getElementById('fp-adj-x').value),
      y: parseInt(document.getElementById('fp-adj-y').value)
    };
    if (typeof saveStoryAvatarConfig === 'function') await saveStoryAvatarConfig(char, nextCfg);
    else { char.storyAvatarCfg = nextCfg; await saveProgress({ characters: selectedCharsData }); }
    api.ui.toast(`「${char.name}」立绘已保存`);
    panel.remove();
  };
}

// ===== 珍宝阁 =====
const TREASURE_CATALOG = {
  '男装': '衮龙袍|明黄朝服|玄端|翼善冠袍|麒麟服|飞鱼服|斗牛服|蟒袍|乌皮皂靴|山文甲|锁子甲|皮弁服|圆领袍|直裰|鹤氅',
  '女装': '凤冠霞帔|百鸟裙|留仙裙|金丝绣花宫装|云肩披帛',
  '宝物': '和氏璧|夜明珠|金镶玉玺|红珊瑚树|祖母绿宝石|猫眼石|玛瑙雕件|水晶球|金累丝提梁壶|银镏金香炉|象牙雕|犀角杯|玳瑁饰品|砗磲摆件|琥珀蜜蜡串|金丝楠木匣|羊脂白玉佩|碧玉扳指|红珊瑚珠串|琉璃盏',
  '琴棋书画': '焦尾琴|绕梁|绿绮|春雷|云子（棋子）|玉棋盘|水晶棋子|玛瑙棋子|湖笔|徽墨|宣纸|端砚|竹简|玉册|清明上河图|洛神赋图|千里江山图|富春山居图|韩熙载夜宴图|五牛图',
  '吃食': '红烧狮子头|东坡肉|叫花鸡|龙井虾仁|佛跳墙|烤全羊|糖醋鲤鱼|水晶肘子|桂花糕|杏仁酥|茯苓糕|枣泥酥|桃酥|竹叶青（酒）|龙井茶|碧螺春|女儿红|杜康酒|人参汤|八宝饭',
  '武器': '龙泉剑|唐刀|环首刀|绣春刀|轩辕剑|湛卢|赤霄|七星剑|方天画戟|青龙偃月刀|丈八蛇矛|沥泉枪|狼牙棒|凤翅镏金镗|霸王弓|李广弓|飞刀|铁鞭|流星锤|熟铜锏'
};

function getTreasureItems(category) {
  const base = String(TREASURE_CATALOG[category] || '').split('|').filter(Boolean).map((name,index) => ({ id:`base_${category}_${index}`, name, category, price: Math.round((80 + index * 55) / 10) * 10 }));
  return base.concat(customTreasureItems.filter(item => item.category === category));
}

async function buyTreasure(item, quantity) {
  const total = item.price * quantity;
  if (total > treasurySilver) { api.ui.toast('国库银两不足'); return; }
  treasurySilver -= total;
  treasureInventory[item.id] = (Number(treasureInventory[item.id]) || 0) + quantity;
  await saveTreasuryState();
  api.ui.toast(`已购${item.name}×${quantity}，耗银${formatSilver(total)}两`);
  openTreasurePavilion(window._treasureTab || '男装');
}

function openCustomTreasureItemModal(category) {
  document.getElementById('custom-treasure-item-modal')?.remove();
  const editor=document.createElement('div'); editor.id='custom-treasure-item-modal';
  editor.style.cssText='position:fixed;inset:0;z-index:100220;background:rgba(0,0,0,.82);display:flex;align-items:center;justify-content:center;padding:22px;font-family:inherit;';
  editor.innerHTML=`<div style="width:min(370px,100%);background:linear-gradient(180deg,#261d14,#130f0b);border:1px solid #8a6b40;border-radius:16px;padding:18px;color:#e6cfa0;box-shadow:0 16px 42px rgba(0,0,0,.58);">
    <div style="text-align:center;font-size:18px;letter-spacing:4px;color:#f1d9a7;">自定义${category}</div>
    <label style="display:block;margin-top:16px;font-size:11px;color:#aa9068;">物品名称</label><input id="custom-treasure-name" maxlength="30" placeholder="输入物品名称" style="box-sizing:border-box;width:100%;margin-top:6px;padding:11px;background:#0e0b08;border:1px solid #665035;border-radius:8px;color:#fff;font-family:inherit;">
    <label style="display:block;margin-top:13px;font-size:11px;color:#aa9068;">单价（两）</label><input id="custom-treasure-price" type="number" inputmode="numeric" min="1" step="1" placeholder="输入正整数价格" style="box-sizing:border-box;width:100%;margin-top:6px;padding:11px;background:#0e0b08;border:1px solid #665035;border-radius:8px;color:#fff;font-family:inherit;">
    <div style="display:flex;gap:9px;margin-top:18px;"><button id="custom-treasure-cancel" style="flex:1;padding:10px;background:transparent;border:1px solid #554b3d;color:#8e8270;border-radius:18px;font-family:inherit;">取消</button><button id="custom-treasure-save" style="flex:1;padding:10px;background:#a5824d;border:0;color:#160f07;border-radius:18px;font-family:inherit;font-weight:bold;">加入珍宝阁</button></div>
  </div>`;
  document.body.appendChild(editor);
  editor.querySelector('#custom-treasure-cancel').onclick=()=>editor.remove();
  editor.addEventListener('click',event=>{if(event.target===editor)editor.remove();});
  editor.querySelector('#custom-treasure-save').onclick=async()=>{
    const name=editor.querySelector('#custom-treasure-name').value.trim().replace(/[<>&]/g,'');
    const price=Math.floor(Number(editor.querySelector('#custom-treasure-price').value));
    if(!name){api.ui.toast('请输入物品名称');return;}
    if(!Number.isFinite(price)||price<1){api.ui.toast('请输入有效的正整数价格');return;}
    customTreasureItems.push({id:`custom_${generateId()}`,name,category,price});
    await saveTreasuryState(); editor.remove(); openTreasurePavilion(category); api.ui.toast(`“${name}”已加入${category}`);
  };
  setTimeout(()=>editor.querySelector('#custom-treasure-name')?.focus(),80);
}

function openTreasurePavilion(category = '男装') {
  window._treasureTab = category;
  document.getElementById('treasure-pavilion-modal')?.remove();
  const modal = document.createElement('div'); modal.id='treasure-pavilion-modal';
  modal.style.cssText='position:fixed;inset:0;z-index:100100;color:#ead9b5;display:flex;flex-direction:column;padding-top:var(--safe-top);font-family:inherit;background-position:center;background-size:cover;';
  modal.style.backgroundImage=`linear-gradient(rgba(8,5,3,.64),rgba(8,5,3,.88)),url("${palaceDetails['珍宝阁']?.bgUrl || ''}")`;
  const categories = Object.keys(TREASURE_CATALOG);
  modal.innerHTML=`<div style="padding:12px 14px;display:flex;justify-content:space-between;align-items:center;border-bottom:1px solid #5f4b30;"><button id="treasure-close" style="background:transparent;border:0;color:#aaa;font-family:inherit;">‹ 返回</button><div style="font-size:19px;letter-spacing:5px;color:#f1dba8;">珍宝阁</div><div style="font-size:11px;color:#d8b978;">国库 ${formatSilver(treasurySilver)}两</div></div>
  <div style="display:flex;gap:7px;overflow:auto;padding:10px;">${categories.map(name=>`<button data-cat="${name}" style="white-space:nowrap;padding:7px 12px;border-radius:15px;background:${name===category?'#8f7144':'rgba(0,0,0,.35)'};border:1px solid #725b39;color:#f0dbaf;font-family:inherit;">${name}</button>`).join('')}</div>
  <div style="padding:0 12px 8px;"><button id="treasure-custom" style="width:100%;padding:8px;background:rgba(178,137,76,.15);border:1px dashed #9a7948;color:#d9bd87;border-radius:10px;font-family:inherit;">＋ 自定义添加${category}与定价</button></div>
  <div style="flex:1;overflow:auto;padding:4px 12px calc(var(--safe-bottom) + 20px);display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:10px;align-content:start;">${getTreasureItems(category).map(item=>`<div style="background:rgba(26,18,11,.82);border:1px solid rgba(201,163,106,.3);border-radius:12px;padding:12px;"><div style="color:#f2ddb0;font-size:14px;">${item.name}</div><div style="font-size:11px;color:#a98d62;margin:5px 0;">${formatSilver(item.price)}两 · 库存${treasureInventory[item.id]||0}</div><div style="display:flex;gap:4px;">${[1,5,10].map(q=>`<button data-buy="${item.id}" data-q="${q}" style="flex:1;padding:5px 0;background:#3b2b1b;border:1px solid #745936;color:#d7bd8d;border-radius:9px;font-family:inherit;font-size:10px;">买${q}</button>`).join('')}</div></div>`).join('')}</div>`;
  document.body.appendChild(modal);
  modal.querySelector('#treasure-close').onclick=()=>modal.remove();
  modal.querySelectorAll('[data-cat]').forEach(btn=>btn.onclick=()=>openTreasurePavilion(btn.dataset.cat));
  const items=getTreasureItems(category); modal.querySelectorAll('[data-buy]').forEach(btn=>btn.onclick=()=>buyTreasure(items.find(item=>item.id===btn.dataset.buy),Number(btn.dataset.q)));
  modal.querySelector('#treasure-custom').onclick=()=>openCustomTreasureItemModal(category);
}

const MALE_CONSORT_TITLES = (() => {
  const singleTitlePool = '昭景嘉瑞安和宁端敬恭温清雅逸怀瑾瑜珩璟熙华德贤良贞荣容玉文宜惠庄静淑敏慧柔婉顺懿纯穆康泰祥祺福庆昌隆盛显耀晖曜朗晏煦暄昀昕霁澄澈泓渊润沐涵汐湘洛川江河海岳岚峰云霄霖霏霜雪月星辰曦旭晨暮春夏秋冬兰竹梅菊莲荷芙蓉桂棠桃杏梨柳松柏桐枫槐榆杉檀榕榭芳菲芬馥馨香韵音琴瑟笙箫歌舞诗书画墨砚棋弈翰章辞赋礼义仁智信忠孝悌廉勇毅恒诚谦慎宽慈善恩佑祐祯禧禄寿锦绣绮罗纨素玄青苍碧翠丹朱紫绯彤金银琼瑶璇玑琅珕璞璋璧玦珏玥';
  return Array.from(new Set(Array.from(singleTitlePool))).slice(0, 200);
})();

function getAllRewardCharacters() {
  const all=[...selectedCharsData, (typeof XLY_CHAR!=='undefined'?XLY_CHAR:null), ...(window._courtNpcData||[])].filter(Boolean), seen=new Set();
  return all.filter(char=>{const key=char.id||char.name;if(seen.has(key))return false;seen.add(key);return true;});
}
function getInventoryItemById(id) {
  for (const category of Object.keys(TREASURE_CATALOG)) { const found=getTreasureItems(category).find(item=>item.id===id); if(found)return found; }
  return customTreasureItems.find(item=>item.id===id);
}
function getRewardIdentity(char) {
  return char.ancientRole === '后妃' ? `${char.assignedRank || '后妃'}${char.honorificTitle ? `·${char.honorificTitle}` : ''}` : (char.ancientRole || char.assignedRank || 'NPC');
}

function openRewardMenu() {
  document.getElementById('reward-menu-modal')?.remove();
  const modal=document.createElement('div'); modal.id='reward-menu-modal'; modal.style.cssText='position:fixed;inset:0;z-index:100300;background:rgba(0,0,0,.82);display:flex;align-items:flex-end;justify-content:center;padding:20px 20px calc(var(--safe-bottom) + 20px);';
  modal.innerHTML=`<div style="width:min(390px,100%);background:#1d1711;border:1px solid #80623c;border-radius:18px;padding:16px;"><div style="color:#ecd49e;text-align:center;font-size:18px;letter-spacing:5px;margin-bottom:14px;">奖赏</div><div style="display:grid;grid-template-columns:repeat(2,1fr);gap:10px;">${[['rank','升位'],['title','赐封号'],['treasure','赐宝'],['silver','赐金']].map(x=>`<button data-reward="${x[0]}" style="padding:15px;background:rgba(140,101,54,.18);border:1px solid #765a36;color:#ead2a1;border-radius:12px;font-family:inherit;font-size:15px;letter-spacing:3px;">${x[1]}</button>`).join('')}</div><button id="reward-close" style="width:100%;margin-top:12px;padding:9px;background:transparent;border:0;color:#777;font-family:inherit;">取消</button></div>`;
  document.body.appendChild(modal); modal.querySelector('#reward-close').onclick=()=>modal.remove(); modal.querySelectorAll('[data-reward]').forEach(btn=>btn.onclick=()=>{modal.remove();openRewardForm(btn.dataset.reward);});
}

function closeAllRewardOverlays() {
  ['reward-form-modal', 'reward-menu-modal', 'op-menu-modal'].forEach(id => document.getElementById(id)?.remove());
}

function openRewardForm(type) {
  document.getElementById('reward-form-modal')?.remove();
  const all=getAllRewardCharacters(); const targets=(type==='rank'||type==='title')?all.filter(char=>char.ancientRole==='后妃'):all;
  if(!targets.length){api.ui.toast('没有可选人物');return;}
  const labels={rank:'升位',title:'赐封号',treasure:'赐宝',silver:'赐金'};
  const modal=document.createElement('div'); modal.id='reward-form-modal'; modal.style.cssText='position:fixed;inset:0;z-index:100310;background:rgba(0,0,0,.86);display:flex;align-items:center;justify-content:center;padding:22px;';
  modal.innerHTML=`<div style="width:min(390px,100%);background:#1c1711;border:1px solid #876a41;border-radius:16px;padding:18px;color:#dec69a;font-family:inherit;"><div style="text-align:center;font-size:18px;letter-spacing:4px;color:#f0d8a6;">${labels[type]}</div><label style="display:block;font-size:11px;margin-top:15px;">选择人物</label><select id="reward-target" style="width:100%;padding:10px;margin:6px 0 12px;background:#100c09;color:#ead5ad;border:1px solid #685035;border-radius:8px;font-family:inherit;">${targets.map((char,index)=>`<option value="${index}">${getRewardIdentity(char)} · ${char.name}${typeof getCharacterDisciplineBadge==='function'&&getCharacterDisciplineBadge(char)?`（${getCharacterDisciplineBadge(char)}）`:''}</option>`).join('')}</select><div id="reward-extra"></div><div style="display:flex;gap:9px;margin-top:16px;"><button id="reward-cancel" style="flex:1;padding:10px;border:1px solid #555;background:transparent;color:#888;border-radius:18px;font-family:inherit;">取消</button><button id="reward-confirm" style="flex:1;padding:10px;border:0;background:#a7834c;color:#160f07;border-radius:18px;font-family:inherit;font-weight:bold;">颁赐</button></div></div>`;
  document.body.appendChild(modal); const extra=modal.querySelector('#reward-extra');
  const renderExtra=()=>{const char=targets[Number(modal.querySelector('#reward-target').value)]; if(type==='rank'){const current=rankData.findIndex(item=>item.rank===char.assignedRank);const higher=rankData.filter((item,index)=>current<0||index<current);extra.innerHTML=`<select id="reward-value" style="width:100%;padding:10px;background:#100c09;color:#ead5ad;border:1px solid #685035;border-radius:8px;font-family:inherit;">${higher.map(item=>`<option value="${item.rank}">${item.rank}</option>`).join('')}</select>`;} else if(type==='title'){extra.innerHTML=`<div style="display:flex;gap:7px;"><input id="reward-value" value="${MALE_CONSORT_TITLES[Math.floor(Math.random()*MALE_CONSORT_TITLES.length)]}" placeholder="输入封号" style="flex:1;padding:10px;background:#100c09;color:#fff;border:1px solid #685035;border-radius:8px;font-family:inherit;"><button id="reward-random" style="padding:0 13px;background:#4b3822;border:1px solid #80613a;color:#e4c996;border-radius:8px;font-family:inherit;">随机</button></div>`;extra.querySelector('#reward-random').onclick=()=>extra.querySelector('#reward-value').value=MALE_CONSORT_TITLES[Math.floor(Math.random()*MALE_CONSORT_TITLES.length)];} else if(type==='treasure'){const owned=Object.entries(treasureInventory).filter(([,qty])=>Number(qty)>0).map(([id,qty])=>({item:getInventoryItemById(id),qty})).filter(x=>x.item);extra.innerHTML=owned.length?`<select id="reward-value" style="width:100%;padding:10px;background:#100c09;color:#ead5ad;border:1px solid #685035;border-radius:8px;font-family:inherit;">${owned.map(x=>`<option value="${x.item.id}">${x.item.name}（库存${x.qty}）</option>`).join('')}</select>`:'<div style="color:#9a7656;text-align:center;">珍宝库存为空，请先去珍宝阁购买</div>';} else extra.innerHTML=`<input id="reward-value" type="number" min="1" max="${treasurySilver}" placeholder="赐予银两（国库${formatSilver(treasurySilver)}两）" style="box-sizing:border-box;width:100%;padding:10px;background:#100c09;color:#fff;border:1px solid #685035;border-radius:8px;font-family:inherit;">`;};
  modal.querySelector('#reward-target').onchange=renderExtra; renderExtra(); modal.querySelector('#reward-cancel').onclick=()=>modal.remove();
  if (type === 'title') modal.addEventListener('input', event => {
    if (event.target?.id === 'reward-value') event.target.value = Array.from(event.target.value || '').slice(0, 1).join('');
  });
  modal.querySelector('#reward-confirm').onclick=async()=>{const char=targets[Number(modal.querySelector('#reward-target').value)], input=modal.querySelector('#reward-value'); if(typeof isCharacterUnavailableForActivity==='function'&&isCharacterUnavailableForActivity(char)){await notifyCharacterUnavailable(char);return;} if(!input){api.ui.toast('暂无可赐之物');return;} const value=input.value.trim(); if(!value){api.ui.toast('请填写赏赐内容');return;} closeAllRewardOverlays(); api.ui.toast('赏赐已颁，谢临渊正在传旨……'); await executeReward(type,char,value);};
}

async function executeReward(type, char, value) {
  let detail='';
  if(type==='rank'){char.assignedRank=value;detail=`晋升为${value}`;if(rankData[0]?.rank===value)char.assignedPalace='坤宁宫正殿';}
  if(type==='title'){char.honorificTitle=value;detail=`赐封号“${value}”`;}
  if(type==='treasure'){const item=getInventoryItemById(value);if(!item||!(treasureInventory[value]>0)){api.ui.toast('库存不足');return;}treasureInventory[value]-=1;if(!Array.isArray(char.treasures))char.treasures=[];const owned=char.treasures.find(x=>x.id===value);if(owned)owned.quantity=(owned.quantity||0)+1;else char.treasures.push({id:value,name:item.name,quantity:1});detail=`赐宝“${item.name}”一件`;}
  if(type==='silver'){const amount=Math.floor(Number(value));if(!amount||amount>treasurySilver){api.ui.toast(amount>treasurySilver?'国库银两不足':'数额无效');return;}treasurySilver-=amount;char.personalSilver=(Number(char.personalSilver)||0)+amount;detail=`赐金${formatSilver(amount)}两`;}
  const time=hudTime?.innerText||'时间不详', identity=getRewardIdentity(char); const publicText=`【赏赐众闻】${time}，皇帝赏${identity}${char.name}：${detail}。`;
  if(!Array.isArray(char.records))char.records=[];char.records.unshift({id:generateId(),time,text:publicText,owner:char.name,type:'system',tags:['赏赐',char.ancientRole==='后妃'?'后宫':'前朝','众闻']});
  if(char.ancientRole!=='后妃'){if(!Array.isArray(window._qianchaoRecords))window._qianchaoRecords=[];window._qianchaoRecords.unshift({...char.records[0]});}
  if(typeof syncRosterKnowledgeToCharacters==='function')syncRosterKnowledgeToCharacters();
  const initialSave = saveTreasuryState({qianchaoRecords:window._qianchaoRecords||[]});
  await startRewardCeremonyStory(char,{type,detail,publicText,time},initialSave);
}

// ===== 养心殿 · 惩罚与后宫管理 =====
const DISCIPLINE_OPTIONS = [
  ['copy', '抄书'], ['confinement', '禁足'], ['kneel', '罚跪'], ['slap', '掌嘴'], ['cane', '杖责'],
  ['demote_rank', '降位'], ['remove_title', '褫夺封号'], ['dismiss', '贬黜'], ['cold_palace', '打入冷宫'], ['death', '赐死'], ['custom', '自定义']
];

function getDisciplineConsorts() {
  return selectedCharsData.filter(char => char.ancientRole === '后妃');
}

function getDisciplinePalaceOptions(includeCold = false) {
  const rooms = ['正殿', '东偏殿', '西偏殿', '耳房'];
  const names = ['坤宁宫', ...eastPalaces, ...westPalaces.filter(name => name !== '储秀宫' || placedPalacesData.some(item => item.name === '储秀宫'))];
  const values = names.flatMap(name => rooms.map(room => `${name}${room}`));
  if (includeCold) values.push('冷宫');
  return values;
}

function openAncientPeoplePicker({ id, title, people, emptyText, onPick }) {
  document.getElementById(id)?.remove();
  const modal = document.createElement('div');
  modal.id = id;
  modal.style.cssText = 'position:fixed;inset:0;z-index:100800;background:rgba(5,3,2,.9);backdrop-filter:blur(12px);display:flex;flex-direction:column;padding-top:var(--safe-top);font-family:"STZhongsong","STSong",serif;';
  modal.innerHTML = `<div style="height:54px;display:flex;align-items:center;justify-content:space-between;padding:0 16px;border-bottom:1px solid rgba(201,163,106,.28);"><button data-close style="background:transparent;border:none;color:#aaa;font-family:inherit;font-size:15px;">‹ 返回</button><div style="color:#efd8a7;font-size:18px;letter-spacing:5px;">${escHtml(title)}</div><div style="width:50px;"></div></div><div data-list style="flex:1;overflow-y:auto;padding:16px 16px calc(var(--safe-bottom) + 22px);display:grid;grid-template-columns:repeat(2,minmax(0,1fr));grid-auto-rows:230px;gap:14px;"></div>`;
  document.body.appendChild(modal);
  modal.querySelector('[data-close]').onclick = () => modal.remove();
  const list = modal.querySelector('[data-list]');
  if (!people.length) {
    list.style.display = 'flex'; list.style.alignItems = 'center'; list.style.justifyContent = 'center';
    list.innerHTML = `<div style="color:#827666;letter-spacing:3px;">${escHtml(emptyText)}</div>`;
    return modal;
  }
  people.forEach((char, index) => {
    const portrait = getCharacterPortraitUrl(char);
    const badge = typeof getCharacterDisciplineBadge === 'function' ? getCharacterDisciplineBadge(char) : '';
    const button = document.createElement('button');
    button.style.cssText = `position:relative;overflow:hidden;border-radius:17px;border:1px solid rgba(201,163,106,.42);background:rgba(24,18,13,.78);font-family:inherit;color:#ead4a8;margin-top:${index % 2 ? '24px' : '0'};`;
    button.innerHTML = `${portrait ? `<img src="${portrait}" style="position:absolute;inset:0;width:100%;height:100%;object-fit:cover;object-position:top center;">` : '<div style="position:absolute;inset:0;display:flex;align-items:center;justify-content:center;color:#6f6251;">暂无立绘</div>'}<div style="position:absolute;inset:auto 0 0;padding:42px 11px 13px;background:linear-gradient(transparent,rgba(5,4,3,.97));text-align:left;"><b style="display:block;color:#f0d8a8;font-size:17px;letter-spacing:3px;">${escHtml(char.name)}</b><small style="color:#9d8966;">${escHtml(char.assignedRank || char.ancientRole || '无位份')}</small>${badge ? `<small style="display:block;color:#d18675;margin-top:4px;">${escHtml(badge)}</small>` : ''}</div>`;
    button.onclick = () => { modal.remove(); onPick(char); };
    list.appendChild(button);
  });
  return modal;
}

function openPunishmentMenu() {
  openAncientPeoplePicker({
    id: 'punishment-picker-modal', title: '惩罚妃嫔', people: getDisciplineConsorts(), emptyText: '当前没有可惩处的后妃',
    onPick: char => openPunishmentConfig(char)
  });
}

function getPunishmentFieldsHtml(type, char) {
  const selectStyle = 'width:100%;padding:10px;background:#110d09;color:#ead5ad;border:1px solid #685035;border-radius:8px;font-family:inherit;';
  const inputStyle = 'box-sizing:border-box;width:100%;padding:10px;background:#110d09;color:#eee;border:1px solid #685035;border-radius:8px;font-family:inherit;';
  if (type === 'copy') return `<label>所抄典籍</label><select id="discipline-value" style="${selectStyle}"><option value="宫规">宫规</option><option value="孝经">孝经</option><option value="__custom__">自定义书名</option></select><input id="discipline-custom-book" placeholder="输入书名" style="${inputStyle}display:none;"><label>遍数</label><select id="discipline-count" style="${selectStyle}">${[1,10,20,50,100].map(n => `<option value="${n}">${n}遍</option>`).join('')}</select>`;
  if (type === 'confinement') return `<label>禁足期限</label><select id="discipline-value" style="${selectStyle}"><option value="1">一天</option><option value="3">三天</option><option value="7">七天</option><option value="30">一个月</option><option value="180">半年</option><option value="365">一年</option></select><div style="color:#a78965;font-size:11px;line-height:1.7;">期限按现实时间流逝。禁足期间不能召见、侍寝、翻牌、随机偶遇或参与随机记事，仅能前往其住所探望。</div>`;
  if (type === 'kneel') return `<label>罚跪时长</label><select id="discipline-value" style="${selectStyle}"><option value="2">一个时辰（约两小时）</option><option value="4">两个时辰（约四小时）</option><option value="24">一天</option></select>`;
  if (type === 'slap' || type === 'cane') return `<label>${type === 'slap' ? '掌嘴' : '杖责'}次数</label><select id="discipline-value" style="${selectStyle}">${[10,20,50,100].map(n => `<option value="${n}">${n}次</option>`).join('')}<option value="__custom__">自定义次数</option></select><input id="discipline-custom-count" type="number" min="1" max="9999" placeholder="输入次数" style="${inputStyle}display:none;">`;
  if (type === 'demote_rank') {
    const current = rankData.findIndex(item => item.rank === char.assignedRank);
    const lower = rankData.filter((item, index) => current < 0 ? item.rank !== char.assignedRank : index > current);
    return lower.length ? `<label>降至位份</label><select id="discipline-value" style="${selectStyle}">${lower.map(item => `<option value="${escHtml(item.rank)}">${escHtml(item.rank)}${item.note ? ` · ${escHtml(item.note)}` : ''}</option>`).join('')}</select>` : '<div style="color:#b27868;">此人已处于位份表最低位，无法继续降位。</div>';
  }
  if (type === 'remove_title') return `<div style="color:#b9a17b;line-height:1.8;">当前封号：${escHtml(char.honorificTitle || '无')}<br>确认后封号将直接清除。</div>`;
  if (type === 'dismiss') return `<div style="color:#d19a84;line-height:1.8;border:1px solid rgba(154,70,52,.45);padding:10px;border-radius:8px;">贬黜后，此人会从正式角色转为侍从或宫女NPC；原有人设、TA看到的、TA了解的、思绪、记事、头像和立绘设置全部保留。将不再出现在后妃召见与翻牌中。</div><label>贬为</label><select id="discipline-value" style="${selectStyle}"><option value="attendant">侍从</option><option value="maid">宫女</option></select>`;
  if (type === 'cold_palace') return '<div style="color:#d19a84;line-height:1.8;border:1px solid rgba(154,70,52,.45);padding:10px;border-radius:8px;">打入冷宫后永久幽禁，位份暂清、居所改为冷宫；不会再被召见、翻牌、随机到或参加随机记事，直到在“管理后宫—恢复位份”中接回。</div>';
  if (type === 'death') return '<div style="color:#e19a8e;line-height:1.8;border:1px solid #8b3029;padding:11px;border-radius:8px;">赐死等同于从本局彻底删除人物：人设、记忆、记事及所有关联资料均会移除，无法恢复。确认后还会再进行一次警告。</div>';
  if (type === 'custom') return `<label>自定义惩罚</label><textarea id="discipline-value" placeholder="写明惩罚内容、期限与执行方式" style="${inputStyle}height:110px;resize:vertical;"></textarea>`;
  return '';
}

function openPunishmentConfig(char) {
  document.getElementById('punishment-config-modal')?.remove();
  const modal = document.createElement('div');
  modal.id = 'punishment-config-modal';
  modal.style.cssText = 'position:fixed;inset:0;z-index:100850;background:rgba(4,3,2,.9);backdrop-filter:blur(12px);display:flex;align-items:flex-end;justify-content:center;font-family:"STZhongsong","STSong",serif;';
  modal.innerHTML = `<div style="width:100%;max-width:440px;max-height:91vh;overflow-y:auto;background:linear-gradient(180deg,#281a14,#100c09);border:1px solid rgba(201,163,106,.5);border-radius:24px 24px 0 0;padding:20px 16px calc(var(--safe-bottom) + 18px);"><div style="text-align:center;color:#efd5a5;font-size:19px;letter-spacing:5px;">惩处 · ${escHtml(char.name)}</div><label style="display:block;color:#bda47c;font-size:12px;margin:16px 0 7px;">惩罚方式</label><select id="discipline-type" style="width:100%;padding:11px;background:#110d09;color:#ead5ad;border:1px solid #685035;border-radius:8px;font-family:inherit;">${DISCIPLINE_OPTIONS.map(([value,label]) => `<option value="${value}">${label}</option>`).join('')}</select><div id="discipline-fields" style="display:flex;flex-direction:column;gap:8px;color:#bda47c;font-size:12px;margin-top:13px;"></div><label style="display:block;color:#bda47c;font-size:12px;margin:14px 0 7px;">额外规定（可选）</label><textarea id="discipline-extra" placeholder="例如：除睡眠外不得休息" style="box-sizing:border-box;width:100%;height:74px;padding:10px;background:#110d09;color:#eee;border:1px solid #685035;border-radius:8px;font-family:inherit;resize:vertical;"></textarea><div style="display:flex;gap:10px;margin-top:16px;"><button data-cancel style="flex:1;padding:11px;border-radius:20px;background:transparent;border:1px solid #5d5143;color:#958979;font-family:inherit;">取消</button><button data-confirm style="flex:2;padding:11px;border-radius:20px;background:#8b3029;border:1px solid #b16b58;color:#f4dfbb;font-family:inherit;font-weight:bold;letter-spacing:3px;">降旨惩处</button></div></div>`;
  document.body.appendChild(modal);
  const typeEl = modal.querySelector('#discipline-type');
  const fields = modal.querySelector('#discipline-fields');
  const renderFields = () => {
    fields.innerHTML = getPunishmentFieldsHtml(typeEl.value, char);
    const value = fields.querySelector('#discipline-value');
    if (typeEl.value === 'copy') value.onchange = () => fields.querySelector('#discipline-custom-book').style.display = value.value === '__custom__' ? 'block' : 'none';
    if (typeEl.value === 'slap' || typeEl.value === 'cane') value.onchange = () => fields.querySelector('#discipline-custom-count').style.display = value.value === '__custom__' ? 'block' : 'none';
  };
  typeEl.onchange = renderFields;
  renderFields();
  modal.querySelector('[data-cancel]').onclick = () => modal.remove();
  modal.querySelector('[data-confirm]').onclick = async event => {
    event?.preventDefault?.();
    event?.stopPropagation?.();
    const type = typeEl.value;
    const valueEl = fields.querySelector('#discipline-value');
    let value = valueEl?.value || '';
    let count = fields.querySelector('#discipline-count')?.value || '';
    const extra = modal.querySelector('#discipline-extra')?.value.trim() || '';
    if (type === 'copy' && value === '__custom__') value = fields.querySelector('#discipline-custom-book')?.value.trim();
    if ((type === 'slap' || type === 'cane') && value === '__custom__') value = fields.querySelector('#discipline-custom-count')?.value;
    if ((type === 'copy' || type === 'slap' || type === 'cane' || type === 'custom' || type === 'demote_rank') && !value) { api.ui.toast('请完整填写惩罚内容'); return; }
    if (type === 'remove_title' && !char.honorificTitle) { api.ui.toast('此人当前没有封号'); return; }
    if (type === 'demote_rank' && !valueEl) { api.ui.toast('当前没有更低位份可选'); return; }
    if (type === 'death') {
      const first = await api.ui.confirm({ title: '赐死将永久删除人物', message: `确定要赐死${char.name}吗？其全部人设、记忆、记事与关系将从本局删除。` });
      if (!first) return;
      const second = await api.ui.confirm({ title: '最后确认', message: `此操作无法撤销。再次确认赐死${char.name}。` });
      if (!second) return;
    }
    event.currentTarget.disabled = true;
    event.currentTarget.innerText = '生成中…';
    modal.remove();
    try {
      await executeConsortPunishment(char, { type, value, count, extra });
    } catch (error) {
      console.error('惩戒流程失败', error);
      api.ui.toast('惩戒剧情生成失败，已保留当前进度');
    }
  };
}

function describePunishment(char, options) {
  const { type, value, count, extra } = options;
  let detail = '';
  if (type === 'copy') detail = `罚抄《${value}》${count}遍`;
  if (type === 'confinement') detail = `禁足${Number(value) === 1 ? '一天' : Number(value) === 3 ? '三天' : Number(value) === 7 ? '七天' : Number(value) === 30 ? '一个月' : Number(value) === 180 ? '半年' : '一年'}`;
  if (type === 'kneel') detail = `罚跪${Number(value) === 2 ? '一个时辰' : Number(value) === 4 ? '两个时辰' : '一天'}`;
  if (type === 'slap') detail = `掌嘴${value}次`;
  if (type === 'cane') detail = `杖责${value}次`;
  if (type === 'demote_rank') detail = `由${char.assignedRank || '原位份'}降为${value}`;
  if (type === 'remove_title') detail = `褫夺封号“${char.honorificTitle}”`;
  if (type === 'dismiss') detail = `贬为${value === 'maid' ? '宫女' : '侍从'}`;
  if (type === 'cold_palace') detail = '褫去位份，打入冷宫，非旨不得出';
  if (type === 'death') detail = '赐死';
  if (type === 'custom') detail = value;
  if (extra) detail += `；另谕：${extra}`;
  return detail;
}

function applyPunishmentMutation(char, options) {
  const now = Date.now();
  if (options.type === 'confinement') {
    char.disciplineState = { type:'confinement', startedAt:now, endAt:now + Number(options.value) * 86400000, detail:describePunishment(char, options) };
  } else if (options.type === 'demote_rank') {
    char.assignedRank = options.value;
  } else if (options.type === 'remove_title') {
    char.honorificTitle = '';
  } else if (options.type === 'cold_palace') {
    char.disciplineState = { type:'cold_palace', startedAt:now, originalRank:char.assignedRank || '', originalPalace:char.assignedPalace || '', originalTitle:char.honorificTitle || '', detail:describePunishment(char, options) };
    char.assignedRank = '';
    char.honorificTitle = '';
    char.assignedPalace = '冷宫';
    if (typeof syncStaffResidencesForMaster === 'function') syncStaffResidencesForMaster(char);
  } else if (options.type === 'dismiss') {
    const idx = selectedCharsData.findIndex(item => item.id === char.id);
    if (idx >= 0) selectedCharsData.splice(idx, 1);
    selectedCharIds?.delete?.(char.id);
    Object.assign(char, {
      _isGameNpc:true, npcType:options.value, ancientRole:options.value === 'maid' ? '宫女' : '侍从',
      assignedRank:'', honorificTitle:'', assignedPalace:'', masterId:'', masterName:'',
      rosterPersonality:'', rosterMood:'', loyalty:''
    });
    char.disciplineState = null;
    if (!window._courtNpcData) window._courtNpcData = [];
    if (!window._courtNpcData.some(item => item.id === char.id)) window._courtNpcData.push(typeof normalizeGameNpc === 'function' ? normalizeGameNpc(char) : char);
  } else if (options.type === 'death') {
    const idx = selectedCharsData.findIndex(item => item.id === char.id);
    if (idx >= 0) selectedCharsData.splice(idx, 1);
    selectedCharIds?.delete?.(char.id);
    (window._courtNpcData || []).forEach(npc => { if (npc.masterId === char.id) { npc.masterId=''; npc.masterName=''; npc.assignedPalace=''; } });
  }
}

async function runImperialDisciplineStory(char, detail, actionLabel, beforeContext, survives = true) {
  const time = hudTime?.innerText || '时间不详';
  storyContext = { mode:'imperialDiscipline', pName:'养心殿', rName:actionLabel, mainChar:char, participants:[XLY_CHAR, char], history:[] };
  storySegments = [];
  currentSegmentIdx = 0;
  setStoryTapHandler(null);
  setMorningCourtStoryUi(false); setMorningAudienceStoryUi(false);
  document.getElementById('story-bg-layer').style.backgroundImage = `url('${palaceDetails['养心殿']?.bgUrl || palaceDetails[char.assignedPalace]?.bgUrl || ''}')`;
  storyActiveCard.style.opacity = '0';
  storyActiveCard.style.display = 'none';
  const textWrap = document.getElementById('story-text-wrap');
  const blocker = document.getElementById('story-blocker');
  textWrap.style.display = 'flex';
  textWrap.style.opacity = '1';
  textWrap.style.bottom = 'calc(var(--safe-bottom) + 8px)';
  blocker.style.display = 'block';
  storyTextBox.style.opacity = '1';
  storyTextBox.innerHTML = '<span style="color:#c9a36a;">谢临渊已奉旨，正在生成宣旨与受罚反应剧情……</span>';
  storyControls.style.display = 'none';
  switchView(vStory);
  const prompt = `你是古代宫廷剧情导演。当前时间：${time}。皇帝降旨对${char.name}执行“${detail}”。

【降旨前人物完整资料与全部记忆】
${beforeContext}

【谢临渊完整资料与全部记忆】
${buildCharactersAiContext([XLY_CHAR])}

写一段约1800至2200字的宣旨与受罚反应剧情。必须完整写出谢临渊奉旨前往、依礼宣旨、${char.name}听懂具体惩罚后的动作、言语、克制或真实反应，以及宫人执行前后的氛围。不得替皇帝说话或追加未给出的决定。人物台词只使用准确姓名。
只输出以下结构：
<reaction-summary>不超过200字，客观总结${char.name}得知“${detail}”后的主要动作、言语与反应</reaction-summary>
<story>用至少18个短<p>写完整正文，台词用<p data-speaker="准确姓名">台词</p></story>
不得输出“旁白”、Markdown、思考过程或标签外文字。
${getAiParagraphFormatGuard()}`;
  let summary = '', story = '';
  try {
    const result = await api.ai.chat({ messages:[{ role:'user', content:prompt }] });
    const raw = String(typeof result === 'string' ? result : (result?.content ?? result?.text ?? '')).replace(/```(?:html|xml)?|```/gi,'').trim();
    summary = raw.match(/<reaction-summary>([\s\S]*?)(?:<\/reaction-summary>|<story>)/i)?.[1]?.replace(/<[^>]+>/g,'').trim().slice(0,200) || '';
    story = raw.match(/<story>([\s\S]*?)(?:<\/story>|$)/i)?.[1] || (raw.match(/<p(?:[^>]*)>[\s\S]*?(?:<\/p>|$)/gi) || []).join('');
  } catch (error) {
    console.error('惩戒剧情AI调用失败', error);
    api.ui.toast('惩戒剧情生成失败，已使用本地兜底剧情');
  }
  if (!summary) summary = `${char.name}听谢临渊宣读惩处“${detail}”，依旨领受，神情与言行皆因这道旨意而变。`.slice(0,200);
  if (!story) story = `<p>谢临渊奉旨来到${char.name}处，宫人肃立无声。</p><p data-speaker="谢临渊">“圣旨既下，请听旨。”</p><p>${char.name}听罢“${detail}”，在阶前依礼领命。</p>`;
  if (survives) {
    if (!Array.isArray(char.memorySeen)) char.memorySeen = [];
    char.memorySeen.unshift({ time, text:`【惩处反应】${summary}` });
  }
  playStory(story);
  return summary;
}

async function executeConsortPunishment(char, options) {
  if (options.type === 'dismiss' && (window._courtNpcData || []).length >= GAME_NPC_LIMIT) { api.ui.toast(`NPC已达${GAME_NPC_LIMIT}人上限，无法贬为NPC`); return; }
  const time = hudTime?.innerText || '时间不详';
  const detail = describePunishment(char, options);
  const subjectDisplayName = getRecordCharacterDisplayName(char);
  const beforeContext = buildCharactersAiContext([char]);
  const survives = options.type !== 'death';
  const storyPromise = runImperialDisciplineStory(char, detail, '惩处', beforeContext, survives);
  const summary = await storyPromise;
  applyPunishmentMutation(char, options);
  const publicText = `【惩戒众闻】${time}，皇帝降旨惩处${subjectDisplayName}：${detail}。`;
  syncPublicNewsToCharacterRecords(publicText, time, ['惩戒', '众闻', '后宫'], char.name);
  if (survives) {
    if (!Array.isArray(char.records)) char.records = [];
    if (!char.records.some(record => record.text === publicText)) char.records.unshift({ id:generateId(), time, text:publicText, owner:char.name, eventOwner:char.name, type:'system', tags:['惩戒','后宫'] });
  }
  if (typeof syncRosterKnowledgeToCharacters === 'function') syncRosterKnowledgeToCharacters();
  await saveProgress({ characters:selectedCharsData, courtNpcData:window._courtNpcData || [], xlyMemoryKnown:XLY_CHAR.memoryKnown, xlyRecords:XLY_CHAR.records, qianchaoRecords:window._qianchaoRecords || [] });
  api.ui.toast(options.type === 'death' ? `${char.name}已从本局人物中删除` : `${detail}已执行；反应小结已写入TA看到的`);
  return summary;
}

function openHaremManagementMenu() {
  document.getElementById('harem-management-modal')?.remove();
  const modal = document.createElement('div');
  modal.id = 'harem-management-modal';
  modal.style.cssText = 'position:fixed;inset:0;z-index:100800;background:rgba(3,2,2,.84);display:flex;align-items:flex-end;justify-content:center;font-family:"STZhongsong","STSong",serif;';
  modal.innerHTML = `<div style="width:100%;max-width:430px;background:linear-gradient(180deg,#251a12,#100c08);border:1px solid rgba(201,163,106,.5);border-radius:24px 24px 0 0;padding:20px 16px calc(var(--safe-bottom) + 18px);"><div style="color:#efd8a7;text-align:center;font-size:19px;letter-spacing:5px;margin-bottom:15px;">管理后宫</div>${[['release','解除禁足'],['restore','恢复位份'],['promote','册封侍从/宫女']].map(([key,label]) => `<button data-manage="${key}" style="width:100%;padding:12px;margin:5px 0;border-radius:21px;background:rgba(201,163,106,.1);border:1px solid rgba(201,163,106,.4);color:#e5cd9d;font-family:inherit;letter-spacing:3px;">${label}</button>`).join('')}<button data-close style="width:100%;padding:10px;background:transparent;border:none;color:#746b5e;font-family:inherit;">取消</button></div>`;
  document.body.appendChild(modal);
  modal.querySelector('[data-close]').onclick = () => modal.remove();
  modal.querySelectorAll('[data-manage]').forEach(button => button.onclick = () => {
    const mode = button.dataset.manage; modal.remove();
    if (mode === 'release') openReleaseConfinementPicker();
    if (mode === 'restore') openRestoreColdPalacePicker();
    if (mode === 'promote') openPromoteStaffPicker();
  });
}

function openReleaseConfinementPicker() {
  const people = getDisciplineConsorts().filter(char => typeof isCharacterConfined === 'function' && isCharacterConfined(char));
  openAncientPeoplePicker({ id:'release-picker-modal', title:'解除禁足', people, emptyText:'当前无人处于禁足', onPick:releaseCharacterConfinement });
}

async function releaseCharacterConfinement(char) {
  if (!(typeof isCharacterConfined === 'function' && isCharacterConfined(char))) {
    api.ui.toast(`${char?.name || '此人'}当前并未禁足`);
    return;
  }
  const ok = await api.ui.confirm({ title:'提前解除禁足', message:`确定立即解除${char.name}的禁足吗？` });
  if (!ok) return;
  const before = buildCharactersAiContext([char]);
  char.disciplineState = null;
  const time = hudTime?.innerText || '时间不详';
  const detail = '提前解除禁足，恢复日常行动';
  await runImperialDisciplineStory(char, detail, '解禁', before, true);
  const publicText=`【后宫众闻】${time}，皇帝降旨为${char.name}${detail}。`;
  syncPublicNewsToCharacterRecords(publicText,time,['后宫','解禁','众闻'],char.name);
  if (typeof syncRosterKnowledgeToCharacters === 'function') syncRosterKnowledgeToCharacters();
  await saveProgress({characters:selectedCharsData,courtNpcData:window._courtNpcData||[],xlyMemoryKnown:XLY_CHAR.memoryKnown,xlyRecords:XLY_CHAR.records});
}

function openRestoreColdPalacePicker() {
  const people = getDisciplineConsorts().filter(char => typeof isCharacterInColdPalace === 'function' && isCharacterInColdPalace(char));
  openAncientPeoplePicker({ id:'restore-cold-picker-modal', title:'恢复位份', people, emptyText:'冷宫当前无人可接回', onPick:char => openRestoreColdPalaceConfig(char) });
}

function openRestoreColdPalaceConfig(char) {
  document.getElementById('restore-cold-config')?.remove();
  const modal=document.createElement('div'); modal.id='restore-cold-config'; modal.style.cssText='position:fixed;inset:0;z-index:100900;background:rgba(3,2,2,.88);display:flex;align-items:flex-end;justify-content:center;font-family:"STZhongsong","STSong",serif;';
  modal.innerHTML=`<div style="width:100%;max-width:430px;background:#17100b;border:1px solid #715536;border-radius:22px 22px 0 0;padding:20px 16px calc(var(--safe-bottom) + 18px);"><div style="color:#efd6a5;text-align:center;font-size:18px;letter-spacing:4px;">接回 · ${escHtml(char.name)}</div><label style="display:block;color:#b9a17b;margin:15px 0 6px;">重新赐位</label><select data-rank style="width:100%;padding:10px;background:#0d0907;color:#eee;border:1px solid #685035;border-radius:8px;">${rankData.map(item=>`<option value="${escHtml(item.rank)}">${escHtml(item.rank)}</option>`).join('')}</select><label style="display:block;color:#b9a17b;margin:13px 0 6px;">重新赐居</label><select data-palace style="width:100%;padding:10px;background:#0d0907;color:#eee;border:1px solid #685035;border-radius:8px;">${getDisciplinePalaceOptions().map(value=>`<option value="${escHtml(value)}">${escHtml(value)}</option>`).join('')}</select><div style="display:flex;gap:10px;margin-top:16px;"><button data-cancel style="flex:1;padding:11px;background:transparent;border:1px solid #5b5145;color:#938779;border-radius:20px;">取消</button><button data-confirm style="flex:2;padding:11px;background:#c9a36a;border:none;color:#17100a;border-radius:20px;font-weight:bold;">确认复位</button></div></div>`; document.body.appendChild(modal);
  const originalRank=char.disciplineState?.originalRank, originalPalace=char.disciplineState?.originalPalace;
  if(originalRank&&[...modal.querySelector('[data-rank]').options].some(option=>option.value===originalRank))modal.querySelector('[data-rank]').value=originalRank;
  if(originalPalace&&[...modal.querySelector('[data-palace]').options].some(option=>option.value===originalPalace))modal.querySelector('[data-palace]').value=originalPalace;
  modal.querySelector('[data-cancel]').onclick=()=>modal.remove(); modal.querySelector('[data-confirm]').onclick=async()=>{const before=buildCharactersAiContext([char]);const rank=modal.querySelector('[data-rank]').value,palace=modal.querySelector('[data-palace]').value,restoredTitle=char.disciplineState?.originalTitle||'';modal.remove();char.assignedRank=rank;char.assignedPalace=palace;char.honorificTitle=restoredTitle;char.disciplineState=null;syncStaffResidencesForMaster(char);const time=hudTime?.innerText||'时间不详',detail=`自冷宫接回，复位为${rank}，赐居${palace}${restoredTitle?`，恢复封号“${restoredTitle}”`:''}`;await runImperialDisciplineStory(char,detail,'复位',before,true);const news=`【后宫众闻】${time}，皇帝降旨将${char.name}${detail}。`;syncPublicNewsToCharacterRecords(news,time,['后宫','复位','众闻'],char.name);if(typeof syncRosterKnowledgeToCharacters==='function')syncRosterKnowledgeToCharacters();await saveProgress({characters:selectedCharsData,courtNpcData:window._courtNpcData||[],xlyMemoryKnown:XLY_CHAR.memoryKnown,xlyRecords:XLY_CHAR.records});};
}

function openPromoteStaffPicker() {
  const people=(typeof getAllGameNpcs==='function'?getAllGameNpcs():(window._courtNpcData||[])).filter(npc=>npc.npcType==='attendant'||npc.npcType==='maid'||npc.ancientRole==='侍从'||npc.ancientRole==='宫女');
  openAncientPeoplePicker({id:'promote-staff-picker-modal',title:'册封侍从/宫女',people,emptyText:'当前没有可册封的侍从或宫女',onPick:npc=>openPromoteStaffConfig(npc)});
}

function openPromoteStaffConfig(npc) {
  document.getElementById('promote-staff-config')?.remove(); const modal=document.createElement('div');modal.id='promote-staff-config';modal.style.cssText='position:fixed;inset:0;z-index:100900;background:rgba(3,2,2,.9);display:flex;align-items:flex-end;justify-content:center;font-family:"STZhongsong","STSong",serif;';
  modal.innerHTML=`<div style="width:100%;max-width:440px;max-height:92vh;overflow-y:auto;background:#17100b;border:1px solid #715536;border-radius:22px 22px 0 0;padding:20px 16px calc(var(--safe-bottom) + 18px);"><div style="color:#efd6a5;text-align:center;font-size:18px;letter-spacing:4px;">册封 · ${escHtml(npc.name)}</div><label style="display:block;color:#b9a17b;margin:14px 0 6px;">位份</label><select data-rank style="width:100%;padding:10px;background:#0d0907;color:#eee;border:1px solid #685035;border-radius:8px;">${rankData.map(item=>`<option value="${escHtml(item.rank)}">${escHtml(item.rank)}</option>`).join('')}</select><label style="display:block;color:#b9a17b;margin:12px 0 6px;">宫殿</label><select data-palace style="width:100%;padding:10px;background:#0d0907;color:#eee;border:1px solid #685035;border-radius:8px;">${getDisciplinePalaceOptions().map(value=>`<option value="${escHtml(value)}">${escHtml(value)}</option>`).join('')}</select><label style="display:block;color:#b9a17b;margin:12px 0 6px;">完整人物设定</label><textarea data-desc style="box-sizing:border-box;width:100%;height:180px;padding:10px;background:#0d0907;color:#eee;border:1px solid #685035;border-radius:8px;resize:vertical;">${escHtml(npc.ancientDescOriginal||npc.ancientDesc||'')}</textarea><button data-ai style="width:100%;margin-top:9px;padding:9px;border-radius:18px;background:rgba(201,163,106,.1);border:1px solid #85683f;color:#d9bd88;">AI重新生成人设</button><div style="display:flex;gap:10px;margin-top:15px;"><button data-cancel style="flex:1;padding:11px;background:transparent;border:1px solid #5b5145;color:#938779;border-radius:20px;">取消</button><button data-confirm style="flex:2;padding:11px;background:#c9a36a;border:none;color:#17100a;border-radius:20px;font-weight:bold;">确认册封</button></div></div>`;document.body.appendChild(modal);
  modal.querySelector('[data-cancel]').onclick=()=>modal.remove();modal.querySelector('[data-ai]').onclick=async event=>{const button=event.currentTarget;button.disabled=true;button.innerText='生成中…';try{const prompt=`根据以下成年宫人原始资料，为其生成一份可直接用于古代后宫角色扮演的完整人物设定，保留原有姓名、经历、性格、记忆事实，不得清空或篡改既有经历。只输出人设正文。\n${buildCharactersAiContext([npc])}`;const result=await api.ai.chat({messages:[{role:'user',content:prompt}]});modal.querySelector('[data-desc]').value=String(typeof result==='string'?result:(result?.content??result?.text??'')).replace(/```/g,'').trim()||modal.querySelector('[data-desc]').value;}catch(e){api.ui.toast('人设生成失败');}finally{button.disabled=false;button.innerText='AI重新生成人设';}};
  modal.querySelector('[data-confirm]').onclick=async()=>{const rank=modal.querySelector('[data-rank]').value,palace=modal.querySelector('[data-palace]').value,desc=modal.querySelector('[data-desc]').value.trim();if(!desc){api.ui.toast('人物设定不可为空');return;}const before=buildCharactersAiContext([npc]);modal.remove();const idx=(window._courtNpcData||[]).findIndex(item=>item.id===npc.id);if(idx>=0)window._courtNpcData.splice(idx,1);delete npc._isGameNpc;delete npc.npcType;delete npc.masterId;delete npc.masterName;npc.ancientRole='后妃';npc.assignedRank=rank;npc.assignedPalace=palace;npc.ancientDesc=desc;npc.ancientDescOriginal=desc;npc._isCustom=true;if(!selectedCharsData.some(item=>item.id===npc.id))selectedCharsData.push(npc);selectedCharIds?.add?.(npc.id);const time=hudTime?.innerText||'时间不详',detail=`由宫人册封为${rank}，赐居${palace}`;await runImperialDisciplineStory(npc,detail,'册封',before,true);const news=`【后宫册封众闻】${time}，皇帝册封${npc.name}为${rank}，赐居${palace}。`;syncPublicNewsToCharacterRecords(news,time,['后宫','赐封','众闻'],npc.name);syncRosterKnowledgeToCharacters();await saveProgress({characters:selectedCharsData,courtNpcData:window._courtNpcData||[],xlyMemoryKnown:XLY_CHAR.memoryKnown,xlyRecords:XLY_CHAR.records});};
}

function openPalaceDisciplineManagement(char) {
  if (!char) return;
  if (char._isGameNpc || char.npcType === 'attendant' || char.npcType === 'maid' || char.ancientRole === '侍从' || char.ancientRole === '宫女') {
    openPromoteStaffConfig(char);
    return;
  }
  if (char.ancientRole !== '后妃') {
    api.ui.toast('此处仅管理后妃、侍从与宫女');
    return;
  }
  if (typeof isCharacterInColdPalace === 'function' && isCharacterInColdPalace(char)) openRestoreColdPalaceConfig(char);
  else if (typeof isCharacterConfined === 'function' && isCharacterConfined(char)) releaseCharacterConfinement(char);
  else openPunishmentConfig(char);
}

// ===== 养心殿操作面板 =====
function openOpMenu() {
  const old = document.getElementById('op-menu-modal');
  if (old) old.remove();

  const modal = document.createElement('div');
  modal.id = 'op-menu-modal';
  modal.style.cssText = 'position:absolute; inset:0; z-index:9999; display:flex; align-items:flex-end; justify-content:center; padding-bottom:calc(var(--safe-bottom) + 80px);';

  const panel = document.createElement('div');
  panel.style.cssText = 'width:200px; background:rgba(20,18,16,0.85); backdrop-filter:blur(16px); -webkit-backdrop-filter:blur(16px); border:1px solid rgba(201,163,106,0.4); border-radius:16px; padding:12px 0; display:flex; flex-direction:column; box-shadow:0 8px 24px rgba(0,0,0,0.6); animation:fadeInDown 0.2s ease reverse;';
  panel.style.transformOrigin = 'bottom center';
  
  const ops = [
    { name: '飞鸽传书', action: () => { modal.remove(); openFeiGePanel(); } },
    { name: '存档', action: () => { modal.remove(); openInGameSaveMenu(); }, color: '#d8b77b' },
    { name: '读档', action: () => { modal.remove(); openInGameLoadMenu(); }, color: '#d8b77b' },
    { name: '管理后宫', action: () => { modal.remove(); openHaremManagementMenu(); } },
    { name: '惩罚妃嫔', action: () => { modal.remove(); openPunishmentMenu(); } },
    { name: '奖赏妃嫔', action: () => { modal.remove(); openRewardMenu(); } },
    { name: '金手指', action: () => { modal.remove(); openCheatMenu(); }, color: '#ffcc00' }
  ];

  ops.forEach((op, idx) => {
    const btn = document.createElement('button');
    btn.style.cssText = `background:transparent; border:none; padding:12px; color:${op.color || '#ccc'}; font-size:14px; letter-spacing:2px; font-family:inherit; transition:background 0.2s;`;
    btn.innerText = op.name;
    if (idx < ops.length - 1) {
      btn.style.borderBottom = '1px solid rgba(255,255,255,0.08)';
    }
    btn.onclick = () => { if(op.name !== '金手指') modal.remove(); op.action(); };
    panel.appendChild(btn);
  });

  modal.appendChild(panel);
  modal.addEventListener('click', (e) => { if(e.target === modal) modal.remove(); });
  document.getElementById('view-palace-detail').appendChild(modal);
}

// 金手指系统
let cheatExpireTime = 0; // 0=未开启
let cheatTimer = null;

function renderCheatStatus() {
  const wrapper = document.getElementById('cheat-status-wrap');
  if(!wrapper) return;
  if(cheatExpireTime > Date.now()) {
    const diff = Math.floor((cheatExpireTime - Date.now()) / 60000);
    const h = Math.floor(diff / 60);
    const m = diff % 60;
    wrapper.innerHTML = `
      <div style="display:flex; align-items:center; gap:8px;">
        <span style="color:#99ff99; font-size:12px; border:1px solid #99ff99; padding:2px 6px; border-radius:12px;">已开启</span>
        <span style="color:#aaa; font-size:12px;">剩余: ${h}小时${m}分</span>
      </div>
    `;
    if(!cheatTimer) {
      cheatTimer = setInterval(() => {
        if(!document.getElementById('cheat-status-wrap')) { clearInterval(cheatTimer); cheatTimer=null; return; }
        renderCheatStatus();
      }, 60000);
    }
  } else {
    cheatExpireTime = 0;
    wrapper.innerHTML = `<span style="color:#666; font-size:12px;">未开启</span>`;
    if(cheatTimer) { clearInterval(cheatTimer); cheatTimer = null; }
  }
}

function openCheatMenu() {
  const old = document.getElementById('cheat-menu-modal');
  if (old) old.remove();

  const modal = document.createElement('div');
  modal.id = 'cheat-menu-modal';
  modal.style.cssText = 'position:fixed; inset:0; z-index:99999; background:rgba(0,0,0,0.85); display:flex; align-items:center; justify-content:center;';

  modal.innerHTML = `
    <div style="width:90%; max-width:360px; background:#1a1816; border:1px solid var(--primary-color); border-radius:16px; padding:24px; display:flex; flex-direction:column; align-items:center; gap:20px; box-shadow:0 0 40px rgba(0,0,0,0.8);">
      <div style="color:var(--primary-color); font-size:20px; font-weight:bold; letter-spacing:4px; font-family:'STZhongsong','STSong',serif; text-shadow:0 2px 4px #000;">帝王特权 · 金手指</div>
      <div style="color:#ccc; font-size:13px; text-align:center; line-height:1.6;">开启金手指，掌控后宫生杀大权，解锁无限可能。</div>
      
      <div id="cheat-status-wrap" style="width:100%; display:flex; justify-content:center; margin:-10px 0 0;"></div>

      <div style="display:flex; width:100%; justify-content:space-between; gap:12px;">
        <!-- 天卡 -->
        <div class="vip-card" data-type="day" data-price="88" data-time="1440">
          <div class="vip-card-inner">
            <div class="vip-card-front">
              <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="var(--primary-color)" stroke-width="1.5"><path d="M12 2v20M17 5H9.5a3.5 3.5 0 0 0 0 7h5a3.5 3.5 0 0 1 0 7H6"/></svg>
              <div style="color:var(--primary-color); margin-top:8px; font-size:14px; font-weight:bold;">天卡</div>
              <div style="color:#888; font-size:11px; margin-top:4px;">¥88</div>
            </div>
            <div class="vip-card-back">
              <div style="color:var(--primary-color); font-size:16px; font-weight:bold;">✓</div>
              <div style="color:#fff; font-size:12px; margin-top:8px;">24小时</div>
            </div>
          </div>
        </div>
        <!-- 周卡 -->
        <div class="vip-card" data-type="week" data-price="488" data-time="10080">
          <div class="vip-card-inner">
            <div class="vip-card-front">
              <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="var(--primary-color)" stroke-width="1.5"><polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"/></svg>
              <div style="color:var(--primary-color); margin-top:8px; font-size:14px; font-weight:bold;">周卡</div>
              <div style="color:#888; font-size:11px; margin-top:4px;">¥488</div>
            </div>
            <div class="vip-card-back">
              <div style="color:var(--primary-color); font-size:16px; font-weight:bold;">✓</div>
              <div style="color:#fff; font-size:12px; margin-top:8px;">7天畅享</div>
            </div>
          </div>
        </div>
        <!-- 月卡 -->
        <div class="vip-card" data-type="month" data-price="2688" data-time="43200">
          <div class="vip-card-inner">
            <div class="vip-card-front">
              <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="var(--primary-color)" stroke-width="1.5"><path d="M21 16V8a2 2 0 0 0-1-1.73l-7-4a2 2 0 0 0-2 0l-7 4A2 2 0 0 0 3 8v8a2 2 0 0 0 1 1.73l7 4a2 2 0 0 0 2 0l7-4A2 2 0 0 0 21 16z"/><polyline points="3.27 6.96 12 12.01 20.73 6.96"/><line x1="12" y1="22.08" x2="12" y2="12"/></svg>
              <div style="color:var(--primary-color); margin-top:8px; font-size:14px; font-weight:bold;">月卡</div>
              <div style="color:#888; font-size:11px; margin-top:4px;">¥2688</div>
            </div>
            <div class="vip-card-back">
              <div style="color:var(--primary-color); font-size:16px; font-weight:bold;">✓</div>
              <div style="color:#fff; font-size:12px; margin-top:8px;">30天尊享</div>
            </div>
          </div>
        </div>
      </div>

      <div style="display:flex; width:100%; gap:12px; margin-top:10px;">
        <button id="cheat-cancel-btn" style="flex:1; background:transparent; border:1px solid #666; color:#aaa; padding:10px; border-radius:8px; font-size:14px;">暂不需要</button>
        <button id="cheat-pay-btn" style="flex:1; background:var(--primary-color); border:none; color:#000; padding:10px; border-radius:8px; font-size:14px; font-weight:bold; opacity:0.5; pointer-events:none;">确认开通</button>
      </div>
    </div>
  `;

  document.body.appendChild(modal);
  renderCheatStatus();

  let selectedOpt = null;
  const cards = modal.querySelectorAll('.vip-card');
  const payBtn = document.getElementById('cheat-pay-btn');

  cards.forEach(card => {
    card.addEventListener('click', () => {
      cards.forEach(c => c.classList.remove('selected'));
      card.classList.add('selected');
      selectedOpt = {
        name: card.dataset.type === 'day' ? '天卡' : card.dataset.type === 'week' ? '周卡' : '月卡',
        price: parseInt(card.dataset.price),
        time: parseInt(card.dataset.time)
      };
      payBtn.style.opacity = '1';
      payBtn.style.pointerEvents = 'auto';
      payBtn.innerText = `支付 ¥${selectedOpt.price}`;
    });
  });

  document.getElementById('cheat-cancel-btn').onclick = () => modal.remove();
  
  payBtn.onclick = async () => {
    if(!selectedOpt) return;
    try {
      const wallet = await api.wallet.get();
      if (!wallet || !wallet.accounts || wallet.accounts.length === 0) {
        api.ui.toast("未找到钱包账户");
        return;
      }
      
      const payRes = await api.wallet.pay({ 
        amount: selectedOpt.price, 
        accountId: wallet.accounts[0].id,
        title: "故梦辞", 
        detail: `购买金手指 ${selectedOpt.name}`,
        category: "游戏内购"
      });
      
      if (payRes && payRes.ok) {
        // 充值成功
        api.ui.toast(`充值成功！金手指已开启`);
        const now = Date.now();
        if (cheatExpireTime < now) cheatExpireTime = now;
        cheatExpireTime += selectedOpt.time * 60000; // 累计时长
        renderCheatStatus();
        
        // 恢复按钮状态让用户可以连续买
        cards.forEach(c => c.classList.remove('selected'));
        selectedOpt = null;
        payBtn.style.opacity = '0.5';
        payBtn.style.pointerEvents = 'none';
        payBtn.innerText = `确认开通`;
        
        // 存个档
        await saveProgress({ cheatExpireTime });
      } else {
        api.ui.toast(payRes.error || "支付取消或失败");
      }
    } catch(e) {
      console.error(e);
      api.ui.toast("支付失败，请检查钱包配置");
    }
  };
}

 // [{ id, charId, charName, dir:'in'|'out', content, time, replyTo }]
let zouZheData = { pending: [], done: [] };

function getZouZheAuthorCharacter(zz) {
  const rawName = String(zz?.author || '').replace(/^臣\s*/, '').split(/[，,（(]/)[0].trim();
  return [...selectedCharsData, (typeof XLY_CHAR !== 'undefined' ? XLY_CHAR : null), ...(window._courtNpcData || [])]
    .filter(Boolean).find(char => char.name === rawName || String(zz?.author || '').includes(char.name));
}

function buildZouZheAuthorAiContext(zz) {
  const char = getZouZheAuthorCharacter(zz);
  return char ? buildCharacterAiContext(char) : `【奏折作者资料】\n姓名：${zz?.author || '未知'}\n当前尚无可关联的人物记忆。`;
}

function syncZouZheToAuthorMemory(zz, status) {
  const char = getZouZheAuthorCharacter(zz);
  if (!char || !zz?.id) return false;
  if (!Array.isArray(char.memorySeen)) char.memorySeen = [];
  const dialogue = Array.isArray(zz._dialog) && zz._dialog.length
    ? zz._dialog.map((entry, index) => `${index + 1}. ${entry.role === 'emperor' ? '皇帝朱批' : '大臣回执'}：${entry.text || ''}`).join('\n')
    : '暂无后续往来';
  const funding = Array.isArray(zz.funding) && zz.funding.length
    ? zz.funding.map(entry => `[${entry.time || '时间不详'}]已拨${formatSilver(entry.amount)}两，承办：${entry.recipient || zz.author || '佚名'}`).join('\n') : '尚未拨款';
  const stage = status || ((zouZheData.done || []).some(item => item.id === zz.id) ? '已批阅' : '待处理');
  const text = `【奏折同步·${stage}】《${zz.title || '无题奏折'}》\n上奏时间：${zz.time || '时间不详'}\n奏折原文：${zz.content || zz.text || zz.body || '无正文'}\n御批：${zz.reply || zz.response || zz.result || '尚未御批'}\n拨款记录：\n${funding}\n后续往来：\n${dialogue}`;
  const existingIndex = char.memorySeen.findIndex(item => item?._zouzheId === zz.id);
  const memoryItem = { time: zz.time || hudTime?.innerText || '时间不详', text, _zouzheId: zz.id };
  if (existingIndex >= 0) char.memorySeen.splice(existingIndex, 1, memoryItem);
  else char.memorySeen.unshift(memoryItem);
  if (typeof XLY_CHAR !== 'undefined' && char === XLY_CHAR) window._xlyMemorySeen = XLY_CHAR.memorySeen;
  return true;
}

async function saveZouZheWithAuthorMemory(zz, status) {
  syncZouZheToAuthorMemory(zz, status);
  await saveProgress({
    zouZheData,
    characters: selectedCharsData,
    xlyMemorySeen: typeof XLY_CHAR !== 'undefined' ? XLY_CHAR.memorySeen : undefined,
    courtNpcData: window._courtNpcData || []
  });
}

async function syncAllZouZheAuthorMemories() {
  let changed = false;
  (zouZheData.pending || []).forEach(zz => { changed = syncZouZheToAuthorMemory(zz, '待处理') || changed; });
  (zouZheData.done || []).forEach(zz => { changed = syncZouZheToAuthorMemory(zz, '已批阅') || changed; });
  if (changed) {
    await saveProgress({
      zouZheData,
      characters: selectedCharsData,
      xlyMemorySeen: typeof XLY_CHAR !== 'undefined' ? XLY_CHAR.memorySeen : undefined,
      courtNpcData: window._courtNpcData || []
    });
  }
}

function getFundingOfficials() {
  return [...selectedCharsData, (typeof XLY_CHAR !== 'undefined' ? XLY_CHAR : null), ...(window._courtNpcData || [])]
    .filter(Boolean).filter(char => ['帝师','左相','右相','臣子','大臣','朝臣'].includes(char.ancientRole) || char._rosterCategory === 'minister');
}

function openMemorialFunding() {
  document.getElementById('memorial-funding-modal')?.remove();
  const memorials = [...(zouZheData.pending || []), ...(zouZheData.done || [])];
  if (!memorials.length) { api.ui.toast('当前没有可选的奏折'); return; }
  const modal = document.createElement('div');
  modal.id = 'memorial-funding-modal';
  modal.style.cssText = 'position:fixed;inset:0;z-index:100500;background:rgba(0,0,0,.86);display:flex;align-items:center;justify-content:center;padding:24px;';
  modal.innerHTML = `<div style="width:min(390px,100%);background:#1d1812;border:1px solid #8b7048;border-radius:16px;padding:18px;color:#d8c49d;font-family:inherit;">
    <div style="font-size:18px;letter-spacing:4px;text-align:center;color:#ecd49e;">御书房·拨款</div><div style="text-align:center;color:#a68b63;font-size:12px;margin:8px 0 16px;">国库实存 ${formatSilver(treasurySilver)} 两</div>
    <select id="funding-memorial" style="width:100%;margin:7px 0 14px;padding:10px;background:#100d0a;color:#e5d2aa;border:1px solid #665338;border-radius:8px;font-family:inherit;">${memorials.map((item,index)=>`<option value="${index}">《${String(item.title||'无题').replace(/[<>&]/g,'')}》·${String(item.author||'佚名').replace(/[<>&]/g,'')}</option>`).join('')}</select>
    <input id="funding-amount" type="number" min="1" max="${treasurySilver}" placeholder="输入拨款银两" style="box-sizing:border-box;width:100%;margin:7px 0 16px;padding:10px;background:#100d0a;color:#fff;border:1px solid #665338;border-radius:8px;font-family:inherit;">
    <div style="display:flex;gap:10px;"><button id="funding-cancel" style="flex:1;padding:10px;background:transparent;border:1px solid #555;color:#999;border-radius:18px;font-family:inherit;">取消</button><button id="funding-confirm" style="flex:1;padding:10px;background:#a4834f;border:none;color:#160f07;border-radius:18px;font-family:inherit;font-weight:bold;">准拨</button></div></div>`;
  document.body.appendChild(modal);
  modal.querySelector('#funding-cancel').onclick = () => modal.remove();
  modal.querySelector('#funding-confirm').onclick = async () => {
    const memorial = memorials[Number(modal.querySelector('#funding-memorial').value)];
    const amount = Math.floor(Number(modal.querySelector('#funding-amount').value));
    if (!Number.isFinite(amount) || amount <= 0) { api.ui.toast('请输入有效款项'); return; }
    if (amount > treasurySilver) { api.ui.toast('国库银两不足'); return; }
    treasurySilver -= amount;
    if (!Array.isArray(memorial.funding)) memorial.funding = [];
    const time = hudTime?.innerText || new Date().toLocaleString('zh-CN');
    memorial.funding.unshift({ id: generateId(), time, amount, recipient: memorial.authorName || memorial.author || '佚名' });
    const text = `【前朝拨款】皇帝就《${memorial.title || '无题奏折'}》准拨${formatSilver(amount)}两，交${memorial.authorName || memorial.author || '相关官员'}承办。拨款后国库实存${formatSilver(treasurySilver)}两。`;
    if (!Array.isArray(window._qianchaoRecords)) window._qianchaoRecords = [];
    window._qianchaoRecords.unshift({ id: generateId(), time, text, owner: memorial.authorName || memorial.author || '朝廷', type: 'system', tags: ['前朝','拨款'] });
    getFundingOfficials().forEach(char => { if (!Array.isArray(char.memorySeen)) char.memorySeen=[]; char.memorySeen.unshift({time,text}); });
    syncZouZheToAuthorMemory(memorial, (zouZheData.done || []).includes(memorial) ? '已批阅' : '待处理');
    await saveTreasuryState({ zouZheData, qianchaoRecords: window._qianchaoRecords });
    modal.remove(); api.ui.toast(`已拨款${formatSilver(amount)}两`);
    document.getElementById('zouzhe-panel-modal')?.remove(); openZouZhePanel();
  };
}

// ===== 御书房·批阅奏折系统 =====
function openZouZhePanel() {
  syncAllZouZheAuthorMemories().catch(() => {});
  const old = document.getElementById('zouzhe-panel-modal');
  if (old) old.remove();

  const modal = document.createElement('div');
  modal.id = 'zouzhe-panel-modal';
  modal.style.cssText = `
    position:fixed; inset:0; z-index:99999;
    background:url('https://www.imgfox.cn/apis/uploads/20260822/59071fc197f0444d/IMG_9834.png') center/cover no-repeat;
    display:flex; flex-direction:column;
  `;

  // 顶栏
  const header = document.createElement('div');
  header.style.cssText = 'padding:calc(var(--safe-top,44px) + 10px) 16px 12px; display:flex; justify-content:space-between; align-items:center; border-bottom:1px solid rgba(201,163,106,0.2); flex-shrink:0; background:rgba(8,6,4,0.6); backdrop-filter:blur(8px);';
  header.innerHTML = `
    <button id="zz-back" style="background:transparent;border:none;color:#888;font-size:16px;font-family:inherit;">‹ 返回</button>
    <div style="color:var(--primary-color);font-size:18px;font-weight:bold;letter-spacing:5px;font-family:'STZhongsong','STSong',serif;
      background:linear-gradient(to bottom,#ffe9b8,#c9a36a);-webkit-background-clip:text;-webkit-text-fill-color:transparent;
      filter:drop-shadow(0 1px 4px rgba(0,0,0,0.8));">御书房</div>
    <button id="zz-treasury" style="background:rgba(0,0,0,.35);border:1px solid rgba(201,163,106,.45);border-radius:14px;color:#d9bd83;padding:5px 8px;font-size:10px;font-family:inherit;">国库 ${formatSilver(treasurySilver)}两</button>
  `;
  modal.appendChild(header);

  // 底部精细操作栏
  const bottomBar = document.createElement('div');
  bottomBar.style.cssText = `
    position:absolute; bottom:calc(var(--safe-bottom) + 16px);
    left:50%; transform:translateX(-50%);
    width:92%; max-width:420px;
    background:rgba(12,10,8,0.65);
    backdrop-filter:blur(20px); -webkit-backdrop-filter:blur(20px);
    border-radius:28px;
    border-bottom:1px solid rgba(201,163,106,0.35);
    padding:10px 8px calc(10px);
    display:flex; justify-content:space-around; align-items:center;
    pointer-events:auto;
    box-shadow:0 8px 32px rgba(0,0,0,0.45);
  `;

  const btnItems = [
    {
      label: '批阅',
      icon: `<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round"><path d="M12 20h9"/><path d="M16.5 3.5a2.121 2.121 0 0 1 3 3L7 19l-4 1 1-4L16.5 3.5z"/></svg>`,
      action: () => startZouZheProcess(modal)
    },
    {
      label: '待处理',
      icon: `<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/><polyline points="14 2 14 8 20 8"/><line x1="16" y1="13" x2="8" y2="13"/><line x1="16" y1="17" x2="8" y2="17"/><line x1="10" y1="9" x2="8" y2="9"/></svg>`,
      action: () => openPendingZouZheList()
    },
    {
      label: '已批阅',
      icon: `<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/><polyline points="14 2 14 8 20 8"/><path d="M9 13l2 2 4-4"/></svg>`,
      action: () => openDoneZouZheList()
    },
    {
      label: '颁布政令',
      icon: `<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round"><path d="M22 11.08V12a10 10 0 1 1-5.93-9.14"/><polyline points="22 4 12 14.01 9 11.01"/></svg>`,
      action: () => api.ui.toast('颁布政令（功能开发中）')
    },
    {
      label: '拨款',
      icon: `<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6"><circle cx="12" cy="12" r="9"/><path d="M8 9h8M8 13h8M12 6v12"/></svg>`,
      action: () => openMemorialFunding()
    },
    {
      label: '传召',
      icon: `<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round"><path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M23 21v-2a4 4 0 0 0-3-3.87"/><path d="M16 3.13a4 4 0 0 1 0 7.75"/></svg>`,
      action: () => api.ui.toast('传召（功能开发中）')
    }
  ];

  btnItems.forEach(item => {
    const btn = document.createElement('button');
    btn.style.cssText = `
      display:flex; flex-direction:column; align-items:center; gap:4px;
      background:transparent; border:none; cursor:pointer;
      padding:6px 4px; border-radius:12px;
      transition:background 0.18s;
      min-width:44px; pointer-events:auto;
    `;
    const iconEl = document.createElement('div');
    iconEl.style.cssText = 'width:20px; height:20px; display:flex; align-items:center; justify-content:center; color:rgba(201,163,106,0.88); filter:drop-shadow(0 1px 3px rgba(0,0,0,0.7));';
    iconEl.innerHTML = item.icon;
    const labelEl = document.createElement('div');
    labelEl.style.cssText = `font-size:10px; color:rgba(201,163,106,0.82); letter-spacing:1px; font-family:'STZhongsong','STSong',serif; text-shadow:0 1px 3px rgba(0,0,0,0.8);`;
    labelEl.textContent = item.label;
    btn.appendChild(iconEl);
    btn.appendChild(labelEl);
    btn.addEventListener('click', item.action);
    btn.addEventListener('touchstart', () => { btn.style.background = 'rgba(201,163,106,0.1)'; }, {passive:true});
    btn.addEventListener('touchend', () => { setTimeout(() => { btn.style.background = 'transparent'; }, 200); }, {passive:true});
    bottomBar.appendChild(btn);
  });

  modal.appendChild(bottomBar);
  header.querySelector('#zz-treasury').onclick = () => openTreasuryRechargeModal();
  document.body.appendChild(modal);

  document.getElementById('zz-back').onclick = () => modal.remove();
}

async function startZouZheProcess(parentModal) {
  const ok = await api.ui.confirm({ title: "奏折送达", message: "内阁刚刚呈上了两封折子，是否现在查看？" });
  if (!ok) return;

  // 在批奏折面板内部显示 loading，而非全屏遮罩
  const zzModal = document.getElementById('zouzhe-panel-modal');
  let zzLoader = null;
  if (zzModal) {
    zzLoader = document.createElement('div');
    zzLoader.id = 'zz-inner-loader';
    zzLoader.style.cssText = 'position:absolute; inset:0; background:rgba(0,0,0,0.6); backdrop-filter:blur(4px); z-index:200; display:flex; flex-direction:column; align-items:center; justify-content:center; gap:16px; border-radius:0;';
    zzLoader.innerHTML = `
      <div style="width:40px; height:40px; border:3px solid rgba(201,163,106,0.3); border-top-color:var(--primary-color); border-radius:50%; animation:spin 1s linear infinite;"></div>
      <div style="color:var(--primary-color); font-size:14px; letter-spacing:2px; text-shadow:0 1px 3px #000;">正在分析朝廷动向…</div>
    `;
    zzModal.style.position = 'fixed';
    zzModal.appendChild(zzLoader);
  }

  const timeStr = hudTime ? hudTime.innerText : '未知时辰';
  
  // 收集前朝大臣和 NPC 的信息
  const officials = [...selectedCharsData, XLY_CHAR].filter(c => ['帝师','左相','右相','臣子','大臣'].includes(c.ancientRole) || c._rosterCategory === 'minister');
  let officialsInfo = buildCharactersAiContext(officials);
  
  if (!officialsInfo) officialsInfo = '当前朝中暂无有名有姓的重臣。';

  const npcList = typeof getAllGameNpcs === 'function' ? getAllGameNpcs() : (window._courtNpcData || []);
  const availableNpcList = npcList.filter(npc => !npc.npcType);
  const npcCanCreate = npcList.length < (typeof GAME_NPC_LIMIT !== 'undefined' ? GAME_NPC_LIMIT : 60);
  const npcInfo = availableNpcList.length
    ? availableNpcList.map(npc => `- ${npc.name}｜${npc.ancientRole || 'NPC'}｜${npc.ancientDesc || '无介绍'}｜性格：${npc.rosterPersonality || '未定'}｜状态：${npc.rosterMood || '未定'}`).join('\n')
    : '当前尚无NPC。';

  let wbText = '';
  if (userAncientDesc) wbText += `【皇帝（User）人设】：\n${userAncientDesc}\n\n`;
  if (window.globalWorldDesc) wbText += `【大世界设定】：\n${window.globalWorldDesc}\n\n`;
  if (window.globalRulesDesc) wbText += `【后宫规矩与皇权设定】：\n${window.globalRulesDesc}\n\n`;

  const sysPrompt = `你是一个古代朝堂模拟器，负责生成两封递交给皇帝的奏折。
当前时间：${timeStr}。
【国库实存】：${formatSilver(treasurySilver)}两。所有财政判断必须严格参照此余额，不得无故声称国库空虚，不得凭空增加未记录银两。
【全局设定】：
${wbText}
【朝中重臣信息】：
${officialsInfo}
【现有NPC名册（${npcList.length}/60）】：
${npcInfo}

请智能分析目前的朝廷动向，生成两封奏折：
【第一封】：必须涉及到上方提供的重臣（如果有）。可以由重臣本人或现有NPC上奏，也可以是涉及他们的弹劾或政务。
【第二封】：${npcCanCreate ? '可以优先复用现有NPC；如剧情确有需要，也允许新建一名不与名册重名的NPC。' : 'NPC名册已经达到或超过60人，绝对不得捏造新人，只能从现有NPC名册或朝中重臣中选择上奏者。'}

${npcCanCreate ? '若isNewNpc为true，必须同时给出该新NPC的简介、两字性格和五字内状态；新NPC会被正式写入名册。' : '两个对象的isNewNpc都必须为false，authorName必须与现有NPC或重臣姓名完全一致。'}

【格式要求，严格遵守】：
必须输出一个合法的 JSON 数组，包含2个对象，每个对象有以下字段：
authorName: "上奏人准确姓名"
authorRole: "上奏人官职或身份"
isNewNpc: ${npcCanCreate ? 'true或false' : 'false'}
npcIntro: "仅新NPC填写40至80字介绍，否则空字符串"
npcPersonality: "仅新NPC填写恰好两个汉字，否则空字符串"
npcStatus: "仅新NPC填写不超过五个汉字，否则空字符串"
title: "奏折主题（如：江南水患请赈灾折）"
content: "奏折正文（古风文言，150~250字，陈述具体事由，最后请旨定夺）"

绝对不要输出 JSON 以外的任何分析、代码块标记或废话！`;

  try {
    const res = await api.ai.chat({ messages: [{ role: 'user', content: sysPrompt }] });
    const text = typeof res === 'string' ? res : (res?.content ?? res?.text ?? '');
    const jsonMatch = text.match(/\[\s*\{[\s\S]*\}\s*\]/);
    if (!jsonMatch) throw new Error("AI 返回格式非 JSON");
    const arr = JSON.parse(jsonMatch[0]);
    
    // 存入待处理
    arr.forEach(a => {
      let authorName = String(a.authorName || a.author || '佚名').trim();
      let authorRole = String(a.authorRole || '').trim();
      let isNewNpc = Boolean(a.isNewNpc) && npcCanCreate;
      let npc = npcList.find(item => item.name === authorName);
      const official = officials.find(item => item.name === authorName);
      if (npc || official) isNewNpc = false;
      if (!npc && !official && npcCanCreate && npcList.length < (typeof GAME_NPC_LIMIT !== 'undefined' ? GAME_NPC_LIMIT : 60)) isNewNpc = true;
      if (!npc && !official && !isNewNpc && availableNpcList.length) {
        npc = availableNpcList[Math.floor(Math.random() * availableNpcList.length)];
        authorName = npc.name;
        authorRole = npc.ancientRole || authorRole || '朝臣';
      }
      if (isNewNpc && npcList.length < (typeof GAME_NPC_LIMIT !== 'undefined' ? GAME_NPC_LIMIT : 60)) {
        npc = typeof normalizeGameNpc === 'function' ? normalizeGameNpc({
          id: `npc_${generateId()}`, name: authorName, ancientRole: authorRole || '朝臣',
          ancientDesc: String(a.npcIntro || '由奏折初次登场的前朝人物。').trim(),
          ancientDescOriginal: String(a.npcIntro || '由奏折初次登场的前朝人物。').trim(),
          rosterPersonality: String(a.npcPersonality || '').replace(/\s/g, '').slice(0, 2),
          rosterMood: String(a.npcStatus || '').replace(/\s/g, '').slice(0, 5),
          memorySeen: [], memoryKnown: [`【身份】：${authorRole || '朝臣'}`], records: []
        }) : { id: `npc_${generateId()}`, name: authorName, ancientRole: authorRole || '朝臣', memorySeen: [], memoryKnown: [], records: [] };
        npcList.push(npc);
        availableNpcList.push(npc);
      }
      if (!npc && !official && availableNpcList.length) {
        npc = availableNpcList[Math.floor(Math.random() * availableNpcList.length)];
        authorName = npc.name;
        authorRole = npc.ancientRole || authorRole || '朝臣';
      } else if (!npc && !official && officials.length) {
        const fallbackOfficial = officials[Math.floor(Math.random() * officials.length)];
        authorName = fallbackOfficial.name;
        authorRole = fallbackOfficial.ancientRole || '大臣';
      }
      const newMemorial = {
        id: 'zz_' + Date.now() + '_' + Math.random().toString(36).slice(2,6),
        time: timeStr,
        author: `${authorRole ? authorRole + ' ' : ''}${authorName}`.trim(),
        authorName,
        authorRole,
        authorNpcId: npc?.id || '',
        title: a.title,
        content: a.content
      };
      zouZheData.pending.push(newMemorial);
      syncZouZheToAuthorMemory(newMemorial, '待处理');
    });
    await saveProgress({ zouZheData, characters: selectedCharsData, xlyMemorySeen: typeof XLY_CHAR !== 'undefined' ? XLY_CHAR.memorySeen : undefined, courtNpcData: npcList });
    api.ui.toast("两封新奏折已放置案头");
    openPendingZouZheList();
  } catch(e) {
    api.ui.toast("奏折生成失败：" + (e?.message || ''));
  } finally {
    if (zzLoader) zzLoader.remove();
  }
}

function openPendingZouZheList() {
  const old = document.getElementById('zz-list-modal');
  if (old) old.remove();

  const modal = document.createElement('div');
  modal.id = 'zz-list-modal';
  modal.style.cssText = `position:fixed; inset:0; z-index:100000; background:url('https://www.imgfox.cn/apis/uploads/20260818/cd2a4b22f1ec4748/IMG_9643.jpeg') center/cover no-repeat; display:flex; flex-direction:column; align-items:center;`;

  const wrap = document.createElement('div');
  wrap.style.cssText = 'width:92%; max-width:420px; display:flex; flex-direction:column; height:calc(100vh - var(--safe-top,64px) - var(--safe-bottom,24px) - 32px); margin-top:calc(var(--safe-top,64px) + 16px);';

  const header = document.createElement('div');
  header.style.cssText = 'padding:14px 16px; display:flex; justify-content:space-between; align-items:center; flex-shrink:0;';
  header.innerHTML = `
    <button id="btn-close-zz-list" style="background:transparent;border:none;color:#888;font-size:14px;font-family:inherit;">关闭</button>
    <div style="display:flex;gap:6px;">
      <button id="btn-zz-pending-fs" style="background:rgba(201,163,106,0.15);border:1px solid rgba(201,163,106,0.4);color:rgba(201,163,106,0.9);font-size:12px;padding:5px 10px;border-radius:12px;font-family:inherit;letter-spacing:1px;">字号</button>
      <button id="btn-zz-pending-adj" style="background:rgba(201,163,106,0.15);border:1px solid rgba(201,163,106,0.4);color:rgba(201,163,106,0.9);font-size:12px;padding:5px 10px;border-radius:12px;font-family:inherit;letter-spacing:1px;">调参</button>
    </div>
  `;
  wrap.appendChild(header);

  const list = document.createElement('div');
  list.style.cssText = 'flex:1; overflow-y:auto; -webkit-overflow-scrolling:touch; padding:0 14px calc(var(--safe-bottom,24px)+20px); display:flex; flex-direction:column; gap:12px; min-height:0;';

  const ZZ_SCROLL_IMG_SM = 'https://www.imgfox.cn/apis/uploads/20260823/b14e740b46654414/68f9af564g5ea10845f57a7d32f183b0.png';

  if (zouZheData.pending.length === 0) {
    list.innerHTML = '<div style="color:#888; text-align:center; padding:20px; font-family:\'STZhongsong\',serif; letter-spacing:2px;">案头清净，暂无待批奏折</div>';
  } else {
    zouZheData.pending.forEach((zz, idx) => {
      const card = document.createElement('div');
      const _ratio = window._zzCardRatio || 60;
      card.style.cssText = `position:relative; border-radius:4px; overflow:hidden; box-shadow:0 4px 16px rgba(0,0,0,0.6); flex-shrink:0; padding-top:${_ratio}%;`;
      // 奏折底图（绝对定位铺满，宽高比由 padding-top 锁定）
      const cardBg = document.createElement('img');
      cardBg.src = ZZ_SCROLL_IMG_SM;
      cardBg.style.cssText = 'position:absolute; inset:0; width:100%; height:100%; object-fit:fill; z-index:0; pointer-events:none;';
      card.appendChild(cardBg);
      // 内容层（绝对定位覆盖，padding 控制文字区域）
      const cardContent = document.createElement('div');
      cardContent.className = 'zz-list-card-content zz-pending-card';
      cardContent.style.cssText = `position:absolute; inset:0; z-index:1; padding:${_zzListCfgPending.padTop}% ${_zzListCfgPending.padRight}% ${_zzListCfgPending.padBottom}% ${_zzListCfgPending.padLeft}%; display:flex; flex-direction:column; gap:8px; overflow:hidden;`;
      cardContent.innerHTML = `
        <div style="display:flex; justify-content:space-between; align-items:flex-start;">
          <div style="color:#2a0d00; font-size:14px; font-weight:bold; font-family:'STZhongsong','STSong',serif; letter-spacing:2px;">${zz.title}</div>
          <div style="color:#5e3a11; font-size:11px; flex-shrink:0; margin-left:8px;">${zz.time}</div>
        </div>
        <div style="color:#3e1e0a; font-size:12px; font-family:'STZhongsong','STSong',serif;">上奏人：${zz.author}</div>
        <div class="zz-card-body" style="color:#2c1408; font-size:${_zzListFontSizePending}px; line-height:1.6; display:-webkit-box; -webkit-line-clamp:2; -webkit-box-orient:vertical; overflow:hidden;">${zz.content}</div>
        <div style="display:flex; justify-content:flex-end; gap:6px; margin-top:2px;">
          <button class="zz-del-btn" data-id="${zz.id}" style="background:transparent; border:none; color:#8b2020; padding:2px 8px; border-radius:4px; font-size:10px; font-family:inherit;">删</button>
          <button class="zz-read-btn" data-id="${zz.id}" style="background:rgba(201,163,106,0.2); border:none; color:#5e3a11; padding:2px 10px; border-radius:4px; font-size:10px; font-weight:bold; font-family:inherit;">阅览批示</button>
        </div>
      `;
      card.appendChild(cardContent);
      list.appendChild(card);
    });
  }
  wrap.appendChild(list);
  modal.appendChild(wrap);
  document.body.appendChild(modal);

  document.getElementById('btn-close-zz-list').onclick = () => modal.remove();

  // 字号弹窗（待处理列表）
  document.getElementById('btn-zz-pending-fs').addEventListener('click', () => {
    const old = document.getElementById('zz-list-fs-panel');
    if (old) { old.remove(); return; }
    const panel = document.createElement('div');
    panel.id = 'zz-list-fs-panel';
    panel.style.cssText = 'position:fixed;bottom:0;left:0;width:100%;background:rgba(14,10,8,0.95);backdrop-filter:blur(16px);border-top:1px solid rgba(201,163,106,0.4);border-radius:20px 20px 0 0;padding:16px 20px calc(var(--safe-bottom,24px)+16px);z-index:200001;display:flex;flex-direction:column;gap:12px;';
    panel.innerHTML = `
      <div style="display:flex;justify-content:space-between;align-items:center;">
        <div style="color:var(--primary-color);font-size:14px;font-weight:bold;letter-spacing:2px;font-family:'STZhongsong','STSong',serif;">待处理列表 · 字号</div>
        <button id="zz-list-fs-close" style="background:transparent;border:none;color:#888;font-size:14px;font-family:inherit;">完成</button>
      </div>
      <div style="display:flex;align-items:center;gap:10px;">
        <span style="color:#aaa;font-size:12px;width:44px;flex-shrink:0;">字号px</span>
        <input type="range" id="zz-pending-fs-range" min="10" max="22" value="${_zzListFontSizePending}" style="flex:1;">
        <span id="zz-pending-fs-val" style="color:var(--primary-color);font-size:13px;font-weight:bold;min-width:28px;text-align:right;">${_zzListFontSizePending}</span>
      </div>
      <button id="zz-pending-fs-save" style="background:var(--primary-color);border:none;color:#000;padding:10px;border-radius:8px;font-weight:bold;font-family:inherit;font-size:14px;">保存</button>
    `;
    document.body.appendChild(panel);
    const range = document.getElementById('zz-pending-fs-range');
    const valEl = document.getElementById('zz-pending-fs-val');
    range.addEventListener('input', () => {
      const v = parseInt(range.value);
      valEl.textContent = v;
      document.querySelectorAll('.zz-pending-card .zz-card-body').forEach(el => el.style.fontSize = v + 'px');
    });
    document.getElementById('zz-pending-fs-save').addEventListener('click', async () => {
      _zzListFontSizePending = parseInt(range.value);
      await saveProgress({ zzListFontSizePending: _zzListFontSizePending });
      api.ui.toast('字号已保存');
      panel.remove();
    });
    document.getElementById('zz-list-fs-close').addEventListener('click', () => panel.remove());
  });

  // 调参按钮（待处理列表）
  document.getElementById('btn-zz-pending-adj').addEventListener('click', () => openZzAdjPanel('pending'));

  list.querySelectorAll('.zz-del-btn').forEach(btn => {
    btn.onclick = async (e) => {
      const id = e.target.dataset.id;
      zouZheData.pending = zouZheData.pending.filter(z => z.id !== id);
      await saveProgress({ zouZheData });
      modal.remove();
      openPendingZouZheList();
    };
  });

  list.querySelectorAll('.zz-read-btn').forEach(btn => {
    btn.onclick = (e) => {
      const id = e.target.dataset.id;
      const zz = zouZheData.pending.find(z => z.id === id);
      if (zz) {
        modal.remove();
        openZouZheDetail(zz, true);
      }
    };
  });
}

function openDoneZouZheList() {
  const old = document.getElementById('zz-list-modal');
  if (old) old.remove();

  const modal = document.createElement('div');
  modal.id = 'zz-list-modal';
  modal.style.cssText = `position:fixed; inset:0; z-index:100000; background:url('https://www.imgfox.cn/apis/uploads/20260818/cd2a4b22f1ec4748/IMG_9643.jpeg') center/cover no-repeat; display:flex; flex-direction:column; align-items:center;`;

  const wrap = document.createElement('div');
  wrap.style.cssText = 'width:92%; max-width:420px; display:flex; flex-direction:column; height:calc(100vh - var(--safe-top,64px) - var(--safe-bottom,24px) - 32px); margin-top:calc(var(--safe-top,64px) + 16px);';

  const header = document.createElement('div');
  header.style.cssText = 'padding:14px 16px; display:flex; justify-content:space-between; align-items:center; flex-shrink:0;';
  header.innerHTML = `
    <button id="btn-close-zz-list" style="background:transparent;border:none;color:#888;font-size:14px;font-family:inherit;">关闭</button>
    <div style="display:flex;gap:6px;">
      <button id="btn-zz-done-fs" style="background:rgba(201,163,106,0.15);border:1px solid rgba(201,163,106,0.4);color:rgba(201,163,106,0.9);font-size:12px;padding:5px 10px;border-radius:12px;font-family:inherit;letter-spacing:1px;">字号</button>
      <button id="btn-zz-done-adj" style="background:rgba(201,163,106,0.15);border:1px solid rgba(201,163,106,0.4);color:rgba(201,163,106,0.9);font-size:12px;padding:5px 10px;border-radius:12px;font-family:inherit;letter-spacing:1px;">调参</button>
    </div>
  `;
  wrap.appendChild(header);

  const list = document.createElement('div');
  list.style.cssText = 'flex:1; overflow-y:auto; -webkit-overflow-scrolling:touch; padding:0 14px calc(var(--safe-bottom,24px)+20px); display:flex; flex-direction:column; gap:12px; min-height:0;';

  const ZZ_SCROLL_IMG_DONE = 'https://www.imgfox.cn/apis/uploads/20260823/b14e740b46654414/68f9af564g5ea10845f57a7d32f183b0.png';

  if (zouZheData.done.length === 0) {
    list.innerHTML = '<div style="color:#888; text-align:center; padding:20px; font-family:\'STZhongsong\',serif; letter-spacing:2px;">暂无已批阅的奏折</div>';
  } else {
    zouZheData.done.forEach((zz, idx) => {
      const card = document.createElement('div');
      const _ratio = window._zzCardRatio || 60;
      card.style.cssText = `position:relative; border-radius:4px; overflow:hidden; box-shadow:0 4px 16px rgba(0,0,0,0.6); flex-shrink:0; padding-top:${_ratio}%;`;
      const cardBg = document.createElement('img');
      cardBg.src = ZZ_SCROLL_IMG_DONE;
      cardBg.style.cssText = 'position:absolute; inset:0; width:100%; height:100%; object-fit:fill; z-index:0; pointer-events:none;';
      card.appendChild(cardBg);
      const cardContent = document.createElement('div');
      cardContent.className = 'zz-list-card-content zz-done-card';
      cardContent.style.cssText = `position:absolute; inset:0; z-index:1; padding:${_zzListCfgDone.padTop}% ${_zzListCfgDone.padRight}% ${_zzListCfgDone.padBottom}% ${_zzListCfgDone.padLeft}%; display:flex; flex-direction:column; gap:8px; overflow:hidden;`;
      // 截取回执前的朱批部分（[大臣回执] 之前）
      const replyDisplay = zz.reply ? zz.reply.split('\n\n[大臣回执]')[0] : '';
      cardContent.innerHTML = `
        <div style="display:flex; justify-content:space-between; align-items:flex-start;">
          <div style="color:#2a0d00; font-size:14px; font-weight:bold; font-family:'STZhongsong','STSong',serif; letter-spacing:2px;">${zz.title}</div>
          <div style="color:#5e3a11; font-size:11px; flex-shrink:0; margin-left:8px;">${zz.time}</div>
        </div>
        <div style="color:#3e1e0a; font-size:12px; font-family:'STZhongsong','STSong',serif;">上奏人：${zz.author}</div>
        <div class="zz-card-body" style="color:#2c1408; font-size:${_zzListFontSizeDone}px; line-height:1.6; display:-webkit-box; -webkit-line-clamp:2; -webkit-box-orient:vertical; overflow:hidden;">${zz.content}</div>
        <div style="color:#8b1010; font-size:12px; margin-top:4px; padding-top:6px; border-top:1px dashed rgba(139,32,32,0.4); font-family:'STKaiti','KaiTi',cursive; line-height:1.5;">
          朱批：${replyDisplay}
        </div>
        <div style="display:flex; justify-content:flex-end; gap:6px; margin-top:2px;">
          <button class="zz-del-done-btn" data-id="${zz.id}" style="background:transparent; border:none; color:#8b2020; padding:2px 8px; border-radius:4px; font-size:10px; font-family:inherit;">删</button>
          <button class="zz-read-btn" data-id="${zz.id}" style="background:rgba(201,163,106,0.2); border:none; color:#5e3a11; padding:2px 10px; border-radius:4px; font-size:10px; font-weight:bold; font-family:inherit;">阅览全文</button>
        </div>
      `;
      card.appendChild(cardContent);
      list.appendChild(card);
    });
  }
  wrap.appendChild(list);
  modal.appendChild(wrap);
  document.body.appendChild(modal);

  document.getElementById('btn-close-zz-list').onclick = () => modal.remove();

  // 字号弹窗（已批阅列表）
  document.getElementById('btn-zz-done-fs').addEventListener('click', () => {
    const old = document.getElementById('zz-list-fs-panel');
    if (old) { old.remove(); return; }
    const panel = document.createElement('div');
    panel.id = 'zz-list-fs-panel';
    panel.style.cssText = 'position:fixed;bottom:0;left:0;width:100%;background:rgba(14,10,8,0.95);backdrop-filter:blur(16px);border-top:1px solid rgba(201,163,106,0.4);border-radius:20px 20px 0 0;padding:16px 20px calc(var(--safe-bottom,24px)+16px);z-index:200001;display:flex;flex-direction:column;gap:12px;';
    panel.innerHTML = `
      <div style="display:flex;justify-content:space-between;align-items:center;">
        <div style="color:var(--primary-color);font-size:14px;font-weight:bold;letter-spacing:2px;font-family:'STZhongsong','STSong',serif;">已批阅列表 · 字号</div>
        <button id="zz-list-fs-close" style="background:transparent;border:none;color:#888;font-size:14px;font-family:inherit;">完成</button>
      </div>
      <div style="display:flex;align-items:center;gap:10px;">
        <span style="color:#aaa;font-size:12px;width:44px;flex-shrink:0;">字号px</span>
        <input type="range" id="zz-done-fs-range" min="10" max="22" value="${_zzListFontSizeDone}" style="flex:1;">
        <span id="zz-done-fs-val" style="color:var(--primary-color);font-size:13px;font-weight:bold;min-width:28px;text-align:right;">${_zzListFontSizeDone}</span>
      </div>
      <button id="zz-done-fs-save" style="background:var(--primary-color);border:none;color:#000;padding:10px;border-radius:8px;font-weight:bold;font-family:inherit;font-size:14px;">保存</button>
    `;
    document.body.appendChild(panel);
    const range = document.getElementById('zz-done-fs-range');
    const valEl = document.getElementById('zz-done-fs-val');
    range.addEventListener('input', () => {
      const v = parseInt(range.value);
      valEl.textContent = v;
      document.querySelectorAll('.zz-done-card .zz-card-body').forEach(el => el.style.fontSize = v + 'px');
    });
    document.getElementById('zz-done-fs-save').addEventListener('click', async () => {
      _zzListFontSizeDone = parseInt(range.value);
      await saveProgress({ zzListFontSizeDone: _zzListFontSizeDone });
      api.ui.toast('字号已保存');
      panel.remove();
    });
    document.getElementById('zz-list-fs-close').addEventListener('click', () => panel.remove());
  });

  // 调参按钮（已批阅列表）
  document.getElementById('btn-zz-done-adj').addEventListener('click', () => openZzAdjPanel('done'));

  list.querySelectorAll('.zz-del-done-btn').forEach(btn => {
    btn.onclick = async (e) => {
      const id = e.currentTarget.dataset.id;
      zouZheData.done = zouZheData.done.filter(z => z.id !== id);
      await saveProgress({ zouZheData });
      modal.remove();
      openDoneZouZheList();
    };
  });

  list.querySelectorAll('.zz-read-btn').forEach(btn => {
    btn.onclick = (e) => {
      const id = e.currentTarget.dataset.id;
      const zz = zouZheData.done.find(z => z.id === id);
      if (zz) {
        modal.remove();
        openZouZheDetail(zz, false);
      }
    };
  });
}

// ===== 奏折回执卷轴展示（新样式）=====
// 调参数据（持久化）
let _zzScrollCfg        = { padTop:34, padBottom:20, padLeft:17, padRight:16, fontSize:12, lineH:1.8 }; // 详情页
let _zzListCfgPending   = { padTop:11, padBottom:14, padLeft:16, padRight:16, fontSize:10 }; // 待处理列表
let _zzListCfgDone      = { padTop:13, padBottom:16, padLeft:16, padRight:16, fontSize:10 };

// 列表页字体大小（持久化）
let _zzListFontSizePending = 14; // 待处理列表字体大小 px
let _zzListFontSizeDone    = 14; // 已批阅列表字体大小 px
// 详情页字体大小（持久化，独立于调参面板的 fontSize）
let _zzDetailFontSizePx    = 14; // 详情正文字体大小 px

// 调参面板
// mode: 'pending'=待处理列表, 'done'=已批阅列表, 'scroll'=详情/回执卷轴
function openZzAdjPanel(mode) {
  const old = document.getElementById('zz-rscroll-adj-panel');
  if (old) { old.remove(); return; } // 再次点击收起

  // 根据 mode 决定当前编辑哪套配置
  const modeLabel = mode === 'pending' ? '待处理列表' : mode === 'done' ? '已批阅列表' : '正文详情 / 回执卷轴';
  const cfg = mode === 'pending' ? _zzListCfgPending : mode === 'done' ? _zzListCfgDone : _zzScrollCfg;

  const adjPanel = document.createElement('div');
  adjPanel.id = 'zz-rscroll-adj-panel';
  adjPanel.style.cssText = `
    position:fixed; bottom:0; left:0; width:100%;
    background:rgba(14,10,8,0.92); backdrop-filter:blur(16px);
    border-top:1px solid rgba(201,163,106,0.4);
    border-radius:20px 20px 0 0;
    padding:16px 20px calc(var(--safe-bottom,24px)+16px);
    z-index:200000; display:flex; flex-direction:column; gap:10px;
    max-height:55vh; overflow-y:auto;
  `;

  const sliders = [
    ['zz-adj-top',    '上边距%',  2, 80, cfg.padTop],
    ['zz-adj-bottom', '下边距%',  2, 80, cfg.padBottom],
    ['zz-adj-left',   '左边距%',  2, 50, cfg.padLeft],
    ['zz-adj-right',  '右边距%',  2, 50, cfg.padRight],
    ['zz-adj-fs',     '字号px',  10, 22, cfg.fontSize],
  ];

  adjPanel.innerHTML = `
    <div style="display:flex; justify-content:space-between; align-items:center;">
      <div style="color:var(--primary-color);font-size:14px;font-weight:bold;letter-spacing:2px;font-family:'STZhongsong','STSong',serif;">调参：${modeLabel}</div>
      <button id="zz-adj-close" style="background:transparent;border:none;color:#888;font-size:14px;font-family:inherit;">完成</button>
    </div>
    <div style="color:#888;font-size:11px;line-height:1.5;">调好后把底部数值告诉我就能固定下来。三套配置独立，互不影响。</div>
    ${sliders.map(([id, label, min, max, val]) => `
      <div style="display:flex;align-items:center;gap:8px;">
        <span style="color:#aaa;font-size:12px;width:54px;flex-shrink:0;">${label}</span>
        <input type="range" id="${id}" min="${min}" max="${max}" value="${val}" style="flex:1;">
        <span id="${id}-val" style="color:var(--primary-color);font-size:12px;width:26px;text-align:right;">${val}</span>
      </div>`).join('')}
    <div id="zz-adj-params-display" style="background:rgba(201,163,106,0.08);border:1px solid rgba(201,163,106,0.2);border-radius:8px;padding:8px 10px;color:#c9a36a;font-size:11px;line-height:1.8;font-family:monospace;margin-top:4px;"></div>
  `;
  document.body.appendChild(adjPanel);

  function doUpdate() {
    const t  = parseInt(document.getElementById('zz-adj-top').value);
    const b  = parseInt(document.getElementById('zz-adj-bottom').value);
    const l  = parseInt(document.getElementById('zz-adj-left').value);
    const r  = parseInt(document.getElementById('zz-adj-right').value);
    const fs = parseInt(document.getElementById('zz-adj-fs').value);
    ['top','bottom','left','right','fs'].forEach(k => {
      const v = k==='top'?t:k==='bottom'?b:k==='left'?l:k==='right'?r:fs;
      document.getElementById(`zz-adj-${k}-val`).textContent = v;
    });

    if (mode === 'pending') {
      _zzListCfgPending = { padTop:t, padBottom:b, padLeft:l, padRight:r, fontSize:fs };
      document.querySelectorAll('.zz-pending-card').forEach(el => {
        el.style.padding = `${t}% ${r}% ${b}% ${l}%`;
        el.querySelectorAll('.zz-card-body').forEach(c => c.style.fontSize = fs + 'px');
      });
    } else if (mode === 'done') {
      _zzListCfgDone = { padTop:t, padBottom:b, padLeft:l, padRight:r, fontSize:fs };
      document.querySelectorAll('.zz-done-card').forEach(el => {
        el.style.padding = `${t}% ${r}% ${b}% ${l}%`;
        el.querySelectorAll('.zz-card-body').forEach(c => c.style.fontSize = fs + 'px');
      });
    } else {
      _zzScrollCfg = { padTop:t, padBottom:b, padLeft:l, padRight:r, fontSize:fs, lineH:_zzScrollCfg.lineH };
      // 同步更新详情页卡片
      const detailContent = document.getElementById('zz-detail-content');
      if (detailContent) {
        detailContent.style.padding = `${t}% ${r}% ${b}% ${l}%`;
        detailContent.querySelectorAll('div').forEach(el => {
          if (el.style.fontSize && el.style.textIndent) el.style.fontSize = fs + 'px';
        });
      }
      // 同步更新回执卷轴文字层
      document.querySelectorAll('.zz-scroll-text-layer').forEach(el => {
        el.style.padding = `${t}% ${r}% ${b}% ${l}%`;
        el.querySelectorAll('.zz-main-text').forEach(c => c.style.fontSize = fs + 'px');
        el.querySelectorAll('.zz-sub-text').forEach(c => c.style.fontSize = Math.max(12, fs-1) + 'px');
      });
    }

    document.getElementById('zz-adj-params-display').textContent =
      `上:${t}%  下:${b}%  左:${l}%  右:${r}%  字号:${fs}px`;
  }

  ['zz-adj-top','zz-adj-bottom','zz-adj-left','zz-adj-right','zz-adj-fs'].forEach(id => {
    document.getElementById(id).addEventListener('input', doUpdate);
  });
  doUpdate();

  document.getElementById('zz-adj-close').addEventListener('click', () => adjPanel.remove());
}

function showZouZheReplyScroll(zz, rrText, onSave) {
  const ZZ_SCROLL_IMG = 'https://www.imgfox.cn/apis/uploads/20260823/b14e740b46654414/68f9af564g5ea10845f57a7d32f183b0.png';
  const MAIN_BG_IMG   = 'https://www.imgfox.cn/apis/uploads/20260818/cd2a4b22f1ec4748/IMG_9643.jpeg';

  const old = document.getElementById('zz-reply-scroll-modal');
  if (old) old.remove();

  const modal = document.createElement('div');
  modal.id = 'zz-reply-scroll-modal';
  modal.style.cssText = `
    position:fixed; inset:0; z-index:100003;
    background:url('https://www.imgfox.cn/apis/uploads/20260818/cd2a4b22f1ec4748/IMG_9643.jpeg') center/cover no-repeat;
    display:flex; flex-direction:column;
    overflow:hidden;
  `;

  // 顶栏：关闭 | 调参（居中） | 占位
  const header = document.createElement('div');
  header.style.cssText = 'padding:calc(var(--safe-top,64px) + 12px) 16px 12px; display:flex; justify-content:space-between; align-items:center; flex-shrink:0;';
  header.innerHTML = `
    <button id="zz-rscroll-close" style="background:transparent;border:none;color:#888;font-size:16px;font-family:inherit;">关闭</button>
    <button id="zz-rscroll-adj" style="background:rgba(201,163,106,0.15);border:1px solid rgba(201,163,106,0.4);color:rgba(201,163,106,0.9);font-size:12px;padding:5px 14px;border-radius:12px;font-family:inherit;letter-spacing:1px;">⚙ 调参</button>
    <div style="width:48px;"></div>
  `;
  modal.appendChild(header);

  // 滚动内容区
  const scrollArea = document.createElement('div');
  scrollArea.style.cssText = 'flex:1; overflow-y:auto; padding:24px 16px calc(var(--safe-bottom,24px)+24px); display:flex; flex-direction:column; align-items:center; gap:28px;';

  // 构建一张奏折卡片
  function makeScrollCard(mainText, subText, isReply) {
    const card = document.createElement('div');
    card.style.cssText = `
      position:relative; width:100%; max-width:380px;
      border-radius:4px;
      box-shadow:0 6px 24px rgba(0,0,0,0.7);
      overflow:hidden; flex-shrink:0;
    `;

    // 底图
    const bg = document.createElement('img');
    bg.src = ZZ_SCROLL_IMG;
    bg.style.cssText = 'position:absolute; inset:0; width:100%; height:100%; object-fit:fill; z-index:0; pointer-events:none;';
    card.appendChild(bg);

    // 文字层
    const textLayer = document.createElement('div');
    textLayer.className = 'zz-scroll-text-layer';
    textLayer.style.cssText = `
      position:relative; z-index:1;
      padding:${_zzScrollCfg.padTop}% ${_zzScrollCfg.padRight}% ${_zzScrollCfg.padBottom}% ${_zzScrollCfg.padLeft}%;
      display:flex; flex-direction:column; gap:12px;
      min-height:200px;
    `;

    const authorEl = document.createElement('div');
    authorEl.style.cssText = 'color:#3e1e0a; font-size:13px; font-weight:bold; font-family:"STZhongsong","STSong",serif; letter-spacing:2px; border-bottom:1px dashed rgba(100,50,10,0.3); padding-bottom:8px;';
    authorEl.textContent = isReply ? `【回执】${zz.author}` : `【原折】${zz.author}`;

    const mainEl = document.createElement('div');
    mainEl.className = 'zz-main-text';
    mainEl.style.cssText = `
      color:#2c1408; font-size:${_zzScrollCfg.fontSize}px;
      line-height:${_zzScrollCfg.lineH};
      letter-spacing:2px;
      font-family:"STZhongsong","STSong",serif;
      white-space:pre-wrap;
    `;
    mainEl.textContent = mainText;

    textLayer.appendChild(authorEl);
    textLayer.appendChild(mainEl);

    if (subText) {
      const divider = document.createElement('div');
      divider.style.cssText = 'border-top:1px dashed rgba(139,32,32,0.4); margin:8px 0;';
      const subEl = document.createElement('div');
      subEl.className = 'zz-sub-text';
      subEl.style.cssText = `
        color:#8b1010; font-size:${Math.max(12, _zzScrollCfg.fontSize - 1)}px;
        line-height:${_zzScrollCfg.lineH};
        letter-spacing:2px;
        font-family:"Ma Shan Zheng","STKaiti","KaiTi",cursive,serif;
        white-space:pre-wrap;
      `;
      subEl.textContent = `朱批：${subText}`;
      textLayer.appendChild(divider);
      textLayer.appendChild(subEl);
    }

    card.appendChild(textLayer);
    return card;
  }

  // 第一张：原折 + 朱批
  const card1 = makeScrollCard(zz.content, zz.reply, false);
  scrollArea.appendChild(card1);

  // 第二张：大臣回执
  const card2 = makeScrollCard(rrText, null, true);
  scrollArea.appendChild(card2);

  modal.appendChild(scrollArea);
  document.body.appendChild(modal);

  document.getElementById('zz-rscroll-close').addEventListener('click', () => {
    const ap = document.getElementById('zz-rscroll-adj-panel');
    if (ap) ap.remove();
    modal.remove();
    if (onSave) onSave();
  });

  document.getElementById('zz-rscroll-adj').addEventListener('click', () => {
    openZzAdjPanel('scroll');
  });
}

function openZouZheDetail(zz, isPending) {
  const old = document.getElementById('zz-detail-modal');
  if (old) old.remove();

  const modal = document.createElement('div');
  modal.id = 'zz-detail-modal';
  modal.style.cssText = `position:fixed; inset:0; z-index:100001; background:url('https://www.imgfox.cn/apis/uploads/20260818/cd2a4b22f1ec4748/IMG_9643.jpeg') center/cover no-repeat; display:flex; flex-direction:column;`;

  // 顶栏（含调参按钮）
  const detailTopBar = document.createElement('div');
  detailTopBar.style.cssText = 'padding:calc(var(--safe-top,64px) + 12px) 16px 12px; display:flex; justify-content:space-between; align-items:center; flex-shrink:0;';
  detailTopBar.innerHTML = `
    <button id="zz-detail-back" style="background:transparent;border:none;color:#888;font-size:16px;font-family:inherit;">‹ 返回</button>
    <div style="display:flex;gap:6px;">
      <button id="zz-detail-font-btn" style="background:rgba(201,163,106,0.15);border:1px solid rgba(201,163,106,0.4);color:rgba(201,163,106,0.9);font-size:12px;padding:4px 10px;border-radius:12px;font-family:inherit;letter-spacing:1px;">字体</button>
      <button id="zz-detail-adj-btn" style="background:rgba(201,163,106,0.15);border:1px solid rgba(201,163,106,0.4);color:rgba(201,163,106,0.9);font-size:12px;padding:4px 10px;border-radius:12px;font-family:inherit;letter-spacing:1px;">调参</button>
    </div>
    <div style="width:48px;"></div>
  `;
  modal.appendChild(detailTopBar);

  const ZZ_SCROLL_IMG = 'https://www.imgfox.cn/apis/uploads/20260823/b14e740b46654414/68f9af564g5ea10845f57a7d32f183b0.png';

  // 滚动外层（居中展示卡片）
  const detailOuter = document.createElement('div');
  detailOuter.style.cssText = 'flex:1; overflow-y:auto; display:flex; flex-direction:column; align-items:center; padding:20px 16px 16px;';

  // 外层卡片只做圆角阴影容器，背景透明
  const wrap = document.createElement('div');
  wrap.style.cssText = 'width:100%; max-width:420px; border-radius:4px; display:flex; flex-direction:column; position:relative; overflow:hidden; flex-shrink:0;';

  // 奏折底图（铺满 wrap）
  const scrollBg = document.createElement('img');
  scrollBg.src = ZZ_SCROLL_IMG;
  scrollBg.style.cssText = 'position:absolute; inset:0; width:100%; height:100%; object-fit:fill; z-index:0; pointer-events:none;';
  wrap.appendChild(scrollBg);

  const content = document.createElement('div');
  content.style.cssText = `
    position:relative; z-index:1; flex:1; overflow-y:auto;
    padding:${_zzScrollCfg.padTop}% ${_zzScrollCfg.padRight}% ${_zzScrollCfg.padBottom}% ${_zzScrollCfg.padLeft}%;
    display:flex; flex-direction:column; gap:14px;
    color:#2a1b16; font-family:"STZhongsong","STSong",serif;
    min-height:200px;
  `;
  content.id = 'zz-detail-content';

  content.innerHTML = `
    <div style="font-size:17px; font-weight:bold; text-align:center; border-bottom:1px dashed rgba(100,50,10,0.4); padding-bottom:8px; margin-bottom:4px; color:#2a0d00;">${zz.title}</div>
    <div style="font-size:13px; font-weight:bold; color:#3e1e0a; letter-spacing:2px;">臣 ${zz.author} 谨奏：</div>
    <div style="font-size:${_zzDetailFontSizePx}px; line-height:${_zzScrollCfg.lineH}; text-indent:28px; color:#2c1408;">${zz.content}</div>
    <div style="font-size:12px; text-align:right; margin-top:6px; color:#5e3a11;">${zz.time}</div>
  `;

  if (!isPending) {
    content.innerHTML += `
      <div style="margin-top:12px; padding-top:10px; border-top:1px dashed rgba(139,32,32,0.4);">
        <div style="color:#8b2020; font-size:12px; font-weight:bold; margin-bottom:6px; letter-spacing:2px;">朱批：</div>
        <div style="color:#8b1010; font-size:${Math.max(13,_zzDetailFontSizePx-1)}px; line-height:${_zzScrollCfg.lineH}; font-family:'Ma Shan Zheng','STKaiti',cursive; white-space:pre-wrap;">${zz.reply}</div>
      </div>
    `;
  }

  wrap.appendChild(content);

  detailOuter.appendChild(wrap);
  modal.appendChild(detailOuter);

  // 底部固定操作栏（不随滚动移动）
  const actionArea = document.createElement('div');
  actionArea.style.cssText = 'flex-shrink:0; padding:10px 16px calc(var(--safe-bottom,24px)+10px); display:flex; gap:10px; justify-content:center; background:rgba(8,6,4,0.7); backdrop-filter:blur(12px); -webkit-backdrop-filter:blur(12px); border-top:1px solid rgba(201,163,106,0.2);';

  if (isPending) {
    actionArea.innerHTML = `
      <button id="zz-btn-later" style="flex:1; background:transparent; border:1px solid #666; color:#aaa; padding:10px; border-radius:6px; font-size:14px;">稍后批</button>
      <button id="zz-btn-now" style="flex:2; background:var(--primary-color); border:none; color:#000; padding:10px; border-radius:6px; font-size:14px; font-weight:bold;">现在批</button>
    `;
  } else {
    const hasReply = zz.reply && zz.reply.includes('[大臣回执]');
    actionArea.innerHTML = `
      <button id="zz-btn-close-done" style="flex:1; background:transparent; border:1px solid #666; color:#aaa; padding:10px; border-radius:6px; font-size:14px;">关闭</button>
      <button id="zz-btn-summon-reply" style="flex:2; background:var(--primary-color); border:none; color:#000; padding:10px; border-radius:6px; font-size:14px; font-weight:bold;">
        ${hasReply ? '往来记录' : '传召大臣回禀'}
      </button>
    `;
  }
  modal.appendChild(actionArea);
  document.body.appendChild(modal);

  // 绑定顶栏按钮
  document.getElementById('zz-detail-back').addEventListener('click', () => modal.remove());
  document.getElementById('zz-detail-adj-btn').addEventListener('click', () => {
    openZzAdjPanel('scroll');
  });

  // 字体 DIY
  document.getElementById('zz-detail-font-btn').addEventListener('click', () => {
    const oldFm = document.getElementById('zz-font-drawer');
    if (oldFm) { oldFm.remove(); return; }

    const drawer = document.createElement('div');
    drawer.id = 'zz-font-drawer';
    drawer.style.cssText = `
      position:fixed; bottom:0; left:0; width:100%;
      background:rgba(14,10,8,0.96); backdrop-filter:blur(20px); -webkit-backdrop-filter:blur(20px);
      border-top:1px solid rgba(201,163,106,0.4);
      border-radius:20px 20px 0 0;
      padding:18px 20px calc(var(--safe-bottom,24px)+18px);
      z-index:200010; display:flex; flex-direction:column; gap:14px;
    `;

    const curFont = window._zzDetailFont || '';

    drawer.innerHTML = `
      <div style="display:flex;justify-content:space-between;align-items:center;">
        <div style="color:var(--primary-color);font-size:14px;font-weight:bold;font-family:'STZhongsong','STSong',serif;letter-spacing:3px;">奏折字体</div>
        <button id="zz-font-close" style="background:transparent;border:none;color:#888;font-size:14px;font-family:inherit;">关闭</button>
      </div>

      <div style="display:flex;align-items:center;gap:10px;background:rgba(201,163,106,0.06);border:1px solid rgba(201,163,106,0.2);border-radius:10px;padding:10px 14px;">
        <span style="color:#aaa;font-size:12px;flex-shrink:0;">字号</span>
        <input type="range" id="zz-detail-fs-range" min="10" max="24" value="${_zzDetailFontSizePx}" style="flex:1;">
        <span id="zz-detail-fs-val" style="color:var(--primary-color);font-size:13px;font-weight:bold;min-width:28px;text-align:right;">${_zzDetailFontSizePx}px</span>
        <button id="zz-detail-fs-save" style="background:var(--primary-color);border:none;color:#000;padding:5px 12px;border-radius:8px;font-size:12px;font-weight:bold;font-family:inherit;white-space:nowrap;">保存</button>
      </div>

      <div style="color:#aaa;font-size:11px;letter-spacing:1px;">预设字体</div>
      <div id="zz-font-presets" style="display:flex;flex-wrap:wrap;gap:8px;"></div>

      <div style="color:#aaa;font-size:11px;letter-spacing:1px;margin-top:2px;">字体链接（Google Fonts CSS 或 TTF 直链）</div>
      <input id="zz-font-url-input" type="text" placeholder="https://fonts.googleapis.com/css2?family=..." value="${(window._zzDetailFontUrl && !window._zzDetailFontUrl.startsWith('data:')) ? window._zzDetailFontUrl : ''}"
        style="width:100%;background:rgba(0,0,0,0.5);border:1px solid rgba(201,163,106,0.3);color:#eaeaea;padding:10px;border-radius:8px;font-size:13px;font-family:inherit;box-sizing:border-box;">

      <div style="color:#aaa;font-size:11px;letter-spacing:1px;">或上传本地字体文件（TTF / OTF / WOFF）</div>
      <button id="zz-font-upload" style="background:rgba(201,163,106,0.08);border:1px dashed rgba(201,163,106,0.35);color:rgba(201,163,106,0.8);padding:11px;border-radius:8px;font-size:13px;font-family:inherit;letter-spacing:1px;">📂 选择字体文件</button>
      <div id="zz-font-file-hint" style="color:#666;font-size:11px;text-align:center;display:none;"></div>

      <div id="zz-font-preview-box" style="background:rgba(240,225,190,0.15);border:1px solid rgba(201,163,106,0.2);border-radius:8px;padding:12px 16px;color:#e8d5a8;font-size:13px;line-height:1.8;letter-spacing:2px;font-family:${curFont||'inherit'};">
        臣伏惟陛下，览此片纸，望圣颜赐批。
      </div>

      <div style="display:flex;gap:10px;margin-top:2px;">
        <button id="zz-font-reset" style="flex:1;background:transparent;border:1px solid #555;color:#aaa;padding:10px;border-radius:8px;font-family:inherit;font-size:13px;">恢复默认</button>
        <button id="zz-font-apply" style="flex:2;background:var(--primary-color);border:none;color:#000;padding:10px;border-radius:8px;font-weight:bold;font-family:inherit;font-size:14px;">应用</button>
      </div>
    `;

    document.body.appendChild(drawer);
    drawer.addEventListener('click', e => e.stopPropagation());

    // 预设
    const presets = [
      { label: '宋体（默认）', family: "'STZhongsong','STSong',serif", url: '' },
      { label: '楷体', family: "'STKaiti','KaiTi','楷体',serif", url: '' },
      { label: '仿宋', family: "'FangSong','仿宋',serif", url: '' },
      { label: '马善政', family: "'Ma Shan Zheng','STKaiti',cursive", url: 'https://fonts.googleapis.com/css2?family=Ma+Shan+Zheng&display=swap' },
      { label: 'ZCOOL XiaoWei', family: "'ZCOOL XiaoWei',serif", url: 'https://fonts.googleapis.com/css2?family=ZCOOL+XiaoWei&display=swap' },
      { label: 'Noto Serif SC', family: "'Noto Serif SC',serif", url: 'https://fonts.googleapis.com/css2?family=Noto+Serif+SC&display=swap' },
    ];

    const presetWrap = document.getElementById('zz-font-presets');
    let _pendingFamily = '';
    let _pendingUrl = '';
    let _uploadedDataUrl = '';

    presets.forEach(p => {
      const btn = document.createElement('button');
      const isActive = window._zzDetailFont === p.family;
      btn.style.cssText = `background:${isActive?'rgba(201,163,106,0.2)':'transparent'};border:1px solid ${isActive?'var(--primary-color)':'#555'};color:${isActive?'var(--primary-color)':'#aaa'};padding:5px 12px;border-radius:16px;font-size:12px;font-family:inherit;cursor:pointer;letter-spacing:1px;transition:all 0.15s;`;
      btn.textContent = p.label;
      btn.onclick = () => {
        if (p.url) loadFontLink(p.url);
        _pendingFamily = p.family;
        _pendingUrl = p.url;
        _uploadedDataUrl = '';
        document.getElementById('zz-font-preview-box').style.fontFamily = p.family;
        document.getElementById('zz-font-url-input').value = p.url;
        presetWrap.querySelectorAll('button').forEach(b => { b.style.background='transparent'; b.style.borderColor='#555'; b.style.color='#aaa'; });
        btn.style.background='rgba(201,163,106,0.2)'; btn.style.borderColor='var(--primary-color)'; btn.style.color='var(--primary-color)';
      };
      presetWrap.appendChild(btn);
    });

    // 链接输入预览
    document.getElementById('zz-font-url-input').addEventListener('input', e => {
      const url = e.target.value.trim();
      if (url) loadFontLink(url);
    });

    // 上传字体
    document.getElementById('zz-font-upload').onclick = async () => {
      try {
        const picked = await api.media.pick({ accept: '.ttf,.otf,.woff,.woff2' });
        if (!picked?.file) return;
        const dataUrl = picked.file.dataUrl;
        const fontName = 'ZzCustomFont_' + Date.now();
        const style = document.createElement('style');
        style.textContent = `@font-face { font-family:'${fontName}'; src:url('${dataUrl}'); }`;
        document.head.appendChild(style);
        _uploadedDataUrl = dataUrl;
        _pendingFamily = `'${fontName}',serif`;
        _pendingUrl = '';
        document.getElementById('zz-font-preview-box').style.fontFamily = _pendingFamily;
        document.getElementById('zz-font-url-input').value = '';
        const hint = document.getElementById('zz-font-file-hint');
        hint.style.display = 'block';
        hint.textContent = `已加载：${picked.file.name || '自定义字体'}`;
      } catch(e) { api.ui.toast('文件读取失败'); }
    };

    // 应用
    document.getElementById('zz-font-apply').onclick = async () => {
      let family = _pendingFamily;
      let fontUrl = _uploadedDataUrl || _pendingUrl;
      if (!family) {
        fontUrl = document.getElementById('zz-font-url-input').value.trim();
        if (fontUrl && !fontUrl.startsWith('data:')) {
          const m = fontUrl.match(/family=([^&:]+)/);
          family = m ? `'${decodeURIComponent(m[1]).replace(/\+/g,' ')}',serif` : "'CustomFont',serif";
          loadFontLink(fontUrl);
        }
      }
      if (!family) { api.ui.toast('请先选择或输入字体'); return; }

      window._zzDetailFont = family;
      window._zzDetailFontUrl = fontUrl;
      if (_uploadedDataUrl) window._zzDetailFontDataUrl = _uploadedDataUrl;

      // 应用到当前页所有文字
      _applyZzDetailFont(family);

      // 更新按钮状态
      document.getElementById('zz-detail-font-btn').textContent = '字体 ✓';
      api.ui.toast('字体已应用');
      drawer.remove();
    };

    // 恢复默认
    document.getElementById('zz-font-reset').onclick = () => {
      window._zzDetailFont = '';
      window._zzDetailFontUrl = '';
      window._zzDetailFontDataUrl = '';
      _applyZzDetailFont('');
      document.getElementById('zz-detail-font-btn').textContent = '字体';
      api.ui.toast('已恢复默认字体');
      drawer.remove();
    };

    // 字号滑块逻辑
    const fsRange = document.getElementById('zz-detail-fs-range');
    const fsVal   = document.getElementById('zz-detail-fs-val');
    if (fsRange) {
      fsRange.addEventListener('input', () => {
        const v = parseInt(fsRange.value);
        fsVal.textContent = v + 'px';
        // 实时预览：更新详情页正文字号
        const detailContent = document.getElementById('zz-detail-content');
        if (detailContent) {
          detailContent.querySelectorAll('div').forEach(el => {
            if (el.style.fontSize && el.style.textIndent) el.style.fontSize = v + 'px';
          });
        }
        document.querySelectorAll('.zz-scroll-text-layer .zz-main-text').forEach(el => {
          el.style.fontSize = v + 'px';
        });
      });
      document.getElementById('zz-detail-fs-save').addEventListener('click', async () => {
        _zzDetailFontSizePx = parseInt(fsRange.value);
        await saveProgress({ zzDetailFontSizePx: _zzDetailFontSizePx });
        api.ui.toast('字号已保存');
      });
    }

    document.getElementById('zz-font-close').onclick = () => drawer.remove();
  });

  // 辅助：将字体应用到详情页所有文字节点
  function _applyZzDetailFont(family) {
    const targets = [
      document.getElementById('zz-detail-content'),
      ...Array.from(document.querySelectorAll('#zz-detail-modal .zz-scroll-text-layer')),
      ...Array.from(document.querySelectorAll('#zz-detail-modal [style*="STZhongsong"]')),
      ...Array.from(document.querySelectorAll('#zz-detail-modal [style*="STKaiti"]')),
    ];
    const base = family || "'STZhongsong','STSong',serif";
    targets.forEach(el => { if (el) el.style.fontFamily = base; });
  }

  // 如果已有保存字体，启动时应用
  if (window._zzDetailFont) {
    if (window._zzDetailFontUrl && !window._zzDetailFontUrl.startsWith('data:')) {
      loadFontLink(window._zzDetailFontUrl);
    } else if (window._zzDetailFontDataUrl) {
      const fontName = window._zzDetailFont.replace(/['"]/g,'').split(',')[0];
      if (!document.querySelector(`style[data-zz-font="${fontName}"]`)) {
        const s = document.createElement('style');
        s.dataset.zzFont = fontName;
        s.textContent = `@font-face { font-family:'${fontName}'; src:url('${window._zzDetailFontDataUrl}'); }`;
        document.head.appendChild(s);
      }
    }
    setTimeout(() => _applyZzDetailFont(window._zzDetailFont), 100);
    document.getElementById('zz-detail-font-btn').textContent = '字体 ✓';
  }

  if (isPending) {
    document.getElementById('zz-btn-later').onclick = () => modal.remove();
    document.getElementById('zz-btn-now').onclick = () => {
      actionArea.innerHTML = `
        <button id="zz-opt-qinpi" style="flex:1; background:rgba(201,163,106,0.2); border:1px solid var(--primary-color); color:var(--primary-color); padding:8px; border-radius:6px; font-size:12px;">亲批</button>
        <button id="zz-opt-daipi" style="flex:1; background:rgba(201,163,106,0.2); border:1px solid var(--primary-color); color:var(--primary-color); padding:8px; border-radius:6px; font-size:12px;">代批</button>
        <button id="zz-opt-dishi" style="flex:1; background:rgba(201,163,106,0.2); border:1px solid var(--primary-color); color:var(--primary-color); padding:8px; border-radius:6px; font-size:12px;">传帝师</button>
      `;
      // 绑定这三个按钮的事件
      document.getElementById('zz-opt-qinpi').onclick = () => openReplyModal(zz, 'qinpi');
      document.getElementById('zz-opt-daipi').onclick = () => openReplyModal(zz, 'daipi');
      document.getElementById('zz-opt-dishi').onclick = () => startDiShiSession(zz, modal);
    };
  } else {
    document.getElementById('zz-btn-close-done').onclick = () => modal.remove();

    // ── 已批阅详情：内联多轮对话区 ──
    // 对话记录：[{ role:'emperor'|'minister', text:string }]
    if (!zz._dialog) zz._dialog = [];

    const ZZ_SCROLL_IMG = 'https://www.imgfox.cn/apis/uploads/20260823/b14e740b46654414/68f9af564g5ea10845f57a7d32f183b0.png';

    // 对话卡片追加到 detailOuter
    // dialogIdx：对应 zz._dialog 中的下标，用于重roll/删除
    function appendDialogCard(role, text, dialogIdx) {
      const isEmperor = role === 'emperor';
      const cardWrap = document.createElement('div');
      cardWrap.style.cssText = 'width:100%; max-width:420px; border-radius:4px; display:flex; flex-direction:column; position:relative; overflow:hidden; flex-shrink:0; margin-top:16px;';

      const bg = document.createElement('img');
      bg.src = ZZ_SCROLL_IMG;
      bg.style.cssText = 'position:absolute; inset:0; width:100%; height:100%; object-fit:fill; z-index:0; pointer-events:none;';
      cardWrap.appendChild(bg);

      const textLayer = document.createElement('div');
      textLayer.style.cssText = `
        position:relative; z-index:1;
        padding:${_zzScrollCfg.padTop}% ${_zzScrollCfg.padRight}% ${_zzScrollCfg.padBottom}% ${_zzScrollCfg.padLeft}%;
        display:flex; flex-direction:column; gap:4px;
      `;

      const labelEl = document.createElement('div');
      labelEl.style.cssText = `color:${isEmperor?'#8b1010':'#3e1e0a'}; font-size:12px; font-weight:bold; font-family:'STZhongsong','STSong',serif; letter-spacing:2px; border-bottom:1px dashed rgba(100,50,10,0.3); padding-bottom:3px; margin-bottom:2px;`;
      labelEl.textContent = isEmperor ? '【朱批】' : `【回执】${zz.author}`;

      const bodyEl = document.createElement('div');
      bodyEl.style.cssText = `
        color:${isEmperor?'#8b1010':'#2c1408'}; font-size:${_zzScrollCfg.fontSize}px;
        line-height:${_zzScrollCfg.lineH}; letter-spacing:2px;
        font-family:${isEmperor?"'Ma Shan Zheng','STKaiti',cursive,serif":"'STZhongsong','STSong',serif"};
        white-space:pre-wrap;
      `;
      bodyEl.textContent = text;

      textLayer.appendChild(labelEl);
      textLayer.appendChild(bodyEl);

      // 大臣回执才加操作行（朱批不加）
      if (!isEmperor && dialogIdx !== undefined) {
        const actRow = document.createElement('div');
        actRow.style.cssText = 'display:flex; justify-content:flex-end; gap:8px; padding-top:6px; border-top:1px dashed rgba(100,50,10,0.2); margin-top:4px; position:relative; z-index:2;';

        const btnDel = document.createElement('button');
        btnDel.textContent = '删除';
        btnDel.style.cssText = 'background:transparent; border:none; color:#8b2020; font-size:10px; font-family:inherit; padding:2px 8px; cursor:pointer;';
        btnDel.onclick = async () => {
          // 删掉该条及其后面所有条（保持对话连贯）
          zz._dialog.splice(dialogIdx);
          await saveZouZheWithAuthorMemory(zz, '已批阅');
          // 重新渲染：移除所有对话卡片和输入区，重新追加
          rebuildDialogArea();
        };

        const btnReroll = document.createElement('button');
        btnReroll.textContent = '重新回禀';
        btnReroll.style.cssText = 'background:rgba(201,163,106,0.15); border:none; color:#5e3a11; font-size:10px; font-weight:bold; font-family:inherit; padding:2px 10px; border-radius:4px; cursor:pointer;';
        btnReroll.onclick = async () => {
          btnReroll.textContent = '回禀中…'; btnReroll.disabled = true; btnDel.disabled = true;
          // 用该条之前的对话历史重新生成
          const prevDialog = zz._dialog.slice(0, dialogIdx);
          const history = prevDialog.map(d => `${d.role==='emperor'?'皇帝朱批':'大臣回执'}：${d.text}`).join('\n');
          const rrPrompt = `你是古代大臣「${zz.author}」，正在与皇帝就奏折进行往来。
奏折内容：${zz.content}
往来记录：
${history || '（首次回执）'}

【本轮重新读取的大臣人设与全部记忆】
${buildZouZheAuthorAiContext(zz)}

请以「${zz.author}」口吻，写一段回执/回禀（50字以内，古风文言），回应皇帝最新朱批。只输出正文。`;
          try {
            const res = await api.ai.chat({ messages:[{role:'user',content:rrPrompt}] });
            const newText = (typeof res==='string'?res:(res?.content??res?.text??'')).trim();
            if (newText) {
              // 替换该条，丢弃之后的内容
              zz._dialog.splice(dialogIdx);
              zz._dialog.push({ role:'minister', text: newText });
              await saveZouZheWithAuthorMemory(zz, '已批阅');
              rebuildDialogArea();
            }
          } catch(e) { api.ui.toast('重新回禀失败'); }
          finally { btnReroll.textContent = '重新回禀'; btnReroll.disabled = false; btnDel.disabled = false; }
        };

        actRow.appendChild(btnDel);
        actRow.appendChild(btnReroll);
        textLayer.appendChild(actRow);
      }

      cardWrap.appendChild(textLayer);
      detailOuter.appendChild(cardWrap);
      // 滚到底部
      detailOuter.scrollTop = detailOuter.scrollHeight;
    }

    // 重建对话区：清除所有对话卡片和输入区，重新按 zz._dialog 渲染
    function rebuildDialogArea() {
      // 移除 wrap（原折卡片）之后的所有元素
      const allChildren = Array.from(detailOuter.children);
      const wrapIdx = allChildren.indexOf(wrap);
      for (let i = allChildren.length - 1; i > wrapIdx; i--) {
        detailOuter.removeChild(allChildren[i]);
      }
      // 重新追加对话卡片
      zz._dialog.forEach((d, i) => appendDialogCard(d.role, d.text, i));
      // 重新追加输入区
      detailOuter.appendChild(replyInputWrap);
      detailOuter.scrollTop = detailOuter.scrollHeight;
    }

    // 渲染已有对话记录
    zz._dialog.forEach((d, i) => appendDialogCard(d.role, d.text, i));

    // 初始化：若有旧式回执数据，迁移进 _dialog
    if (zz._dialog.length === 0 && zz.reply) {
      const parts = zz.reply.split('\n\n[大臣回执]：');
      if (parts.length >= 2) {
        zz._dialog.push({ role:'minister', text: parts[1] });
        appendDialogCard('minister', parts[1], 0);
      }
    }

    // 回复输入区（在 detailOuter 底部追加，不在 wrap 内）
    const replyInputWrap = document.createElement('div');
    replyInputWrap.style.cssText = 'width:100%; max-width:420px; display:flex; gap:8px; margin-top:12px; flex-shrink:0; padding-bottom:16px;';

    const replyInput = document.createElement('textarea');
    replyInput.placeholder = '输入朱批，或点 AI 代写…';
    replyInput.style.cssText = 'flex:1; min-height:56px; background:rgba(0,0,0,0.55); border:1px solid rgba(201,163,106,0.4); color:#eaeaea; padding:10px; border-radius:8px; font-family:"STZhongsong","STSong",serif; font-size:13px; resize:none;';

    const btnCol = document.createElement('div');
    btnCol.style.cssText = 'display:flex; flex-direction:column; gap:6px; flex-shrink:0;';

    const btnAi = document.createElement('button');
    btnAi.textContent = 'AI 代写';
    btnAi.style.cssText = 'background:rgba(201,163,106,0.15); border:1px solid var(--primary-color); color:var(--primary-color); padding:6px 12px; border-radius:6px; font-size:12px; font-family:inherit; white-space:nowrap;';

    const btnSend = document.createElement('button');
    btnSend.textContent = '发出朱批';
    btnSend.style.cssText = 'background:var(--primary-color); border:none; color:#000; padding:6px 12px; border-radius:6px; font-size:12px; font-weight:bold; font-family:inherit; white-space:nowrap;';

    btnCol.appendChild(btnAi);
    btnCol.appendChild(btnSend);
    replyInputWrap.appendChild(replyInput);
    replyInputWrap.appendChild(btnCol);
    detailOuter.appendChild(replyInputWrap);

    // AI 代写朱批
    btnAi.onclick = async () => {
      btnAi.textContent = '代写中…'; btnAi.disabled = true;
      const lastMinister = [...zz._dialog].reverse().find(d => d.role === 'minister');
      const prompt = `请为以下奏折往来，以皇帝身份代写一句简短朱批（不超过30字，古风文言）。
奏折主题：${zz.title}
大臣最新言：${lastMinister ? lastMinister.text : zz.content}
只输出朱批正文，不带引号。`;
      try {
        const res = await api.ai.chat({ messages:[{role:'user',content:prompt}] });
        replyInput.value = (typeof res==='string'?res:(res?.content??res?.text??'')).trim();
      } catch(e) { api.ui.toast('代写失败'); }
      finally { btnAi.textContent = 'AI 代写'; btnAi.disabled = false; }
    };

    // 发出朱批 → 追加朱批卡片 → 再生成大臣回执
    btnSend.onclick = async () => {
      const txt = replyInput.value.trim();
      if (!txt) { api.ui.toast('朱批内容不能为空'); return; }
      replyInput.value = '';
      btnSend.textContent = '发出中…'; btnSend.disabled = true;
      btnAi.disabled = true;

      // 追加朱批
      const empIdx = zz._dialog.length;
      zz._dialog.push({ role:'emperor', text: txt });
      appendDialogCard('emperor', txt, empIdx);
      await saveZouZheWithAuthorMemory(zz, '已批阅');

      // 生成大臣回执
      btnSend.textContent = '等待回禀…';
      try {
        const history = zz._dialog.map(d => `${d.role==='emperor'?'皇帝朱批':'大臣回执'}：${d.text}`).join('\n');
        const rrPrompt = `你是古代大臣「${zz.author}」，正在与皇帝就奏折进行往来。
奏折内容：${zz.content}
往来记录：
${history}

【本轮重新读取的大臣人设与全部记忆】
${buildZouZheAuthorAiContext(zz)}

请以「${zz.author}」口吻，写一段回执/回禀（50字以内，古风文言），回应皇帝最新朱批。只输出正文。`;
        const res2 = await api.ai.chat({ messages:[{role:'user',content:rrPrompt}] });
        const rrText = (typeof res2==='string'?res2:(res2?.content??res2?.text??'')).trim();
        if (rrText) {
          const newIdx = zz._dialog.length;
          zz._dialog.push({ role:'minister', text: rrText });
          appendDialogCard('minister', rrText, newIdx);
          await saveZouZheWithAuthorMemory(zz, '已批阅');
        }
      } catch(e) { api.ui.toast('大臣回执生成失败'); }
      finally {
        btnSend.textContent = '发出朱批';
        btnSend.disabled = false;
        btnAi.disabled = false;
      }
    };

    // 原「传召大臣回禀」按钮逻辑：首次点击生成第一条回执
    document.getElementById('zz-btn-summon-reply').onclick = async () => {
      if (zz._dialog.length > 0) {
        // 已有对话，滚到底部
        detailOuter.scrollTop = detailOuter.scrollHeight;
        return;
      }
      const btn = document.getElementById('zz-btn-summon-reply');
      btn.textContent = '传召中…'; btn.disabled = true;
      try {
        const prompt = `你是古代大臣「${zz.author}」。
你上奏了：${zz.content}
皇帝朱批：${zz.reply}
${buildZouZheAuthorAiContext(zz)}
请以「${zz.author}」口吻写一段谢恩/领旨回执（50字以内，古风文言）。只输出正文。`;
        const res = await api.ai.chat({ messages:[{role:'user',content:prompt}] });
        const rrText = (typeof res==='string'?res:(res?.content??res?.text??'')).trim();
        if (rrText) {
          const newIdx = zz._dialog.length;
          zz._dialog.push({ role:'minister', text: rrText });
          appendDialogCard('minister', rrText, newIdx);
          await saveZouZheWithAuthorMemory(zz, '已批阅');
          btn.textContent = '往来记录';
          btn.disabled = false;
        }
      } catch(e) {
        api.ui.toast('回执生成失败');
        btn.textContent = '传召大臣回禀';
        btn.disabled = false;
      }
    };

    // 「传召大臣回禀」按钮文字根据是否已有对话更新
    const summonBtn = document.getElementById('zz-btn-summon-reply');
    if (zz._dialog.length > 0) {
      summonBtn.textContent = '往来记录';
    }
  }
}

function openReplyModal(zz, type) {
  const old = document.getElementById('zz-reply-modal');
  if (old) old.remove();

  const modal = document.createElement('div');
  modal.id = 'zz-reply-modal';
  modal.style.cssText = 'position:fixed; inset:0; z-index:100002; background:rgba(0,0,0,0.85); display:flex; align-items:center; justify-content:center;';

  const wrap = document.createElement('div');
  wrap.style.cssText = 'width:90%; max-width:360px; background:#1a1816; border:1px solid var(--primary-color); border-radius:12px; padding:20px; display:flex; flex-direction:column; gap:12px;';

  let titleText = type === 'qinpi' ? '亲批奏折' : '选择代批人';
  let charOptHtml = '';
  if (type === 'daipi') {
    const chars = [...selectedCharsData, XLY_CHAR];
    charOptHtml = `<select id="daipi-char-sel" style="width:100%; background:rgba(0,0,0,0.5); border:1px solid #666; color:#fff; padding:8px; border-radius:6px; font-size:13px; margin-bottom:10px;">
      ${chars.map(c => `<option value="${c.name}">${c.name}</option>`).join('')}
    </select>`;
  }

  wrap.innerHTML = `
    <div style="color:var(--primary-color); font-size:16px; font-weight:bold; text-align:center;">${titleText}</div>
    ${charOptHtml}
    <textarea id="zz-reply-input" placeholder="输入批示内容，或点击 AI代写..." style="width:100%; height:80px; background:rgba(0,0,0,0.5); border:1px solid #666; color:#ccc; padding:10px; border-radius:8px; resize:vertical; font-size:13px; font-family:inherit;"></textarea>
    <div style="display:flex; gap:10px; margin-top:4px;">
      <button id="zz-reply-ai" style="flex:1; background:rgba(201,163,106,0.15); border:1px solid var(--primary-color); color:var(--primary-color); padding:8px; border-radius:6px; font-size:12px;">✦ AI代写</button>
      <button id="zz-reply-cancel" style="flex:1; background:transparent; border:1px solid #666; color:#aaa; padding:8px; border-radius:6px; font-size:12px;">取消</button>
      <button id="zz-reply-confirm" style="flex:1; background:var(--primary-color); border:none; color:#000; padding:8px; border-radius:6px; font-size:12px; font-weight:bold;">完成批示</button>
    </div>
  `;

  modal.appendChild(wrap);
  document.body.appendChild(modal);

  document.getElementById('zz-reply-cancel').onclick = () => modal.remove();

  document.getElementById('zz-reply-ai').onclick = async () => {
    const btn = document.getElementById('zz-reply-ai');
    btn.innerText = '代写中...'; btn.disabled = true;
    
    let authorName = '皇帝';
    if (type === 'daipi') authorName = document.getElementById('daipi-char-sel').value;

    const sysPrompt = `请为以下奏折代写一行朱批回复。
奏折主题：${zz.title}
奏折内容：${zz.content}
批示人：${authorName}
要求：古文风格，简明扼要，一句话即可（如"准奏"、"荒唐，发回重议"等）。只输出批示内容，不带引号。`;

    try {
      const res = await api.ai.chat({ messages: [{ role: 'user', content: sysPrompt }] });
      const text = typeof res === 'string' ? res : (res?.content ?? res?.text ?? '');
      document.getElementById('zz-reply-input').value = text.trim();
    } catch(e) {
      api.ui.toast("代写失败");
    } finally {
      btn.innerText = '✦ AI代写'; btn.disabled = false;
    }
  };

  document.getElementById('zz-reply-confirm').onclick = async () => {
    let replyText = document.getElementById('zz-reply-input').value.trim();
    if (!replyText) { api.ui.toast("批示内容不能为空"); return; }
    
    if (type === 'daipi') {
      const charName = document.getElementById('daipi-char-sel').value;
      replyText = `（${charName} 代批）${replyText}`;
    }

    zz.reply = replyText;
    zouZheData.pending = zouZheData.pending.filter(z => z.id !== zz.id);
    zouZheData.done.unshift(zz);
    await saveZouZheWithAuthorMemory(zz, '已批阅');
    api.ui.toast("批阅完成，已存档");
    modal.remove();
    document.getElementById('zz-detail-modal')?.remove();
    openDoneZouZheList();
    
    // 提示 user 先去御书房等候大臣回执
    setTimeout(() => {
      api.ui.toast(`${zz.author.split('，')[0].replace(/^臣\s*/,'')} 已领旨，稍候将至御书房回禀`);
    }, 800);

    // 批完后再次调取 API 收到大臣回复（在御书房批奏折面板内显示）
    setTimeout(async () => {
      try {
        // 在批奏折面板内部显示 loading
        const zzModal = document.getElementById('zouzhe-panel-modal');
        let zzLoader = null;
        if (zzModal) {
          zzLoader = document.createElement('div');
          zzLoader.id = 'zz-inner-loader';
          zzLoader.style.cssText = 'position:absolute; inset:0; background:rgba(0,0,0,0.6); backdrop-filter:blur(4px); z-index:200; display:flex; flex-direction:column; align-items:center; justify-content:center; gap:16px;';
          zzLoader.innerHTML = `
            <div style="width:40px;height:40px;border:3px solid rgba(201,163,106,0.3);border-top-color:var(--primary-color);border-radius:50%;animation:spin 1s linear infinite;"></div>
            <div style="color:var(--primary-color);font-size:14px;letter-spacing:2px;text-shadow:0 1px 3px #000;">正在等待大臣回禀…</div>
          `;
          zzModal.appendChild(zzLoader);
        }
        
        const replyToReplyPrompt = `你是古代大臣「${zz.author}」。
你上奏了：${zz.content}
皇帝（或帝师）朱批回复：${zz.reply}

【本轮重新读取的大臣人设与全部记忆】
${buildZouZheAuthorAiContext(zz)}

请以「${zz.author}」的口吻，写一封简短的谢恩/领旨回执（50字以内），古风文言。只输出正文。`;
        const rrRes = await api.ai.chat({ messages: [{ role: 'user', content: replyToReplyPrompt }] });
        const rrText = (typeof rrRes === 'string' ? rrRes : (rrRes?.content ?? rrRes?.text ?? '')).trim();
        
        if (globalLoader) globalLoader.style.display = 'none';
        
        if (zzLoader) zzLoader.remove();
        if (rrText) {
          // 直接存入 _dialog，不弹全屏卷轴
          if (!zz._dialog) zz._dialog = [];
          zz._dialog.push({ role:'minister', text: rrText });
          zz.reply += `\n\n[大臣回执]：${rrText}`;
          await saveZouZheWithAuthorMemory(zz, '已批阅');
          api.ui.toast(`${zz.author.split('，')[0].replace(/^臣\s*/,'')} 已回禀，可进入已批阅查看往来`);
        }
      } catch (e) {
        console.error("生成大臣回执失败", e);
        const el = document.getElementById('zz-inner-loader');
        if (el) el.remove();
      }
    }, 2000);
  };
}

async function startDiShiSession(zz, detailModal) {
  // 查找身份为“帝师”的角色
  const dishiChar = selectedCharsData.find(c => c.ancientRole === '帝师');
  if (!dishiChar) {
    api.ui.toast("当前后宫/群臣中未设置身份为「帝师」的角色");
    return;
  }

  detailModal.remove();

  // 复用室内视图
  const vIndoor = document.getElementById('view-indoor');
  document.getElementById('indoor-bg-layer').style.backgroundImage = `url('${palaceDetails['御书房']?.bgUrl || palaceDetails['养心殿']?.bgUrl || ''}')`;
  
  // 设置立绘
  const displayAvatar = dishiChar.customAvatar || dishiChar.avatar;
  const indoorAvatarImgEl = document.getElementById('indoor-avatar-img');
  indoorAvatarImgEl.src = displayAvatar;
  if (dishiChar.storyAvatarCfg) {
    const cfg = dishiChar.storyAvatarCfg;
    indoorAvatarImgEl.style.transform = `translate(${cfg.x}px, ${cfg.y}px) scale(${cfg.scale / 100})`;
  } else {
    indoorAvatarImgEl.style.transform = 'translate(0px, 0px) scale(1)';
  }
  document.getElementById('indoor-avatar-container').style.display = 'flex';
  
  // 隐藏默认底部按钮，使用专属聊天控件
  document.getElementById('indoor-bottom-bar').style.display = 'none';

  const chatWrap = document.getElementById('indoor-chat-wrap');
  const chatBox = document.getElementById('indoor-chat-box');
  const controls = document.getElementById('indoor-chat-controls');
  const blocker = document.getElementById('indoor-blocker');

  chatWrap.style.display = 'flex';
  chatBox.innerHTML = `<span style="color:var(--primary-color);">传旨，宣 ${dishiChar.name} 进殿议事...</span>`;
  chatBox.style.opacity = '1';
  chatWrap.style.opacity = '1';
  blocker.style.display = 'block';

  window.currentIndoorChar = dishiChar;
  indoorChatContext.history = [];
  indoorChatContext.mode = 'dishi_zouzhe';
  indoorChatContext.zz = zz; // 保存当前讨论的奏折

  switchView(vIndoor);

  // 覆盖退出按钮
  const origBack = document.getElementById('btn-exit-indoor').onclick;
  const exitHandler = () => {
    chatWrap.style.display = 'none';
    chatBox.innerHTML = '';
    blocker.style.display = 'none';
    controls.style.display = 'none';
    document.getElementById('indoor-avatar-container').style.display = 'flex';
    document.getElementById('indoor-bottom-bar').style.display = 'flex';
    document.getElementById('indoor-bottom-bar').style.opacity = '1';
    // 恢复可能被修改的退出按钮（比如变成"就这个方案"）
    const exitBtn = document.getElementById('btn-inchat-exit');
    exitBtn.textContent = '离去';
    exitBtn.style.background = 'rgba(139,32,32,0.2)';
    exitBtn.style.color = '#ff9999';
    exitBtn.style.borderColor = '#8b2020';
    exitBtn.onclick = null; // 依赖重新绑定
    
    document.getElementById('btn-exit-indoor').onclick = origBack;
    switchView(vPalaceDetail);
  };
  document.getElementById('btn-exit-indoor').onclick = exitHandler;

  // 专属离去按钮处理
  const exitBtn = document.getElementById('btn-inchat-exit');
  exitBtn.textContent = '结束商议';
  exitBtn.onclick = exitHandler;

  const timeStr = hudTime ? hudTime.innerText : '未知时辰';
  const sysPrompt = `你是一个古代后宫文字互动引擎。当前游戏时间：${timeStr}。
【本次场景：御书房·与帝师商议奏折】
皇帝（User）传召帝师「${dishiChar.name}」进殿，商议以下奏折：
标题：${zz.title}
内容：${zz.content}

【本轮重新读取的全局设定】
${buildGlobalAiContext()}

【本轮重新读取的帝师人设、人物世界书与全部记忆】
${buildCharacterAiContext(dishiChar)}

请描写帝师进殿、行礼，并就这份奏折给出一个初步的分析或建议的第一幕互动。
要求：
1. 【称谓铁律】用"你"指代皇帝，用"${dishiChar.name}"指代角色。
2. 不可替皇帝说话。
3. 对话用 <p data-speaker="${dishiChar.name}">"说的话"</p> 格式。
4. 每段 <p> 不超过50字。

${getAiParagraphFormatGuard()}`;

  try {
    const res = await api.ai.chat({ messages: [{ role: 'user', content: sysPrompt }] });
    const text = typeof res === 'string' ? res : (res?.content ?? res?.text ?? '');
    playIndoorChat(text);
  } catch(e) {
    chatBox.innerHTML = '<span style="color:#d9534f;">推演失败，请重试。</span>';
    blocker.style.display = 'none';
  }
}

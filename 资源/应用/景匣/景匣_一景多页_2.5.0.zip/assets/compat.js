(function () {
  "use strict";
  // This file intentionally stays ES5 so a parser error in app.js is visible.
  function report(error, stage) {
    var box = document.getElementById("appError");
    var copy = document.getElementById("appErrorText");
    if (!box || !copy) return;
    var detail = error && error.message ? error.message : String(error || "未知错误");
    copy.textContent = "景匣 2.4.1 · " + (stage || "界面操作") + "：" + detail.slice(0, 220);
    box.classList.remove("is-hidden");
  }
  window.JingxiaReportError = report;
  window.addEventListener("error", function (event) {
    // Resource failures (such as a remote avatar) are not fatal app errors.
    if (event.target === window && event.message) report(event.error || event.message, "页面脚本");
  });
  window.addEventListener("unhandledrejection", function (event) {
    report(event.reason, "操作未完成");
  });
  if (!Element.prototype.replaceChildren) {
    Element.prototype.replaceChildren = function () {
      while (this.firstChild) this.removeChild(this.firstChild);
      for (var i = 0; i < arguments.length; i++) {
        var item = arguments[i];
        this.appendChild(item && typeof item === "object" && item.nodeType ? item : document.createTextNode(String(item)));
      }
    };
  }
  function viewport() {
    var height = window.visualViewport ? window.visualViewport.height : window.innerHeight;
    if (height > 0) document.documentElement.style.setProperty("--jx-vh", height + "px");
  }
  viewport();
  window.addEventListener("resize", viewport);
  if (window.visualViewport) window.visualViewport.addEventListener("resize", viewport);
  document.getElementById("dismissAppError").addEventListener("click", function () {
    document.getElementById("appError").classList.add("is-hidden");
  });
  document.getElementById("retryAppError").addEventListener("click", function () {
    if (window.confirm("重新打开景匣？未保存的输入会清除，已保存的作品不受影响。")) window.location.reload();
  });
})();

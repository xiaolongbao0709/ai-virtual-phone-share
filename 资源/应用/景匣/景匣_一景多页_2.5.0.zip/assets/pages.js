(function (root) {
  "use strict";
  var MAX_PAGES = 24, MAX_SIZE = 1200000;
  function resolve(href, from) {
    var raw = String(href == null ? "" : href).trim();
    if (/^[a-z][a-z0-9+.-]*:/i.test(raw) || /^\/\//.test(raw) || /[\\\u0000-\u0020]/.test(raw)) throw new Error("仅支持这个网页内的相对 HTML 路径");
    var hashAt = raw.indexOf("#"), hash = hashAt < 0 ? "" : raw.slice(hashAt);
    raw = hashAt < 0 ? raw : raw.slice(0, hashAt);
    var queryAt = raw.indexOf("?"), query = queryAt < 0 ? "" : raw.slice(queryAt);
    raw = queryAt < 0 ? raw : raw.slice(0, queryAt);
    var base = String(from || "index.html").split(/[?#]/)[0];
    if (!raw) return { path: base, query: query, hash: hash, href: base + query + hash };
    var absolute = raw.charAt(0) === "/";
    try { raw = decodeURIComponent(raw); } catch (_) { throw new Error("页面路径编码无效"); }
    if (/[\\%?#:\u0000-\u0020]/.test(raw) || raw.indexOf("//") >= 0) throw new Error("页面路径不能包含协议、空格或特殊分隔符");
    var parts = absolute ? [] : base.split("/").slice(0, -1);
    raw.split("/").forEach(function (part) {
      if (!part || part === ".") return;
      if (part === "..") { if (!parts.length) throw new Error("链接不能离开当前网页"); parts.pop(); }
      else parts.push(part);
    });
    var path = parts.join("/");
    if (!/\.html?$/i.test(path) || path.length > 180) throw new Error("页面请使用 .html 或 .htm 文件名");
    return { path: path, query: query, hash: hash, href: path + query + hash };
  }
  function filePath(value) {
    var route = resolve(value, "index.html");
    if (!String(value || "").trim() || route.query || route.hash) throw new Error("文件名不能带查询参数或锚点");
    return route.path;
  }
  function normalize(pages, entryPath) {
    if (!Array.isArray(pages) || !pages.length || pages.length > MAX_PAGES) throw new Error("一个网页需要 1–24 个 HTML 页面");
    var seen = Object.create(null), size = 0;
    var clean = pages.map(function (page) {
      if (!page || typeof page !== "object") throw new Error("页面格式应为 path、title、html");
      var path = filePath(page.path), html = String(page.html || "").trim().replace(/^```(?:html)?\s*([\s\S]*?)\s*```$/i, "$1");
      if (seen[path]) throw new Error("页面路径重复：" + path);
      seen[path] = true;
      if (!/<[a-z][\s\S]*>/i.test(html)) throw new Error(path + " 没有可显示的 HTML");
      size += html.length;
      return {path: path, title: String(page.title || path).replace(/\s+/g, " ").trim().slice(0, 80), html: html};
    });
    if (size > MAX_SIZE) throw new Error("网页源码合计请控制在 120 万字符以内");
    var entry = filePath(entryPath || (seen["index.html"] ? "index.html" : clean[0].path));
    if (!seen[entry]) throw new Error("找不到指定首页：" + entry);
    return {pages: clean, entryPath: entry, html: clean.filter(function (p) { return p.path === entry; })[0].html};
  }
  function content(args, previous) {
    args = args || {}; previous = previous || {};
    var existing = Array.isArray(previous.pages) && previous.pages.length ? previous.pages : null;
    if (!existing && args.pages === undefined) return {html: String(args.html || "").trim().replace(/^```(?:html)?\s*([\s\S]*?)\s*```$/i, "$1")};
    if (args.pages !== undefined && (!Array.isArray(args.pages) || !args.pages.length)) throw new Error("pages 必须是非空页面数组");
    var pages = existing ? existing.map(function (p) { return {path:p.path,title:p.title,html:p.html}; }) : [];
    (args.pages || []).forEach(function (p) {
      var path = filePath(p.path), index = pages.findIndex(function (old) { return old.path === path; });
      if (index < 0) pages.push(p); else pages[index] = p;
    });
    if (args.pages === undefined && existing && args.html) {
      pages = pages.map(function (p) { return p.path === previous.entryPath ? {path:p.path,title:p.title,html:args.html} : p; });
    }
    return normalize(pages, args.entryPath || previous.entryPath);
  }
  // Runs INSIDE the opaque preview. No access to AiPhone, app storage or other works.
  function bridge(config) {
    var api = window.JingXia = window.JingXia || {}, values = config.values || {};
    window.__jingxiaPageToken = config.token;
    function send(action, extra) { parent.postMessage({source:"jingxia:pages", token:config.token, action:action, value:extra}, "*"); }
    api.open = function (path) { send("open", String(path)); };
    api.back = function () { send("back"); };
    api.home = function () { send("home"); };
    api.emit = function (payload) { send("trace", payload || {}); };
    api.page = {path:config.path, search:config.query, hash:config.hash};
    api.state = {
      get:function (key) { return Object.prototype.hasOwnProperty.call(values, key) ? values[key] : null; },
      set:function (key, value) {
        if (["__proto__","constructor","prototype"].indexOf(String(key)) >= 0) return;
        var next = JSON.parse(JSON.stringify(values)); next[String(key)] = value;
        if (JSON.stringify(next).length > 32000) throw new Error("网页临时状态超过 32 KB");
        values = next; send("state", values);
      }
    };
    document.addEventListener("click", function (event) {
      var node = event.target && event.target.closest ? event.target.closest("[data-jingxia-page],a[href]") : null;
      if (!node || event.defaultPrevented) return;
      var href = node.getAttribute("data-jingxia-page") || node.getAttribute("href");
      if (!href) return;
      if (href.charAt(0) === "#") {
        event.preventDefault();
        try {
          var target = document.getElementById(decodeURIComponent(href.slice(1)));
          if (target) target.scrollIntoView(); else if (href === "#") window.scrollTo(0, 0);
          api.page.hash = href;
        } catch (_) {}
        return;
      }
      event.preventDefault(); api.open(href);
    });
    document.addEventListener("submit", function (event) {
      var form = event.target, action = form && form.getAttribute("action");
      if (!form || event.defaultPrevented) return;
      action = action || "/" + config.path;
      event.preventDefault();
      if (String(form.method).toLowerCase() !== "get") { send("notice", "跨页表单请使用 GET；互动结果也可以通过 JingXia.state.set 保存"); return; }
      var params = new URLSearchParams();
      new FormData(form).forEach(function (value, key) { if (typeof value === "string") params.append(key, value); });
      var parts = action.split("#");
      api.open(parts[0] + (parts[0].indexOf("?") >= 0 ? "&" : "?") + params.toString() + (parts[1] ? "#" + parts.slice(1).join("#") : ""));
    });
    if (config.hash) document.addEventListener("DOMContentLoaded", function () {
      try { var el = document.getElementById(decodeURIComponent(config.hash.slice(1))); if (el) el.scrollIntoView(); } catch (_) {}
    });
  }
  function prependScript(html, script) {
    var source = String(html);
    if (/<head(?:\s[^>]*)?>/i.test(source)) return source.replace(/<head(?:\s[^>]*)?>/i, function (tag) { return tag + script; });
    if (/<html(?:\s[^>]*)?>/i.test(source)) return source.replace(/<html(?:\s[^>]*)?>/i, function (tag) { return tag + "<head>" + script + "</head>"; });
    return script + source;
  }
  function inject(html, config) {
    var json = JSON.stringify(config).replace(/</g, "\\u003c").replace(/\u2028/g, "\\u2028").replace(/\u2029/g, "\\u2029");
    return prependScript(html, "<script>(" + bridge.toString() + ")(" + json + ");<\/script>");
  }
  root.JingxiaPages = {resolve:resolve,filePath:filePath,normalize:normalize,content:content,inject:inject,prependScript:prependScript};
})(typeof window === "undefined" ? globalThis : window);
